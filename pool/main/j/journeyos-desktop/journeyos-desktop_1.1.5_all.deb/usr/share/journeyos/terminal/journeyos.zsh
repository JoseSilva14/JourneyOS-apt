# JourneyOS zsh setup: history, completion, plugins, the JourneyOS prompt and fastfetch when a
# terminal opens. Loaded from ~/.zshrc (the default one in /etc/skel). Settings for it go before
# the "source" line in ~/.zshrc:
#   JOURNEYOS_FASTFETCH=0    no fastfetch when a terminal opens
#   JOURNEYOS_PROMPT=0       keep your own PROMPT
[[ -o interactive ]] || return

# --- Commands installed per user (Claude Code, pipx, cargo, go install…) ---
typeset -U path
for _jos_dir in $HOME/.local/bin $HOME/.cargo/bin $HOME/go/bin; do
    [[ -d $_jos_dir ]] && path=($_jos_dir $path)
done
unset _jos_dir

# --- History ---
HISTFILE=${HISTFILE:-$HOME/.zsh_history}
HISTSIZE=20000
SAVEHIST=20000
setopt HIST_IGNORE_ALL_DUPS HIST_IGNORE_SPACE HIST_REDUCE_BLANKS SHARE_HISTORY
setopt AUTO_CD INTERACTIVE_COMMENTS NO_BEEP

# --- Completion ---
_jos_cache=${XDG_CACHE_HOME:-$HOME/.cache}/zsh
[[ -d $_jos_cache ]] || mkdir -p "$_jos_cache"
autoload -Uz compinit && compinit -d "$_jos_cache/zcompdump"
zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}' 'r:|[._-]=* r:|=*'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' group-name ''
zstyle ':completion:*:descriptions' format '%F{8}%d%f'
unset _jos_cache

# --- Keys (emacs style, plus Home/End/Delete and Ctrl+arrows) ---
bindkey -e
bindkey '^[[H' beginning-of-line '^[[F' end-of-line '^[[3~' delete-char
bindkey '^[[1;5C' forward-word '^[[1;5D' backward-word '^H' backward-kill-word
autoload -Uz up-line-or-beginning-search down-line-or-beginning-search
zle -N up-line-or-beginning-search
zle -N down-line-or-beginning-search
bindkey '^[[A' up-line-or-beginning-search '^[[B' down-line-or-beginning-search

# --- Colours for ls/grep ---
command -v dircolors >/dev/null && eval "$(dircolors -b)"
alias ls='ls --color=auto' ll='ls -lh --color=auto' la='ls -lAh --color=auto' grep='grep --color=auto'

# --- Prompt: the JourneyOS logo, the folder and the git branch (monochrome, like the shell) ---
# The logo is a glyph of the "JourneyOS Symbols" font (U+F0000), used as a fallback by the terminal.
if [[ ${JOURNEYOS_PROMPT:-1} != 0 ]]; then
    autoload -Uz vcs_info add-zsh-hook
    zstyle ':vcs_info:*' enable git
    zstyle ':vcs_info:git:*' formats ' %F{8}%b%f'
    zstyle ':vcs_info:git:*' actionformats ' %F{8}%b|%a%f'
    add-zsh-hook precmd vcs_info
    setopt PROMPT_SUBST
    JOURNEYOS_GLYPH=$'\U000F0000'
    PROMPT='${JOURNEYOS_GLYPH}  %B%~%b${vcs_info_msg_0_} %(?.%F{default}.%F{red})❯%f '
    # A blank line between commands (not before the first prompt)
    _jos_spacing() { [[ -n $_jos_first ]] && print; _jos_first=1; }
    add-zsh-hook precmd _jos_spacing
fi

# --- Plugins: suggestions from history (→ accepts) and syntax colours ---
if [[ -r /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh ]]; then
    ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=8'
    ZSH_AUTOSUGGEST_STRATEGY=(history completion)
    source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
fi
if [[ -r /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]]; then
    source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
fi

# --- Long commands: a notification when one ends while you're in another window ---
# Commands of 10 s or more are reported to the shell, which decides (Settings → Development: on/off and
# how long counts as long) and checks whether this terminal is the active window. JOURNEYOS_NOTIFY=0 = never.
if [[ ${JOURNEYOS_NOTIFY:-1} != 0 && -n $WAYLAND_DISPLAY ]] && (( $+commands[qs] )); then
    zmodload zsh/datetime
    autoload -Uz add-zsh-hook
    _jos_cmd_start() { _jos_cmd=$1; _jos_cmd_t=$EPOCHSECONDS; }
    _jos_cmd_done() {
        local code=$? t=$_jos_cmd_t cmd=$_jos_cmd
        unset _jos_cmd_t _jos_cmd
        [[ -n $t ]] && (( EPOCHSECONDS - t >= 10 )) || return 0
        # Programs that stay open by nature (editors, pagers, remote shells, REPLs)
        case ${${(z)cmd}[1]:t} in
            (vi|vim|nvim|nano|micro|hx|emacs|less|more|man|ssh|mosh|htop|btop|top|tmux|screen|watch|fg|claude|python|python3|ipython|node|psql|mysql|sqlite3|bash|zsh|sh|journalctl|docker-compose) return 0 ;;
        esac
        [[ $cmd == (docker|podman)\ (exec|attach|run\ -it|logs\ -f)* || $cmd == *" -f" && $cmd == (tail|kubectl)* ]] && return 0
        # This shell and its parents: the terminal window is one of them
        local pids=$$ p=$$
        while [[ -r /proc/$p/status ]]; do
            p=${${(M)${(f)"$(</proc/$p/status)"}:#PPid:*}//[^0-9]/}
            [[ -n $p && $p -gt 1 ]] || break
            pids+=" $p"
        done
        local dir=${$(qs list --all 2>/dev/null)[(r)*shell.qml]}
        [[ -n $dir ]] || return 0
        qs -p ${dir:h} ipc call terminal finished "$cmd" $code $(( EPOCHSECONDS - t )) "$pids" &>/dev/null &!
        return 0
    }
    add-zsh-hook preexec _jos_cmd_start
    # First of the precmd hooks: it needs the command's exit code
    precmd_functions=(_jos_cmd_done ${precmd_functions:#_jos_cmd_done})
fi

# --- fastfetch when a terminal opens (not in nested shells, scripts or IDE terminals) ---
if [[ ${JOURNEYOS_FASTFETCH:-1} != 0 && $SHLVL -le 1 && -t 1 && $TERM_PROGRAM != vscode ]] \
        && command -v fastfetch >/dev/null; then
    if [[ -r ${XDG_CONFIG_HOME:-$HOME/.config}/fastfetch/config.jsonc ]]; then
        fastfetch                      # the user's own fastfetch setup
    else
        # Terminals that show images (kitty graphics protocol: Konsole, kitty, WezTerm, Ghostty; not
        # inside tmux) get the real logo, in the colour of the shell's theme (theme.conf "logo=");
        # the others, the ASCII one
        _jos_logo=()
        if [[ -z $TMUX && ( -n $KONSOLE_VERSION || -n $KITTY_WINDOW_ID || $TERM_PROGRAM == WezTerm || $TERM == xterm-ghostty ) ]]; then
            _jos_img=""
            [[ -r $HOME/.local/state/shadow-kde/theme.conf ]] \
                && _jos_img=${${(M)${(f)"$(<$HOME/.local/state/shadow-kde/theme.conf)"}:#logo=*}#logo=}
            [[ -r $_jos_img ]] || _jos_img=/usr/share/journeyos/shell/assets/logos/journeyos.png
            [[ -r $_jos_img ]] && _jos_logo=(--logo "$_jos_img" --logo-type kitty --logo-width 24 --logo-height 12)
        fi
        fastfetch --config /usr/share/journeyos/terminal/fastfetch.jsonc $_jos_logo
        unset _jos_logo _jos_img
    fi
fi
