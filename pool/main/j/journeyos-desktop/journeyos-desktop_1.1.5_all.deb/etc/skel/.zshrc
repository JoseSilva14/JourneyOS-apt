# ~/.zshrc - JourneyOS
# The system's zsh setup: history, completion, suggestions, syntax colours, the JourneyOS
# prompt and fastfetch when a terminal opens. Options for it go before the "source" line:
#   JOURNEYOS_FASTFETCH=0    no fastfetch when a terminal opens
#   JOURNEYOS_PROMPT=0       keep your own PROMPT
source /usr/share/journeyos/terminal/journeyos.zsh

# Your own settings below
