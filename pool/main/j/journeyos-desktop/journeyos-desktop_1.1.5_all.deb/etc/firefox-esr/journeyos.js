// JourneyOS defaults for Firefox (users can change them in about:config / Settings)
// Window decorations from the system (KWin, the shell's look) instead of Firefox's own title bar
pref("browser.tabs.inTitlebar", 0);
// No welcome/what's-new pages on first start
pref("browser.aboutwelcome.enabled", false);
pref("browser.startup.homepage_override.mstone", "ignore");
pref("startup.homepage_welcome_url", "");
pref("startup.homepage_welcome_url.additional", "");
pref("datareporting.policy.dataSubmissionPolicyBypassNotification", true);
// Cleaner new tab
pref("browser.newtabpage.activity-stream.showSponsored", false);
pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false);
// Overlay scrollbars like the shell's
pref("widget.gtk.overlay-scrollbars.enabled", true);
