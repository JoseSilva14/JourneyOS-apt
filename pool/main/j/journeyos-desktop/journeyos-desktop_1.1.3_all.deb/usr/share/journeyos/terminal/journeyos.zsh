# JourneyOS zsh setup: history, completion, plugins, the JourneyOS prompt and fastfetch when a
# terminal opens. Loaded from ~/.zshrc (the default one in /etc/skel). Settings for it go before
# the "source" line in ~/.zshrc:
#   JOURNEYOS_FASTFETCH=0    no fastfetch when a terminal opens
#   JOURNEYOS_PROMPT=0       keep your own PROMPT
[[ -o interactive ]] || return

# --- History ---
HISTFILE=${HISTFILE:-$HOME/.zsh_history}
HISTSIZE=20000
SAVEHIST=20000
setopt HIST_IGNORE_ALL_DUPS HIST_IGNORE_SPACE HIST_REDUCE_BLANKS SHARE_HISTORY
setopt AUTO_CD INTERACTIVE_COMMENTS NO_BEEP

# --- Completion ---
_jos_cache=${XDG_CACHE_HOME:-$HOME/.cache}/zsh
[[ -d $_jos_cache ]] || mkdir -p "$_jos_cache"
autoload -Uz compinit && compinit -d "$_jos_cache/zcompdump"
zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}' 'r:|[._-]=* r:|=*'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' group-name ''
zstyle ':completion:*:descriptions' format '%F{8}%d%f'
unset _jos_cache

# --- Keys (emacs style, plus Home/End/Delete and Ctrl+arrows) ---
bindkey -e
bindkey '^[[H' beginning-of-line '^[[F' end-of-line '^[[3~' delete-char
bindkey '^[[1;5C' forward-word '^[[1;5D' backward-word '^H' backward-kill-word
autoload -Uz up-line-or-beginning-search down-line-or-beginning-search
zle -N up-line-or-beginning-search
zle -N down-line-or-beginning-search
bindkey '^[[A' up-line-or-beginning-search '^[[B' down-line-or-beginning-search

# --- Colours for ls/grep ---
command -v dircolors >/dev/null && eval "$(dircolors -b)"
alias ls='ls --color=auto' ll='ls -lh --color=auto' la='ls -lAh --color=auto' grep='grep --color=auto'

# --- Prompt: the JourneyOS logo, the folder and the git branch (monochrome, like the shell) ---
# The logo is a glyph of the "JourneyOS Symbols" font (U+F0000), used as a fallback by the terminal.
if [[ ${JOURNEYOS_PROMPT:-1} != 0 ]]; then
    autoload -Uz vcs_info add-zsh-hook
    zstyle ':vcs_info:*' enable git
    zstyle ':vcs_info:git:*' formats ' %F{8}%b%f'
    zstyle ':vcs_info:git:*' actionformats ' %F{8}%b|%a%f'
    add-zsh-hook precmd vcs_info
    setopt PROMPT_SUBST
    JOURNEYOS_GLYPH=$'\U000F0000'
    PROMPT='${JOURNEYOS_GLYPH}  %B%~%b${vcs_info_msg_0_} %(?.%F{default}.%F{red})❯%f '
    # A blank line between commands (not before the first prompt)
    _jos_spacing() { [[ -n $_jos_first ]] && print; _jos_first=1; }
    add-zsh-hook precmd _jos_spacing
fi

# --- Plugins: suggestions from history (→ accepts) and syntax colours ---
if [[ -r /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh ]]; then
    ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=8'
    ZSH_AUTOSUGGEST_STRATEGY=(history completion)
    source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
fi
if [[ -r /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]]; then
    source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
fi

# --- fastfetch when a terminal opens (not in nested shells, scripts or IDE terminals) ---
if [[ ${JOURNEYOS_FASTFETCH:-1} != 0 && $SHLVL -le 1 && -t 1 && $TERM_PROGRAM != vscode ]] \
        && command -v fastfetch >/dev/null; then
    if [[ -r ${XDG_CONFIG_HOME:-$HOME/.config}/fastfetch/config.jsonc ]]; then
        fastfetch                      # the user's own fastfetch setup
    else
        fastfetch --config /usr/share/journeyos/terminal/fastfetch.jsonc
    fi
fi
