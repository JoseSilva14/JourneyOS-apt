import QtQuick
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// JourneyOS logo in white: opens the app launcher.
BarButton {
    id: root

    color: Launcher.open || hovered ? Theme.button : "transparent"
    onClicked: Launcher.toggle(QsWindow.window?.screen ?? null)

    implicitWidth: implicitHeight + 4

    IconImage {
        anchors.centerIn: parent
        implicitSize: Theme.barIcon
        source: Theme.logo
        opacity: root.hovered ? 1 : 0.9
    }
}
