pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Shell language. Texts are written in English in the code and go through Tr.t("…"): in
// Portuguese they come from i18n/pt.json (English → Portuguese); anything missing there stays in
// English. config.json language: "auto" (the system's: pt* → Portuguese, anything else → English)
// | "pt" | "en". Changes immediately, no restart.
//
// Context: a key may end in "##something" to tell apart the same English text that translates
// differently ("Off" → "Desligado", "Off##f" → "Desligada"); the suffix is never shown.
// Texts with variable parts are translated piece by piece ("In " + n + " min").
Singleton {
    id: root

    readonly property string setting: Config.options.language ?? "auto"
    readonly property string system: Qt.locale().name
    readonly property string lang: setting === "auto" ? (system.startsWith("pt") ? "pt" : "en") : setting
    readonly property bool en: lang === "en"
    readonly property bool pt: lang === "pt"
    // For numbers and dates (toLocaleString, Qt.formatDate…)
    readonly property var locale: Qt.locale(pt ? "pt_PT" : "en_GB")

    property var dict: ({})

    function strip(s) {
        const i = s.indexOf("##");
        return i < 0 ? s : s.slice(0, i);
    }

    function t(s) {
        if (s === undefined || s === null)
            return s;
        s = String(s);
        if (pt) {
            const v = dict[s];
            if (v !== undefined)
                return v;
        }
        return strip(s);
    }

    FileView {
        path: Quickshell.shellPath("i18n/pt.json")
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                root.dict = JSON.parse(text());
            } catch (e) {
                console.warn("i18n/pt.json:", e);
            }
        }
    }

    IpcHandler {
        target: "lang"
        function set(value: string): void { Config.options.language = value; }
        function get(): string { return root.lang + " (" + root.setting + ")"; }
        // For testing: what a text becomes in the current language
        function t(s: string): string { return root.t(s); }
    }
}
