#!/bin/sh
# Installs shadow-kde for the current user (no sudo), from this folder.
#   install.sh             installs (or updates: it can be run again)
#   install.sh --simular   only shows what it would do (dry run)
#
# What it does:
#   1. checks for missing programs and says which packages to install (installs nothing itself)
#   2. saves the current KDE choices in ~/.local/state/shadow-kde/antes.conf (only the first
#      time), so scripts/uninstall.sh can restore them
#   3. user services (shell + watchdog) pointing at this folder, and disables
#      plasmashell (mask): the shell provides the bar, notifications, clipboard…
#   4. lock screen, window decoration, Alt+Tab and session splash screen
#   5. starts the shell
# The login screen (SDDM) needs root: the command is shown at the end.
set -e
dir=$(readlink -f "$(dirname "$(readlink -f "$0")")/..")
state="$HOME/.local/state/shadow-kde"
units="$HOME/.config/systemd/user"
before="$state/antes.conf"
sim=""
[ "$1" = "--simular" ] && sim=1

say() { printf '\033[1m›\033[0m %s\n' "$*"; }
# Runs a command (or only shows it, in a dry run)
run() {
    if [ -n "$sim" ]; then
        printf '    %s\n' "$*"
    else
        "$@"
    fi
}

# --- 1. Dependencies ---
say "Checking programs"
missing=""
optional=""
need() {  # command package [optional]
    command -v "$1" >/dev/null 2>&1 && return 0
    if [ -n "$3" ]; then optional="$optional $2"; else missing="$missing $2"; fi
}
need qs quickshell
need python3 python3
need kwriteconfig6 libkf6config-bin
need gdbus libglib2.0-bin
need busctl systemd
need wl-copy wl-clipboard
need magick imagemagick
need spectacle kde-spectacle
need pw-play pipewire-bin
need nmcli network-manager
need eglinfo mesa-utils-bin
need rsync rsync
need curl curl
need kdialog kdialog opcional
need cava cava opcional
need qrencode qrencode opcional
need powerprofilesctl power-profiles-daemon opcional
python3 -c "import gi; gi.require_version('Gio', '2.0')" 2>/dev/null || missing="$missing python3-gi"

if [ -n "$missing" ]; then
    echo "Required packages are missing. Install them and run again:"
    echo "    sudo apt install$missing"
    echo "(quickshell comes from the Debian 13 backports: sudo apt install -t trixie-backports quickshell)"
    [ -n "$sim" ] || exit 1
fi
[ -n "$optional" ] && echo "    Optional (dialogs, music visualiser, sharing QR code, power profiles):$optional"

if systemctl --user is-active -q quickshell.service 2>/dev/null; then
    echo "Warning: another Quickshell shell is running (quickshell.service). Stop it first:"
    echo "    systemctl --user disable --now quickshell.service"
    [ -n "$sim" ] || exit 1
fi

# --- 2. What was there before ---
# A value that already belongs to this shell (installed by hand before this script) counts as "nothing chosen"
read_kde() {
    v=$(kreadconfig6 --file "$1" --group "$2" --key "$3" 2>/dev/null || true)
    case "$v" in *shadowkde*|*ShadowKDE*|"Shadow KDE"*) v="" ;; esac
    echo "$v"
}
plasmashell_state() {
    if systemctl --user is-enabled -q shadow-kde.service 2>/dev/null; then
        echo enabled   # disabled by this shell
    else
        systemctl --user is-enabled plasma-plasmashell.service 2>/dev/null || true
    fi
}
if [ ! -f "$before" ]; then
    say "Saving the current KDE choices ($before)"
    if [ -z "$sim" ]; then
        mkdir -p "$state"
        {
            echo "# KDE choices before shadow-kde (restored by scripts/uninstall.sh)"
            # Engine and theme go together: with this shell's theme, neither counts
            deco_theme=$(read_kde kwinrc org.kde.kdecoration2 theme)
            deco_lib=""
            [ -n "$deco_theme" ] && deco_lib=$(read_kde kwinrc org.kde.kdecoration2 library)
            echo "decoration_library=$deco_lib"
            echo "decoration_theme=$deco_theme"
            echo "tabbox=$(read_kde kwinrc TabBox LayoutName)"
            echo "tabbox_alt=$(read_kde kwinrc TabBoxAlternative LayoutName)"
            echo "splash_engine=$(read_kde ksplashrc KSplash Engine)"
            echo "splash_theme=$(read_kde ksplashrc KSplash Theme)"
            echo "shell_package=$(read_kde plasmashellrc Shell ShellPackage)"
            echo "color_scheme=$(read_kde kdeglobals General ColorScheme)"
            echo "konsole_profile=$(read_kde konsolerc 'Desktop Entry' DefaultProfile)"
            echo "plasmashell=$(plasmashell_state)"
        } > "$before.tmp"
        mv "$before.tmp" "$before"
    fi
else
    say "Previous KDE choices already saved (from an earlier install)"
fi

# --- 3. Services ---
say "Installing the user services"
run chmod +x "$dir"/scripts/*.sh "$dir"/scripts/*.py
run mkdir -p "$units"
for unit in shadow-kde.service shadow-kde-watchdog.service shadow-kde-watchdog.timer; do
    # A real file (not a link): this folder's path replaces the repository's
    if [ -n "$sim" ]; then
        printf '    %s → %s\n' "systemd/$unit" "$units/$unit"
    else
        sed "s|%h/Projetos/shadow-kde|$dir|g" "$dir/systemd/$unit" > "$units/$unit.tmp"
        rm -f "$units/$unit"
        mv "$units/$unit.tmp" "$units/$unit"
    fi
done
run systemctl --user daemon-reload
run systemctl --user enable shadow-kde.service shadow-kde-watchdog.timer

say "Disabling plasmashell (the shell replaces it)"
run systemctl --user stop plasma-plasmashell.service
run systemctl --user mask plasma-plasmashell.service

# --- 4. KDE parts with the shell's look ---
say "Lock screen"
run mkdir -p "$HOME/.local/share/plasma/shells"
run ln -sfn "$dir/lockscreen" "$HOME/.local/share/plasma/shells/org.shadowkde.desktop"
run kwriteconfig6 --file plasmashellrc --group Shell --key ShellPackage org.shadowkde.desktop

say "Window decoration"
run "$dir/scripts/decoration.sh" apply
say "Alt+Tab"
run "$dir/scripts/switcher.sh" apply
say "Session splash screen"
run "$dir/scripts/splash.sh" apply
say "No KDE notices over the shell (donations, Welcome Center)"
run "$dir/scripts/kde-quiet.sh" apply
say "Dolphin menu (share on the local network)"
run "$dir/scripts/servicemenu.sh" apply

# --- 5. Start ---
say "Starting the shell"
run systemctl --user start shadow-kde.service shadow-kde-watchdog.timer

echo
echo "Done. Only the login screen is left (asks for the administrator password):"
echo "    sudo $dir/scripts/sddm.sh instalar"
echo "To remove everything and go back to KDE: $dir/scripts/uninstall.sh"
