pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// The shell's calculator (replaces KCalc): the expression, the live result, scientific mode and the history
// (~/.local/state/shadow-kde/calculator.json, the last 50 calculations). Calculations use the same engine as the
// launcher (Launcher.calculate) and the conversions from Convert ("5 km em milhas" = "5 km in miles").
Singleton {
    id: root

    property bool open: false
    property string expr: ""
    property bool scientific: false
    property bool showHistory: true
    property var history: []          // [{ expr, result, at }], most recent first
    // After "=": the next number starts a new calculation, an operator continues from the result
    property bool justEvaluated: false
    property string error: ""

    readonly property int maxHistory: 50
    // Decimal separator of the shell language ("," in Portuguese, "." in English)
    readonly property string dec: Tr.locale.decimalPoint

    function toggle() {
        open = !open;
    }

    // What is shown (× ÷ −) → what the engine understands
    function toEngine(s) {
        return s.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/√/g, "sqrt")
            .replace(/π/g, "pi").replace(/%/g, "/100").replace(/\s+/g, "");
    }

    // The expression's result (null if it is not a valid calculation yet)
    function evaluate(s) {
        const t = s.trim();
        if (!t)
            return null;
        // Hand-typed conversions and percentages ("5 km em milhas", "15% de 230", Portuguese for "5 km in miles", "15% of 230")
        const conv = Convert.results(t);
        if (conv.length && conv[0].copy !== "")
            return { text: conv[0].title.replace(/^= /, ""), copy: conv[0].copy };
        // Unclosed parentheses count as closed
        let e = toEngine(t);
        const open = (e.match(/\(/g) ?? []).length - (e.match(/\)/g) ?? []).length;
        e += ")".repeat(Math.max(0, open));
        // A trailing operator does not count yet
        e = e.replace(/[+\-*/^]+$/, "");
        const v = Launcher.calculate("=" + e);
        return v === null ? null : { text: format(v), copy: String(v) };
    }

    readonly property var live: evaluate(expr)

    function format(v) {
        if (Math.abs(v) >= 1e15 || (Math.abs(v) < 1e-9 && v !== 0))
            return v.toExponential(6).replace(".", ",");
        return v.toLocaleString(Tr.locale, "f", 10).replace(/[.,]?0+$/, "");
    }

    // --- Keys ---
    function isOperator(k) { return ["+", "−", "×", "÷", "^", "%"].includes(k); }

    function press(k) {
        error = "";
        if (k === "C") {
            expr = "";
            justEvaluated = false;
            return;
        }
        if (k === "⌫") {
            expr = expr.slice(0, -1);
            justEvaluated = false;
            return;
        }
        if (k === "=") {
            equals();
            return;
        }
        if (k === "±") {
            // Flips the sign of the last number
            const m = /(-?)([0-9.,]+)$/.exec(expr);
            if (m)
                expr = expr.slice(0, m.index) + (m[1] ? "" : "-") + m[2];
            else if (live)
                expr = "-(" + expr + ")";
            return;
        }
        if (justEvaluated) {
            justEvaluated = false;
            // A number starts over; an operator continues from the result
            if (!isOperator(k))
                expr = "";
        }
        const fn = { "√": "√(", "sin": "sin(", "cos": "cos(", "tan": "tan(", "log": "log(", "ln": "ln(" }[k];
        if (fn) {
            expr += fn;
            return;
        }
        if (k === "x²") {
            expr += "^2";
            return;
        }
        // Two operators in a row: the new one replaces the previous
        if (isOperator(k) && k !== "%" && /[+−×÷^]$/.test(expr)) {
            expr = expr.slice(0, -1) + k;
            return;
        }
        expr += k;
    }

    function equals() {
        const r = live;
        if (!expr.trim())
            return;
        if (!r) {
            error = /÷\s*0(?![,0-9])/.test(expr) ? Tr.t("Can't divide by zero") : Tr.t("Incomplete expression");
            return;
        }
        history = [{ expr: expr, result: r.text, copy: r.copy, at: Date.now() }, ...history].slice(0, maxHistory);
        save();
        // The result stays in the expression (with a comma), to continue the calculation
        expr = r.copy.replace(".", dec);
        justEvaluated = true;
    }

    function copyResult() {
        const r = live;
        if (!r)
            return;
        Quickshell.execDetached(["wl-copy", "--", r.copy]);
        Events.push({ icon: "content_copy", title: Tr.t("Copied"), text: r.text, duration: 1500 });
    }

    function useHistory(h) {
        expr = h.expr;
        justEvaluated = false;
    }

    function clearHistory() {
        history = [];
        save();
    }

    function save() { file.setText(JSON.stringify({ history }) + "\n"); }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/calculator.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const h = JSON.parse(text()).history;
                if (Array.isArray(h))
                    root.history = h.slice(0, root.maxHistory);
            } catch (e) {
                console.warn("calculator.json:", e);
            }
        }
    }

    IpcHandler {
        target: "calculator"
        function toggle(): void { root.toggle(); }
        function scientific(on: bool): void { root.scientific = on; }
        function clear(): void { root.clearHistory(); root.expr = ""; }
        function calc(expr: string): string { return root.evaluate(expr)?.text ?? ""; }
        // For testing without a mouse: presses a sequence of space-separated keys
        function keys(seq: string): string {
            for (const k of seq.split(" "))
                root.press(k);
            return root.expr + " = " + (root.live?.text ?? "");
        }
    }
}
