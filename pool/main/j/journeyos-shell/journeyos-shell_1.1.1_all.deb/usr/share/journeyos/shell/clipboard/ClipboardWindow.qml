import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Clipboard history (Meta+V): search, arrows, Enter copies; pin and delete
// with the mouse (or Delete). Esc or clicking outside closes.
PanelWindow {
    id: root

    required property var modelScreen
    readonly property bool open: Clipboard.open && Clipboard.screen === modelScreen

    property string query: ""
    readonly property var shown: {
        const q = query.trim().toLowerCase();
        return q ? Clipboard.items.filter(i => i.text.toLowerCase().includes(q)) : Clipboard.items;
    }

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-clipboard"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open) {
            search.text = "";
            list.currentIndex = 0;
            search.forceActiveFocus();
        } else {
            closing.restart();
        }
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    Rectangle {
        anchors.fill: parent
        color: Theme.scrim
        opacity: root.open ? 1 : 0
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
    }

    MouseArea {
        anchors.fill: parent
        onClicked: Clipboard.open = false
    }

    function ago(t) {
        const min = Math.floor((Date.now() - t) / 60000);
        if (min < 1) return Tr.t("now");
        if (min < 60) return Tr.t("") + min + Tr.t(" min");
        const h = Math.floor(min / 60);
        if (h < 24) return Tr.t("") + h + Tr.t(" h");
        return Tr.locale.toString(new Date(t), "d MMM");
    }

    Rectangle {
        id: box

        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(parent.height * 0.16) + (root.open ? 0 : Theme.gap * 2)
        width: Math.min(Theme.launcherWidth, parent.width - Theme.gap * 4)
        height: column.implicitHeight
        opacity: root.open ? 1 : 0
        radius: Theme.radiusCard + 4
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        clip: true

        Behavior on y {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }

        MouseArea {
            anchors.fill: parent
        }

        ColumnLayout {
            id: column
            anchors.left: parent.left
            anchors.right: parent.right
            spacing: 0

            RowLayout {
                Layout.fillWidth: true
                Layout.margins: Theme.cardPadding
                Layout.bottomMargin: Theme.gap
                spacing: 12

                MIcon {
                    icon: "content_paste"
                    size: 22
                    color: Theme.subtext
                }

                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge
                    clip: true
                    onTextChanged: {
                        root.query = text;
                        list.currentIndex = 0;
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !search.text
                        text: Tr.t("Search what you copied")
                        color: Theme.dim
                        font: search.font
                    }

                    Keys.onEscapePressed: Clipboard.open = false
                    Keys.onReturnPressed: if (root.shown[list.currentIndex]) Clipboard.copy(root.shown[list.currentIndex])
                    Keys.onEnterPressed: if (root.shown[list.currentIndex]) Clipboard.copy(root.shown[list.currentIndex])
                    Keys.onDownPressed: list.currentIndex = Math.min(list.count - 1, list.currentIndex + 1)
                    Keys.onUpPressed: list.currentIndex = Math.max(0, list.currentIndex - 1)
                    Keys.onDeletePressed: event => {
                        // Delete with an empty field deletes the chosen item
                        if (!search.text && root.shown[list.currentIndex])
                            Clipboard.remove(root.shown[list.currentIndex]);
                        else
                            event.accepted = false;
                    }
                }

                Rectangle {
                    visible: Clipboard.items.some(i => !i.pinned)
                    implicitWidth: clearText.implicitWidth + 20
                    implicitHeight: 28
                    radius: height / 2
                    color: clearMouse.containsMouse ? Theme.buttonHover : Theme.button
                    Text {
                        id: clearText
                        anchors.centerIn: parent
                        text: Tr.t("Clear")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        font.weight: Font.DemiBold
                    }
                    MouseArea {
                        id: clearMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Clipboard.clear()
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 1
                color: Theme.surfaceBorder
            }

            ListView {
                id: list
                Layout.fillWidth: true
                Layout.margins: Theme.gap / 2
                implicitHeight: Math.min(count, 8) * 52
                visible: count > 0
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                highlightMoveDuration: 0
                model: root.shown

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool current: ListView.isCurrentItem

                    width: list.width
                    height: 52
                    radius: Theme.radius
                    // No transition, as in menus
                    color: current ? Theme.buttonHover : rowMouse.containsMouse ? Theme.button : "transparent"

                    MouseArea {
                        id: rowMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Clipboard.copy(row.modelData)
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 14
                        anchors.rightMargin: 10
                        spacing: 10

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1
                            Text {
                                Layout.fillWidth: true
                                text: row.modelData.text.trim().split("\n")[0]
                                elide: Text.ElideRight
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontNormal
                            }
                            Text {
                                Layout.fillWidth: true
                                text: root.ago(row.modelData.time)
                                    + (row.modelData.text.includes("\n") ? " · " + row.modelData.text.split("\n").length + " linhas" : "")
                                    + " · " + row.modelData.text.length + Tr.t(" characters")
                                color: Theme.dim
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                        }

                        Small {
                            visible: row.modelData.pinned || rowMouse.containsMouse || row.current
                            icon: "push_pin"
                            active: row.modelData.pinned
                            onClicked: Clipboard.pin(row.modelData)
                        }
                        Small {
                            visible: rowMouse.containsMouse || row.current
                            icon: "delete"
                            onClicked: Clipboard.remove(row.modelData)
                        }
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                Layout.margins: Theme.cardPadding + 4
                visible: list.count === 0
                horizontalAlignment: Text.AlignHCenter
                text: Clipboard.items.length === 0 ? Tr.t("You haven't copied anything yet") : Tr.t("Nothing for “") + root.query + "”"
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
        }
    }

    component Small: Rectangle {
        id: small
        property string icon: ""
        property bool active: false
        signal clicked

        implicitWidth: 28
        implicitHeight: 28
        radius: 14
        color: active ? Theme.accent : smallMouse.containsMouse ? Theme.buttonHover : Theme.button

        MIcon {
            anchors.centerIn: parent
            icon: small.icon
            size: 15
            color: small.active ? Theme.accentText : Theme.subtext
        }
        MouseArea {
            id: smallMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: small.clicked()
        }
    }
}
