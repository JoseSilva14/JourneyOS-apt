import QtQuick
import Quickshell
import Quickshell.Wayland
import qs

// Top bar: logo on the left, status on the right. Styles (config.json, bar.style):
// flat = strip stuck to the top; floating = strip with a margin and rounded corners;
// islands = one pill on each side; island = everything in one centred pill.
PanelWindow {
    id: root

    readonly property string barStyle: Theme.barStyle
    readonly property bool split: barStyle === "flat" || barStyle === "floating"

    anchors {
        top: true
        left: true
        right: true
    }
    implicitHeight: Theme.barZone
    color: "transparent"
    WlrLayershell.namespace: "shadow-bar"
    WlrLayershell.layer: WlrLayer.Top

    // The floating ones only catch the mouse on the pills
    mask: Region {
        item: root.barStyle === "flat" || root.barStyle === "floating" ? strip : null
        Region { item: root.barStyle === "islands" ? leftIsland : null }
        Region { item: root.barStyle === "islands" ? rightIsland : null }
        Region { item: root.barStyle === "island" ? island : null }
    }

    // flat / floating: one strip with the logo and the status at the ends
    Rectangle {
        id: strip
        visible: root.split
        anchors.fill: parent
        anchors.topMargin: Theme.barMargin
        anchors.leftMargin: Theme.barMargin * 2
        anchors.rightMargin: Theme.barMargin * 2
        radius: root.barStyle === "floating" ? Theme.radius : 0
        color: Theme.barBg
        border.width: root.barStyle === "floating" ? 1 : 0
        border.color: Theme.cardBorder

        DistroLogo {
            anchors.left: parent.left
            anchors.leftMargin: Theme.barPadding - 4
            anchors.verticalCenter: parent.verticalCenter
        }

        Status {
            anchors.right: parent.right
            anchors.rightMargin: Theme.barPadding - 6
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    // islands: one pill on each side
    Island {
        id: leftIsland
        visible: root.barStyle === "islands"
        anchors.left: parent.left
        anchors.leftMargin: Theme.barMargin * 2
        contentWidth: leftLogo.width

        DistroLogo {
            id: leftLogo
            anchors.centerIn: parent
        }
    }

    Island {
        id: rightIsland
        visible: root.barStyle === "islands"
        anchors.right: parent.right
        anchors.rightMargin: Theme.barMargin * 2
        contentWidth: rightStatus.width

        Status {
            id: rightStatus
            anchors.centerIn: parent
        }
    }

    // island: everything in one centred pill
    Island {
        id: island
        visible: root.barStyle === "island"
        anchors.horizontalCenter: parent.horizontalCenter
        contentWidth: islandRow.width

        Row {
            id: islandRow
            anchors.centerIn: parent
            spacing: 4

            DistroLogo {
                anchors.verticalCenter: parent.verticalCenter
            }
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: 1
                height: Theme.barHeight - 16
                color: Theme.faint
            }
            Status {
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }

    component Island: Rectangle {
        property real contentWidth: 0

        y: Theme.barMargin
        width: contentWidth + 12
        height: Theme.barHeight
        radius: height / 2
        color: Theme.barBg
        border.width: 1
        border.color: Theme.cardBorder

        Behavior on width {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
    }
}
