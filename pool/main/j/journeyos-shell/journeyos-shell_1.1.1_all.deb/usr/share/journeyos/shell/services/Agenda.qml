pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Calendar: events from the ICS calendars the user adds (Google, Nextcloud, Outlook… via
// the "secret" ICS/webcal address, or an .ics file) and local events, read by
// scripts/agenda.py (five weeks back, ten ahead). Shows a heads-up in the pill a few
// minutes before each event. (Not called "Calendar": that name is taken by Qt types.)
Singleton {
    id: root

    readonly property var cfg: Config.options.calendar
    property var events: []
    property bool loading: false
    property bool loaded: false
    // The day shown in the Agenda tab (click a day in the calendars)
    property date focusDay: new Date()

    // Colours for new sources (the next one not in use)
    readonly property var palette: ["#4dabf7", "#20c997", "#fcc419", "#ff922b", "#f06595", "#845ef7", "#94d82d", "#fa5252"]

    function refresh() {
        if (loading)
            return;
        loading = true;
        const sources = cfg.sources.map(s => s.name + "|" + s.color + "|" + s.url);
        Run.cmd([Quickshell.shellPath("scripts/agenda.py"), "eventos", "35", "70", ...sources], (code, out) => {
            root.loading = false;
            if (code !== 0)
                return;
            try {
                root.events = JSON.parse(out);
                root.loaded = true;
            } catch (e) {
                console.warn("agenda:", e);
            }
        }, { SHADOW_LANG: Tr.lang });
    }

    // Events that touch a day (multi-day ones show on every day)
    function eventsOn(day) {
        const start = new Date(day.getFullYear(), day.getMonth(), day.getDate()).getTime();
        const end = start + 86400000;
        // An all-day event ends at 0h the next day: it does not count on that day
        return events.filter(e => e.start < end && (e.end > start || (e.end === e.start && e.start >= start)));
    }

    // Days (yyyy-m-d) with events, for the dots in the calendars
    readonly property var busyDays: {
        const out = {};
        for (const e of events) {
            const d = new Date(e.start);
            const last = new Date(Math.max(e.start, e.end - 1));
            for (let i = 0; i < 62 && d <= last; i++) {
                out[d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate()] = e.color || "accent";
                d.setDate(d.getDate() + 1);
            }
        }
        return out;
    }
    function busy(day) { return busyDays[day.getFullYear() + "-" + day.getMonth() + "-" + day.getDate()] ?? ""; }

    // Upcoming ones (in progress or starting), without past all-day ones
    function upcoming(count) {
        const now = Date.now();
        return events.filter(e => e.end > now).slice(0, count);
    }

    function iso(d) { return Qt.formatDateTime(d, "yyyy-MM-ddTHH:mm:ss"); }

    function add(title, start, end, allDay) {
        Run.cmd([Quickshell.shellPath("scripts/agenda.py"), "juntar", title, iso(start), iso(end), allDay ? "1" : "0"], () => refresh());
    }

    function remove(id) {
        Run.cmd([Quickshell.shellPath("scripts/agenda.py"), "tirar", id], () => refresh());
    }

    function addSource(name, url) {
        const used = cfg.sources.map(s => s.color);
        const color = palette.find(c => !used.includes(c)) ?? palette[cfg.sources.length % palette.length];
        cfg.sources = [...cfg.sources, { name: name || Tr.t("Calendar##calendario"), url: url.trim(), color }];
    }

    function removeSource(index) {
        cfg.sources = cfg.sources.filter((_, i) => i !== index);
    }

    // Calendars added or removed (here or in config.json): reload
    readonly property var sources: cfg.sources
    onSourcesChanged: if (loaded) Qt.callLater(refresh)

    // Short time of an event ("10:00–11:00", "All day")
    function timeText(e) {
        if (e.allDay)
            return Tr.t("All day##todo");
        const f = Config.options.clock.use24h ? "HH:mm" : "h:mm AP";
        return Qt.formatTime(new Date(e.start), f) + (e.end > e.start ? "–" + Qt.formatTime(new Date(e.end), f) : "");
    }

    Timer {
        running: Config.ready
        interval: 15 * 60 * 1000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // --- In the pill: the next event, from a few minutes before until 5 min after it starts ---
    // (same minutes as the reminder; with the reminder off, 10). Closing it in the pill hides it.
    property real now: Date.now()
    property var hidden: ({})
    readonly property int soonMinutes: cfg.remind > 0 ? cfg.remind : 10
    readonly property var soon: {
        if (!cfg.pill)
            return null;
        const ahead = soonMinutes * 60000;
        return events.find(e => !e.allDay && !hidden[e.id] && e.start - now <= ahead && now < e.start + 5 * 60000) ?? null;
    }
    // Minutes until it starts (rounded up; 0 = already started or starting)
    readonly property int soonMinutesLeft: soon ? Math.max(0, Math.ceil((soon.start - now) / 60000)) : 0
    readonly property string soonText: !soon ? "" : soonMinutesLeft === 0 ? (soon.start <= now ? Tr.t("ongoing") : Tr.t("now"))
        : Tr.t("in ##em") + soonMinutesLeft + Tr.t(" min")

    function hideSoon() {
        if (!soon)
            return;
        const h = Object.assign({}, hidden);
        h[soon.id] = true;
        hidden = h;
    }

    // Opens the dashboard Agenda on the event's day
    function openDay(day) {
        focusDay = day;
        if (!Dashboard.open || Dashboard.tab !== "agenda")
            Dashboard.toggle("agenda", null);
    }

    Timer {
        running: root.cfg.pill
        interval: 10000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.now = Date.now()
    }

    // --- Reminders: a few minutes before it starts ---
    property var reminded: ({})
    Timer {
        running: root.cfg.remind > 0
        interval: 30000
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            const now = Date.now(), ahead = root.cfg.remind * 60000;
            const done = Object.assign({}, root.reminded);
            for (const e of root.events) {
                if (e.allDay || done[e.id] || e.start < now - 60000 || e.start - now > ahead)
                    continue;
                done[e.id] = true;
                const mins = Math.max(0, Math.round((e.start - now) / 60000));
                Events.push({
                    icon: "event",
                    title: e.title,
                    text: (mins === 0 ? Tr.t("Now") : Tr.t("In ") + mins + Tr.t(" min")) + (e.location ? " · " + e.location : ""),
                    duration: 6000
                });
            }
            root.reminded = done;
        }
    }

    IpcHandler {
        target: "agenda"
        function refresh(): void { root.refresh(); }
        // Opens the Agenda on a day (yyyy/mm/dd or yyyy-mm-dd; empty = today)
        function open(day: string): void {
            const p = day.split(/[-\/.]/).map(Number);
            root.openDay(day ? new Date(p[0], p[1] - 1, p[2]) : new Date());
        }
        function soon(): string { return root.soon ? root.soon.title + " " + root.soonText : ""; }
        function today(): string { return root.eventsOn(new Date()).map(e => root.timeText(e) + " " + e.title).join("\n"); }
    }
}
