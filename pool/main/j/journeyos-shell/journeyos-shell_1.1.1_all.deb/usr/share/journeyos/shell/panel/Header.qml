import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Panel header: photo, greeting, date and big time.
Section {
    id: root

    implicitHeight: 72

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    readonly property int hour: clock.date.getHours()
    readonly property string greeting: hour >= 6 && hour < 12 ? Tr.t("Good morning")
        : hour >= 12 && hour < 20 ? Tr.t("Good afternoon")
        : Tr.t("Good evening")

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 14
        anchors.rightMargin: Theme.cardPadding
        spacing: 12

        RoundImage {
            id: avatar
            implicitWidth: 44
            implicitHeight: 44
            radius: 22
            source: User.face

            Text {
                anchors.centerIn: parent
                visible: !avatar.ready
                text: User.name.charAt(0).toUpperCase()
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge
                font.weight: Font.Bold
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 2

            Text {
                Layout.fillWidth: true
                text: root.greeting + ", " + User.name
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Text {
                text: Tr.locale.toString(clock.date, Tr.t("dddd, d MMMM"))
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        Text {
            text: DateTime.time(clock.date)
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: 26
            font.weight: Font.Bold
        }
    }
}
