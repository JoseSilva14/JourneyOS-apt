import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Storage: disks and partitions with used space, mount/unmount/eject, and the trash.
Page {
    id: root

    Component.onCompleted: Storage.refresh()

    Repeater {
        model: Storage.disks

        ColumnLayout {
            id: disk
            required property var modelData
            readonly property var d: modelData
            readonly property bool removable: d.rm || d.hotplug || d.tran === "usb"

            Layout.fillWidth: true
            spacing: 8

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 6

                SectionLabel {
                    Layout.fillWidth: true
                    text: (disk.d.model || (disk.d.type === "rom" ? Tr.t("Disk reader") : Tr.t("Disk"))) + " · " + disk.d.name + " · " + Storage.size(disk.d.size)
                }
                PillButton {
                    visible: disk.removable
                    text: Tr.t("Eject")
                    onClicked: Storage.eject(disk.d)
                }
            }

            Repeater {
                model: Storage.volumes(disk.d)

                SettingRow {
                    id: vol
                    required property var modelData
                    readonly property var v: modelData
                    readonly property real used: v.fsused ? Number(v.fsused) : 0
                    readonly property real total: v.fssize ? Number(v.fssize) : Number(v.size)

                    title: v.mountpoint === "/" ? Tr.t("System") : (v.label || v.name)
                    description: (v.mountpoint ? v.mountpoint + " · " : Tr.t("Not mounted · ")) + (v.fstype ?? "")
                        + (v.mountpoint && total ? " · " + Storage.size(used) + Tr.t(" of ") + Storage.size(total) : "")
                    icon: v.mountpoint === "/" ? "storage" : disk.removable ? "usb" : "sd_storage"

                    RowLayout {
                        spacing: 10

                        // Used space
                        Rectangle {
                            visible: !!vol.v.mountpoint && vol.total > 0
                            implicitWidth: 120
                            implicitHeight: 6
                            radius: 3
                            color: Theme.buttonHover

                            Rectangle {
                                width: parent.width * Math.min(1, vol.used / vol.total)
                                height: parent.height
                                radius: 3
                                color: vol.used / vol.total > 0.9 ? Theme.privacyMic : Theme.accent
                            }
                        }
                        PillButton {
                            visible: !!vol.v.mountpoint && vol.v.mountpoint !== "/"
                            text: Tr.t("Open")
                            onClicked: Storage.open(vol.v.mountpoint)
                        }
                        PillButton {
                            visible: vol.v.mountpoint !== "/" && vol.v.mountpoint !== "[SWAP]" && !(vol.v.mountpoint ?? "").startsWith("/boot")
                            text: vol.v.mountpoint ? Tr.t("Unmount") : Tr.t("Mount")
                            onClicked: vol.v.mountpoint ? Storage.unmount(vol.v.path) : Storage.mount(vol.v.path)
                        }
                    }
                }
            }

            Text {
                visible: Storage.volumes(disk.d).length === 0
                Layout.leftMargin: 4
                text: disk.d.type === "rom" ? Tr.t("No disk.") : Tr.t("No partitions with files.")
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }

    SectionLabel { text: Tr.t("Trash") }

    SettingRow {
        title: Storage.trashBytes > 0 ? Storage.size(Storage.trashBytes) + Tr.t(" in the trash") : Tr.t("The trash is empty")
        description: Tr.t("Deleted files stay here until you empty it.")
        icon: "delete"
        PillButton {
            visible: Storage.trashBytes > 0
            text: Tr.t("Empty")
            onClicked: Storage.emptyTrash()
        }
    }
}
