import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Notifications: Do Not Disturb, time on screen and clearing.
Page {
    SettingRow {
        title: Tr.t("Do not disturb")
        description: Notifs.dnd ? Tr.t("Only urgent ones show on screen; the rest stay in the center.")
            : Tr.t("Alerts show in the top-right corner.")
        icon: "notifications_off"

        Toggle {
            checked: Notifs.dnd
            onToggled: on => Notifs.setDnd(on)
        }
    }

    SettingRow {
        title: Tr.t("Where they show")
        description: Tr.t("Top-right corner, in the pill (a few seconds) or both. Urgent ones always show in the corner too.")
        icon: "picture_in_picture"

        Segmented {
            model: [
                { id: "pill", label: Tr.t("Pill") },
                { id: "corner", label: Tr.t("Corner") },
                { id: "both", label: Tr.t("Both") }
            ]
            current: Config.options.notifications.where
            onSelected: id => Config.options.notifications.where = id
        }
    }

    SettingRow {
        title: Tr.t("Sound")
        description: Tr.t("A short sound when an alert arrives (urgent ones have another). Silent in Do not disturb.")
        icon: "volume_up"

        Toggle {
            checked: Config.options.notifications.sound
            onToggled: on => Config.options.notifications.sound = on
        }
    }

    SettingRow {
        title: Tr.t("Time on screen")
        description: Tr.t("How long each alert stays, when the app doesn't say. Urgent ones stay until you close them.")
        icon: "schedule"

        Segmented {
            model: [
                { id: "3000", label: Tr.t("3 s") },
                { id: "5000", label: Tr.t("5 s") },
                { id: "8000", label: Tr.t("8 s") },
                { id: "12000", label: Tr.t("12 s") }
            ]
            current: String(Config.options.notifications.timeout)
            onSelected: id => Config.options.notifications.timeout = Number(id)
        }
    }

    SettingRow {
        title: Notifs.list.length === 0 ? Tr.t("No notifications in the center")
            : Notifs.list.length === 1 ? Tr.t("1 notification in the center")
            : Notifs.list.length + Tr.t(" notifications in the center")
        description: Tr.t("The center opens from the bell in the bar (") + Config.options.shortcuts.notifications + ")."
        icon: "clear_all"

        Rectangle {
            visible: Notifs.list.length > 0
            implicitWidth: clearText.implicitWidth + 28
            implicitHeight: 32
            radius: height / 2
            color: clearMouse.containsMouse ? Theme.buttonHover : Theme.button

            Behavior on color {
                ColorAnimation { duration: Theme.animFast }
            }

            Text {
                id: clearText
                anchors.centerIn: parent
                text: Tr.t("Clear all")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }

            MouseArea {
                id: clearMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Notifs.clearAll()
            }
        }
    }
}
