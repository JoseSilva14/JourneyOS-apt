import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Power: profile, dimming/turning off the screen and suspend (on AC and, on a laptop,
// on battery) and automatic locking.
Page {
    id: root

    Component.onCompleted: Power.refresh()

    readonly property var times: [
        { id: "-1", label: Tr.t("Never") }, { id: "60", label: Tr.t("1 minute") }, { id: "120", label: Tr.t("2 minutes") },
        { id: "300", label: Tr.t("5 minutes") }, { id: "600", label: Tr.t("10 minutes") }, { id: "900", label: Tr.t("15 minutes") },
        { id: "1800", label: Tr.t("30 minutes") }, { id: "3600", label: Tr.t("1 hour") }
    ]

    SettingRow {
        visible: Power.profiles.length > 1
        title: Tr.t("Power profile")
        description: Tr.t("Power saver uses less; Performance gives everything.")
        icon: "bolt"
        Segmented {
            model: Power.profiles.map(p => ({ id: p, label: Power.profileNames[p] ?? p }))
            current: Power.profile
            onSelected: id => Power.setProfile(id)
        }
    }

    Repeater {
        model: Power.hasBattery ? ["AC", "Battery"] : ["AC"]

        ColumnLayout {
            id: group
            required property string modelData
            readonly property var s: Power.settings[modelData] ?? {}

            Layout.fillWidth: true
            spacing: 8

            SectionLabel {
                text: !Power.hasBattery ? Tr.t("When the computer is idle")
                    : group.modelData === "AC" ? Tr.t("Plugged in") : Tr.t("On battery")
            }

            SettingRow {
                title: Tr.t("Dim screen")
                icon: "brightness_medium"
                Select {
                    options: root.times
                    current: String(group.s.dim ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "dim", Number(id))
                }
            }
            SettingRow {
                title: Tr.t("Turn off screen")
                icon: "desktop_access_disabled"
                Select {
                    options: root.times
                    current: String(group.s.off ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "off", Number(id))
                }
            }
            SettingRow {
                title: Tr.t("Sleep")
                icon: "bedtime"
                Select {
                    options: root.times
                    current: String(group.s.suspend ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "suspend", Number(id))
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Screen lock") }

    SettingRow {
        title: Tr.t("Lock automatically")
        description: Tr.t("Asks for the password after a while without using the computer.")
        icon: "lock_clock"
        Toggle {
            checked: Power.autolock
            onToggled: on => Power.setLock("Autolock", on)
        }
    }

    SettingRow {
        visible: Power.autolock
        title: Tr.t("Lock after")
        icon: "timer"
        Select {
            options: [1, 2, 5, 10, 15, 30, 60].map(m => ({ id: String(m), label: m === 60 ? Tr.t("1 hour") : m + (m === 1 ? Tr.t(" minute") : Tr.t(" minutes")) }))
            current: String(Power.lockMinutes)
            onSelected: id => Power.setLock("Timeout", id)
        }
    }

    SettingRow {
        title: Tr.t("Lock on wake")
        description: Tr.t("After sleep, asks for the password.")
        icon: "lock"
        Toggle {
            checked: Power.lockOnResume
            onToggled: on => Power.setLock("LockOnResume", on)
        }
    }
}
