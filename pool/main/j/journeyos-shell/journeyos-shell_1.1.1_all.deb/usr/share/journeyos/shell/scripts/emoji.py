#!/usr/bin/env python3
"""Emoji list (English name, from Python's Unicode data) for the launcher.

Writes JSON [{"e": "😀", "n": "grinning face"}, …]; the launcher caches it.
"""

import json
import sys
import unicodedata

# Blocks with emojis (faces, people, nature, food, travel, objects, symbols…)
RANGES = [(0x1F300, 0x1F5FF), (0x1F600, 0x1F64F), (0x1F680, 0x1F6FF), (0x1F900, 0x1F9FF),
          (0x1FA70, 0x1FAFF), (0x2600, 0x26FF), (0x2700, 0x27BF)]


def main():
    out = []
    for start, end in RANGES:
        for cp in range(start, end + 1):
            ch = chr(cp)
            name = unicodedata.name(ch, "")
            if not name or unicodedata.category(ch) not in ("So", "Sk"):
                continue
            out.append({"e": ch, "n": name.lower()})
    json.dump(out, sys.stdout, ensure_ascii=False)


if __name__ == "__main__":
    main()
