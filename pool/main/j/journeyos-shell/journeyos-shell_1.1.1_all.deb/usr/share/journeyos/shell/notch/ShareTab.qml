import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Share tab (only exists with a share): QR code for the phone, the link, copy and stop.
Item {
    id: root

    // For "until 14:52" and the time left
    property real now: Date.now()
    Timer {
        running: Share.active
        interval: 15000
        repeat: true
        onTriggered: root.now = Date.now()
    }
    readonly property int minutesLeft: Math.max(0, Math.ceil((Share.endsAt - now) / 60000))

    RowLayout {
        anchors.fill: parent
        spacing: 16

        // QR code (white background in the light theme too: readers need contrast)
        Rectangle {
            Layout.preferredWidth: Math.min(root.height, 132)
            Layout.preferredHeight: Layout.preferredWidth
            radius: Theme.radiusCard - 4
            color: Share.qr ? "#ffffff" : Theme.button

            Image {
                anchors.fill: parent
                anchors.margins: 8
                visible: Share.qr !== ""
                source: Share.qr ? "file://" + Share.qr : ""
                smooth: false
                fillMode: Image.PreserveAspectFit
                cache: false
            }
            ColumnLayout {
                anchors.centerIn: parent
                width: parent.width - 16
                visible: Share.qr === ""
                spacing: 4

                MIcon {
                    Layout.alignment: Qt.AlignHCenter
                    icon: Share.starting ? "hourglass_top" : "qr_code_2"
                    size: 34
                    color: Theme.dim
                }
                Text {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    text: Share.starting ? Tr.t("Preparing…") : Tr.t("No QR code")
                    wrapMode: Text.WordWrap
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 6

            Text {
                Layout.fillWidth: true
                text: Share.name || Tr.t("Preparing to share…")
                elide: Text.ElideMiddle
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 2
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                visible: Share.active
                text: Share.size + Tr.t(" · ") + root.minutesLeft + Tr.t(" min")
                    + (Share.downloads ? " · " + Share.downloads + (Share.downloads === 1 ? Tr.t(" download") : Tr.t(" downloads")) : "")
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            // The link: clicking copies
            Rectangle {
                Layout.fillWidth: true
                Layout.topMargin: 2
                visible: Share.active
                implicitHeight: 30
                radius: 15
                color: linkMouse.containsMouse ? Theme.buttonHover : Theme.button

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 10
                    spacing: 6

                    Text {
                        Layout.fillWidth: true
                        text: Share.url.replace(/^http:\/\//, "")
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                    MIcon {
                        icon: "content_copy"
                        size: 14
                        color: Theme.subtext
                    }
                }
                MouseArea {
                    id: linkMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: Share.copyUrl()
                }
            }

            Text {
                Layout.fillWidth: true
                text: Share.qr || !Share.active ? Tr.t("Point your phone's camera at the code. Only devices on the same network can open it.")
                    : Tr.t("Open the link on your phone (same network). For the QR code, install qrencode.")
                wrapMode: Text.WordWrap
                maximumLineCount: 2
                elide: Text.ElideRight
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall - 1
            }

            Item { Layout.fillHeight: true }

            RowLayout {
                spacing: 8

                Control {
                    icon: "folder_open"
                    implicitWidth: 32
                    enabled: Share.active
                    onClicked: Share.pick()
                }
                Text {
                    text: Tr.t("Another file")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
                Item { Layout.fillWidth: true }
                Control {
                    icon: "stop"
                    implicitWidth: 32
                    onClicked: Share.stop()
                }
            }
        }
    }
}
