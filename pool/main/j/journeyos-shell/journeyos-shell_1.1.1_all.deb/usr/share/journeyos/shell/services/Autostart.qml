pragma Singleton

import QtQuick
import Quickshell

// Apps that start at login (scripts/autostart.py; the session's essential ones are not shown).
Singleton {
    id: root

    property var list: []               // [{ id, name, icon, enabled, system }]

    function refresh() {
        Run.cmd([Quickshell.shellPath("scripts/autostart.py"), "list"], (code, out) => {
            try {
                root.list = JSON.parse(out);
            } catch (e) {
            }
        });
    }

    function run(cmd, id) {
        Run.cmd([Quickshell.shellPath("scripts/autostart.py"), cmd, id], () => refresh());
    }

    function setEnabled(id, on) { run(on ? "enable" : "disable", id); }
    function add(id) { run("add", id); }
    function remove(id) { run("remove", id); }
}
