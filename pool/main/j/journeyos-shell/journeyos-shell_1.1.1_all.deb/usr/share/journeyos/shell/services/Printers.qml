pragma Singleton

import QtQuick
import Quickshell

// Printers (CUPS): the installed ones (lpstat), the default (lpoptions), test page,
// removing and adding network printers that print driverless (driverless / IPP
// Everywhere). Adding and removing use lpadmin (via pkexec if authorization is needed).
Singleton {
    id: root

    property var printers: []           // [{ name, state, enabled }]
    property string defaultPrinter: ""
    property var found: []              // [{ uri, name }] found on the network
    property bool searching: false

    function refresh() {
        Run.sh("lpstat -p 2>/dev/null; echo '--'; lpstat -d 2>/dev/null", (code, out) => {
            const [list, def] = out.split("--\n");
            root.printers = (list ?? "").trim().split("\n").filter(l => l.startsWith("printer ")).map(l => {
                const m = l.match(/^printer (\S+) (?:is )?(.*)$/);
                return { name: m[1], state: m[2].includes("idle") ? Tr.t("Ready") : m[2].includes("printing") ? Tr.t("Printing") : Tr.t("Stopped##f"),
                    enabled: !m[2].includes("disabled") };
            });
            root.defaultPrinter = ((def ?? "").match(/: (\S+)/) ?? [, ""])[1];
        });
    }

    function search() {
        searching = true;
        Run.cmd(["driverless"], (code, out) => {
            root.searching = false;
            root.found = out.trim().split("\n").filter(u => u.startsWith("ipp")).map(uri => ({
                uri, name: decodeURIComponent((uri.match(/\/\/([^.:/]+)/) ?? [, uri])[1]).replace(/[^A-Za-z0-9_-]/g, "_")
            })).filter(f => !root.printers.some(p => p.name === f.name));
        });
    }

    function admin(args) {
        Run.cmd(["/usr/sbin/lpadmin", ...args], code => {
            if (code !== 0)
                Run.cmd(["pkexec", "/usr/sbin/lpadmin", ...args], () => refresh());
            else
                refresh();
        });
    }

    function add(f) { admin(["-p", f.name, "-E", "-v", f.uri, "-m", "everywhere"]); }
    function remove(name) { admin(["-x", name]); }
    function setDefault(name) { Run.cmd(["lpoptions", "-d", name], () => refresh()); }
    function testPage(name) { Run.cmd(["lp", "-d", name, "/usr/share/cups/data/testprint"]); }
}
