#!/bin/sh
# kded modules that pop up over the shell: KDE's donation request ("donationmessage") and the
# Plasma Welcome Center after updates ("kded_plasma-welcome"; the shell has its own
# Welcome). kde-quiet.sh apply|reset|status — reversible (only the user's kded6rc).
set -e
MODULES="donationmessage kded_plasma-welcome"
kded() { qdbus6 org.kde.kded6 /kded "org.kde.kded6.$1" "$2" >/dev/null 2>&1 || true; }

case "$1" in
apply)
    for m in $MODULES; do
        kwriteconfig6 --file kded6rc --group "Module-$m" --key autoload false
        kded unloadModule "$m"
    done
    ;;
reset)
    for m in $MODULES; do
        kwriteconfig6 --file kded6rc --group "Module-$m" --key autoload --delete
        kded loadModule "$m"
    done
    ;;
status)
    for m in $MODULES; do
        echo "$m: autoload=$(kreadconfig6 --file kded6rc --group "Module-$m" --key autoload --default true)"
    done
    ;;
*)
    echo "usage: $0 apply|reset|status" >&2
    exit 2
    ;;
esac
