import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs

// Setting row: title and description on the left, the control on the right.
Rectangle {
    id: root

    property string title: ""
    property string description: ""
    property string icon: ""
    // Instead of the Material icon: an app's icon (theme name or path)
    property string iconSource: ""
    default property alias control: slot.data

    Layout.fillWidth: true
    implicitHeight: Math.max(60, texts.implicitHeight + 24)
    radius: Theme.radius
    color: Theme.surfaceCard
    border.width: 1
    border.color: Theme.surfaceBorder

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 16
        anchors.rightMargin: 16
        spacing: 14

        MIcon {
            visible: root.icon !== "" && root.iconSource === ""
            icon: root.icon
            size: 20
            color: Theme.subtext
        }
        IconImage {
            visible: root.iconSource !== ""
            implicitSize: 26
            source: !root.iconSource ? "" : root.iconSource.startsWith("/") ? "file://" + root.iconSource : Quickshell.iconPath(root.iconSource, true)
        }

        ColumnLayout {
            id: texts
            Layout.fillWidth: true
            spacing: 2

            Text {
                Layout.fillWidth: true
                text: root.title
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: root.description
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        Item {
            id: slot
            implicitWidth: childrenRect.width
            implicitHeight: childrenRect.height
        }
    }
}
