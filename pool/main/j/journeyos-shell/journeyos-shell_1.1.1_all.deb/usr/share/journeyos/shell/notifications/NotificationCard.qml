import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Notifications
import qs
import qs.components
import qs.services

// Card for one notification, in the popup and in the centre.
// In the popup it disappears by itself (paused while hovered); critical ones stay.
Rectangle {
    id: root

    required property var entry
    property bool popup: false

    // The row leaving the list loses its modelData (entry = null) before the
    // animation finishes: the last one is used
    property var lastEntry: null
    onEntryChanged: if (entry) lastEntry = entry
    readonly property var e: entry ?? lastEntry

    // On closing, the notification is destroyed before the exit animation finishes,
    // and QML nulls the reference without notifying bindings: a copy of the fields
    // is always shown, rebuilt when the notification changes
    readonly property var n: snapshot
    property var snapshot: ({ appName: "", appIcon: "", desktopEntry: "", summary: "", body: "", image: "",
            urgency: NotificationUrgency.Normal, expireTimeout: -1 })

    function capture() {
        const s = e?.n;
        if (s)
            snapshot = { appName: s.appName, appIcon: s.appIcon, desktopEntry: s.desktopEntry, summary: s.summary,
                body: s.body, image: s.image, urgency: s.urgency, expireTimeout: s.expireTimeout };
    }

    Component.onCompleted: {
        lastEntry = entry;
        capture();
    }

    // Replaced by the app (same id): new content
    Connections {
        target: root.e?.n
        function onSummaryChanged() { root.capture(); }
        function onBodyChanged() { root.capture(); }
        function onImageChanged() { root.capture(); }
        function onAppIconChanged() { root.capture(); }
        function onUrgencyChanged() { root.capture(); }
    }
    readonly property bool critical: n.urgency === NotificationUrgency.Critical
    readonly property var actions: (e?.n?.actions ?? []).filter(a => a.identifier !== "default")

    readonly property string appIcon: {
        const name = n.appIcon || (DesktopEntries.byId(n.desktopEntry)?.icon ?? "");
        if (!name)
            return "";
        return name.startsWith("/") ? "file://" + name : Quickshell.iconPath(name, true);
    }

    implicitHeight: content.implicitHeight + Theme.cardPadding * 2 - 4
    radius: Theme.radiusCard
    color: hover.hovered ? Theme.surfaceCardHover : Theme.surfaceCard
    border.width: 1
    border.color: critical ? Theme.subtext : Theme.surfaceBorder

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    function ago(t) {
        const min = Math.floor((clock.date - t) / 60000);
        if (min < 1) return Tr.t("now");
        if (min < 60) return Tr.t("") + min + Tr.t(" min");
        const h = Math.floor(min / 60);
        if (h < 24) return Tr.t("") + h + Tr.t(" h");
        return Tr.locale.toString(t, "d MMM");
    }

    HoverHandler {
        id: hover
    }

    Timer {
        running: root.popup && !root.critical && !hover.hovered
        // expireTimeout comes in ms (-1 = the app does not say)
        interval: root.n.expireTimeout > 0 ? root.n.expireTimeout : Config.options.notifications.timeout
        onTriggered: Notifs.hidePopup(root.e)
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        acceptedButtons: Qt.LeftButton | Qt.MiddleButton
        // Click: default action; middle button: close
        onClicked: m => m.button === Qt.MiddleButton ? Notifs.dismiss(root.e) : Notifs.activate(root.e)
    }

    RowLayout {
        id: content
        anchors.fill: parent
        anchors.margins: Theme.cardPadding - 2
        spacing: 12

        // Notification image, otherwise the app icon
        Item {
            Layout.alignment: Qt.AlignTop
            implicitWidth: Theme.notifIcon
            implicitHeight: Theme.notifIcon

            RoundImage {
                id: image
                anchors.fill: parent
                radius: Theme.radiusSmall + 2
                source: root.n.image || ""
                visible: root.n.image !== "" && ready
            }

            Rectangle {
                anchors.fill: parent
                radius: Theme.radiusSmall + 2
                color: Theme.button
                visible: !image.visible

                IconImage {
                    id: appIconImage
                    anchors.centerIn: parent
                    implicitSize: parent.width - 12
                    source: root.appIcon
                    visible: root.appIcon !== "" && status === Image.Ready
                }

                MIcon {
                    anchors.centerIn: parent
                    visible: !appIconImage.visible
                    icon: root.critical ? "priority_high" : "notifications"
                    size: 22
                    color: Theme.subtext
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 3

            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                Text {
                    Layout.fillWidth: true
                    text: (root.n.appName || Tr.t("Notification")) + "  ·  " + root.ago(root.e?.time ?? new Date())
                    elide: Text.ElideRight
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }

                // Close
                Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    radius: 10
                    color: closeMouse.containsMouse ? Theme.buttonHover : "transparent"
                    opacity: hover.hovered ? 1 : 0

                    Behavior on opacity {
                        NumberAnimation { duration: Theme.animFast }
                    }

                    MIcon {
                        anchors.centerIn: parent
                        icon: "close"
                        size: 14
                        color: Theme.subtext
                    }

                    MouseArea {
                        id: closeMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Notifs.dismiss(root.e)
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: root.n.summary
                elide: Text.ElideRight
                maximumLineCount: 2
                wrapMode: Text.Wrap
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }

            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: root.n.body
                textFormat: Text.StyledText
                elide: Text.ElideRight
                maximumLineCount: root.popup ? 3 : 6
                wrapMode: Text.Wrap
                color: Theme.subtext
                linkColor: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                onLinkActivated: link => Qt.openUrlExternally(link)
            }

            Flow {
                Layout.fillWidth: true
                Layout.topMargin: 6
                visible: root.actions.length > 0
                spacing: 6

                Repeater {
                    model: root.actions

                    Rectangle {
                        id: action
                        required property var modelData
                        implicitWidth: actionText.implicitWidth + 22
                        implicitHeight: 28
                        radius: height / 2
                        color: actionMouse.containsMouse ? Theme.buttonHover : Theme.button

                        Behavior on color {
                            ColorAnimation { duration: Theme.animFast }
                        }

                        Text {
                            id: actionText
                            anchors.centerIn: parent
                            text: action.modelData.text
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            font.weight: Font.DemiBold
                        }

                        MouseArea {
                            id: actionMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: action.modelData.invoke()
                        }
                    }
                }
            }
        }
    }
}
