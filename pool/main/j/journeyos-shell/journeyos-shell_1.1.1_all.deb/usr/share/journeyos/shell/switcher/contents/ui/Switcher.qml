import QtQuick
import QtCore

// The Alt+Tab visuals (nothing from KWin, so it can be tested separately):
// one card per window with the thumbnail, icon and title; the chosen one has an outline.
// Colours come from the theme.conf the shell exports.
Item {
    id: root

    property var model: null
    property int count: 0
    property int currentIndex: 0
    property real maxWidth: 1200
    // Components passed from main.qml (in KWin: WindowThumbnail and Kirigami.Icon); inside
    // them, the window data is in parent.windowModel
    property Component thumbnail: null
    property Component icon: null
    signal activated(int index)

    readonly property int cardWidth: 210
    readonly property int thumbHeight: 120

    implicitWidth: Math.min(maxWidth, list.contentWidth + 32)
    implicitHeight: thumbHeight + 92

    Settings {
        id: theme
        location: "file://" + StandardPaths.writableLocation(StandardPaths.HomeLocation)
            .toString().replace("file://", "") + "/.local/state/shadow-kde/theme.conf"
        category: "Theme"
        property string surface: "#18181a"
        property string surfaceCard: "#222224"
        property string border: "#14ffffff"
        property string buttonHover: "#1fffffff"
        property string text: "#ececec"
        property string subtext: "#9a9a9c"
        property string accent: "#f2f2f2"
        property string font: "JetBrains Mono"
    }

    Rectangle {
        anchors.fill: parent
        radius: 22
        color: theme.surface
        border.width: 1
        border.color: theme.border
    }

    ListView {
        id: list
        anchors.fill: parent
        anchors.margins: 16
        orientation: ListView.Horizontal
        spacing: 10
        clip: true
        interactive: false
        model: root.model
        currentIndex: root.currentIndex
        highlightMoveDuration: 0
        onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)

        delegate: Item {
            id: card

            required property int index
            required property var model
            readonly property bool current: index === root.currentIndex

            width: root.cardWidth
            height: list.height

            Rectangle {
                anchors.fill: parent
                radius: 16
                color: card.current ? theme.buttonHover : "transparent"
                border.width: card.current ? 2 : 0
                border.color: theme.accent
            }

            // Thumbnail
            Item {
                id: thumbBox
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.margins: 8
                height: root.thumbHeight

                Rectangle {
                    anchors.fill: parent
                    radius: 10
                    color: theme.surfaceCard
                }
                Loader {
                    anchors.fill: parent
                    anchors.margins: 4
                    sourceComponent: root.thumbnail
                    property var windowModel: card.model
                }
            }

            // Icon at the middle of the thumbnail's bottom edge
            Loader {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.verticalCenter: thumbBox.bottom
                width: 36
                height: 36
                sourceComponent: root.icon
                property var windowModel: card.model
            }

            Text {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.margins: 10
                horizontalAlignment: Text.AlignHCenter
                text: card.model.caption ?? ""
                elide: Text.ElideRight
                color: card.current ? theme.text : theme.subtext
                font.family: theme.font
                font.pixelSize: 12
                font.weight: card.current ? Font.DemiBold : Font.Normal
            }

            MouseArea {
                anchors.fill: parent
                onClicked: root.activated(card.index)
            }
        }
    }
}
