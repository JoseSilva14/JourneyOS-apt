import QtQuick
import QtQuick.Layouts
import Quickshell.Bluetooth
import Quickshell.Services.Pipewire
import qs
import qs.components
import qs.services

// Quick toggles: Wi-Fi, Bluetooth, Do not disturb, microphone, Keep awake, focus and settings.
// On = light square with the dark icon.
Section {
    id: root

    readonly property var adapter: Bluetooth.defaultAdapter
    readonly property PwNode source: Pipewire.defaultAudioSource
    readonly property bool micMuted: source?.audio?.muted ?? true

    implicitHeight: column.implicitHeight + 28

    PwObjectTracker {
        objects: [root.source]
    }

    ColumnLayout {
        id: column
        anchors.fill: parent
        anchors.margins: 14
        spacing: 10

        // Title and, on the right, the name of the button under the mouse
        RowLayout {
            Layout.fillWidth: true

            Text {
                Layout.fillWidth: true
                text: Tr.t("Quick buttons")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Text {
                text: tips.text
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Tile {
                icon: Net.wifiEnabled ? "wifi" : "wifi_off"
                tip: "Wi-Fi"
                active: Net.wifiEnabled
                onClicked: Net.setWifi(!Net.wifiEnabled)
            }
            Tile {
                icon: root.adapter?.enabled ? "bluetooth" : "bluetooth_disabled"
                tip: "Bluetooth"
                active: root.adapter?.enabled ?? false
                enabled: root.adapter !== null
                onClicked: root.adapter.enabled = !root.adapter.enabled
            }
            Tile {
                icon: Notifs.dnd ? "notifications_off" : "notifications"
                tip: Tr.t("Do not disturb")
                active: Notifs.dnd
                onClicked: Notifs.setDnd(!Notifs.dnd)
            }
            Tile {
                icon: root.micMuted ? "mic_off" : "mic"
                tip: Tr.t("Microphone")
                active: !root.micMuted
                enabled: root.source !== null
                onClicked: root.source.audio.muted = !root.micMuted
            }
            Tile {
                icon: "coffee"
                tip: KeepAwake.enabled ? Tr.t("Awake: no sleep or lock") : Tr.t("Keep awake")
                active: KeepAwake.enabled
                onClicked: KeepAwake.toggle()
            }
            Tile {
                icon: Focus.current?.icon ?? "center_focus_strong"
                tip: Focus.current ? Tr.t("Focus: ") + Tr.t(Focus.current.name) : Tr.t("Focus mode (") + Tr.t(Focus.mode(Config.options.focus.last)?.name ?? "") + ")"
                active: Focus.current !== null
                onClicked: Focus.toggleLast()
            }
            Tile {
                icon: "settings"
                tip: Tr.t("Settings")
                onClicked: SettingsApp.show("home")
            }
        }
    }

    QtObject {
        id: tips
        property string text: ""
    }

    component Tile: Rectangle {
        id: tile

        property string icon: ""
        property string tip: ""
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 48
        radius: Theme.radius
        color: active ? Theme.accent : tileMouse.containsMouse ? Theme.buttonHover : Theme.button
        opacity: enabled ? 1 : 0.35
        scale: tileMouse.pressed ? 0.94 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: tile.icon
            size: 21
            color: tile.active ? Theme.accentText : Theme.text
        }

        MouseArea {
            id: tileMouse
            anchors.fill: parent
            hoverEnabled: true
            enabled: tile.enabled
            cursorShape: Qt.PointingHandCursor
            onClicked: tile.clicked()
            onContainsMouseChanged: {
                if (containsMouse)
                    tips.text = tile.tip;
                else if (tips.text === tile.tip)
                    tips.text = "";
            }
        }
    }
}
