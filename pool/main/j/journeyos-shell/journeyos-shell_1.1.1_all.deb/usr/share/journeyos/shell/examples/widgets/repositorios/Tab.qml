import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Example tab: the git repositories in a folder (the tab folder's estado.sh, every 30 s).
// Clicking opens the repository (terminal, file manager or VS Code) and closes the pill/dashboard.
Item {
    id: root

    property var options: ({})
    property string place: "notch"
    property string widgetDir: ""
    signal done

    readonly property bool compact: place === "notch"
    property var repos: []
    property bool loaded: false

    function refresh() {
        if (!root.widgetDir)
            return;
        Run.cmd([root.widgetDir + "/estado.sh", root.options.pasta || "~/Projetos"], (code, out) => {
            root.loaded = true;
            root.repos = out.trim().split("\n").filter(l => l).map(l => {
                const f = l.split("|");
                return { path: f[0], name: f[0].split("/").pop(), branch: f[1], changes: Number(f[2]), ahead: Number(f[3]), behind: Number(f[4]) };
            })
            // Those with something pending first
            .sort((a, b) => (b.changes + b.ahead + b.behind > 0) - (a.changes + a.ahead + a.behind > 0) || a.name.localeCompare(b.name));
        });
    }

    function open(r) {
        const how = root.options.editor;
        Apps.run(how === "code" ? ["code", r.path] : how === "ficheiros" ? ["xdg-open", r.path] : ["konsole", "--workdir", r.path]);
        root.done();
    }

    onWidgetDirChanged: refresh()
    Timer {
        running: true
        repeat: true
        interval: 30000
        onTriggered: root.refresh()
    }

    GridView {
        id: grid
        anchors.fill: parent
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        cellWidth: width / (root.compact ? 2 : 3)
        cellHeight: root.compact ? 48 : 64
        model: root.repos

        delegate: Item {
            id: cell
            required property var modelData
            readonly property bool clean: modelData.changes === 0 && modelData.ahead === 0 && modelData.behind === 0
            width: grid.cellWidth
            height: grid.cellHeight

            Rectangle {
                anchors.fill: parent
                anchors.margins: 3
                radius: Theme.radius
                color: mouse.containsMouse ? Theme.buttonHover : Theme.button

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 10
                    spacing: 8

                    Rectangle {
                        implicitWidth: 8
                        implicitHeight: 8
                        radius: 4
                        color: cell.clean ? Theme.privacyCamera : Theme.accent
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0
                        Text {
                            Layout.fillWidth: true
                            text: cell.modelData.name
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall + (root.compact ? 0 : 1)
                            font.weight: Font.DemiBold
                        }
                        Text {
                            Layout.fillWidth: true
                            text: [cell.modelData.branch,
                                cell.modelData.changes ? cell.modelData.changes + (cell.modelData.changes === 1 ? " change" : " changes") : "",
                                cell.modelData.ahead ? "↑" + cell.modelData.ahead : "",
                                cell.modelData.behind ? "↓" + cell.modelData.behind : ""].filter(t => t).join(" · ")
                            elide: Text.ElideRight
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall - 1
                        }
                    }
                }
                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.open(cell.modelData)
                }
            }
        }
    }

    Text {
        anchors.centerIn: parent
        visible: root.loaded && root.repos.length === 0
        text: "No git repositories in " + (root.options.pasta || "~/Projetos")
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }
}
