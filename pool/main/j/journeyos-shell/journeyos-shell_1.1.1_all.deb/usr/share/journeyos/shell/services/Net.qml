pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Network state via nmcli, every 5 s.
Singleton {
    id: root

    property string kind: "none"     // "wifi" | "ethernet" | "none"
    property string name: ""
    property int signal: 0           // 0–100, Wi-Fi only
    property bool wifiEnabled: true  // Wi-Fi radio on

    function setWifi(on) {
        wifiEnabled = on;
        Quickshell.execDetached(["nmcli", "radio", "wifi", on ? "on" : "off"]);
        refresh.restart();
    }

    readonly property string icon: kind === "ethernet" ? "lan"
        : kind === "none" ? "wifi_off"
        : signal >= 75 ? "wifi"
        : signal >= 40 ? "wifi_2_bar"
        : "wifi_1_bar"

    // Wi-Fi radio, connected device (wifi first) and the signal of the active Wi-Fi network
    readonly property string script: `
echo "radio:$(nmcli radio wifi 2>/dev/null)"
nmcli -t -f TYPE,STATE,CONNECTION device 2>/dev/null | grep ':connected:' | sort -r | head -n1
nmcli -t -f ACTIVE,SIGNAL device wifi 2>/dev/null | grep '^yes:' | head -n1
`

    Process {
        id: reader
        command: ["sh", "-c", root.script]
        stdout: StdioCollector {
            onStreamFinished: {
                let kind = "none", name = "", signal = 0;
                for (const line of text.trim().split("\n")) {
                    const f = line.split(":");
                    if (f[0] === "radio") {
                        root.wifiEnabled = f[1] === "enabled";
                    } else if (f[0] === "yes") {
                        signal = Number(f[1]) || 0;
                    } else if (f[1] === "connected") {
                        kind = f[0] === "wifi" ? "wifi" : f[0] === "ethernet" ? "ethernet" : "none";
                        name = f.slice(2).join(":");
                    }
                }
                root.kind = kind;
                root.name = name;
                root.signal = signal;
            }
        }
    }

    // After changing the radio, read again shortly
    Timer {
        id: refresh
        interval: 1500
        onTriggered: if (!reader.running) reader.running = true
    }

    Timer {
        interval: 5000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: if (!reader.running) reader.running = true
    }
}
