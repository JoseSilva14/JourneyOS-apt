import QtQuick
import org.kde.kwin.decoration

// Round title-bar button (DecorationButton handles the click).
// Close turns red on hover.
DecorationButton {
    id: button

    property string glyph: ""
    property bool danger: false
    property var colors
    property string iconFont: ""

    readonly property color dangerColor: "#fa5252"

    width: 22
    height: 22

    Rectangle {
        anchors.fill: parent
        radius: width / 2
        color: button.danger && (button.hovered || button.pressed) ? button.dangerColor
            : button.pressed ? button.colors.buttonHover
            : button.hovered ? button.colors.buttonHover
            : button.colors.button
        scale: button.pressed ? 0.9 : 1

        Behavior on color {
            ColorAnimation { duration: 120 }
        }
        Behavior on scale {
            NumberAnimation { duration: 100 }
        }
    }

    Text {
        anchors.centerIn: parent
        text: button.glyph
        font.family: button.iconFont
        font.pixelSize: 14
        color: button.danger && (button.hovered || button.pressed) ? "#ffffff"
            : decoration.client.active ? button.colors.text : button.colors.dim
    }
}
