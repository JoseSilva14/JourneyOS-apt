pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Eyedropper colours (the captures' "color" mode): the chosen format
// (config.json colors.format: hex | rgb | hsl), copying and the last copied
// colours (~/.local/state/shadow-kde/colors.json, at most 12, most recent first).
Singleton {
    id: root

    readonly property int max: 12
    readonly property string format: Config.options.colors.format
    readonly property var formats: [
        { id: "hex", label: "HEX" },
        { id: "rgb", label: "RGB" },
        { id: "hsl", label: "HSL" }
    ]
    property var history: []

    function setFormat(id) { Config.options.colors.format = id; }

    // "#1e90ff" → text in the requested format
    function text(hex, fmt) {
        const c = Qt.color(hex);
        const r = Math.round(c.r * 255), g = Math.round(c.g * 255), b = Math.round(c.b * 255);
        switch (fmt ?? format) {
        case "rgb":
            return "rgb(" + r + ", " + g + ", " + b + ")";
        case "hsl": {
            // hslHue is -1 for greys
            const h = Math.max(0, Math.round(c.hslHue * 360));
            return "hsl(" + h + ", " + Math.round(c.hslSaturation * 100) + "%, " + Math.round(c.hslLightness * 100) + "%)";
        }
        default:
            return hex.toLowerCase();
        }
    }

    // Copies in the chosen format, saves to the history and shows a notice in the pill with the colour
    function copy(hex) {
        hex = hex.toLowerCase();
        const value = text(hex);
        Quickshell.execDetached(["wl-copy", "--", value]);
        history = [hex, ...history.filter(h => h !== hex)].slice(0, max);
        save();
        Events.push({ icon: "colorize", swatch: hex, title: value, text: Tr.t("Color copied"), duration: 2000 });
    }

    function remove(hex) {
        history = history.filter(h => h !== hex);
        save();
    }

    function clear() {
        history = [];
        save();
    }

    function save() { file.setText(JSON.stringify({ colors: history }) + "\n"); }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/colors.json"
        atomicWrites: true
        onLoaded: {
            try {
                const list = JSON.parse(text()).colors;
                if (Array.isArray(list))
                    root.history = list.filter(h => /^#[0-9a-f]{6}$/.test(h)).slice(0, root.max);
            } catch (e) {
                console.warn("colors.json:", e);
            }
        }
    }

    IpcHandler {
        target: "colors"
        function pick(): void { Capture.start("color"); }
        function copy(hex: string): void { root.copy(hex); }
        function list(): string { return root.history.join(" "); }
        function format(id: string): void { root.setFormat(id); }
        function clear(): void { root.clear(); }
    }
}
