import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Dashboard: rises from the bottom of the screen, with the Home, Wallpapers, Theme, Performance and About tabs.
// Esc or clicking outside closes; 1–7 and Ctrl+Tab switch tabs.
PanelWindow {
    id: root

    // This instance's screen (the window's "screen" changes with "visible": binding loop)
    required property var modelScreen
    readonly property bool open: Dashboard.open && Dashboard.screen === modelScreen

    readonly property var tabs: [
        { id: "home", label: Tr.t("Home"), icon: "dashboard" },
        { id: "agenda", label: Tr.t("Calendar"), icon: "event" },
        { id: "notes", label: Tr.t("Notes"), icon: "sticky_note_2" },
        { id: "apps", label: "Apps", icon: "apps" },
        { id: "web", label: "Web", icon: "language" },
        // Only with UI Dev (Settings → Development)
        ...(Dev.enabled ? [{ id: "dev", label: "Dev", icon: "terminal" }] : []),
        // The extension tabs (Settings → Tabs)
        ...Widgets.dashboardTabs,
        { id: "wallpapers", label: "Wallpapers", icon: "wallpaper" },
        { id: "theme", label: Tr.t("Theme"), icon: "palette" },
        { id: "performance", label: Tr.t("Performance"), icon: "speed" },
        { id: "about", label: Tr.t("About"), icon: "info" }
    ]

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-dashboard"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: if (!open) closing.restart()

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    MouseArea {
        anchors.fill: parent
        onClicked: Dashboard.open = false
    }

    Rectangle {
        id: panel

        anchors.horizontalCenter: parent.horizontalCenter
        width: Math.min(Theme.dashboardWidth, parent.width - Theme.gap * 2)
        height: Math.min(Theme.dashboardHeight, parent.height - Theme.gap * 2)
        // Rises from the bottom
        y: root.open ? parent.height - height - Theme.gap : parent.height
        opacity: root.open ? 1 : 0
        radius: Theme.radiusCard + 6
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        Behavior on y {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }

        focus: root.open
        Keys.onEscapePressed: Dashboard.open = false
        Keys.onPressed: event => {
            const n = event.key - Qt.Key_1;
            if (n >= 0 && n < root.tabs.length && !(event.modifiers & Qt.ControlModifier)) {
                Dashboard.tab = root.tabs[n].id;
                event.accepted = true;
            } else if (event.key === Qt.Key_Tab && (event.modifiers & Qt.ControlModifier)) {
                const i = Dashboard.tabs.indexOf(Dashboard.tab);
                Dashboard.tab = Dashboard.tabs[(i + 1) % Dashboard.tabs.length];
                event.accepted = true;
            }
        }

        // Clicks on the panel do not close it
        MouseArea {
            anchors.fill: parent
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Theme.cardPadding
            spacing: Theme.gap + 2

            Segmented {
                Layout.alignment: Qt.AlignHCenter
                // With many tabs (the extension ones) the names do not fit: only the chosen one shows it.
                // Estimate from the monospace font (~8 px per character) + icon and margins.
                compact: root.tabs.reduce((w, t) => w + t.label.length * 8 + 51, 8) > Theme.dashboardWidth - 40
                model: root.tabs
                current: Dashboard.tab
                onSelected: id => Dashboard.tab = id
            }

            // Only the open tab exists (wallpapers load images)
            Loader {
                Layout.fillWidth: true
                Layout.fillHeight: true
                active: root.visible
                sourceComponent: Dashboard.tab.startsWith("user/") ? (Widgets.dashboardTabs.some(t => t.id === Dashboard.tab) ? extensionTab : homeTab)
                    : Dashboard.tab === "agenda" ? agendaTab
                    : Dashboard.tab === "notes" ? notesTab
                    : Dashboard.tab === "apps" ? appsTab
                    : Dashboard.tab === "web" ? webTab
                    : Dashboard.tab === "dev" && Dev.enabled ? devTab
                    : Dashboard.tab === "wallpapers" ? wallpapersTab
                    : Dashboard.tab === "theme" ? themeTab
                    : Dashboard.tab === "performance" ? performanceTab
                    : Dashboard.tab === "about" ? aboutTab
                    : homeTab
            }
        }
    }

    Component {
        id: homeTab
        HomeTab {}
    }
    Component {
        id: agendaTab
        AgendaTab {}
    }
    Component {
        id: notesTab
        NotesTab {
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: appsTab
        AppsTab {
            // The search field gets the keyboard; Esc still closes
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: extensionTab
        ExtensionTab {
            type: Dashboard.tab
            place: "dashboard"
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: devTab
        DevTab {
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: webTab
        WebAppsTab {
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: wallpapersTab
        WallpapersTab {
            // The search field gets the keyboard; Esc still closes
            onCloseRequested: Dashboard.open = false
        }
    }
    Component {
        id: themeTab
        ThemeTab {}
    }
    Component {
        id: performanceTab
        PerformanceTab {}
    }
    Component {
        id: aboutTab
        AboutTab {}
    }
}
