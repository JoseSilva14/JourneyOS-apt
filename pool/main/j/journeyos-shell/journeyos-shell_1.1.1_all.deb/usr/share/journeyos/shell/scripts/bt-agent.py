#!/usr/bin/env python3
"""BlueZ pairing agent for the shell (what bluedevil does in Plasma).

Without an agent, devices that show or ask for a code (phones, keyboards, many headsets)
cannot pair. Registers org.bluez.Agent1 as the default agent ("KeyboardDisplay") and talks to
the shell (services/BtAgent) through JSON lines:
  stdout → {"id", "type", "device", "name", "passkey"?, "entered"?, "service"?}
     type: confirm (yes/no for a 6-digit code) | authorize (pairing without a code) |
           service (a paired device wants a service) | pin (type a PIN) | passkey (type a number) |
           display (show a code to type on the device) | cancel (BlueZ gave up) | ready
  stdin  ← {"id", "ok": bool, "value"?: str}
Re-registers when bluetoothd restarts.
"""

import json
import re
import sys

from gi.repository import Gio, GLib

PATH = "/org/journeyos/BluetoothAgent"
XML = """
<node>
  <interface name="org.bluez.Agent1">
    <method name="Release"/>
    <method name="RequestPinCode"><arg type="o" direction="in"/><arg type="s" direction="out"/></method>
    <method name="DisplayPinCode"><arg type="o" direction="in"/><arg type="s" direction="in"/></method>
    <method name="RequestPasskey"><arg type="o" direction="in"/><arg type="u" direction="out"/></method>
    <method name="DisplayPasskey"><arg type="o" direction="in"/><arg type="u" direction="in"/><arg type="q" direction="in"/></method>
    <method name="RequestConfirmation"><arg type="o" direction="in"/><arg type="u" direction="in"/></method>
    <method name="RequestAuthorization"><arg type="o" direction="in"/></method>
    <method name="AuthorizeService"><arg type="o" direction="in"/><arg type="s" direction="in"/></method>
    <method name="Cancel"/>
  </interface>
</node>
"""
# Service UUIDs people may recognise (the rest are shown as "a service")
SERVICES = {
    "0000110a": "audio", "0000110b": "audio", "0000110d": "audio", "0000111e": "hands-free",
    "0000111f": "hands-free", "00001108": "headset", "00001112": "headset", "00001124": "input",
    "00001812": "input", "00001105": "file transfer", "00001106": "file transfer",
    "0000112f": "contacts", "00001132": "messages", "00001116": "network", "00001115": "network",
}

bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
pending = {}          # id -> (invocation, type)
next_id = [1]


def emit(obj):
    print(json.dumps(obj), flush=True)


def device_info(path):
    try:
        props = bus.call_sync("org.bluez", path, "org.freedesktop.DBus.Properties", "GetAll",
                              GLib.Variant("(s)", ("org.bluez.Device1",)), GLib.VariantType("(a{sv})"),
                              Gio.DBusCallFlags.NONE, 2000, None).unpack()[0]
    except GLib.Error:
        props = {}
    address = path.rsplit("/", 1)[-1].replace("dev_", "").replace("_", ":")
    # The real name first; BlueZ's alias is the address itself ("AA-BB-…") when there is no name
    name = next((n for n in (props.get("Name"), props.get("Alias"))
                 if n and not re.fullmatch(r"([0-9A-Fa-f]{2}[-:_]){5}[0-9A-Fa-f]{2}", n)), address)
    return name, props


def set_trusted(path):
    try:
        bus.call_sync("org.bluez", path, "org.freedesktop.DBus.Properties", "Set",
                      GLib.Variant("(ssv)", ("org.bluez.Device1", "Trusted", GLib.Variant("b", True))),
                      None, Gio.DBusCallFlags.NONE, 2000, None)
    except GLib.Error:
        pass


def ask(inv, kind, device, **extra):
    rid = next_id[0]
    next_id[0] += 1
    pending[rid] = (inv, kind, device)
    name, _ = device_info(device)
    emit({"id": rid, "type": kind, "device": device, "name": name, **extra})


def on_call(conn, sender, path, iface, method, params, inv):
    args = params.unpack()
    if method == "Release":
        inv.return_value(None)
    elif method == "Cancel":
        for inv2, _, _ in pending.values():
            inv2.return_dbus_error("org.bluez.Error.Canceled", "Canceled")
        pending.clear()
        emit({"type": "cancel"})
        inv.return_value(None)
    elif method == "RequestConfirmation":
        ask(inv, "confirm", args[0], passkey=f"{args[1]:06d}")
    elif method == "RequestAuthorization":
        ask(inv, "authorize", args[0])
    elif method == "AuthorizeService":
        _, props = device_info(args[0])
        if props.get("Paired") and props.get("Trusted"):
            inv.return_value(None)
        else:
            ask(inv, "service", args[0], service=SERVICES.get(args[1][:8].lower(), ""))
    elif method == "RequestPinCode":
        ask(inv, "pin", args[0])
    elif method == "RequestPasskey":
        ask(inv, "passkey", args[0])
    elif method == "DisplayPinCode":
        name, _ = device_info(args[0])
        emit({"type": "display", "device": args[0], "name": name, "passkey": args[1]})
        inv.return_value(None)
    elif method == "DisplayPasskey":
        name, _ = device_info(args[0])
        emit({"type": "display", "device": args[0], "name": name, "passkey": f"{args[1]:06d}", "entered": args[2]})
        inv.return_value(None)
    else:
        inv.return_dbus_error("org.bluez.Error.Rejected", "Unknown method")


def on_stdin(channel, condition):
    if condition & (GLib.IO_HUP | GLib.IO_ERR):
        loop.quit()
        return False
    line = channel.readline()
    if not line:
        loop.quit()
        return False
    try:
        r = json.loads(line)
    except ValueError:
        return True
    item = pending.pop(r.get("id"), None)
    if not item:
        return True
    inv, kind, device = item
    if not r.get("ok"):
        inv.return_dbus_error("org.bluez.Error.Rejected", "Rejected by the user")
    elif kind == "pin":
        inv.return_value(GLib.Variant("(s)", (str(r.get("value", "")),)))
    elif kind == "passkey":
        try:
            inv.return_value(GLib.Variant("(u)", (int(r.get("value", "0")) % 1000000,)))
        except ValueError:
            inv.return_dbus_error("org.bluez.Error.Rejected", "Invalid passkey")
    else:
        if kind == "service":
            set_trusted(device)      # do not ask again for this device
        inv.return_value(None)
    return True


def register(*_):
    try:
        for method, args in (("RegisterAgent", GLib.Variant("(os)", (PATH, "KeyboardDisplay"))),
                             ("RequestDefaultAgent", GLib.Variant("(o)", (PATH,)))):
            bus.call_sync("org.bluez", "/org/bluez", "org.bluez.AgentManager1", method, args,
                          None, Gio.DBusCallFlags.NONE, 5000, None)
        emit({"type": "ready"})
    except GLib.Error as e:
        if "AlreadyExists" not in e.message:
            print(f"bt-agent: {e.message}", file=sys.stderr, flush=True)


bus.register_object(PATH, Gio.DBusNodeInfo.new_for_xml(XML).interfaces[0], on_call, None, None)
Gio.bus_watch_name_on_connection(bus, "org.bluez", Gio.BusNameWatcherFlags.NONE, register, None)
stdin = GLib.IOChannel.unix_new(sys.stdin.fileno())
GLib.io_add_watch(stdin, GLib.PRIORITY_DEFAULT, GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, on_stdin)
loop = GLib.MainLoop()
loop.run()
