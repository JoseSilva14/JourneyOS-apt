import QtQuick
import QtQuick.Layouts

// shadow-kde login screen (SDDM), in the lock screen's design: big clock on the
// left, account and password on the right, session and power at the bottom. Runs as the
// "sddm" user, before any session: colours come from this theme's theme.conf, generated
// from the shell theme by scripts/sddm.sh. SDDM API: sddm, userModel, sessionModel.
Item {
    id: root

    width: 1280
    height: 800

    // Tokens (theme.conf → [General])
    QtObject {
        id: t
        readonly property bool light: config.boolValue("light")
        readonly property color bg: config.stringValue("bg") || "#111112"
        readonly property color surface: config.stringValue("surface") || "#18181a"
        readonly property color border: config.stringValue("border") || "#14ffffff"
        readonly property color button: config.stringValue("button") || "#0fffffff"
        readonly property color buttonHover: config.stringValue("buttonHover") || "#1fffffff"
        readonly property color text: config.stringValue("text") || "#ececec"
        readonly property color subtext: config.stringValue("subtext") || "#9a9a9c"
        readonly property color dim: config.stringValue("dim") || "#5c5c60"
        readonly property color accent: config.stringValue("accent") || "#f2f2f2"
        readonly property color accentText: config.stringValue("accentText") || "#111112"
        readonly property color wallTop: config.stringValue("wallTop") || "#161618"
        readonly property color wallBottom: config.stringValue("wallBottom") || "#0b0b0c"
        readonly property string font: config.stringValue("font") || "JetBrains Mono"
        readonly property bool clock24: config.stringValue("clock24") !== "false"
        readonly property string wallpaper: config.stringValue("wallpaper")
        readonly property string logo: config.stringValue("logo")
    }

    FontLoader {
        id: icons
        source: "icons.otf"
    }

    // ── State ──────────────────────────────────────────────────────────────

    property bool busy: false
    property string message: ""

    // SDDM models can only be read through delegates: invisible 1×1 px lists
    readonly property var user: users.currentItem
    readonly property var session: sessions.currentItem

    function login() {
        if (busy || !user)
            return;
        message = "";
        busy = true;
        sddm.login(user.name, password.text, sessions.currentIndex);
    }

    function cycle(view, delta) {
        if (view.count > 0)
            view.currentIndex = (view.currentIndex + delta + view.count) % view.count;
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            root.busy = false;
            root.message = "Palavra-passe errada";
            password.text = "";
            password.forceActiveFocus();
            shake.restart();
        }
        function onLoginSucceeded() {
            content.opacity = 0;
        }
    }

    ListView {
        id: users
        width: 1                        // with size 0 no current item is created
        height: 1
        opacity: 0
        enabled: false
        model: userModel
        currentIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
        delegate: Item {
            width: 1
            height: 1
            required property string name
            required property string realName
            required property string icon
        }
        onCurrentIndexChanged: {
            root.message = "";
            password.text = "";
        }
    }

    ListView {
        id: sessions
        width: 1
        height: 1
        opacity: 0
        enabled: false
        model: sessionModel
        currentIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
        delegate: Item {
            width: 1
            height: 1
            required property string name
        }
    }

    // ── Background: the wallpaper (or the gradient) with a veil ──────────────────────

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: t.wallTop }
            GradientStop { position: 0.55; color: t.bg }
            GradientStop { position: 1.0; color: t.wallBottom }
        }
    }

    Image {
        anchors.fill: parent
        source: t.wallpaper
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        sourceSize.width: root.width
        sourceSize.height: root.height
    }

    Rectangle {
        anchors.fill: parent
        color: t.bg
        opacity: t.wallpaper ? 0.55 : 0
    }

    MouseArea {
        anchors.fill: parent
        onClicked: password.forceActiveFocus()
    }

    // Logo at the top, centred
    Image {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 36
        height: 30
        fillMode: Image.PreserveAspectFit
        source: t.logo
        sourceSize.height: 60
        opacity: 0.85
    }

    readonly property bool narrow: width < 900

    GridLayout {
        id: content
        anchors.centerIn: parent
        width: Math.min(parent.width - 80, 1000)
        columns: root.narrow ? 1 : 2
        columnSpacing: 80
        rowSpacing: 40
        opacity: 0

        Component.onCompleted: opacity = 1
        Behavior on opacity {
            NumberAnimation { duration: 400 }
        }

        // Clock: hours above minutes
        ColumnLayout {
            Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignVCenter | Qt.AlignLeft
            spacing: 0

            Column {
                Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignLeft
                spacing: -40

                Text {
                    id: hours
                    color: t.text
                    font.family: t.font
                    font.pixelSize: 180
                    font.weight: Font.ExtraBold
                    font.letterSpacing: -7
                }
                Text {
                    id: minutes
                    color: t.subtext
                    font.family: t.font
                    font.pixelSize: 180
                    font.weight: Font.ExtraBold
                    font.letterSpacing: -7
                }
            }

            Text {
                id: date
                Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignLeft
                Layout.leftMargin: 6
                color: t.subtext
                font.family: t.font
                font.pixelSize: 18
            }

            Timer {
                running: true
                repeat: true
                interval: 1000
                triggeredOnStart: true
                onTriggered: {
                    const now = new Date();
                    hours.text = Qt.formatTime(now, t.clock24 ? "HH" : "h");
                    minutes.text = Qt.formatTime(now, "mm");
                    const d = Qt.locale("pt_PT").toString(now, "dddd, d 'de' MMMM");
                    date.text = d.charAt(0).toUpperCase() + d.slice(1);
                }
            }
        }

        // Account and password
        ColumnLayout {
            Layout.alignment: Qt.AlignCenter
            Layout.preferredWidth: 340
            Layout.maximumWidth: 340
            spacing: 14

            // Avatar, with arrows to switch account (only with more than one)
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 18

                RoundButton {
                    visible: users.count > 1
                    glyph: "chevron_left"
                    onClicked: root.cycle(users, -1)
                }

                Rectangle {
                    implicitWidth: 112
                    implicitHeight: 112
                    radius: width / 2
                    color: t.button
                    border.width: 1
                    border.color: t.border
                    clip: true

                    Image {
                        id: avatar
                        anchors.fill: parent
                        anchors.margins: 1
                        source: !root.user?.icon ? "" : root.user.icon.startsWith("/") ? "file://" + root.user.icon : root.user.icon
                        fillMode: Image.PreserveAspectCrop
                        sourceSize.width: 224
                        sourceSize.height: 224
                    }
                    // SDDM gives a generic icon when there is no photo: the initial is shown instead
                    Text {
                        anchors.centerIn: parent
                        visible: avatar.status !== Image.Ready
                        text: (root.user?.name ?? "?").charAt(0).toUpperCase()
                        color: t.text
                        font.family: t.font
                        font.pixelSize: 44
                        font.weight: Font.Bold
                    }
                }

                RoundButton {
                    visible: users.count > 1
                    glyph: "chevron_right"
                    onClicked: root.cycle(users, 1)
                }
            }

            Text {
                Layout.alignment: Qt.AlignHCenter
                text: root.user ? (root.user.realName || root.user.name) : ""
                color: t.text
                font.family: t.font
                font.pixelSize: 22
                font.weight: Font.Bold
            }

            // Password in a pill, with the log-in button inside
            Rectangle {
                id: field
                Layout.fillWidth: true
                Layout.topMargin: 10
                implicitHeight: 50
                radius: height / 2
                color: t.surface
                border.width: 1
                border.color: password.activeFocus ? t.accent : t.border

                Behavior on border.color {
                    ColorAnimation { duration: 150 }
                }

                transform: Translate {
                    id: fieldShift
                }

                SequentialAnimation {
                    id: shake
                    NumberAnimation { target: fieldShift; property: "x"; to: -12; duration: 50 }
                    NumberAnimation { target: fieldShift; property: "x"; to: 12; duration: 70 }
                    NumberAnimation { target: fieldShift; property: "x"; to: -8; duration: 60 }
                    NumberAnimation { target: fieldShift; property: "x"; to: 0; duration: 50 }
                }

                TextInput {
                    id: password
                    anchors.left: parent.left
                    anchors.right: enter.left
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.leftMargin: 22
                    anchors.rightMargin: 10
                    echoMode: TextInput.Password
                    passwordCharacter: "●"
                    color: t.text
                    selectionColor: t.accent
                    selectedTextColor: t.accentText
                    font.family: t.font
                    font.pixelSize: 16
                    font.letterSpacing: 2
                    enabled: !root.busy
                    focus: true
                    clip: true
                    onAccepted: root.login()
                    onTextChanged: if (text) root.message = ""
                    Keys.onEscapePressed: text = ""

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !password.text
                        text: root.busy ? "A entrar…" : "Palavra-passe"
                        color: t.dim
                        font.family: t.font
                        font.pixelSize: 15
                    }
                }

                Rectangle {
                    id: enter
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.rightMargin: 6
                    width: 38
                    height: 38
                    radius: 19
                    color: t.accent
                    opacity: password.text ? 1 : 0.4
                    scale: enterMouse.pressed ? 0.92 : 1

                    Behavior on opacity {
                        NumberAnimation { duration: 150 }
                    }
                    Behavior on scale {
                        NumberAnimation { duration: 100 }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "arrow_forward"
                        font.family: icons.name
                        font.pixelSize: 20
                        color: t.accentText
                    }
                    MouseArea {
                        id: enterMouse
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.login()
                    }
                }
            }

            Text {
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredHeight: 20
                text: root.message
                color: "#ff6b6b"
                font.family: t.font
                font.pixelSize: 13
            }
        }
    }

    // ── Bottom: session on the left, power on the right ──────────────────────

    Pill {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.margins: 32
        visible: sessions.count > 1
        glyph: "desktop_windows"
        label: root.session?.name ?? ""
        onClicked: root.cycle(sessions, 1)
    }

    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 32
        spacing: 8

        Pill {
            visible: sddm.canSuspend
            glyph: "bedtime"
            label: "Suspender"
            onClicked: sddm.suspend()
        }
        Pill {
            visible: sddm.canReboot
            glyph: "restart_alt"
            label: "Reiniciar"
            onClicked: sddm.reboot()
        }
        Pill {
            visible: sddm.canPowerOff
            glyph: "power_settings_new"
            label: "Desligar"
            onClicked: sddm.powerOff()
        }
    }

    Component.onCompleted: password.forceActiveFocus()

    component RoundButton: Rectangle {
        id: button
        property string glyph: ""
        signal clicked

        implicitWidth: 36
        implicitHeight: 36
        radius: 18
        color: buttonMouse.containsMouse ? t.buttonHover : t.button

        Text {
            anchors.centerIn: parent
            text: button.glyph
            font.family: icons.name
            font.pixelSize: 22
            color: t.text
        }
        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }

    component Pill: Rectangle {
        id: pill
        property string glyph: ""
        property string label: ""
        signal clicked

        width: pillRow.implicitWidth + 32
        height: 40
        radius: 20
        color: pillMouse.containsMouse ? t.buttonHover : t.button
        border.width: 1
        border.color: t.border
        scale: pillMouse.pressed ? 0.96 : 1

        Behavior on color {
            ColorAnimation { duration: 150 }
        }

        Row {
            id: pillRow
            anchors.centerIn: parent
            spacing: 8
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: pill.glyph
                font.family: icons.name
                font.pixelSize: 18
                color: t.text
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: pill.label
                color: t.text
                font.family: t.font
                font.pixelSize: 14
            }
        }
        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
