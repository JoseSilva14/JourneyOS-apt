pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Exports the theme for what runs outside the shell, without Theme
// (~/.local/state/shadow-kde/theme.conf): the lock screen and the window decoration read this INI
// with QtCore's Settings. The decoration only reads the colours when KWin creates it: after each change, it is recreated.
Singleton {
    id: root

    readonly property string path: Quickshell.env("HOME") + "/.local/state/shadow-kde/theme.conf"

    function c(color) { return color.toString(); }

    readonly property string content: `[Theme]
light=${Theme.light}
bg=${c(Theme.bg)}
surface=${c(Theme.surface)}
surfaceCard=${c(Theme.surfaceCard)}
border=${c(Theme.surfaceBorder)}
button=${c(Theme.button)}
buttonHover=${c(Theme.buttonHover)}
text=${c(Theme.text)}
subtext=${c(Theme.subtext)}
dim=${c(Theme.dim)}
accent=${c(Theme.accent)}
accentText=${c(Theme.accentText)}
wallTop=${c(Theme.wallTop)}
wallBottom=${c(Theme.wallBottom)}
font=${Theme.font}
clock24=${Config.options.clock.use24h}
iconFont=${Quickshell.shellPath("assets/fonts/MaterialIconsRound-Regular.otf")}
logo=${Theme.logo.replace("file://", "")}

[User]
name=${User.name}
avatar=${User.face.replace("file://", "")}

[Desktop]
wallpaper=${Config.options.wallpaper}

[Strings]
locale=${Tr.locale.name}
date="${Tr.t("dddd, d MMMM")}"
wrongPassword=${Tr.t("Wrong password")}
suspend=${Tr.t("Sleep")}
password=${Tr.t("Password")}
checking=${Tr.t("Checking…")}
tryAgain="${Tr.t("Didn't get an answer, try again")}"
hello="${Tr.t("Hello, ")}"
starting=${Tr.t("Starting")}
`

    // Writes shortly after the last change (switching scheme touches several colours)
    onContentChanged: if (Config.ready) save.restart()

    Timer {
        id: save
        interval: 500
        onTriggered: {
            file.setText(root.content);
            // The decoration only after startup (the first write is the theme KWin already has);
            // the apps also at startup (the script does nothing if the colours did not change)
            syncLogin.restart();
            if (root.written)
                refreshDecoration.restart();
            else if (Config.options.theme.apps)
                Quickshell.execDetached([Quickshell.shellPath("scripts/kde-colors.py"), "apply"]);
            root.written = true;
        }
    }

    property bool written: false

    // The login screen (SDDM) follows the theme: scripts/sddm.sh sincronizar copies it to the shared
    // login folder (only does anything for admins, where that folder exists). After the file is on disk.
    Timer {
        id: syncLogin
        interval: 1500
        onTriggered: Quickshell.execDetached([Quickshell.shellPath("scripts/sddm.sh"), "sincronizar"])
    }

    // Recreate the window decoration (only does anything if it is the shell's) and, if enabled,
    // give the apps the same colours (the script only applies when the colours changed)
    Timer {
        id: refreshDecoration
        interval: 300
        onTriggered: {
            Quickshell.execDetached([Quickshell.shellPath("scripts/decoration.sh"), "refresh"]);
            if (Config.options.theme.apps)
                Quickshell.execDetached([Quickshell.shellPath("scripts/kde-colors.py"), "apply"]);
        }
    }

    // Turning the option on applies right away; turning it off goes back to Breeze
    readonly property bool appsFollow: Config.options.theme.apps
    onAppsFollowChanged: {
        if (!written)
            return;
        Quickshell.execDetached([Quickshell.shellPath("scripts/kde-colors.py"), appsFollow ? "apply" : "reset"]);
    }

    FileView {
        id: file
        path: root.path
        atomicWrites: true
        printErrors: false
    }

    Component.onCompleted: save.restart()
}
