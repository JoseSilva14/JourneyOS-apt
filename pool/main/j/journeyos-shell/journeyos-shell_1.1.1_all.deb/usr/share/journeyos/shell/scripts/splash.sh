#!/bin/sh
# The shell's session splash screen (KSplash): splash/ in this repository.
#   splash.sh apply     copies the package to ~/.local/share/plasma/look-and-feel (KPackage
#                       ignores symlinks) and selects it in ~/.config/ksplashrc
#   splash.sh default   goes back to the global theme's (deletes the keys)
#   splash.sh test      shows it in a window (closes by itself)
# ~/.config/ksplashrc takes precedence over ~/.config/kdedefaults (the global theme's).
set -e
here=$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)
id=org.shadowkde.splash
dest="$HOME/.local/share/plasma/look-and-feel/$id"

install_copy() {
    mkdir -p "$(dirname "$dest")"
    rm -rf "$dest.new"
    cp -rL "$here/splash" "$dest.new"
    rm -rf "$dest"
    mv "$dest.new" "$dest"
}

case "$1" in
    apply)
        install_copy
        kwriteconfig6 --file ksplashrc --group KSplash --key Engine KSplashQML
        kwriteconfig6 --file ksplashrc --group KSplash --key Theme "$id"
        ;;
    default)
        kwriteconfig6 --file ksplashrc --group KSplash --key Engine --delete
        kwriteconfig6 --file ksplashrc --group KSplash --key Theme --delete
        ;;
    test)
        install_copy
        exec ksplashqml "$id" --test --window --nofork
        ;;
    *)
        echo "usage: splash.sh apply|default|test"; exit 1
        ;;
esac
