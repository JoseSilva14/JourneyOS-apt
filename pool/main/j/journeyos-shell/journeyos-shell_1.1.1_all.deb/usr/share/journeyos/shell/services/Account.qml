pragma Singleton

import QtQuick
import Quickshell

// The user's account (AccountsService): name and photo; the password is
// changed with passwd in a terminal (it never goes through the shell).
Singleton {
    id: root

    readonly property string login: Quickshell.env("USER") || ""
    property string path: ""
    property string realName: ""
    property string iconFile: ""
    property bool admin: false

    function busctl(args, callback) {
        Run.cmd(["busctl", "--system", ...args], callback);
    }

    function refresh() {
        busctl(["call", "org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
            "FindUserByName", "s", login], (code, out) => {
            const m = out.match(/"([^"]+)"/);
            if (!m)
                return;
            root.path = m[1];
            const get = (prop, cb) => busctl(["get-property", "org.freedesktop.Accounts", root.path,
                "org.freedesktop.Accounts.User", prop], (c, o) => cb(o.trim()));
            get("RealName", v => root.realName = (v.match(/"(.*)"/) ?? [, ""])[1]);
            get("IconFile", v => root.iconFile = (v.match(/"(.*)"/) ?? [, ""])[1]);
            get("AccountType", v => root.admin = v.endsWith(" 1"));
        });
    }

    function setName(name) {
        if (!path || !name.trim())
            return;
        busctl(["call", "org.freedesktop.Accounts", path, "org.freedesktop.Accounts.User", "SetRealName", "s", name.trim()],
            () => refresh());
    }

    // Choosing a photo: copies it to ~/.face (what the shell uses) and hands it to
    // AccountsService (the login screen); the config's avatar option no longer takes precedence
    function choosePhoto() {
        Run.cmd(["kdialog", "--title", Tr.t("Choose photo"), "--getopenfilename",
            Quickshell.env("HOME") + "/Pictures", "image/png image/jpeg image/webp image/svg+xml"], (code, out) => {
            const file = out.trim();
            if (code !== 0 || !file)
                return;
            Run.cmd(["cp", "-f", file, Quickshell.env("HOME") + "/.face"], () => {
                busctl(["call", "org.freedesktop.Accounts", root.path, "org.freedesktop.Accounts.User",
                    "SetIconFile", "s", Quickshell.env("HOME") + "/.face"], () => refresh());
                Config.options.avatar = "";
            });
        });
    }

    function changePassword() {
        Apps.run(["konsole", "-e", "sh", "-c", "echo '" + Tr.t("Change the password of ") + login + "'; echo; passwd; echo; read -p '" + Tr.t("Press Enter to close") + " ' x"]);
    }
}
