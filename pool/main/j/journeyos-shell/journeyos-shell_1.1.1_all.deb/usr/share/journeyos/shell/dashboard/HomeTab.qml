import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services
import qs.panel
import qs.desktop.widgets

// Home tab: weather, calendar, computer usage and music.
RowLayout {
    id: root

    spacing: Theme.gap

    // Weather
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.preferredWidth: 3

        ColumnLayout {
            anchors.fill: parent
            spacing: 8
            visible: Weather.ready

            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                MIcon {
                    icon: "location_on"
                    size: 15
                    color: Theme.subtext
                }
                Text {
                    Layout.fillWidth: true
                    text: Weather.area
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                    font.weight: Font.DemiBold
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 14

                MIcon {
                    icon: Weather.icon
                    size: 56
                }
                ColumnLayout {
                    spacing: 0
                    Text {
                        text: Weather.temp + "°"
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 44
                        font.weight: Font.Bold
                    }
                    Text {
                        text: Weather.desc
                        color: Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                text: Tr.t("Feels like ") + Weather.feels + Tr.t("° · Humidity ") + Weather.humidity + Tr.t("% · Wind ") + Weather.wind + Tr.t(" km/h")
                wrapMode: Text.Wrap
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            Item { Layout.fillHeight: true }

            // Next days
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Repeater {
                    model: Weather.days

                    Rectangle {
                        id: day
                        required property var modelData
                        required property int index

                        Layout.fillWidth: true
                        implicitHeight: 92
                        radius: Theme.radius
                        color: Theme.button

                        Column {
                            anchors.centerIn: parent
                            spacing: 4

                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: {
                                    if (day.index === 0)
                                        return Tr.t("Today");
                                    const d = new Date(day.modelData.date + "T12:00:00");
                                    const s = Tr.locale.toString(d, "ddd").replace(".", "");
                                    return s.charAt(0).toUpperCase() + s.slice(1);
                                }
                                color: Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                            MIcon {
                                anchors.horizontalCenter: parent.horizontalCenter
                                icon: day.modelData.icon
                                size: 22
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: day.modelData.max + "° " + day.modelData.min + "°"
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                                font.weight: Font.DemiBold
                            }
                        }
                    }
                }
            }
        }

        Text {
            anchors.centerIn: parent
            visible: !Weather.ready
            text: Tr.t("No weather data")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }
    }

    CalendarWidget {
        Layout.fillHeight: true
        Layout.preferredWidth: height
        color: Theme.surfaceCard
        border.color: Theme.surfaceBorder
    }

    ColumnLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.preferredWidth: 3
        spacing: Theme.gap

        // Usage
        Tile {
            Layout.fillWidth: true
            Layout.fillHeight: true
            title: Tr.t("Usage")
            icon: "speed"

            RowLayout {
                anchors.fill: parent
                spacing: 8

                Usage { label: "CPU"; icon: "memory"; value: Stats.cpu }
                Usage { label: "RAM"; icon: "developer_board"; value: Stats.ram }
                Usage { label: Tr.t("Disk"); icon: "storage"; value: Stats.disk }
            }
        }

        MediaCard {
            Layout.fillWidth: true
        }
    }

    component Usage: ColumnLayout {
        id: usage

        property string label: ""
        property string icon: ""
        property real value: 0

        Layout.fillWidth: true
        spacing: 6

        Ring {
            Layout.alignment: Qt.AlignHCenter
            implicitWidth: 64
            implicitHeight: 64
            thickness: 4
            icon: usage.icon
            value: usage.value
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: Math.round(usage.value * 100) + "%"
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontMedium
            font.weight: Font.Bold
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: usage.label
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
