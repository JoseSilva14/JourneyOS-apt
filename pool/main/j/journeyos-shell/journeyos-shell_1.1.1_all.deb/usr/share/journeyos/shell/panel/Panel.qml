import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.services

// Quick panel: on the right, below the bar. Closes with Esc or by clicking outside.
PanelWindow {
    id: root

    // This instance's screen (the window's "screen" changes with "visible": binding loop)
    required property var modelScreen
    readonly property bool open: QuickPanel.open && QuickPanel.screen === modelScreen

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-panel"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: if (!open) closing.restart()

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    MouseArea {
        anchors.fill: parent
        onClicked: QuickPanel.open = false
    }

    Rectangle {
        id: panel

        readonly property real slide: root.open ? 0 : Theme.gap * 3

        // Content height (scrolls if it does not fit)
        width: Theme.panelWidth
        height: Math.min(column.implicitHeight + Theme.gap * 2, parent.height - Theme.gap * 2)
        y: Theme.gap
        x: parent.width - width - Theme.gap + slide
        opacity: root.open ? 1 : 0
        radius: Theme.radiusCard + 4
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        Behavior on x {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }

        focus: root.open
        Keys.onEscapePressed: QuickPanel.open = false

        // Clicks on the panel do not close it
        MouseArea {
            anchors.fill: parent
        }

        Flickable {
            anchors.fill: parent
            anchors.margins: Theme.gap
            contentHeight: column.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds

            ColumnLayout {
                id: column
                width: parent.width
                spacing: Theme.gap

                // The most used at the top: must fit without scrolling
                Header {
                    Layout.fillWidth: true
                }
                QuickToggles {
                    Layout.fillWidth: true
                }
                SlidersCard {
                    Layout.fillWidth: true
                }
                MediaCard {
                    Layout.fillWidth: true
                }
                CaptureCard {
                    Layout.fillWidth: true
                }
            }
        }
    }
}
