pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Networking

// The Wi-Fi connection form (menus/WifiForm): the state lives here, not in the network list,
// so it survives the list being rebuilt on every scan (the password field used to lose focus)
// and the bar menu closing (to pick a certificate, the form moves to Settings → Network).
//
// WPA/WPA2/WPA3 Personal of a visible network: Quickshell's connectWithPsk. Everything else
// (WEP, LEAP, 802.1X/Enterprise, hidden networks): scripts/wifi-connect.py over NetworkManager's D-Bus.
Singleton {
    id: root

    property bool active: false
    property var network: null          // the WifiNetwork (null = hidden network typed by hand)
    property bool hidden: false
    property string iface: ""           // the network's Wi-Fi card ("" = any managed one)
    property string ssid: ""
    // open | psk | sae | wep | leap | eap
    property string security: "psk"
    property string keyMgmt: "wpa-eap"  // eap: wpa-eap | wpa-eap-suite-b-192 | ieee8021x
    property string eap: "peap"         // peap | ttls | tls | pwd
    property string phase2: "mschapv2"
    property string identity: ""
    property string anonymous: ""
    property string password: ""
    property string domain: ""
    property string caCert: ""
    property string clientCert: ""
    property string privateKey: ""
    property string keyPassword: ""

    property bool busy: false
    property string error: ""

    readonly property bool enterprise: security === "eap" || security === "leap"
    readonly property var phase2Options: eap === "ttls"
        ? [{ id: "pap", label: "PAP" }, { id: "mschapv2", label: "MSCHAPv2" }, { id: "chap", label: "CHAP" }, { id: "gtc", label: "GTC" }]
        : [{ id: "mschapv2", label: "MSCHAPv2" }, { id: "gtc", label: "GTC" }, { id: "md5", label: "MD5" }]

    // What each Quickshell security type needs
    function kindOf(type) {
        switch (type) {
        case WifiSecurityType.Open:
        case WifiSecurityType.Owe:
            return "open";
        case WifiSecurityType.StaticWep:
            return "wep";
        case WifiSecurityType.Leap:
            return "leap";
        case WifiSecurityType.WpaEap:
        case WifiSecurityType.Wpa2Eap:
        case WifiSecurityType.Wpa3SuiteB192:
        case WifiSecurityType.DynamicWep:
            return "eap";
        default:
            return "psk";               // WpaPsk, Wpa2Psk, Sae (NM picks the key management from the AP)
        }
    }

    function clearFields() {
        identity = anonymous = password = domain = caCert = clientCert = privateKey = keyPassword = "";
        eap = "peap";
        phase2 = "mschapv2";
        error = "";
    }

    // A network from the list (n) or, without one, a hidden network
    function begin(n) {
        const same = active && network === n && n;
        network = n ?? null;
        hidden = !n;
        iface = n?.device?.name ?? "";
        if (!same) {
            clearFields();
            ssid = n ? n.name : "";
            security = n ? kindOf(n.security) : "psk";
            keyMgmt = !n ? "wpa-eap"
                : n.security === WifiSecurityType.Wpa3SuiteB192 ? "wpa-eap-suite-b-192"
                : n.security === WifiSecurityType.DynamicWep ? "ieee8021x" : "wpa-eap";
            if (keyMgmt === "wpa-eap-suite-b-192")
                eap = "tls";
        }
        busy = false;
        active = true;
    }

    function cancel() {
        if (busy)
            return;
        active = false;
        network = null;
        clearFields();
    }

    readonly property bool ready: {
        if (!ssid.trim() || busy)
            return false;
        switch (security) {
        case "open": return true;
        case "psk":
        case "sae": return password.length >= 8 && password.length <= 64;
        case "wep": return password.length > 0;
        case "leap": return identity.length > 0 && password.length > 0;
        default: return identity.length > 0 && (eap === "tls" ? clientCert && privateKey : password.length > 0);
        }
    }

    function submit() {
        if (!ready)
            return;
        error = "";
        // Visible WPA network: Quickshell's own path (keeps the network's saved settings)
        if (network && !hidden && security === "psk") {
            network.connectWithPsk(password);
            active = false;
            network = null;
            clearFields();
            return;
        }
        busy = true;
        const req = {
            ssid: ssid.trim(), hidden, security, keyMgmt, eap, phase2, identity, anonymous,
            password, domain, caCert, clientCert, privateKey, keyPassword, iface
        };
        helper.request = JSON.stringify(req) + "\n";
        helper.running = true;
    }

    // Called by the network list when a saved network asks for secrets again
    // (same network already in the form: keep what was typed - user, certificates, hidden - and only
    // ask for the password again)
    function failed(n) {
        if (!(active && ssid === n.name))
            begin(n);
        password = "";
        error = Tr.t("Couldn't connect. Check the details and try again.");
    }

    // Certificate file (kdialog). It is a normal window: the bar menu (above everything) is closed
    // and the form goes on in Settings → Network.
    function pick(field) {
        if (BarMenu.open !== "")
            SettingsApp.show("network");
        const titles = {
            caCert: Tr.t("CA certificate"), clientCert: Tr.t("User certificate"), privateKey: Tr.t("Private key")
        };
        Run.cmd(["kdialog", "--title", titles[field] ?? "", "--getopenfilename", Quickshell.env("HOME"),
                 "*.pem *.crt *.cer *.der *.p12 *.pfx *.key|" + Tr.t("Certificates and keys") + "\n*|" + Tr.t("All files")],
            (code, out) => {
                if (code === 0 && out.trim())
                    root[field] = out.trim();
            });
    }

    // Tests without a mouse: wifi form <ssid> ("" = hidden) | set <field> <value> | submit | cancel | status
    IpcHandler {
        target: "wifi"
        function form(ssid: string): string {
            const devs = Networking.devices.values;
            const dev = devs.find(d => d.type === DeviceType.Wifi && d.nmManaged) ?? devs.find(d => d.type === DeviceType.Wifi);
            const n = ssid ? dev?.networks.values.find(x => x.name === ssid) : null;
            if (ssid && !n)
                return "no network " + ssid;
            root.begin(n);
            if (BarMenu.open !== "network")
                BarMenu.toggle("network", null);
            return "ok";
        }
        // The cards the shell sees and their networks (diagnostics)
        function devices(): string {
            return JSON.stringify(Networking.devices.values.map(d => ({
                name: d.name, type: d.type, managed: d.nmManaged,
                networks: d.type === DeviceType.Wifi ? d.networks.values.map(n => n.name) : undefined
            })));
        }
        function set(field: string, value: string): void { root[field] = value; }
        function submit(): void { root.submit(); }
        function cancel(): void { root.cancel(); }
        function status(): string {
            return JSON.stringify({ active: root.active, ssid: root.ssid, security: root.security, eap: root.eap,
                phase2: root.phase2, ready: root.ready, busy: root.busy, error: root.error,
                passwordLength: root.password.length });
        }
    }

    Process {
        id: helper
        property string request: ""
        command: [Quickshell.shellPath("scripts/wifi-connect.py")]
        stdinEnabled: true
        onStarted: write(request)
        stdout: SplitParser {
            onRead: line => {
                let r;
                try {
                    r = JSON.parse(line);
                } catch (e) {
                    return;
                }
                root.busy = false;
                if (r.ok) {
                    root.active = false;
                    root.network = null;
                    root.clearFields();
                } else {
                    root.error = r.error === "failed" || r.error === "timeout"
                        ? Tr.t("Couldn't connect. Check the details and try again.")
                        : Tr.t("Couldn't connect: ") + r.error;
                }
            }
        }
        onExited: (code) => {
            helper.request = "";
            if (root.busy) {
                root.busy = false;
                root.error = Tr.t("Couldn't connect. Check the details and try again.");
            }
        }
    }
}
