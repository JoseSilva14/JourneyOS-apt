pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Conversions for the launcher (results ready to copy); the examples are the Portuguese input:
//   percentages: "15% de 230", "230 + 15%", "30 de 120 em %", "de 80 para 100"
//   units:       "5 km em milhas", "30 c em f", "2 gb em mb", "90 min em h"
//   currencies:  "20 usd em eur", "20€ em dólares" (ECB rates via frankfurter.dev, fetched only
//                when a currency is requested and cached for a day in ~/.cache/shadow-kde/rates.json)
//   times:       "14h em Tóquio", "hora em Nova Iorque", "9:30 de Sydney" (scripts/fuso.py)
// Each result: { title, subtitle, copy, glyph }.
Singleton {
    id: root

    function fold(s) { return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim(); }
    function num(s) { return parseFloat(String(s).replace(/\s/g, "").replace(",", ".")); }
    // Up to 6 significant decimal places, Portuguese style
    function fmt(v) {
        const abs = Math.abs(v);
        const digits = abs >= 1000 ? 2 : abs >= 1 ? 4 : 6;
        const r = Math.round(v * Math.pow(10, digits)) / Math.pow(10, digits);
        return r.toLocaleString(Tr.locale, "f", digits).replace(/[.,]?0+$/, "");
    }
    // For copying: with a dot, no thousands separators
    function plain(v) { return String(Math.round(v * 1e6) / 1e6); }

    readonly property string numRe: "(-?\\d+(?:[.,]\\d+)?)"

    // --- Percentages ---
    function percent(q) {
        let m = new RegExp("^" + numRe + "\\s*%\\s*(?:de|of)\\s*" + numRe + "$").exec(q);
        if (m) {
            const v = num(m[1]) / 100 * num(m[2]);
            return { title: "= " + fmt(v), subtitle: fmt(num(m[1])) + Tr.t(" % of ") + fmt(num(m[2])), copy: plain(v), glyph: "percent" };
        }
        m = new RegExp("^" + numRe + "\\s*([+-])\\s*" + numRe + "\\s*%$").exec(q);
        if (m) {
            const base = num(m[1]), pct = num(m[3]) * (m[2] === "-" ? -1 : 1);
            const v = base * (1 + pct / 100);
            return { title: "= " + fmt(v), subtitle: fmt(base) + (pct < 0 ? Tr.t(" minus ") : Tr.t(" plus ")) + fmt(Math.abs(pct)) + " %",
                copy: plain(v), glyph: "percent" };
        }
        m = new RegExp("^" + numRe + "\\s*(?:de|em|of|in)\\s*" + numRe + "\\s*(?:em|in|=)\\s*%$").exec(q);
        if (m && num(m[2]) !== 0) {
            const v = num(m[1]) / num(m[2]) * 100;
            return { title: "= " + fmt(v) + " %", subtitle: fmt(num(m[1])) + Tr.t(" in ##em") + fmt(num(m[2])), copy: plain(v) + "%", glyph: "percent" };
        }
        m = new RegExp("^(?:de|from)\\s*" + numRe + "\\s*(?:para|a|to)\\s*" + numRe + "$").exec(q);
        if (m && num(m[1]) !== 0) {
            const v = (num(m[2]) - num(m[1])) / Math.abs(num(m[1])) * 100;
            return { title: "= " + (v > 0 ? "+" : "") + fmt(v) + " %", subtitle: Tr.t("Change from ") + fmt(num(m[1])) + Tr.t(" to ") + fmt(num(m[2])),
                copy: plain(v) + "%", glyph: v >= 0 ? "trending_up" : "trending_down" };
        }
        return null;
    }

    // --- Units: factor to each group's base unit (temperature handled separately) ---
    readonly property var unitList: [
        // length (m)
        { g: "len", f: 0.001, n: "mm", a: ["mm", "milimetro", "milimetros", "millimeter", "millimeters", "millimetre", "millimetres"] },
        { g: "len", f: 0.01, n: "cm", a: ["cm", "centimetro", "centimetros", "centimeter", "centimeters", "centimetre", "centimetres"] },
        { g: "len", f: 1, n: "m", a: ["m", "metro", "metros", "meter", "meters", "metre", "metres"] },
        { g: "len", f: 1000, n: "km", a: ["km", "quilometro", "quilometros", "kms", "kilometer", "kilometers", "kilometre", "kilometres"] },
        { g: "len", f: 0.0254, n: "in", a: ["in", "inch", "inches", "pol", "polegada", "polegadas", "\""] },
        { g: "len", f: 0.3048, n: "ft", a: ["ft", "pe", "pes", "feet", "foot"] },
        { g: "len", f: 0.9144, n: "yd", a: ["yd", "yard", "yards", "jarda", "jardas"] },
        { g: "len", f: 1609.344, n: "mi", a: ["mi", "milha", "milhas", "miles", "mile"] },
        { g: "len", f: 1852, n: "nmi", a: ["nmi", "milha nautica", "milhas nauticas", "nautical mile", "nautical miles"] },
        // mass (g)
        { g: "mass", f: 0.001, n: "mg", a: ["mg", "miligrama", "miligramas"] },
        { g: "mass", f: 1, n: "g", a: ["g", "grama", "gramas", "gram", "grams"] },
        { g: "mass", f: 1000, n: "kg", a: ["kg", "quilo", "quilos", "quilograma", "quilogramas", "kgs", "kilo", "kilos", "kilogram", "kilograms"] },
        { g: "mass", f: 1e6, n: "t", a: ["t", "tonelada", "toneladas", "ton", "tons", "tonne", "tonnes"] },
        { g: "mass", f: 28.349523125, n: "oz", a: ["oz", "onca", "oncas", "ounce", "ounces"] },
        { g: "mass", f: 453.59237, n: "lb", a: ["lb", "lbs", "libra", "libras", "pound", "pounds"] },
        // volume (l)
        { g: "vol", f: 0.001, n: "ml", a: ["ml", "mililitro", "mililitros", "milliliter", "milliliters", "millilitre", "millilitres"] },
        { g: "vol", f: 0.01, n: "cl", a: ["cl", "centilitro", "centilitros"] },
        { g: "vol", f: 0.1, n: "dl", a: ["dl", "decilitro", "decilitros"] },
        { g: "vol", f: 1, n: "l", a: ["l", "litro", "litros", "liter", "liters", "litre", "litres"] },
        { g: "vol", f: 1000, n: "m³", a: ["m3", "m³", "metro cubico", "metros cubicos"] },
        { g: "vol", f: 3.785411784, n: "gal", a: ["gal", "galao", "galoes", "gallon", "gallons"] },
        { g: "vol", f: 0.2365882365, n: "cups", a: ["chavena", "chavenas", "cup", "cups"] },
        // area (m²)
        { g: "area", f: 1, n: "m²", a: ["m2", "m²", "metro quadrado", "metros quadrados"] },
        { g: "area", f: 1e6, n: "km²", a: ["km2", "km²", "quilometro quadrado", "quilometros quadrados"] },
        { g: "area", f: 10000, n: "ha", a: ["ha", "hectare", "hectares"] },
        { g: "area", f: 0.09290304, n: "ft²", a: ["ft2", "ft²", "pes quadrados", "sqft", "square feet"] },
        { g: "area", f: 4046.8564224, n: "acres", a: ["acre", "acres"] },
        // speed (m/s)
        { g: "speed", f: 1, n: "m/s", a: ["m/s", "ms"] },
        { g: "speed", f: 1 / 3.6, n: "km/h", a: ["km/h", "kmh", "kph"] },
        { g: "speed", f: 0.44704, n: "mph", a: ["mph", "milhas por hora"] },
        { g: "speed", f: 0.514444, n: "kn", a: ["no", "nos", "kn", "knot", "knots"] },
        // data (bytes)
        { g: "data", f: 0.125, n: "bits", a: ["bit", "bits"] },
        { g: "data", f: 1, n: "B", a: ["b", "byte", "bytes"] },
        { g: "data", f: 1e3, n: "KB", a: ["kb", "kilobyte", "kilobytes"] },
        { g: "data", f: 1e6, n: "MB", a: ["mb", "megabyte", "megabytes", "mega", "megas"] },
        { g: "data", f: 1e9, n: "GB", a: ["gb", "gigabyte", "gigabytes", "giga", "gigas"] },
        { g: "data", f: 1e12, n: "TB", a: ["tb", "terabyte", "terabytes"] },
        { g: "data", f: 1024, n: "KiB", a: ["kib"] },
        { g: "data", f: 1048576, n: "MiB", a: ["mib"] },
        { g: "data", f: 1073741824, n: "GiB", a: ["gib"] },
        { g: "data", f: 1099511627776, n: "TiB", a: ["tib"] },
        // time (s)
        { g: "time", f: 0.001, n: "ms", a: ["milissegundo", "milissegundos"] },
        { g: "time", f: 1, n: "s", a: ["s", "seg", "segundo", "segundos", "sec", "secs", "second", "seconds"] },
        { g: "time", f: 60, n: "min", a: ["min", "mins", "minuto", "minutos", "minute", "minutes"] },
        { g: "time", f: 3600, n: "h", a: ["h", "hora", "horas", "hour", "hours", "hr", "hrs"] },
        { g: "time", f: 86400, n: "days", a: ["d", "dia", "dias", "day", "days"] },
        { g: "time", f: 604800, n: "weeks", a: ["semana", "semanas", "week", "weeks"] },
        { g: "time", f: 31557600, n: "years", a: ["ano", "anos", "year", "years"] },
        // energy (J) and power (W)
        { g: "energy", f: 1, n: "J", a: ["j", "joule", "joules"] },
        { g: "energy", f: 4184, n: "kcal", a: ["kcal", "calorie", "calories", "caloria", "calorias", "quilocaloria", "quilocalorias"] },
        { g: "energy", f: 3.6e6, n: "kWh", a: ["kwh"] },
        { g: "power", f: 1, n: "W", a: ["w", "watt", "watts"] },
        { g: "power", f: 1000, n: "kW", a: ["kw", "quilowatt", "quilowatts"] },
        { g: "power", f: 735.49875, n: "cv", a: ["cv", "cavalo", "cavalos"] },
        { g: "power", f: 745.69987, n: "hp", a: ["hp", "horsepower"] },
        // temperature (formulas)
        { g: "temp", n: "°C", a: ["c", "°c", "ºc", "celsius", "graus", "graus celsius", "degrees", "degrees celsius"] },
        { g: "temp", n: "°F", a: ["f", "°f", "ºf", "fahrenheit"] },
        { g: "temp", n: "K", a: ["k", "kelvin"] }
    ]
    readonly property var unitIndex: {
        const out = {};
        for (const u of unitList)
            for (const a of u.a)
                out[a] = u;
        return out;
    }

    function toKelvin(v, n) { return n === "°C" ? v + 273.15 : n === "°F" ? (v - 32) * 5 / 9 + 273.15 : v; }
    function fromKelvin(v, n) { return n === "°C" ? v - 273.15 : n === "°F" ? (v - 273.15) * 9 / 5 + 32 : v; }

    // "5 km em milhas" ("5 km in miles") → [value, from, to] (the value may be missing: 1)
    function split(q) {
        const m = /^(-?\d+(?:[.,]\d+)?)?\s*(.+?)\s+(?:em|para|in|to|->|→|=)\s+(.+)$/.exec(q);
        return m ? [m[1] !== undefined ? num(m[1]) : 1, m[2].trim(), m[3].trim()] : null;
    }

    function units(q) {
        const p = split(q);
        if (!p)
            return null;
        const a = unitIndex[p[1]], b = unitIndex[p[2]];
        if (!a || !b || a.g !== b.g || a === b)
            return null;
        const v = a.g === "temp" ? fromKelvin(toKelvin(p[0], a.n), b.n) : p[0] * a.f / b.f;
        return { title: "= " + fmt(v) + " " + Tr.t(b.n), subtitle: fmt(p[0]) + " " + Tr.t(a.n), copy: plain(v), glyph: a.g === "temp" ? "thermostat" : "straighten" };
    }

    // --- Currencies ---
    property var rates: ({})
    property string ratesDate: ""
    property real ratesFetched: 0
    property bool ratesLoading: false

    readonly property var currencyAliases: ({ "€": "EUR", "euro": "EUR", "euros": "EUR", "$": "USD", "us$": "USD",
        "dolar": "USD", "dolares": "USD", "£": "GBP", "libra esterlina": "GBP", "libras esterlinas": "GBP",
        "real": "BRL", "reais": "BRL", "r$": "BRL", "¥": "JPY", "iene": "JPY", "ienes": "JPY", "yuan": "CNY",
        "renminbi": "CNY", "franco suico": "CHF", "francos suicos": "CHF", "rupia": "INR", "rupias": "INR",
        "zloty": "PLN", "coroa sueca": "SEK", "coroas suecas": "SEK", "dolar canadiano": "CAD",
        "dolares canadianos": "CAD", "dolar australiano": "AUD", "dolares australianos": "AUD", "peso mexicano": "MXN" })

    function currency(word) {
        const w = word.trim();
        if (currencyAliases[w])
            return currencyAliases[w];
        const code = w.toUpperCase();
        return /^[A-Z]{3}$/.test(code) && (code === "EUR" || code in rates || !ratesDate) ? code : "";
    }

    function money(q) {
        // "20€" / "$20" / "€ 20": the symbol moves after the number
        const t = q.replace(/^([€$£¥]|r\$|us\$)\s*(\d)/, "$2 $1").replace(/(\d)\s*([€$£¥])(?=\s)/, "$1 $2");
        const p = split(t);
        if (!p)
            return null;
        const a = currency(p[1]), b = currency(p[2]);
        if (!a || !b || a === b)
            return null;
        // Called inside a binding: fetching the rates is deferred
        if (!ratesDate || Date.now() - ratesFetched > 12 * 3600000)
            Qt.callLater(fetchRates);
        if (!ratesDate)
            return { title: ratesLoading ? Tr.t("Fetching exchange rates…") : Tr.t("No exchange rates (offline?)"), subtitle: a + " → " + b,
                copy: "", glyph: "currency_exchange", keep: true };
        const ra = a === "EUR" ? 1 : rates[a], rb = b === "EUR" ? 1 : rates[b];
        if (!ra || !rb)
            return null;
        const v = p[0] / ra * rb;
        const r = Math.round(v * 100) / 100;
        return { title: "= " + r.toLocaleString(Tr.locale, "f", 2) + " " + b,
            subtitle: fmt(p[0]) + " " + a + Tr.t(" · ECB rate of ") + ratesDate.split("-").reverse().join("/"),
            copy: r.toFixed(2), glyph: "currency_exchange" };
    }

    readonly property string ratesPath: Quickshell.env("HOME") + "/.cache/shadow-kde/rates.json"

    function fetchRates() {
        if (ratesLoading)
            return;
        ratesLoading = true;
        Run.cmd(["curl", "-fsS", "-m", "10", "https://api.frankfurter.dev/v1/latest"], (code, out) => {
            root.ratesLoading = false;
            if (code !== 0)
                return;
            try {
                const j = JSON.parse(out);
                root.rates = j.rates;
                root.ratesDate = j.date;
                root.ratesFetched = Date.now();
                ratesFile.setText(JSON.stringify({ date: j.date, fetched: root.ratesFetched, rates: j.rates }) + "\n");
            } catch (e) {
                console.warn("exchange rates:", e);
            }
        });
    }

    FileView {
        id: ratesFile
        path: root.ratesPath
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const j = JSON.parse(text());
                root.rates = j.rates ?? {};
                root.ratesDate = j.date ?? "";
                root.ratesFetched = j.fetched ?? 0;
            } catch (e) {
            }
        }
    }

    // --- Times in other places (asynchronous: the launcher shows it when it arrives) ---
    property string tzFor: ""
    property var tzResult: null

    // "14h em tóquio" ("2pm in Tokyo") → { time: "14:00", dir: "em", place } ; "hora em tóquio" ("time in Tokyo") → now
    function tzQuery(q) {
        let m = /^(?:que\s+|what\s+)?(?:horas?|agora|time|now)(?:\s+sao|\s+is\s+it)?\s+(?:em|no|na|nos|nas|in|at)\s+(.+)$/.exec(q);
        if (m)
            return { time: "agora", dir: "em", place: m[1] };
        m = /^(\d{1,2})(?::(\d{2})|h(\d{2})?)\s+(em|no|na|nos|nas|in|at|de|do|da|dos|das|from)\s+(.+)$/.exec(q);
        if (m && Number(m[1]) < 24 && Number(m[2] ?? m[3] ?? 0) < 60)
            return { time: m[1].padStart(2, "0") + ":" + (m[2] ?? m[3] ?? "00"), dir: /^(d|from)/.test(m[4]) ? "de" : "em", place: m[5] };
        // 2pm / 2:30pm
        m = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s+(em|no|na|in|at|de|do|da|from)\s+(.+)$/.exec(q);
        if (m && Number(m[1]) >= 1 && Number(m[1]) <= 12 && Number(m[2] ?? 0) < 60) {
            const h = Number(m[1]) % 12 + (m[3] === "pm" ? 12 : 0);
            return { time: String(h).padStart(2, "0") + ":" + (m[2] ?? "00"), dir: /^(d|from)/.test(m[4]) ? "de" : "em", place: m[5] };
        }
        return null;
    }

    Timer {
        id: tzTimer
        interval: 150
        property string q: ""
        onTriggered: {
            const t = root.tzQuery(q);
            const asked = q;
            if (!t)
                return;
            Run.cmd([Quickshell.shellPath("scripts/fuso.py"), t.time, t.dir, t.place], (code, out) => {
                if (root.tzFor !== asked)
                    return;
                try {
                    root.tzResult = out.trim() ? Object.assign(JSON.parse(out), t) : null;
                } catch (e) {
                    root.tzResult = null;
                }
            }, { SHADOW_LANG: Tr.lang });
        }
    }

    // Requests the time (changes state: never inside a binding)
    function askTz(q) {
        if (q === tzFor)
            return;
        tzFor = q;
        tzResult = null;
        if (tzQuery(q)) {
            tzTimer.q = q;
            tzTimer.restart();
        }
    }

    function tz(q) {
        const r = q === tzFor ? tzResult : null;
        if (!r)
            return null;
        const ahead = r.diff === 0 ? Tr.t("same time") : Math.abs(r.diff) + " h " + (r.diff > 0 ? Tr.t("ahead") : Tr.t("behind"));
        const dayText = r.day > 0 ? Tr.t(" (next day)") : r.day < 0 ? Tr.t(" (previous day)") : "";
        if (r.dir === "de")
            return { title: r.here + Tr.t(" here") + dayText, subtitle: r.time + Tr.t(" in ##em") + r.city + " · " + r.city + Tr.t(" is ") + ahead,
                copy: r.here, glyph: "schedule" };
        return { title: r.there + Tr.t(" in ##em") + r.city + dayText, subtitle: (r.time === "agora" ? Tr.t("Now") : r.here + Tr.t(" here")) + " · " + r.city + Tr.t(" is ") + ahead,
            copy: r.there, glyph: "schedule" };
    }

    // Everything recognised, in order; null if nothing
    function results(raw) {
        const q = fold(raw);
        if (!q)
            return [];
        if (q !== tzFor)
            Qt.callLater(() => root.askTz(q));
        return [percent(q), units(q), money(q), tz(q)].filter(x => x);
    }

    // Looks like a conversion (so the launcher does not search files)
    function looksLike(raw) {
        const q = fold(raw);
        return !!(percent(q) || tzQuery(q) || (split(q) && (units(q) || (currency(split(q)[1]) && currency(split(q)[2])))));
    }

    IpcHandler {
        target: "convert"
        // What the launcher would show (times arrive a bit later: ask again)
        function query(text: string): string {
            root.askTz(root.fold(text));
            return root.results(text).map(r => r.title + " | " + r.subtitle).join("\n");
        }
    }
}
