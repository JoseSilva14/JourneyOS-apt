pragma Singleton

import QtQuick
import Quickshell

// Date and time: time zone and automatic sync (timedatectl, asks for
// authorization) and the shell clock format (config.json, clock.use24h / clock.seconds).
Singleton {
    id: root

    property string timezone: ""
    property bool ntp: false
    property bool synced: false
    property var timezones: []

    readonly property bool use24h: Config.options.clock.use24h

    // Time in the chosen format (24 h or 12 h with AM/PM)
    function time(date) { return Qt.formatTime(date, use24h ? "HH:mm" : "h:mm AP"); }
    // Hours only, for the big clock
    function hours(date) { return Qt.formatTime(date, use24h ? "HH" : "h"); }

    function refresh() {
        Run.cmd(["timedatectl", "show"], (code, out) => {
            for (const line of out.split("\n")) {
                const i = line.indexOf("=");
                const k = line.slice(0, i), v = line.slice(i + 1);
                if (k === "Timezone") root.timezone = v;
                else if (k === "NTP") root.ntp = v === "yes";
                else if (k === "NTPSynchronized") root.synced = v === "yes";
            }
        });
        if (!timezones.length)
            Run.cmd(["timedatectl", "list-timezones"], (code, out) => root.timezones = out.trim().split("\n"));
    }

    function setTimezone(tz) {
        Run.cmd(["timedatectl", "set-timezone", tz], () => refresh());
    }

    function setNtp(on) {
        Run.cmd(["timedatectl", "set-ntp", on ? "true" : "false"], () => refresh());
    }
}
