import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs
import qs.components
import qs.services

// Shell calculator: a normal window (KWin decoration, shows in the dock) in the shell's
// style. Display with the expression and the live result, basic or scientific keypad, history on the
// right (clicking reuses the calculation). Keyboard: numbers and operators, Enter/=, Backspace,
// Esc clears, Ctrl+C copies the result. Also understands conversions ("5 km in miles").
FloatingWindow {
    id: root

    title: Tr.t("Calculator")
    visible: Calculator.open
    implicitWidth: (Calculator.scientific ? 452 : 340) + (Calculator.showHistory ? Theme.calcHistoryWidth : 0)
    implicitHeight: 540
    color: Theme.bg

    onVisibleChanged: {
        if (!visible)
            Calculator.open = false;
        else
            keys.forceActiveFocus();
    }

    // Keys: [label, type] (type: num | op | fn | eq | clear)
    readonly property var basic: [
        ["C", "clear"], ["⌫", "fn"], ["%", "op"], ["÷", "op"],
        ["7", "num"], ["8", "num"], ["9", "num"], ["×", "op"],
        ["4", "num"], ["5", "num"], ["6", "num"], ["−", "op"],
        ["1", "num"], ["2", "num"], ["3", "num"], ["+", "op"],
        ["±", "fn"], ["0", "num"], [Calculator.dec, "num"], ["=", "eq"]
    ]
    readonly property var science: [
        ["(", "fn"], [")", "fn"],
        ["sin", "fn"], ["cos", "fn"],
        ["tan", "fn"], ["√", "fn"],
        ["x²", "fn"], ["^", "op"],
        ["log", "fn"], ["ln", "fn"],
        ["π", "fn"], ["e", "fn"]
    ]

    Item {
        id: keys
        anchors.fill: parent
        focus: true

        Keys.onPressed: event => {
            const ctrl = event.modifiers & Qt.ControlModifier;
            if (ctrl && event.key === Qt.Key_C) {
                Calculator.copyResult();
            } else if (ctrl && event.key === Qt.Key_V) {
                pasteProc.running = true;
            } else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter || event.key === Qt.Key_Equal) {
                Calculator.press("=");
            } else if (event.key === Qt.Key_Backspace) {
                Calculator.press("⌫");
            } else if (event.key === Qt.Key_Escape || event.key === Qt.Key_Delete) {
                Calculator.press("C");
            } else {
                const map = { "*": "×", "/": "÷", "-": "−", ".": Calculator.dec, ",": Calculator.dec, "x": "×" };
                const t = event.text;
                if (/^[0-9+%^()]$/.test(t))
                    Calculator.press(t);
                else if (map[t])
                    Calculator.press(map[t]);
                else
                    return;
            }
            event.accepted = true;
        }

        // Ctrl+V: pastes the expression (only what looks like a calculation)
        Process {
            id: pasteProc
            command: ["wl-paste", "--no-newline"]
            stdout: StdioCollector {
                onStreamFinished: {
                    const t = text.trim().replace(/\*/g, "×").replace(/\//g, "÷");
                    if (t && t.length < 200)
                        Calculator.expr += t;
                }
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.margins: Theme.gap
            spacing: Theme.gap

            // --- Calculator ---
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: Theme.gap

                // Display
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 120
                    radius: Theme.radiusCard
                    color: Theme.surfaceCard
                    border.width: 1
                    border.color: Theme.surfaceBorder

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 2

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 6

                            // Scientific / basic and history
                            Chip {
                                text: Calculator.scientific ? Tr.t("Scientific") : Tr.t("Basic")
                                glyph: "functions"
                                active: Calculator.scientific
                                onClicked: Calculator.scientific = !Calculator.scientific
                            }
                            Item { Layout.fillWidth: true }
                            Chip {
                                glyph: "history"
                                active: Calculator.showHistory
                                onClicked: Calculator.showHistory = !Calculator.showHistory
                            }
                        }

                        Item { Layout.fillHeight: true }

                        // The expression
                        Text {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignRight
                            text: Calculator.expr || "0"
                            elide: Text.ElideLeft
                            color: Calculator.justEvaluated ? Theme.text : Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Calculator.justEvaluated ? Theme.fontStat + 6 : Theme.fontMedium
                            font.weight: Calculator.justEvaluated ? Font.Bold : Font.Normal
                        }
                        // The live result (or the error)
                        Text {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignRight
                            visible: !Calculator.justEvaluated
                            text: Calculator.error || (Calculator.live ? "= " + Calculator.live.text : " ")
                            elide: Text.ElideLeft
                            color: Calculator.error ? Theme.privacyMic : Theme.text
                            font.family: Theme.font
                            font.pixelSize: Calculator.error ? Theme.fontNormal : Theme.fontStat + 6
                            font.weight: Font.Bold

                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Calculator.live ? Qt.PointingHandCursor : Qt.ArrowCursor
                                onClicked: Calculator.copyResult()
                            }
                        }
                    }
                }

                // Keypad
                RowLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    spacing: 8

                    // Scientific (on the left)
                    GridLayout {
                        visible: Calculator.scientific
                        // Fixed width: the keys ask for fillWidth and, without a limit, this column ate the keypad
                        Layout.preferredWidth: 104
                        Layout.maximumWidth: 104
                        Layout.fillWidth: false
                        Layout.fillHeight: true
                        columns: 2
                        rowSpacing: 8
                        columnSpacing: 8

                        Repeater {
                            model: root.science
                            Key {
                                required property var modelData
                                label: modelData[0]
                                kind: modelData[1]
                                small: true
                            }
                        }
                    }

                    GridLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        columns: 4
                        rowSpacing: 8
                        columnSpacing: 8

                        Repeater {
                            model: root.basic
                            Key {
                                required property var modelData
                                label: modelData[0]
                                kind: modelData[1]
                            }
                        }
                    }
                }
            }

            // --- History ---
            Rectangle {
                visible: Calculator.showHistory
                Layout.preferredWidth: Theme.calcHistoryWidth - Theme.gap
                Layout.fillHeight: true
                radius: Theme.radiusCard
                color: Theme.surfaceCard
                border.width: 1
                border.color: Theme.surfaceBorder

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 8

                    RowLayout {
                        Layout.fillWidth: true
                        MIcon {
                            icon: "history"
                            size: 15
                            color: Theme.subtext
                        }
                        Text {
                            Layout.fillWidth: true
                            text: Tr.t("History")
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            font.weight: Font.DemiBold
                        }
                        Chip {
                            visible: Calculator.history.length > 0
                            text: Tr.t("Clear")
                            onClicked: Calculator.clearHistory()
                        }
                    }

                    ListView {
                        id: historyList
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 2
                        boundsBehavior: Flickable.StopAtBounds
                        model: Calculator.history

                        delegate: Rectangle {
                            id: hrow
                            required property var modelData
                            width: historyList.width
                            implicitHeight: hcol.implicitHeight + 14
                            radius: Theme.radiusSmall
                            color: hmouse.containsMouse ? Theme.buttonHover : "transparent"

                            ColumnLayout {
                                id: hcol
                                anchors.left: parent.left
                                anchors.right: parent.right
                                anchors.verticalCenter: parent.verticalCenter
                                anchors.margins: 8
                                spacing: 0
                                Text {
                                    Layout.fillWidth: true
                                    horizontalAlignment: Text.AlignRight
                                    text: hrow.modelData.expr
                                    elide: Text.ElideLeft
                                    color: Theme.subtext
                                    font.family: Theme.font
                                    font.pixelSize: Theme.fontSmall
                                }
                                Text {
                                    Layout.fillWidth: true
                                    horizontalAlignment: Text.AlignRight
                                    text: "= " + hrow.modelData.result
                                    elide: Text.ElideLeft
                                    color: Theme.text
                                    font.family: Theme.font
                                    font.pixelSize: Theme.fontNormal
                                    font.weight: Font.DemiBold
                                }
                            }
                            MouseArea {
                                id: hmouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    Calculator.useHistory(hrow.modelData);
                                    keys.forceActiveFocus();
                                }
                            }
                        }
                    }

                    Text {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        visible: Calculator.history.length === 0
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        wrapMode: Text.WordWrap
                        text: Tr.t("Your calculations show up here. Click one to use it again.")
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }
        }
    }

    // One key of the calculator keypad
    component Key: Rectangle {
        id: key
        property string label: ""
        property string kind: "num"     // num | op | fn | eq | clear
        property bool small: false

        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.minimumHeight: 40
        radius: Theme.radius
        color: kind === "eq" ? (keyMouse.containsMouse ? Qt.lighter(Theme.accent, 1.1) : Theme.accent)
            : kind === "op" ? (keyMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard)
            : keyMouse.containsMouse ? Theme.buttonHover : Theme.button
        border.width: kind === "op" ? 1 : 0
        border.color: Theme.surfaceBorder
        scale: keyMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Text {
            anchors.centerIn: parent
            text: key.label
            color: key.kind === "eq" ? Theme.accentText : key.kind === "clear" ? Theme.privacyMic
                : key.kind === "op" ? Theme.accent : Theme.text
            font.family: Theme.font
            font.pixelSize: key.small ? Theme.fontNormal : Theme.fontLarge
            font.weight: key.kind === "num" ? Font.Medium : Font.Bold
        }
        MouseArea {
            id: keyMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                Calculator.press(key.label);
                keys.forceActiveFocus();
            }
        }
    }

    // Small pill button (mode, history, clear)
    component Chip: Rectangle {
        id: chip
        property string text: ""
        property string glyph: ""
        property bool active: false
        signal clicked
        implicitHeight: 26
        implicitWidth: chipRow.implicitWidth + (text ? 20 : 12)
        radius: 13
        color: active ? Theme.accent : chipMouse.containsMouse ? Theme.buttonHover : Theme.button

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        Row {
            id: chipRow
            anchors.centerIn: parent
            spacing: 5
            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                visible: chip.glyph !== ""
                icon: chip.glyph
                size: 14
                color: chip.active ? Theme.accentText : Theme.subtext
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                visible: chip.text !== ""
                text: chip.text
                color: chip.active ? Theme.accentText : Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }
        }
        MouseArea {
            id: chipMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                chip.clicked();
                keys.forceActiveFocus();
            }
        }
    }
}
