#!/usr/bin/env python3
"""Screen brightness through the org.kde.ScreenBrightness service (powerdevil).

Writes a JSON line on start and on every change (brightness keys included):
    [{"id": "display0", "label", "value", "max", "internal"}]
and reads commands from stdin, one per line:
    set <id> <value>       (0..max)
"""

import json
import sys

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS = "org.kde.ScreenBrightness"
ROOT = "/org/kde/ScreenBrightness"
IFACE = "org.kde.ScreenBrightness"
DISPLAY = "org.kde.ScreenBrightness.Display"
SUPPRESS_OSD = 1   # the shell's pill shows the brightness; KDE's OSD does not


def main():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def get(path, iface, name):
        res = conn.call_sync(BUS, path, "org.freedesktop.DBus.Properties", "Get",
                             GLib.Variant("(ss)", (iface, name)), GLib.VariantType("(v)"),
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack()[0]

    def displays():
        out = []
        try:
            names = get(ROOT, IFACE, "DisplaysDBusNames")
        except GLib.Error:
            return out
        for name in names:
            path = f"{ROOT}/{name}"
            try:
                out.append({
                    "id": name,
                    "label": get(path, DISPLAY, "Label"),
                    "value": get(path, DISPLAY, "Brightness"),
                    "max": get(path, DISPLAY, "MaxBrightness"),
                    "internal": get(path, DISPLAY, "IsInternal"),
                })
            except GLib.Error:
                pass
        return out

    def emit(*_):
        print(json.dumps(displays()), flush=True)

    for sig in ("BrightnessChanged", "BrightnessRangeChanged", "DisplayAdded", "DisplayRemoved"):
        conn.signal_subscribe(BUS, IFACE, sig, ROOT, None, Gio.DBusSignalFlags.NONE, emit)

    loop = GLib.MainLoop()

    def on_stdin(channel, cond):
        if cond & (GLib.IO_HUP | GLib.IO_ERR):
            loop.quit()
            return False
        line = channel.readline()
        if not line:
            loop.quit()
            return False
        parts = line.split()
        if len(parts) == 3 and parts[0] == "set":
            try:
                conn.call_sync(BUS, f"{ROOT}/{parts[1]}", DISPLAY, "SetBrightness",
                               GLib.Variant("(iu)", (int(parts[2]), SUPPRESS_OSD)), None,
                               Gio.DBusCallFlags.NONE, -1, None)
            except (GLib.Error, ValueError) as e:
                print(f"brightness: {e}", file=sys.stderr, flush=True)
        return True

    GLib.io_add_watch(GLib.IOChannel.unix_new(sys.stdin.fileno()), GLib.PRIORITY_DEFAULT,
                      GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, on_stdin)
    emit()
    loop.run()


if __name__ == "__main__":
    main()
