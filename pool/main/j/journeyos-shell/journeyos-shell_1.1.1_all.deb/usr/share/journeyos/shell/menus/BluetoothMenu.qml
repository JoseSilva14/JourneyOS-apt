import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Bluetooth
import qs
import qs.components
import qs.services

// Bluetooth menu: on/off, paired devices (click connects/disconnects) and,
// while open, scans for and pairs new devices.
ColumnLayout {
    id: root

    spacing: 8

    // Inside the settings page: no "Settings…" at the end
    property bool embedded: false

    readonly property var adapter: Bluetooth.defaultAdapter
    readonly property bool on: adapter?.enabled ?? false
    readonly property var devices: adapter?.devices.values ?? []
    readonly property var paired: devices.filter(d => d.paired || d.bonded)
        .sort((a, b) => (b.connected - a.connected) || label(a).localeCompare(label(b)))
    // New ones only with a real name: without one BlueZ's alias is the address itself
    // ("AA-BB-CC-…", which the old check, against "AA:BB:…", let through) - nearby BLE gadgets
    readonly property var others: devices.filter(d => !d.paired && !d.bonded && realName(d) !== "")
        .sort((a, b) => realName(a).localeCompare(realName(b)))

    function addressLike(t) {
        return /^([0-9a-f]{2}[-:_]){5}[0-9a-f]{2}$/i.test(t ?? "");
    }
    // The device's own name (BlueZ Name), else an alias the user gave; "" if neither is a name
    function realName(d) {
        if (d.deviceName && !addressLike(d.deviceName))
            return d.deviceName;
        if (d.name && !addressLike(d.name))
            return d.name;
        return "";
    }
    // What to show: the name or, for a paired device without one, its kind + the end of the address
    function label(d) {
        const n = realName(d);
        if (n)
            return n;
        const kinds = { headphones: Tr.t("Headphones"), speaker: Tr.t("Speaker"), mouse: Tr.t("Mouse"),
            keyboard: Tr.t("Keyboard"), smartphone: Tr.t("Phone"), computer: Tr.t("Computer"),
            sports_esports: Tr.t("Game controller") };
        return (kinds[iconFor(d)] ?? Tr.t("Device")) + " " + (d.address ?? "").slice(-5).replace(/[-_]/g, ":");
    }

    // Just paired: connect right away
    property string pairingAddress: ""
    onPairedChanged: {
        const d = paired.find(x => x.address === pairingAddress);
        if (d) {
            pairingAddress = "";
            if (!d.connected)
                d.connect();
        }
    }

    // Scans only with the menu open
    function scan(on) {
        if (adapter && adapter.enabled)
            adapter.discovering = on;
    }
    Component.onCompleted: scan(true)
    Component.onDestruction: scan(false)
    onOnChanged: scan(on)

    // Device icon (from the icon name BlueZ gives)
    function iconFor(d) {
        const i = d.icon ?? "";
        if (/headset|headphone/.test(i)) return "headphones";
        if (/audio|speaker/.test(i)) return "speaker";
        if (/mouse/.test(i)) return "mouse";
        if (/keyboard/.test(i)) return "keyboard";
        if (/phone/.test(i)) return "smartphone";
        if (/computer|laptop/.test(i)) return "computer";
        if (/gaming|joystick/.test(i)) return "sports_esports";
        return "bluetooth";
    }

    function status(d) {
        if (d.pairing) return Tr.t("Pairing…");
        if (d.state === BluetoothDeviceState.Connecting) return Tr.t("Connecting…");
        if (d.state === BluetoothDeviceState.Disconnecting) return Tr.t("Disconnecting…");
        if (d.connected) return Tr.t("On") + (d.batteryAvailable ? Tr.t(" · battery ") + Math.round(d.battery * 100) + "%" : "");
        return d.paired || d.bonded ? Tr.t("Paired") : Tr.t("New");
    }

    function busy(d) {
        return d.pairing || d.state === BluetoothDeviceState.Connecting || d.state === BluetoothDeviceState.Disconnecting;
    }

    // Header: title and the switch
    RowLayout {
        Layout.fillWidth: true
        Layout.bottomMargin: 4

        Text {
            Layout.fillWidth: true
            visible: !root.embedded || root.adapter !== null
            text: !root.embedded ? "Bluetooth" : root.on ? Tr.t("On") : Tr.t("Off")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontLarge
            font.weight: Font.Bold
        }
        Toggle {
            visible: root.adapter !== null
            checked: root.on
            onToggled: on => root.adapter.enabled = on
        }
    }

    Text {
        visible: root.adapter === null
        Layout.fillWidth: true
        text: Tr.t("This computer has no Bluetooth.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Text {
        visible: root.adapter !== null && !root.on
        Layout.fillWidth: true
        text: Tr.t("Bluetooth is off.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // --- Paired ---
    Repeater {
        model: root.on ? root.paired : []

        MenuRow {
            id: row
            required property var modelData
            readonly property var d: modelData

            icon: root.iconFor(d)
            title: root.label(d)
            subtitle: root.status(d)
            active: d.connected
            busy: root.busy(d)
            onClicked: d.connected ? d.disconnect() : d.connect()

            MenuButton {
                visible: row.hovered
                icon: "delete"
                onClicked: row.d.forget()
            }
        }
    }

    // --- New (while scanning) ---
    RowLayout {
        visible: root.on
        Layout.fillWidth: true
        Layout.topMargin: 6
        spacing: 6

        Text {
            text: Tr.t("Other devices")
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.Bold
        }
        MIcon {
            visible: root.adapter?.discovering ?? false
            icon: "autorenew"
            size: 14
            color: Theme.dim

            RotationAnimation on rotation {
                running: root.adapter?.discovering ?? false
                from: 0
                to: 360
                duration: 1200
                loops: Animation.Infinite
            }
        }
    }

    Text {
        visible: root.on && root.others.length === 0
        Layout.fillWidth: true
        text: Tr.t("Searching… put the device in pairing mode.")
        wrapMode: Text.Wrap
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: root.on ? root.others.slice(0, 6) : []

        MenuRow {
            required property var modelData
            readonly property var d: modelData

            icon: root.iconFor(d)
            title: root.label(d)
            subtitle: root.status(d)
            busy: root.busy(d)
            onClicked: {
                // Pair and trust (to reconnect automatically)
                d.trusted = true;
                root.pairingAddress = d.address;
                d.pair();
            }
        }
    }

    Rectangle {
        visible: !root.embedded
        Layout.fillWidth: true
        Layout.topMargin: 4
        implicitHeight: 1
        color: Theme.surfaceBorder
    }

    MenuRow {
        visible: !root.embedded
        icon: "settings"
        title: Tr.t("Bluetooth settings…")
        onClicked: {
            BarMenu.open = "";
            SettingsApp.show("bluetooth");
        }
    }
}
