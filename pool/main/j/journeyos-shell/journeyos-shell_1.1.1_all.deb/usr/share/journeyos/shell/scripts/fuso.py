#!/usr/bin/env python3
"""Time in other places, for the launcher.

fuso.py <HH:MM|agora> <em|de> <city>          ("agora" = now)
  em ("in"):   the time here (or now) → the time there      ("14h em Tóquio")
  de ("from"): the time there → the time here               ("14h de Tóquio")
Writes a JSON line { city, zone, there, here, day, diff } or nothing (unknown city).
"""
import json
import os
import sys
import unicodedata
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo, available_timezones


def fold(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn").strip()


# Portuguese names (and some countries with a single time zone); the rest is matched against the zone name
ALIASES = {
    "lisboa": ("Lisboa", "Europe/Lisbon"), "portugal": ("Portugal", "Europe/Lisbon"),
    "porto": ("Porto", "Europe/Lisbon"), "acores": ("Açores", "Atlantic/Azores"),
    "madeira": ("Madeira", "Atlantic/Madeira"), "funchal": ("Funchal", "Atlantic/Madeira"),
    "londres": ("Londres", "Europe/London"), "reino unido": ("Reino Unido", "Europe/London"),
    "inglaterra": ("Inglaterra", "Europe/London"), "dublin": ("Dublin", "Europe/Dublin"),
    "irlanda": ("Irlanda", "Europe/Dublin"),
    "madrid": ("Madrid", "Europe/Madrid"), "espanha": ("Espanha", "Europe/Madrid"),
    "barcelona": ("Barcelona", "Europe/Madrid"), "paris": ("Paris", "Europe/Paris"),
    "franca": ("França", "Europe/Paris"), "berlim": ("Berlim", "Europe/Berlin"),
    "alemanha": ("Alemanha", "Europe/Berlin"), "roma": ("Roma", "Europe/Rome"),
    "italia": ("Itália", "Europe/Rome"), "milao": ("Milão", "Europe/Rome"),
    "amesterdao": ("Amesterdão", "Europe/Amsterdam"), "holanda": ("Países Baixos", "Europe/Amsterdam"),
    "paises baixos": ("Países Baixos", "Europe/Amsterdam"), "bruxelas": ("Bruxelas", "Europe/Brussels"),
    "belgica": ("Bélgica", "Europe/Brussels"), "zurique": ("Zurique", "Europe/Zurich"),
    "genebra": ("Genebra", "Europe/Zurich"), "suica": ("Suíça", "Europe/Zurich"),
    "viena": ("Viena", "Europe/Vienna"), "austria": ("Áustria", "Europe/Vienna"),
    "varsovia": ("Varsóvia", "Europe/Warsaw"), "polonia": ("Polónia", "Europe/Warsaw"),
    "praga": ("Praga", "Europe/Prague"), "estocolmo": ("Estocolmo", "Europe/Stockholm"),
    "suecia": ("Suécia", "Europe/Stockholm"), "oslo": ("Oslo", "Europe/Oslo"),
    "noruega": ("Noruega", "Europe/Oslo"), "copenhaga": ("Copenhaga", "Europe/Copenhagen"),
    "dinamarca": ("Dinamarca", "Europe/Copenhagen"), "helsinquia": ("Helsínquia", "Europe/Helsinki"),
    "finlandia": ("Finlândia", "Europe/Helsinki"), "atenas": ("Atenas", "Europe/Athens"),
    "grecia": ("Grécia", "Europe/Athens"), "istambul": ("Istambul", "Europe/Istanbul"),
    "turquia": ("Turquia", "Europe/Istanbul"), "moscovo": ("Moscovo", "Europe/Moscow"),
    "kiev": ("Kiev", "Europe/Kyiv"), "ucrania": ("Ucrânia", "Europe/Kyiv"),
    "nova iorque": ("Nova Iorque", "America/New_York"), "nova york": ("Nova Iorque", "America/New_York"),
    "washington": ("Washington", "America/New_York"), "boston": ("Boston", "America/New_York"),
    "miami": ("Miami", "America/New_York"), "toronto": ("Toronto", "America/Toronto"),
    "montreal": ("Montreal", "America/Toronto"), "chicago": ("Chicago", "America/Chicago"),
    "texas": ("Texas", "America/Chicago"), "denver": ("Denver", "America/Denver"),
    "los angeles": ("Los Angeles", "America/Los_Angeles"), "sao francisco": ("São Francisco", "America/Los_Angeles"),
    "california": ("Califórnia", "America/Los_Angeles"), "seattle": ("Seattle", "America/Los_Angeles"),
    "vancouver": ("Vancouver", "America/Vancouver"), "cidade do mexico": ("Cidade do México", "America/Mexico_City"),
    "mexico": ("México", "America/Mexico_City"), "sao paulo": ("São Paulo", "America/Sao_Paulo"),
    "rio de janeiro": ("Rio de Janeiro", "America/Sao_Paulo"), "rio": ("Rio de Janeiro", "America/Sao_Paulo"),
    "brasilia": ("Brasília", "America/Sao_Paulo"), "brasil": ("Brasil (Brasília)", "America/Sao_Paulo"),
    "buenos aires": ("Buenos Aires", "America/Argentina/Buenos_Aires"), "argentina": ("Argentina", "America/Argentina/Buenos_Aires"),
    "santiago": ("Santiago", "America/Santiago"), "chile": ("Chile", "America/Santiago"),
    "lima": ("Lima", "America/Lima"), "bogota": ("Bogotá", "America/Bogota"),
    "luanda": ("Luanda", "Africa/Luanda"), "angola": ("Angola", "Africa/Luanda"),
    "maputo": ("Maputo", "Africa/Maputo"), "mocambique": ("Moçambique", "Africa/Maputo"),
    "praia": ("Praia", "Atlantic/Cape_Verde"), "cabo verde": ("Cabo Verde", "Atlantic/Cape_Verde"),
    "bissau": ("Bissau", "Africa/Bissau"), "guine-bissau": ("Guiné-Bissau", "Africa/Bissau"),
    "sao tome": ("São Tomé", "Africa/Sao_Tome"), "joanesburgo": ("Joanesburgo", "Africa/Johannesburg"),
    "africa do sul": ("África do Sul", "Africa/Johannesburg"), "cairo": ("Cairo", "Africa/Cairo"),
    "egito": ("Egito", "Africa/Cairo"), "lagos": ("Lagos", "Africa/Lagos"), "nairobi": ("Nairobi", "Africa/Nairobi"),
    "marrocos": ("Marrocos", "Africa/Casablanca"), "dubai": ("Dubai", "Asia/Dubai"),
    "abu dhabi": ("Abu Dhabi", "Asia/Dubai"), "doha": ("Doha", "Asia/Qatar"), "israel": ("Israel", "Asia/Jerusalem"),
    "jerusalem": ("Jerusalém", "Asia/Jerusalem"), "telavive": ("Telavive", "Asia/Jerusalem"),
    "india": ("Índia", "Asia/Kolkata"), "mumbai": ("Mumbai", "Asia/Kolkata"), "deli": ("Deli", "Asia/Kolkata"),
    "nova deli": ("Nova Deli", "Asia/Kolkata"), "bangalore": ("Bangalore", "Asia/Kolkata"),
    "goa": ("Goa", "Asia/Kolkata"), "banguecoque": ("Banguecoque", "Asia/Bangkok"),
    "tailandia": ("Tailândia", "Asia/Bangkok"), "singapura": ("Singapura", "Asia/Singapore"),
    "hong kong": ("Hong Kong", "Asia/Hong_Kong"), "macau": ("Macau", "Asia/Macau"),
    "pequim": ("Pequim", "Asia/Shanghai"), "xangai": ("Xangai", "Asia/Shanghai"), "china": ("China", "Asia/Shanghai"),
    "taipe": ("Taipé", "Asia/Taipei"), "seul": ("Seul", "Asia/Seoul"), "coreia": ("Coreia do Sul", "Asia/Seoul"),
    "toquio": ("Tóquio", "Asia/Tokyo"), "japao": ("Japão", "Asia/Tokyo"), "manila": ("Manila", "Asia/Manila"),
    "jacarta": ("Jacarta", "Asia/Jakarta"), "dili": ("Díli", "Asia/Dili"), "timor": ("Timor-Leste", "Asia/Dili"),
    "sydney": ("Sydney", "Australia/Sydney"), "melbourne": ("Melbourne", "Australia/Melbourne"),
    "perth": ("Perth", "Australia/Perth"), "auckland": ("Auckland", "Pacific/Auckland"),
    "nova zelandia": ("Nova Zelândia", "Pacific/Auckland"), "havai": ("Havai", "Pacific/Honolulu"),
    "honolulu": ("Honolulu", "Pacific/Honolulu"), "utc": ("UTC", "UTC"), "gmt": ("GMT", "UTC"),
}


def find(place):
    key = fold(place)
    if key in ALIASES:
        return ALIASES[key]
    want = key.replace(" ", "_")
    for zone in sorted(available_timezones()):
        city = zone.split("/")[-1]
        if fold(city) == want:
            return city.replace("_", " "), zone
    return None


def main():
    if len(sys.argv) < 4:
        print(__doc__, file=sys.stderr)
        return 2
    time, direction, place = sys.argv[1], sys.argv[2], " ".join(sys.argv[3:])
    found = find(place)
    if not found:
        return 0
    name, zone = found
    # English by default: the zone's name (Asia/Tokyo → Tokyo); Portuguese names with SHADOW_LANG=pt
    if os.environ.get("SHADOW_LANG") != "pt" and zone != "UTC":
        name = zone.split("/")[-1].replace("_", " ")
    tz = ZoneInfo(zone)
    local = datetime.now().astimezone()
    if time == "agora":
        here = local
        there = here.astimezone(tz)
    else:
        h, m = (int(x) for x in time.split(":"))
        if direction == "de":
            there = datetime.now(tz).replace(hour=h, minute=m, second=0, microsecond=0)
            here = there.astimezone(local.tzinfo)
        else:
            here = local.replace(hour=h, minute=m, second=0, microsecond=0)
            there = here.astimezone(tz)
    # Difference between the two clocks, in hours
    diff = (there.utcoffset() - here.utcoffset()) / timedelta(hours=1)
    other, base = (there, here) if direction != "de" else (here, there)
    days = (other.date() - base.date()).days
    print(json.dumps({
        "city": name, "zone": zone,
        "there": there.strftime("%H:%M"), "here": here.strftime("%H:%M"),
        "day": days, "diff": diff,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
