pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Screen brightness (scripts/brightness.py, powerdevil service). The main one
// is the internal (laptop) screen if there is one, otherwise the first.
Singleton {
    id: root

    property var displays: []        // [{ id, label, value, max, internal }]
    readonly property var main: displays.find(d => d.internal) ?? displays[0] ?? null
    readonly property bool available: main !== null
    readonly property real value: main && main.max > 0 ? main.value / main.max : 0

    // Changed (by the shell or the keys): the pill shows the OSD
    signal changed

    // 0–1; below 1% the screen went black, so the minimum is 1%
    function set(v) {
        if (!main)
            return;
        const target = Math.round(Math.max(0.01, Math.min(1, v)) * main.max);
        helper.write("set " + main.id + " " + target + "\n");
    }

    function step(delta) { set(value + delta); }

    Process {
        id: helper
        running: true
        stdinEnabled: true
        command: [Quickshell.shellPath("scripts/brightness.py")]
        stdout: SplitParser {
            onRead: line => {
                try {
                    const old = root.value;
                    root.displays = JSON.parse(line);
                    if (Math.abs(root.value - old) > 0.001)
                        root.changed();
                } catch (e) {
                    console.warn("brightness: invalid line");
                }
            }
        }
        onExited: restart.start()
    }

    Timer {
        id: restart
        interval: 3000
        onTriggered: helper.running = true
    }

    IpcHandler {
        target: "brightness"
        function set(percent: int): void { root.set(percent / 100); }
        function up(): void { root.step(0.05); }
        function down(): void { root.step(-0.05); }
        function get(): int { return Math.round(root.value * 100); }
    }
}
