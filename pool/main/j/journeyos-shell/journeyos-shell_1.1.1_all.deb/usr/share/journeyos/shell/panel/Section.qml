import QtQuick
import qs

// Panel block (opaque, above the windows).
Rectangle {
    color: Theme.surfaceCard
    radius: Theme.radiusCard
    border.width: 1
    border.color: Theme.surfaceBorder
}
