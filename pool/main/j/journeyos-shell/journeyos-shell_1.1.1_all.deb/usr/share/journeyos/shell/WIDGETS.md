# Making widgets and tabs

A widget is a folder with two files: a `manifest.json` (name, icon, options) and a
`Widget.qml` (what you see). Once you put it in the widgets folder, it shows up in the **+** of
widget editing, next to the shell's own. The same folder can also provide **a tab for the pill
and/or the dashboard** (see [Tabs in the pill and the dashboard](#11-tabs-in-the-pill-and-the-dashboard)).
It has access to the shell's theme, components and services, and it can connect to any other app:

- through the command line;
- over HTTP;
- over D-Bus;
- through files;
- through sockets;
- or by receiving data that those apps send it.

> A widget runs with your permissions, like any program. Only install widgets you trust
> (read the `Widget.qml` first).

## Contents

1. [Get started in two minutes](#1-get-started-in-two-minutes)
2. [A widget's folder](#2-a-widgets-folder)
3. [The `manifest.json`](#3-the-manifestjson)
4. [The `Widget.qml`](#4-the-widgetqml)
5. [What a widget can use](#5-what-a-widget-can-use)
6. [Connecting to other apps](#6-connecting-to-other-apps)
7. [Performance](#7-performance)
8. [Debugging](#8-debugging)
9. [Sharing and installing](#9-sharing-and-installing)
10. [Quick reference](#10-quick-reference)
11. [Tabs in the pill and the dashboard](#11-tabs-in-the-pill-and-the-dashboard)

---

## 1. Get started in two minutes

The shell ships four examples in `examples/widgets/`:

| Example | Shows how to… |
|---|---|
| `ola` | do the simplest thing: a card with text and one option |
| `comando` | run a command every few seconds and show what it prints |
| `http` | read JSON from a web API and show one field |
| `mensagens` | receive data that another app or script sends it |

To install them all: **Settings → Desktop → Install the examples**. Then, in widget editing
(right-click the background → Edit widgets), press **+**.

To make your own, start from an example:

```sh
cp -r ~/Projetos/shadow-kde/examples/widgets/ola ~/widgets/my-widget
~/Projetos/shadow-kde/scripts/widget-dev.sh ~/widgets/my-widget
```

`widget-dev.sh` links the folder to the shell and puts the widget on the desktop. From then on,
**every time you save a file in the folder, the widget reloads**, and messages (`console.log`) and
errors appear in the terminal. Ctrl+C exits; the widget stays installed.

(The paths in this guide assume the shell is in `~/Projetos/shadow-kde`; replace them with wherever you have it.)

---

## 2. A widget's folder

User widgets live in:

```
~/.local/share/shadow-kde/widgets/
└── my-widget/             ← the folder name is the id (letters, numbers, - and _)
    ├── manifest.json      ← required
    ├── Widget.qml         ← required (or the file that "main" points to)
    └── …                  ← anything else you want: images, scripts, other QML
```

- The id cannot change once the widget is on the desktop. The shell stores it as type
  `user/<id>`; if you rename the folder, the old widget shows as "no longer installed".
- A folder can also be a symbolic link (that is what `widget-dev.sh` does).
- After copying or changing a folder by hand, press **Settings → Desktop → Rescan**, or run
  `qs -p ~/Projetos/shadow-kde ipc call widgets rescan`.

---

## 3. The `manifest.json`

```json
{
    "name": "Server",
    "icon": "dns",
    "description": "Status of a server over SSH.",
    "author": "Ana",
    "version": "1.2",
    "main": "Widget.qml",
    "style": "card",
    "options": [
        { "key": "host", "label": "Server", "type": "string", "default": "my-vps" },
        { "key": "intervalo", "label": "How often (s)", "type": "number", "default": 30, "min": 5, "max": 3600 },
        { "key": "detalhes", "label": "Show details", "type": "bool", "default": true },
        { "key": "unidade", "label": "Unit", "type": "choice", "default": "gb",
          "choices": [ { "id": "gb", "label": "GB" }, { "id": "gib", "label": "GiB" } ] }
    ]
}
```

| Field | Required | What |
|---|---|---|
| `name` | no (the id) | Name in the **+** menu and in Settings |
| `icon` | no | Name of a [Material Icon](https://fonts.google.com/icons?icon.style=Rounded) (e.g. `dns`, `rocket_launch`) |
| `description` | no | One sentence |
| `author`, `version` | no | For sharing |
| `main` | no (`Widget.qml`) | The main QML, inside the folder |
| `style` | no (`card`) | Style when added: `card` or `plain` (transparent) |
| `options` | no | The options the user changes in Settings (see below) |
| `places` | no (`["desktop"]`) | Where it appears: `desktop`, `notch` (pill tab), `dashboard` (dashboard tab). A list (all using `main`) or an object with the QML for each place (see [11](#11-tabs-in-the-pill-and-the-dashboard)) |

### Options

Each option appears in **Settings → Desktop**, below the widget. In editing mode, a widget's
settings button (⚙) takes you there. Each widget on the desktop has its own values: you can
have two "Command" widgets with different commands.

| `type` | Control | Value in QML | Extra fields |
|---|---|---|---|
| `string` | text field | text | — |
| `number` | text field (numbers only) | number | `min`, `max` |
| `bool` | switch | `true`/`false` | — |
| `choice` | list | the chosen `id` | `choices`: `[{ "id", "label" }]` or plain strings |

All accept `label`, `description` and `default`.

> **Passwords and tokens:** options are stored as plain text in
> `~/.config/shadow-kde/config.json`. For secrets, read them from the system keyring (see
> [Secrets](#secrets-tokens-and-passwords)).

If the manifest has an error, the widget does not appear in **+**: it appears in Settings, under
"Your widgets", with the error (for example `invalid manifest.json (line 4): Expecting ',' delimiter`).

---

## 4. The `Widget.qml`

As small as it gets:

```qml
import QtQuick
import qs
import qs.components

Card {
    property var options: ({})

    width: 300
    height: 110

    Text {
        anchors.centerIn: parent
        text: "Hello, " + (parent.options.nome || "world")
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: Theme.fontLarge
    }
}
```

### The contract

**Size.** The root must have `width` and `height` set (not just the implicit ones). The shell
measures the widget by them and multiplies by the scale the user picks when resizing (50–200%)
and by the screen height. Design for a 1080 px tall screen; you don't need to handle scaling.

**Properties the shell gives you.** Declare only the ones you use: the shell only fills in those
that exist on the root.

| Property | Type | What |
|---|---|---|
| `options` | `var` | The values of the manifest options (with defaults). Changes when the user changes an option |
| `plain` | `bool` | `true` in the transparent style. `Card` already has it: if the root is a `Card`, the "transparent/card" button in editing works on its own |
| `editing` | `bool` | `true` while the user is editing widgets (for example, to pause animations) |
| `widgetId` | `string` | The id of this copy on the desktop (different for each copy of the same widget) |
| `widgetDir` | `string` | The path to the widget's folder (for images, your own scripts, etc.) |

**Clicks.** Widgets sit on the background, below windows, and receive the mouse normally
(`MouseArea`). In editing mode, the shell puts its own drag area on top: your clicks don't get
through, which is what you want. Right-clicking the background opens the desktop menu; if the
widget needs it, use `acceptedButtons: Qt.RightButton` in your `MouseArea`.

**Images from the folder:** `Image { source: "file://" + root.widgetDir + "/logo.png" }`. Sibling
QML files (`Row.qml` next to `Widget.qml`) can be used directly as types, as in any QML.

---

## 5. What a widget can use

A widget imports the same modules as the shell's components:

```qml
import QtQuick
import QtQuick.Layouts
import Quickshell          // Quickshell.env(), DesktopEntries, SystemClock…
import Quickshell.Io       // Process, FileView, Socket, StdioCollector, SplitParser
import qs                  // Theme
import qs.components       // Card, MIcon, Ring, Graph…
import qs.services         // Stats, Media, Weather, Agenda, Run, Apps, Events, Widgets…
```

### `Theme`: colours, fonts and sizes

Always use `Theme`, never fixed values: that way the widget follows the colour schemes, the
light/dark theme and "Reduce motion".

| For | Tokens |
|---|---|
| Backgrounds | `Theme.card` (card), `Theme.button`, `Theme.buttonHover`, `Theme.surface`, `Theme.surfaceCard` |
| Borders | `Theme.cardBorder`, `Theme.surfaceBorder` |
| Text | `Theme.text`, `Theme.subtext` (secondary), `Theme.dim` (dimmed), `Theme.faint` |
| Accent | `Theme.accent` and `Theme.accentText` (text on top of the accent) |
| States | `Theme.privacyMic` (red/orange: error, alert), `Theme.privacyCamera` (green: good) |
| Charts | `Theme.ringTrack`, `Theme.ringFill`, `Theme.graphFill` |
| Font | `Theme.font`, sizes `Theme.fontSmall`, `fontNormal`, `fontMedium`, `fontLarge`, `fontStat` |
| Measurements | `Theme.cardPadding`, `Theme.gap`, `Theme.radius`, `Theme.radiusSmall`, `Theme.radiusCard` |
| Animations | `Theme.animFast`, `animNormal`, `animSlow` (0 with "Reduce motion") |
| Mode | `Theme.light` (`true` in the light theme) |

### Components (`qs.components`)

| Component | What for |
|---|---|
| `Card` | The widget card (has `plain`). Use it as the root |
| `MIcon` | Material icon: `MIcon { icon: "bolt"; size: 20; color: Theme.subtext }` |
| `Ring` | Progress ring: `Ring { value: 0.4; icon: "memory" }` |
| `Graph` | Line chart: `Graph { values: [...]; max: 1; capacity: 60 }` |
| `Toggle`, `Slider`, `Segmented`, `TextField`, `Select` | Controls, if the widget is interactive |
| `RoundImage` | Round image (avatars, covers), light on the software renderer |

### Services (`qs.services`)

Read freely; to change system things, use the functions listed.

| Service | What it gives |
|---|---|
| `Stats` | `cpu`, `ram`, `gpu`, `disk` (0–1), `netDown`/`netUp` (bytes/s), `uptime`, `cpuHistory`… |
| `Media` | Music (MPRIS): `playing`, `title`, `artist`, `art`, `toggle()`, `next()`, `previous()` |
| `Weather` | `ready`, `temp`, `desc`, `icon`, `area`, `days` |
| `Agenda` | Calendar: `events`, `eventsOn(date)`, `upcoming(n)`, `timeText(event)` |
| `Net` | `kind` (`wifi`/`ethernet`/`none`), `name`, `signal` |
| `Notifs` | `list` (notifications in the centre), `dnd` |
| `Focus` | `current` (active focus mode, or `null`) |
| `Run` | `Run.cmd(argv, (code, out, err) => …)`: runs a command and returns the result |
| `Apps` | `Apps.run(argv)` (launches a program outside the shell), `Apps.launch(DesktopEntries.byId("firefox-esr"))` |
| `Events` | `Events.push({ icon, title, text, duration })`: a short notice in the top pill |
| `Widgets` | Messages from outside (`message`, `lastMessage(channel)`; see 6.5) |
| `Config` | `Config.options.…` (read-only: for example `Config.options.clock.use24h`) |
| `Tr` | Shell language: `Tr.en` (`true` in English), `Tr.locale` (for numbers and dates), `Tr.t("text")` (translates the shell's own strings) |

> Don't write to `Config` from a widget: settings belong to the user. Your options come from
> the manifest.

---

## 6. Connecting to other apps

### 6.1 Command line

The most universal way: almost every app has a command (`git`, `docker`, `gh`, `kubectl`,
`playerctl`, `nmcli`, `sensors`, `curl`…).

**Once, with the result:** `Run.cmd` waits for the process to finish and gives you the exit code and the text.

```qml
Timer {
    running: true; repeat: true; triggeredOnStart: true
    interval: 30000
    onTriggered: Run.cmd(["docker", "ps", "--format", "{{json .}}"], (code, out) => {
        if (code !== 0) return;
        root.containers = out.trim().split("\n").filter(l => l).map(l => JSON.parse(l));
    })
}
```

**With a declared `Process`:** useful when the command depends on the options. The `comando`
example does this:

```qml
Process {
    id: proc
    command: ["sh", "-c", root.options.comando]
    stdout: StdioCollector { id: out }
    onExited: code => root.output = out.text.trim()
}
Timer { interval: 60000; running: true; repeat: true; triggeredOnStart: true
        onTriggered: if (!proc.running) proc.running = true }
```

**A continuous stream** (a program that keeps printing lines: `journalctl -f`, `tail -F`,
`playerctl --follow`, `pactl subscribe`, `nmcli monitor`):

```qml
Process {
    running: true
    command: ["playerctl", "--follow", "metadata", "--format", "{{artist}} — {{title}}"]
    stdout: SplitParser { onRead: line => root.nowPlaying = line }
}
```

Rules:

- Pass arguments as a list (`["git", "-C", folder, "status"]`), not glued into one string: that
  way there are no problems with spaces and no command injection. Use `sh -c` only when you
  really need pipes, and never put outside text in there carelessly.
- To open apps or windows, use `Apps.run([...])` and not `Process`: `Apps.run` puts the program
  outside the shell (otherwise it would die when the shell restarts).
- Programs that can hang (network, Bluetooth): `["timeout", "5", …]`.

### 6.2 HTTP and web APIs

QML includes `XMLHttpRequest`, nothing to install. The `http` example does this:

```qml
function fetch() {
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
        if (xhr.readyState !== XMLHttpRequest.DONE) return;
        if (xhr.status === 200)
            root.data = JSON.parse(xhr.responseText);
        else
            root.error = xhr.status ? "Error " + xhr.status : "No connection";
    };
    xhr.open("GET", "https://api.github.com/repos/" + root.options.repo);
    xhr.setRequestHeader("Accept", "application/vnd.github+json");
    if (root.token) xhr.setRequestHeader("Authorization", "Bearer " + root.token);
    xhr.send();
}
```

- To send: `xhr.open("POST", url)`, `setRequestHeader("Content-Type", "application/json")`
  and `xhr.send(JSON.stringify(body))`.
- Respect API limits: once a minute is enough for almost everything, and 10–15 min for things
  that rarely change.
- Without a network, keep the last value and show the error in small type (don't empty the widget).
- Local services work too: Home Assistant (`http://homeassistant.local:8123/api/…`),
  Syncthing, Jellyfin, your own server on `localhost`.

### Secrets (tokens and passwords)

Don't ask for tokens in an option (they would sit in plain text in `config.json`). Store them in
the system keyring (KWallet / Secret Service) and read them with `secret-tool`:

```sh
# once, in the terminal (asks for the value without showing it)
secret-tool store --label="GitHub (widget)" servico github-widget
```

```qml
property string token: ""
Component.onCompleted: Run.cmd(["secret-tool", "lookup", "servico", "github-widget"],
    (code, out) => { if (code === 0) root.token = out.trim(); })
```

(`secret-tool` comes in the `libsecret-tools` package.)

### 6.3 D-Bus

Many Linux apps speak D-Bus: KDE Connect, Spotify, NetworkManager, systemd, powerdevil…
There are two ways.

**First, check whether there is already a native Quickshell module**, easier and free:

| Module | For |
|---|---|
| `Quickshell.Services.Mpris` | any music/video player (or use the `Media` service) |
| `Quickshell.Services.UPower` | batteries (laptop, mouse, headphones) |
| `Quickshell.Services.Pipewire` | sound: volume, outputs, inputs, apps playing |
| `Quickshell.Bluetooth` | Bluetooth devices and battery |
| `Quickshell.Services.SystemTray` | app tray icons |

**Read a property or call a method:** `busctl` with `--json=short` gives JSON directly.

```qml
// Phone battery via KDE Connect (the device id comes from the options)
Run.cmd(["busctl", "--user", "--json=short", "get-property", "org.kde.kdeconnect",
         "/modules/kdeconnect/devices/" + root.options.device + "/battery",
         "org.kde.kdeconnect.device.battery", "charge"],
    (code, out) => { if (code === 0) root.charge = JSON.parse(out).data; })
```

To explore what an app exposes: `busctl --user tree org.kde.kdeconnect` and
`busctl --user introspect <name> <path>`.

**Listen to signals** (the widget updates the instant something changes, without polling every
few seconds):

```qml
Process {
    running: true
    command: ["gdbus", "monitor", "--session", "--dest", "org.kde.kdeconnect"]
    stdout: SplitParser {
        onRead: line => { if (line.includes("refreshed")) root.reload(); }
    }
}
```

### 6.4 Files

If the other app writes a state file (JSON, text), `FileView` reads it and tells you when it changes:

```qml
FileView {
    path: Quickshell.env("HOME") + "/.local/state/my-app/state.json"
    watchChanges: true
    onFileChanged: reload()
    onLoaded: {
        try { root.state = JSON.parse(text()); } catch (e) { root.state = null; }
    }
}
```

Good for connecting to your own scripts: the script writes the file, the widget shows it. The
writer should save atomically (write a temporary file and rename it), otherwise the widget may
read a half-written file.

### 6.5 Pushing data from outside: the message channel

Instead of the widget asking, the other app sends it data whenever it wants: a git hook, the end
of a build, a cron job, your own Python or Node app. The shell has a named message channel:

```sh
# from any terminal, script or app
~/Projetos/shadow-kde/scripts/widget-send.sh deploy '{"title":"Deploy","text":"Sending…","progress":0.6,"icon":"rocket_launch"}'

# is the same as
qs -p ~/Projetos/shadow-kde ipc call widgets send deploy '{"title":"Deploy","progress":0.6}'
```

- The first argument is the **channel** (a name of your choice); the second, the **data**: JSON
  when it is JSON, otherwise plain text.
- The widget listens like this:

```qml
property var payload: Widgets.lastMessage("deploy")   // the last one, on start

Connections {
    target: Widgets
    function onMessage(channel, value) {
        if (channel === "deploy")
            root.payload = value;
    }
}
```

- The shell keeps the last message of each channel (until it restarts): a widget added later
  receives it on start.
- The `mensagens` example already does this: it shows `title`, `text`, `icon` and a bar with
  `progress` (0 to 1). The channel name is an option, so you don't need to write QML to use it.

Examples of senders:

```sh
# .git/hooks/post-commit
widget-send.sh git "{\"title\":\"$(basename "$PWD")\",\"text\":\"$(git log -1 --format=%s)\",\"icon\":\"commit\"}"

# at the end of a long build
make && widget-send.sh build '{"title":"Build","text":"Done","icon":"check_circle"}' \
     || widget-send.sh build '{"title":"Build","text":"Failed","icon":"error"}'
```

```python
# from a Python app
import json, subprocess
subprocess.run(["qs", "-p", "/home/ana/Projetos/shadow-kde", "ipc", "call", "widgets", "send",
                "sensors", json.dumps({"title": "Living room", "text": "21.5 °C"})])
```

### 6.6 Sockets

For apps with a Unix socket (mpv with `--input-ipc-server`, some daemons), the `Socket` from
`Quickshell.Io` connects directly:

```qml
Socket {
    id: mpv
    path: "/tmp/mpv-socket"
    connected: true
    parser: SplitParser { onRead: line => root.handle(JSON.parse(line)) }
    onConnectedChanged: {
        if (connected) {
            write('{"command":["observe_property",1,"media-title"]}\n');
            flush();
        }
    }
}
```

### 6.7 Doing things in other apps

- Open a URL or file: `Apps.run(["xdg-open", url])`
- Open an app: `Apps.launch(DesktopEntries.byId("org.kde.dolphin"))`
- A command in a terminal: `Apps.run(["konsole", "-e", "htop"])`
- Copy text: `Apps.run(["wl-copy", text])`
- Show a notice in the top pill: `Events.push({ icon: "check", title: "Copied", text: "", duration: 1500 })`
- A real notification (stays in the notification centre):
  `Apps.run(["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications", "--object-path", "/org/freedesktop/Notifications", "--method", "org.freedesktop.Notifications.Notify", "--", "My widget", "0", "", "Title", "Text", "[]", "{}", "5000"])`

---

## 7. Performance

The shell often runs without a graphics card (software renderer), and widgets are always on
screen. To keep them light:

- **Sensible intervals:** 1–2 s only for things like CPU; 30–60 s for commands; minutes for
  APIs. Prefer signals (6.3, 6.5) to polling every few seconds.
- **Light commands**, and never two at once: `if (!proc.running) proc.running = true`.
- **Short animations** of colour, opacity, scale or position, with `Theme.anim*`. No infinite
  animations (spinners) unless needed.
- **No shader effects** (`MultiEffect`, `ShaderEffect`, `layer.effect`): they don't work on the
  software renderer.
- For rounded corners on images use `RoundImage`, not masks.
- Large images: `sourceSize.width/height` set to the displayed size.
- Stop what isn't visible: `running: !root.editing` on animation timers.

---

## 8. Debugging

**While developing:** `scripts/widget-dev.sh <folder>`. Reloads on every save and shows the log
in the terminal.

**What you see when something goes wrong:**

| Symptom | Cause |
|---|---|
| Not in **+** | Error in `manifest.json`: see **Settings → Desktop → Your widgets** |
| "The QML has errors" card | Error in `Widget.qml`: the log gives the line and column |
| "No longer installed" card | The folder was renamed or deleted |
| Size 0 (nothing shows) | The root has no `width`/`height` |

**The shell log**, if you're not using `widget-dev.sh`:

```sh
journalctl --user -u shadow-kde -f
```

It shows the `console.log(...)`, `console.warn(...)` and `console.error(...)` from your QML, and
errors with the file and line (for example
`…/my-widget/Widget.qml?v=3[12:5]: Cannot assign to non-existent property "colour"`).

**QML pitfalls:**

- Don't declare properties with names `Item` already has: `data`, `children`, `state`, `width`,
  `visible`, `opacity`, `scale`… For example, `property var data` breaks the widget. Use
  `payload`, `info`, `items`.
- Properties starting with `on` + an uppercase letter (`onlineCount` is fine, `onAir` is not) are
  read as signal handlers.
- `id`s that are JavaScript reserved words (`from`, `to`, `default`, `function`) give strange
  errors. Use `fromField`, `toField`.
- The `options` value changes as a whole: to react to one option, bind to it directly
  (`interval: root.options.intervalo * 1000`) or use `onOptionsChanged`.
- QML function names cannot start with an uppercase letter.

**Testing the message channel by hand:** `scripts/widget-send.sh my-channel '{"text":"hello"}'`.

---

## 9. Sharing and installing

A widget is just the folder. To share it, **Settings → Desktop** (or **→ Tabs**) →
**Export** next to the extension: it makes a `.zip` of the folder. `zip -r my-widget.zip
my-widget` works too, or a git repository.

To install someone else's widget:

1. **Settings → Desktop** (or **→ Tabs**) → **Choose .zip…**, or drag the `.zip` onto the
   "Install an extension" card.
2. Before installing, a review appears: the name, where it appears, how many files it contains
   and **what the code can do** (run commands, connect to the internet, read/write files,
   sockets, D-Bus) and the scripts it includes. It is read from the code and helps you decide
   whether you trust it: when in doubt, open the `.zip` and read the QML.
3. **Install** (or **Replace**, if you already have it: positions, sizes and options are kept).

The `.zip` can have the `manifest.json` at the root or inside a single folder (whose name is the
id; at the root, the id is the name of the `.zip`). `.zip` files with paths leading outside the
folder, symbolic links, more than 500 files or more than 30 MB are rejected.

You can also do it by hand: unzip into `~/.local/share/shadow-kde/widgets/` (the folder with the
`manifest.json` directly in it) and press **Rescan**. **Remove** (with a second click) deletes
the folder and removes the widget from the desktop and the tabs.

From the command line: `scripts/widgets.py ver|instalar [--substituir]|exportar|remover`.

---

## 10. Quick reference

```text
Folder:         ~/.local/share/shadow-kde/widgets/<id>/{manifest.json, Widget.qml}
Type:           user/<id>
Properties:     options · plain · editing · widgetId · widgetDir   (declare only the ones you use)
Size:           width/height on the root (designed for a 1080 px tall screen)

Develop:        scripts/widget-dev.sh <folder>
Rescan:         qs -p <shell> ipc call widgets rescan
Add:            qs -p <shell> ipc call widgets add user/<id>
Types:          qs -p <shell> ipc call widgets types
Tabs:           "places": { "notch": "Tab.qml", "dashboard": "Tab.qml" }  ·  Settings → Tabs
                qs -p <shell> ipc call widgets tab notch|dashboard user/<id> true|false
Send data:      scripts/widget-send.sh <channel> '<json or text>'
                (= qs -p <shell> ipc call widgets send <channel> '<json>')
Log:            journalctl --user -u shadow-kde -f

In QML:         Widgets.lastMessage(channel) · Connections { target: Widgets; function onMessage(c, v) {} }
                Run.cmd(argv, (code, out, err) => {}) · Apps.run(argv) · Events.push({ icon, title, text })
```

---

## 11. Tabs in the pill and the dashboard

> For a step-by-step tutorial (from scratch to a complete tab), see [`TABS.md`](TABS.md).

An extension can also be a tab: in the pill (when open, next to Music, Weather, Alerts and
Actions) and/or in the dashboard (next to Home, Calendar…). Where is set in `manifest.json`:

```json
{
    "name": "World clocks",
    "icon": "public",
    "places": { "notch": "Tab.qml", "dashboard": "Tab.qml" },
    "options": [ { "key": "cidades", "label": "Cities", "type": "string", "default": "Lisbon=Europe/Lisbon" } ]
}
```

- `places` as an **object**: the QML for each place (they can be different files, or the same one).
- `places` as a **list** (`["desktop", "notch"]`): all use `main` (`Widget.qml`).
- Without `places`, it is only a desktop widget (as before). With `places` but without
  `desktop`, it does not appear in the **+** of widget editing.

The user turns tabs on in **Settings → Tabs** (one list for the pill, another for the
dashboard), where the options are also changed (each place has its own values). They go at the
end of the tabs, with the manifest's `name` and `icon`. `widget-dev.sh` turns them on by itself.

The `relogios` example (in `examples/widgets/`) is a tabs-only extension: the same `Tab.qml` in
both places, more compact in the pill.

### A tab's QML

Unlike a widget, a tab **fills the space it is given**: don't set `width`/`height` on the root
(the shell anchors it). The root can be an `Item` or a layout.

| Place | Space (approx.) | Background |
|---|---|---|
| `notch` | 448 × 144 px, inside the pill's card | `Theme.surfaceCard` (use `Theme.button` for boxes) |
| `dashboard` | 964 × 392 px, below the tabs | the dashboard background (use `Theme.surfaceCard` cards with `Theme.surfaceBorder` and `Theme.radiusCard`, like the rest) |

Properties the shell gives (declare only the ones you use):

| Property | Type | What |
|---|---|---|
| `options` | `var` | The option values (with defaults) for this place |
| `place` | `string` | `"notch"` or `"dashboard"` (so one QML can serve both) |
| `widgetDir` | `string` | The extension's folder |
| `widgetId` | `string` | `<place>-user-<id>` (for storing your own things) |

And an optional signal: declare `signal done()` and emit it to **close** the pill or the
dashboard (for example, after opening an app).

```qml
import QtQuick
import qs

Item {
    property var options: ({})
    property string place: "notch"
    signal done

    Text {
        anchors.centerIn: parent
        text: parent.place === "notch" ? "In the pill" : "In the dashboard"
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: Theme.fontLarge
    }
}
```

A tab only exists while it is open (the pill and the dashboard create it when shown and destroy
it when closed or when switching tabs): `Timer`s stop by themselves, but state is lost. To keep
something between openings, write a file (`FileView`) or use the message channel.

If the QML has an error, the tab shows "This tab has an error" instead of staying blank; the
shell log (`widget-dev.sh` shows it) says which.
