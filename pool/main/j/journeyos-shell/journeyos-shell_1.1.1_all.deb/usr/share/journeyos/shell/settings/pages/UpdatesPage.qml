import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Updates: check, the package list and install (asks for authorization), with progress.
Page {
    id: root

    Component.onCompleted: Updates.list()

    Rectangle {
        Layout.fillWidth: true
        implicitHeight: 92
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        RowLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 14

            MIcon {
                icon: Updates.packages.length ? "system_update" : "verified"
                size: 34
                color: Updates.packages.length ? Theme.accent : Theme.subtext
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text {
                    text: Updates.installing ? Tr.t("Updating… ") + Updates.progress + "%"
                        : Updates.checking ? Tr.t("Searching…")
                        : Updates.packages.length === 0 ? Tr.t("The system is up to date")
                        : Updates.packages.length === 1 ? Tr.t("1 update") : Updates.packages.length + Tr.t(" updates")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge
                    font.weight: Font.Bold
                }
                Text {
                    text: Updates.installing ? Updates.status
                        : Updates.status ? Updates.status
                        : Updates.lastChecked ? Tr.t("Checked at ") + Updates.lastChecked : Tr.t("The list may be out of date: press Check.")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                // Progress
                Rectangle {
                    visible: Updates.installing
                    Layout.fillWidth: true
                    Layout.topMargin: 4
                    implicitHeight: 4
                    radius: 2
                    color: Theme.buttonHover
                    Rectangle {
                        width: parent.width * Updates.progress / 100
                        height: parent.height
                        radius: 2
                        color: Theme.accent
                        Behavior on width {
                            NumberAnimation { duration: Theme.animNormal }
                        }
                    }
                }
            }
            PillButton {
                text: Tr.t("Search")
                enabled: !Updates.checking && !Updates.installing
                onClicked: Updates.check()
            }
            PillButton {
                visible: Updates.packages.length > 0
                text: Tr.t("Install")
                accent: true
                enabled: !Updates.installing && !Updates.checking
                onClicked: Updates.install()
            }
        }
    }

    SectionLabel {
        visible: Updates.packages.length > 0
        text: Tr.t("Packages")
    }

    Repeater {
        model: Updates.packages.slice(0, 80)

        Rectangle {
            required property var modelData
            Layout.fillWidth: true
            implicitHeight: 40
            radius: Theme.radiusSmall + 2
            color: Theme.surfaceCard

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 14
                anchors.rightMargin: 14
                Text {
                    Layout.fillWidth: true
                    text: modelData.name
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                }
                Text {
                    text: modelData.from ? modelData.from + "  →  " + modelData.to : ""
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }
    }
}
