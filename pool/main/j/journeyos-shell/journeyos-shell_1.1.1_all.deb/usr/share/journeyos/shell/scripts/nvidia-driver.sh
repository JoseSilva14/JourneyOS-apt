#!/bin/sh
# NVIDIA's driver for Debian (run in a terminal by the store's "Drivers" card: asks for the password).
# Enables Debian's contrib and non-free components when missing, installs the driver, the firmware
# and the kernel headers (the driver module is built for each kernel), then asks to restart.
set -e
pt() { [ "${SHADOW_LANG:-en}" = pt ]; }
say() { if pt; then printf '%s\n' "$1"; else printf '%s\n' "$2"; fi; }

say "== Driver NVIDIA ==" "== NVIDIA driver =="

if ! apt-cache policy nvidia-driver 2>/dev/null | grep -q "Candidate: [0-9]"; then
    say "A ativar os componentes contrib e non-free do Debian…" "Enabling Debian's contrib and non-free components…"
    for f in /etc/apt/sources.list.d/*.sources; do
        [ -f "$f" ] || continue
        sudo sed -i -E '/^Components:/{/ non-free( |$)/!s/$/ non-free/;/ contrib( |$)/!s/$/ contrib/}' "$f"
    done
    if [ -f /etc/apt/sources.list ]; then
        sudo sed -i -E '/^deb(-src)? /{/ non-free( |$)/!s/$/ non-free/;/ contrib( |$)/!s/$/ contrib/}' /etc/apt/sources.list
    fi
fi

sudo apt update
sudo apt install -y nvidia-driver firmware-misc-nonfree linux-headers-amd64

echo
say "Pronto. Reinicia o computador para usar o driver NVIDIA." "Done. Restart the computer to use the NVIDIA driver."
printf '%s' "$(say 'Carrega em Enter para fechar ' 'Press Enter to close ')"
read -r _
