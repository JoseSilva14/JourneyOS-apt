pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Session (ksmserverrc): what opens at login (last session's apps or nothing), confirm on
// logout, and the lock/suspend/log out/restart/shut down actions with the shell's logout
// screen (session/SessionWindow). scripts/logout-prompt.py owns the name
// org.kde.LogoutPrompt, so Ctrl+Alt+Del and the "Log out" of KDE apps also open the shell's.
Singleton {
    id: root

    property string loginMode: "restorePreviousLogout"   // restorePreviousLogout | emptySession
    property bool confirmLogout: true

    // Logout screen: open, the chosen action and the seconds until it does it on its own (0 = no countdown)
    property bool open: false
    property string selected: "shutdown"
    property int countdown: 0
    readonly property int countdownStart: 30

    property bool canSuspend: false
    property bool canHibernate: false

    // In screen order
    readonly property var actions: [
        { id: "lock", label: Tr.t("Lock"), icon: "lock" },
        { id: "suspend", label: Tr.t("Sleep"), icon: "bedtime", hidden: !canSuspend },
        { id: "hibernate", label: Tr.t("Hibernate"), icon: "downloading", hidden: !canHibernate },
        { id: "logout", label: Tr.t("Log out"), icon: "logout" },
        { id: "reboot", label: Tr.t("Restart"), icon: "restart_alt" },
        { id: "shutdown", label: Tr.t("Shut down"), icon: "power_settings_new" }
    ].filter(a => !a.hidden)

    function refresh() {
        Kcfg.readMany("ksmserverrc", [
            { group: "General", key: "loginMode", fallback: "restorePreviousLogout" },
            { group: "General", key: "confirmLogout", fallback: "true" }
        ], v => {
            root.loginMode = v["General/loginMode"];
            root.confirmLogout = v["General/confirmLogout"] === "true";
        });
        for (const what of ["Suspend", "Hibernate"]) {
            const name = what;
            Run.cmd(["gdbus", "call", "--system", "--dest", "org.freedesktop.login1", "--object-path", "/org/freedesktop/login1",
                "--method", "org.freedesktop.login1.Manager.Can" + name], (code, out) => {
                root["can" + name] = code === 0 && out.includes("'yes'");
            });
        }
    }

    function set(key, value) { Kcfg.write("ksmserverrc", "General", key, value, () => refresh()); }

    function lock() { Apps.run(["loginctl", "lock-session"]); }

    // kind: logout | reboot | shutdown | all. With "confirm on
    // logout" off it acts right away (except "all", which is a choice)
    function prompt(kind) {
        if (!["logout", "reboot", "shutdown"].includes(kind))
            kind = "all";
        if (!confirmLogout && kind !== "all") {
            perform(kind);
            return;
        }
        selected = kind === "all" ? "shutdown" : kind;
        // Only a concrete request runs the countdown (as in KDE)
        countdown = kind === "all" ? 0 : countdownStart;
        open = true;
    }

    function cancel() {
        open = false;
        countdown = 0;
    }

    function perform(id) {
        open = false;
        countdown = 0;
        // A moment for the logout screen to disappear first (otherwise it shows up in the lock screen)
        later.action = id;
        later.restart();
    }

    // Without Plasma (no ksmserver, so no org.kde.Shutdown): logind/systemd directly
    readonly property var fallbacks: ({
        logout: ["sh", "-c", "loginctl terminate-session \"${XDG_SESSION_ID:-self}\""],
        logoutAndReboot: ["systemctl", "reboot"],
        logoutAndShutdown: ["systemctl", "poweroff"]
    })

    function run(id) {
        const shutdown = method => Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.Shutdown",
            "--object-path", "/Shutdown", "--method", "org.kde.Shutdown." + method], code => {
            if (code !== 0)
                Run.cmd(root.fallbacks[method]);
        });
        switch (id) {
        case "lock": lock(); break;
        case "suspend": Apps.run(["systemctl", "suspend"]); break;
        case "hibernate": Apps.run(["systemctl", "hibernate"]); break;
        case "logout": shutdown("logout"); break;
        case "reboot": shutdown("logoutAndReboot"); break;
        case "shutdown": shutdown("logoutAndShutdown"); break;
        }
    }

    Timer {
        id: later
        property string action: ""
        interval: 250
        onTriggered: root.run(action)
    }

    Timer {
        running: root.open && root.countdown > 0
        interval: 1000
        repeat: true
        onTriggered: {
            root.countdown -= 1;
            if (root.countdown === 0)
                root.perform(root.selected);
        }
    }

    // --- KDE requests (org.kde.LogoutPrompt) ---
    Process {
        id: prompts
        running: true
        command: [Quickshell.shellPath("scripts/logout-prompt.py")]
        stdout: SplitParser {
            onRead: line => root.prompt(line.trim())
        }
        // KDE's was open, or it crashed: try again shortly
        onExited: retry.restart()
    }
    Timer {
        id: retry
        interval: 10000
        onTriggered: prompts.running = true
    }

    Component.onCompleted: refresh()

    IpcHandler {
        target: "session"
        function prompt(kind: string): void { root.prompt(kind); }
        function cancel(): void { root.cancel(); }
    }
}
