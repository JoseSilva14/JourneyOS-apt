pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Bluetooth pairing agent (scripts/bt-agent.py, the shell's bluedevil): the codes to confirm,
// type or show while pairing, shown by auth/PairWindow.
Singleton {
    id: root

    // { id, type: confirm|authorize|service|pin|passkey|display, device, name, passkey?, service? }
    property var request: null
    readonly property bool active: request !== null

    function answer(ok, value) {
        if (!request)
            return;
        if (request.type !== "display")
            agent.write(JSON.stringify({ id: request.id, ok: ok, value: value ?? "" }) + "\n");
        request = null;
    }

    Process {
        id: agent
        running: true
        stdinEnabled: true
        command: [Quickshell.shellPath("scripts/bt-agent.py")]
        stdout: SplitParser {
            onRead: line => {
                let r;
                try {
                    r = JSON.parse(line);
                } catch (e) {
                    return;
                }
                if (r.type === "ready")
                    return;
                if (r.type === "cancel") {
                    root.request = null;
                    return;
                }
                root.request = r;
            }
        }
        onExited: {
            root.request = null;
            restart.start();
        }
    }

    // bluetoothd absent or the script stopped: try again later
    Timer {
        id: restart
        interval: 10000
        onTriggered: agent.running = true
    }

    // The code shown for typing on the device closes by itself (BlueZ does not say when it is done)
    Timer {
        running: root.request?.type === "display"
        interval: 60000
        onTriggered: root.request = null
    }

    IpcHandler {
        target: "btagent"
        function status(): string { return JSON.stringify(root.request); }
        function accept(value: string): void { root.answer(true, value); }
        function reject(): void { root.answer(false); }
    }
}
