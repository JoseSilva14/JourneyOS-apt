import QtQuick
import qs

// Line chart with a filled area below. values: numbers; max: top (0 = the largest value).
Canvas {
    id: root

    property var values: []
    property real max: 1
    property int capacity: 60
    property color lineColor: Theme.ringFill
    property color fillColor: Theme.graphFill

    onValuesChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        const ctx = getContext("2d");
        ctx.reset();
        const n = values.length;
        if (n < 2)
            return;
        const top = max > 0 ? max : Math.max(1, ...values);
        const step = width / (capacity - 1);
        const x0 = width - (n - 1) * step;
        const y = v => height - 2 - Math.min(1, v / top) * (height - 4);

        ctx.beginPath();
        ctx.moveTo(x0, y(values[0]));
        for (let i = 1; i < n; i++)
            ctx.lineTo(x0 + i * step, y(values[i]));
        ctx.lineWidth = 2;
        ctx.strokeStyle = lineColor;
        ctx.lineJoin = "round";
        ctx.stroke();

        ctx.lineTo(width, height);
        ctx.lineTo(x0, height);
        ctx.closePath();
        ctx.fillStyle = fillColor;
        ctx.fill();
    }
}
