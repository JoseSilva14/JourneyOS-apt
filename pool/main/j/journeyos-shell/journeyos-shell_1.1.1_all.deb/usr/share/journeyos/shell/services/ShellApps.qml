pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// App consistency:
//  - the shell's tools have .desktop entries (shadow-kde-<id>), with icons in the shell's style
//    (assets/icons/), so they show up in the launcher, the Apps tab and the dock like any app; when
//    opened, Apps.launch calls them directly;
//  - apps the shell replaces (or that are just internal KDE pieces) are hidden from the
//    launcher and the Apps tab (config.json launcher.hideReplaced; launcher.shown = those the
//    user still wants to see; launcher.hidden = those they hid).
// Nothing is uninstalled: hiding is just not showing.
Singleton {
    id: root

    readonly property var cfg: Config.options.launcher

    // The tools (id → .desktop shadow-kde-<id>)
    readonly property var tools: [
        { id: "calculadora", name: Tr.t("Calculator"), generic: Tr.t("Calculator"), icon: "calculadora",
          comment: Tr.t("Math, percentages and conversions"), keywords: "calculator;math;kcalc;calculadora;contas;calcular;",
          run: () => Calculator.toggle() },
        { id: "monitor", name: Tr.t("System monitor"), generic: Tr.t("System monitor"), icon: "monitor",
          comment: Tr.t("Processor, memory, disk and network"), keywords: "monitor;system;processes;cpu;memory;performance;sistema;processos;memória;desempenho;",
          run: () => Dashboard.toggle("performance", null) },
        { id: "captura", name: Tr.t("Screenshot##app"), generic: Tr.t("Screenshot##app"), icon: "captura",
          comment: Tr.t("Region, screen or window"), keywords: "screenshot;capture;print;screen;image;captura;ecrã;imagem;",
          run: () => Capture.start("region") },
        { id: "conta-gotas", name: Tr.t("Color picker"), generic: Tr.t("Color picker##seletor"), icon: "conta-gotas",
          comment: Tr.t("Copies the color of any point on the screen"), keywords: "color;colour;picker;eyedropper;hex;cor;cores;conta-gotas;pipeta;",
          run: () => Capture.start("color") },
        { id: "emojis", name: Tr.t("Emojis and symbols"), generic: Tr.t("Emoji picker"), icon: "emojis",
          comment: Tr.t("Find and copy emojis"), keywords: "emoji;emojis;symbols;smile;símbolos;",
          run: () => Qt.callLater(() => { Launcher.toggle(null); Launcher.query = ":"; }) },
        { id: "area-transferencia", name: Tr.t("Clipboard"), generic: Tr.t("History of what you copied"), icon: "area-transferencia",
          comment: Tr.t("What you copied recently"), keywords: "clipboard;copy;paste;history;área de transferência;copiar;colar;histórico;",
          run: () => Clipboard.toggle(null) },
        { id: "notas", name: Tr.t("Notes and tasks"), generic: Tr.t("Notes"), icon: "notas",
          comment: Tr.t("Notes and to-do list"), keywords: "notes;tasks;todo;list;notas;tarefas;lista;",
          run: () => Dashboard.toggle("notes", null) }
    ]
    function toolFor(desktopId) {
        return tools.find(t => "shadow-kde-" + t.id === desktopId) ?? null;
    }

    // Apps the shell replaces (entry id → what to use instead) or
    // that are internal pieces of no interest in the launcher
    readonly property var replaced: ({
        "org.kde.kcalc": Tr.t("Replaced by the shell's Calculator"),
        "org.kde.plasma-systemmonitor": Tr.t("Replaced by the System monitor (dashboard → Performance)"),
        "org.kde.spectacle": Tr.t("Replaced by the shell's Screenshot (stays installed: the shell uses it underneath)"),
        "org.kde.plasma.emojier": Tr.t("Replaced by emojis in the launcher (type \":\")"),
        "systemsettings": Tr.t("Replaced by the shell's Settings"),
        "org.kde.kinfocenter": Tr.t("Replaced by Settings → About"),
        "org.kde.plasma-welcome": Tr.t("Replaced by the shell's Welcome"),
        "org.kde.kmenuedit": Tr.t("Replaced by this page"),
        "org.kde.sweeper": Tr.t("Replaced by Settings → Privacy"),
        "org.kde.kfind": Tr.t("Replaced by the launcher's file search"),
        "org.kde.khelpcenter": Tr.t("KDE help (doesn't apply to the shell)"),
        "org.kde.drkonqi.coredump.gui": Tr.t("KDE debugging tool"),
        "org.kde.contactprintthemeeditor": Tr.t("Internal KAddressBook component"),
        "org.kde.contactthemeeditor": Tr.t("Internal KAddressBook component"),
        "org.kde.headerthemeeditor": Tr.t("Internal KMail component"),
        "org.kde.pimdataexporter": Tr.t("Internal KMail/Kontact component"),
        "org.kde.sieveeditor": Tr.t("Internal KMail component"),
        "org.kde.ktnef": Tr.t("Internal KMail component"),
        "org.kde.kontrast": Tr.t("Contrast checking: the shell's Color picker copies colors"),
        "konqbrowser": Tr.t("Old KDE browser (you have Firefox)"),
        "debian-xterm": Tr.t("Old terminal (you have Konsole)"),
        "debian-uxterm": Tr.t("Old terminal (you have Konsole)"),
        "display-im7.q16": Tr.t("ImageMagick component (the shell uses it underneath)")
    })

    // Entries made for other desktops (NotShowIn=KDE / OnlyShowIn without KDE):
    // DesktopEntries does not read those fields, so scripts/apps-outros.py reads them
    property var otherDesktops: []
    Component.onCompleted: Run.cmd([Quickshell.shellPath("scripts/apps-outros.py")], (code, out) => {
        if (code === 0)
            root.otherDesktops = out.trim().split("\n").filter(l => l);
    })

    // Why it is hidden ("" = it is not)
    function reason(id) {
        if (id in replaced)
            return replaced[id];
        if (otherDesktops.includes(id))
            return Tr.t("Made for other desktops (not KDE)");
        return "";
    }

    function isHidden(id) {
        if (otherDesktops.includes(id))
            return true;
        if (cfg.hidden.includes(id))
            return true;
        return cfg.hideReplaced && id in replaced && !cfg.shown.includes(id);
    }
    function setHidden(id, hide) {
        if (id in replaced) {
            cfg.shown = hide ? cfg.shown.filter(x => x !== id) : [...new Set([...cfg.shown, id])];
            if (hide && !cfg.hideReplaced)
                cfg.hidden = [...new Set([...cfg.hidden, id])];
            if (!hide)
                cfg.hidden = cfg.hidden.filter(x => x !== id);
        } else {
            cfg.hidden = hide ? [...new Set([...cfg.hidden, id])] : cfg.hidden.filter(x => x !== id);
        }
    }

    // The tools' .desktop entries (written at startup, like the dashboard/settings ones)
    Instantiator {
        model: root.tools

        FileView {
            required property var modelData
            path: Quickshell.env("HOME") + "/.local/share/applications/shadow-kde-" + modelData.id + ".desktop"
            atomicWrites: true
            printErrors: false
            // Exec is used outside the shell (Dolphin, another launcher); in the shell, Apps.launch calls the tool
            // In the shell language; rewritten when the language changes
            readonly property string entryText: `[Desktop Entry]
Type=Application
Name=${Tr.t(modelData.name)}
GenericName=${Tr.t(modelData.generic)}
Comment=${Tr.t(modelData.comment)}
Icon=${Quickshell.shellPath("assets/icons/" + modelData.icon + ".svg")}
Exec=qs -p ${Quickshell.shellPath("")} ipc call apps open ${modelData.id}
Categories=Utility;
Keywords=${modelData.keywords}${Tr.t(modelData.name)};
StartupNotify=false
`
            onEntryTextChanged: setText(entryText)
            Component.onCompleted: setText(entryText)
        }
    }

    IpcHandler {
        target: "apps"
        // Opens a shell tool (the Exec of the .desktop entries)
        function open(id: string): void {
            const t = root.tools.find(x => x.id === id);
            if (t)
                t.run();
        }
        function hidden(): string { return Launcher.allApps.filter(e => root.isHidden(e.id)).map(e => e.id).join(" "); }
    }
}
