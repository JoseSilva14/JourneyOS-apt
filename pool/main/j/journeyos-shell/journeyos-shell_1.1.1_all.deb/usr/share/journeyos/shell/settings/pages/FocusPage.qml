import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Focus modes: what each one changes (notifications, keep awake, power, theme, wallpaper) and
// the schedule on which it turns on by itself. Leaving a mode restores everything.
Page {
    id: root

    property string editing: Focus.active || Focus.modes[0]?.id || ""
    readonly property var m: Focus.mode(editing)

    function set(changes) { Focus.update(editing, changes); }
    function setSchedule(changes) { Focus.update(editing, { schedule: Object.assign({}, m.schedule, changes) }); }

    // Mode being edited and activated
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: header.implicitHeight + 32
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        ColumnLayout {
            id: header
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.margins: 16
            spacing: 12

            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Segmented {
                    model: Focus.modes.map(f => ({ id: f.id, label: Tr.t(f.name), icon: f.icon }))
                    current: root.editing
                    onSelected: id => root.editing = id
                }
                Item { Layout.fillWidth: true }
                PillButton {
                    text: Focus.active === root.editing ? Tr.t("Turn off") : Tr.t("Turn on")
                    accent: Focus.active !== root.editing
                    onClicked: Focus.toggle(root.editing)
                }
            }

            Text {
                Layout.fillWidth: true
                text: Focus.active === root.editing
                    ? (Config.options.focus.auto ? Tr.t("On by schedule. When it ends, everything goes back as it was.") : Tr.t("On. When it ends, everything goes back as it was."))
                    : Focus.current ? Tr.t("Active now: ") + Focus.current.name + "."
                    : Tr.t("No mode active.")
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }

    SectionLabel { text: Tr.t("When on") }

    SettingRow {
        title: Tr.t("Do not disturb")
        description: Tr.t("Only urgent alerts show; the rest stay in the center.")
        icon: "notifications_off"
        Toggle {
            checked: root.m?.dnd ?? false
            onToggled: on => root.set({ dnd: on })
        }
    }

    SettingRow {
        title: Tr.t("Keep awake")
        description: Tr.t("No sleep, screen off or lock.")
        icon: "coffee"
        Toggle {
            checked: root.m?.keepAwake ?? false
            onToggled: on => root.set({ keepAwake: on })
        }
    }

    SettingRow {
        visible: Power.profiles.length > 0
        title: Tr.t("Power profile")
        description: Tr.t("\"Same\" keeps whatever is set.")
        icon: "speed"
        Segmented {
            model: ["", ...Power.profiles].map(p => ({ id: p, label: Focus.profileNames[p] ?? p }))
            current: root.m?.profile ?? ""
            onSelected: id => root.set({ profile: id })
        }
    }

    SettingRow {
        title: Tr.t("Theme")
        description: Tr.t("Light or dark while the mode is on.")
        icon: "contrast"
        Segmented {
            model: [
                { id: "", label: Tr.t("Same") },
                { id: "dark", label: Tr.t("Dark") },
                { id: "light", label: Tr.t("Light") }
            ]
            current: root.m?.theme ?? ""
            onSelected: id => root.set({ theme: id })
        }
    }

    SettingRow {
        title: "Wallpaper"
        description: root.m?.wallpaper ? root.m.wallpaper.split("/").pop() : Tr.t("Keeps whatever is set.")
        icon: "wallpaper"
        RowLayout {
            spacing: 6
            PillButton {
                text: Tr.t("Use current")
                enabled: Config.options.wallpaper !== ""
                onClicked: root.set({ wallpaper: Config.options.wallpaper })
            }
            PillButton {
                visible: (root.m?.wallpaper ?? "") !== ""
                text: Tr.t("Remove##tirar")
                onClicked: root.set({ wallpaper: "" })
            }
        }
    }

    SectionLabel { text: Tr.t("Schedule") }

    SettingRow {
        title: Tr.t("Turn on automatically")
        description: Tr.t("Turns on and off at the set time, on the chosen days. If you turn it off midway, it only comes back the next day.")
        icon: "schedule"
        Toggle {
            checked: root.m?.schedule?.enabled ?? false
            onToggled: on => root.setSchedule({ enabled: on })
        }
    }

    SettingRow {
        enabled: root.m?.schedule?.enabled ?? false
        opacity: enabled ? 1 : 0.5
        title: Tr.t("From … to")
        description: Tr.t("24 h format (e.g. 23:00 to 07:00 goes past midnight).")
        icon: "more_time"
        RowLayout {
            spacing: 8
            TimeField {
                text: root.m?.schedule?.from ?? ""
                onTimeChanged: value => root.setSchedule({ from: value })
            }
            Text {
                text: Tr.t("at")
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            TimeField {
                text: root.m?.schedule?.to ?? ""
                onTimeChanged: value => root.setSchedule({ to: value })
            }
        }
    }

    SettingRow {
        enabled: root.m?.schedule?.enabled ?? false
        opacity: enabled ? 1 : 0.5
        title: Tr.t("Days")
        icon: "calendar_month"
        Row {
            spacing: 6
            Repeater {
                model: ["S", "T", "Q", "Q", "S", "S", "D"]
                delegate: Rectangle {
                    id: day
                    required property string modelData
                    required property int index
                    readonly property int n: index + 1
                    readonly property bool on: (root.m?.schedule?.days ?? []).includes(n)

                    width: 30
                    height: 30
                    radius: 15
                    color: on ? Theme.accent : dayMouse.containsMouse ? Theme.buttonHover : Theme.button

                    Behavior on color {
                        ColorAnimation { duration: Theme.animFast }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: day.modelData
                        color: day.on ? Theme.accentText : Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        font.weight: Font.Bold
                    }
                    MouseArea {
                        id: dayMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            const days = root.m.schedule.days ?? [];
                            root.setSchedule({ days: day.on ? days.filter(d => d !== day.n) : [...days, day.n].sort() });
                        }
                    }
                }
            }
        }
    }

    // --- Pomodoro (the pill's Time tab; focus and break durations are changed there) ---
    SectionLabel { text: "Pomodoro" }

    SettingRow {
        title: Tr.t("Long break")
        description: Tr.t("After ") + Config.options.pomodoro.every + Tr.t(" sessions. Focus of ")
            + Config.options.pomodoro.focus + Tr.t(" min and break of ") + Config.options.pomodoro.shortBreak + Tr.t(" min (change them in the pill).")
        icon: "coffee"
        Segmented {
            model: [10, 15, 20, 30].map(n => ({ id: String(n), label: n + Tr.t(" min") }))
            current: String(Config.options.pomodoro.longBreak)
            onSelected: id => Config.options.pomodoro.longBreak = Number(id)
        }
    }

    SettingRow {
        title: Tr.t("Sessions until long break")
        icon: "repeat"
        Segmented {
            model: [2, 3, 4, 5, 6].map(n => ({ id: String(n), label: String(n) }))
            current: String(Config.options.pomodoro.every)
            onSelected: id => Config.options.pomodoro.every = Number(id)
        }
    }

    SettingRow {
        title: Tr.t("Start the next phase automatically")
        description: Tr.t("When off, the Pomodoro waits for you to press continue in the pill.")
        icon: "play_circle"
        Toggle {
            checked: Config.options.pomodoro.autoStart
            onToggled: on => Config.options.pomodoro.autoStart = on
        }
    }

    SettingRow {
        title: Tr.t("Focus mode during Pomodoro")
        description: Tr.t("Turns on when starting and off when stopping (if no other was already on).")
        icon: "center_focus_strong"
        Select {
            options: [{ id: "", label: Tr.t("None") }, ...Focus.modes.map(m => ({ id: m.id, label: Tr.t(m.name) }))]
            current: Config.options.pomodoro.focusMode
            onSelected: id => Config.options.pomodoro.focusMode = id
        }
    }

    SettingRow {
        title: Tr.t("Show the next task")
        description: Tr.t("The first pending task from the dashboard, so you can mark it done.")
        icon: "task_alt"
        Toggle {
            checked: Config.options.pomodoro.showTask
            onToggled: on => Config.options.pomodoro.showTask = on
        }
    }

    // HH:MM time: only notifies (timeChanged) with a valid time; an invalid one reverts to the previous
    component TimeField: TextField {
        id: field
        property string last: ""
        signal timeChanged(string value)
        Component.onCompleted: last = text
        implicitWidth: 80
        placeholder: "00:00"
        onAccepted: value => {
            const m = /^(\d{1,2})(?::?(\d{2}))?$/.exec(value.trim());
            if (!m || Number(m[1]) > 23 || Number(m[2] ?? 0) > 59) {
                field.text = field.last;
                return;
            }
            const fixed = m[1].padStart(2, "0") + ":" + (m[2] ?? "00");
            field.text = fixed;
            if (fixed !== field.last) {
                field.last = fixed;
                field.timeChanged(fixed);
            }
        }
    }
}
