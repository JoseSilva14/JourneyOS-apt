import QtQuick
import QtCore
import org.kde.kwin.decoration

// shadow-kde window decoration (KWin's Aurorae engine, in QML).
// 34 px bar with the shell's surface colour, 12 px corners at the top, 1 px outline,
// centred title and round buttons on the right. Colours come from the theme.conf the shell exports
// (KWin only reads them when creating the decoration; the shell recreates it when the theme changes).
Decoration {
    id: root

    alpha: true

    readonly property bool maximized: decoration.client.maximized
    readonly property bool active: decoration.client.active

    // Sizes
    readonly property int titleHeight: 34
    readonly property int radius: maximized ? 0 : 12
    readonly property int pad: maximized ? 0 : 12          // shadow space
    readonly property int resizeMargin: 6                 // invisible margin for resizing

    Settings {
        id: theme
        location: "file://" + StandardPaths.writableLocation(StandardPaths.HomeLocation)
            .toString().replace("file://", "") + "/.local/state/shadow-kde/theme.conf"
        category: "Theme"

        property bool light: false
        property string bg: "#111112"
        property string surface: "#18181a"
        property string border: "#14ffffff"
        property string button: "#0fffffff"
        property string buttonHover: "#1fffffff"
        property string text: "#ececec"
        property string subtext: "#9a9a9c"
        property string dim: "#5c5c60"
        property string accent: "#f2f2f2"
        property string font: "JetBrains Mono"
        property string iconFont: ""
    }

    FontLoader {
        id: icons
        source: theme.iconFont ? "file://" + theme.iconFont : ""
    }

    function updateBorders() {
        borders.setBorders(maximized ? 0 : 1);
        borders.setTitle(titleHeight);
        maximizedBorders.setBorders(0);
        maximizedBorders.setTitle(titleHeight);
        padding.setAllBorders(pad);
        extendedBorders.setAllBorders(maximized ? 0 : resizeMargin);
    }

    Component.onCompleted: updateBorders()
    onMaximizedChanged: updateBorders()

    // Drag area: KWin reads it in window coordinates, without the shadow margin,
    // so it is a separate item at (0, 0) the size of the bar
    Item {
        id: titleArea
        width: frame.width
        height: root.titleHeight
        Component.onCompleted: decoration.installTitleItem(titleArea)
    }

    // Shadow: increasingly faint layers outwards (no effects, for the software renderer)
    Repeater {
        model: root.maximized ? 0 : 4

        Rectangle {
            required property int index
            readonly property int spread: (index + 1) * 3
            x: root.pad - spread
            y: root.pad - spread + 3
            width: root.width - 2 * root.pad + 2 * spread
            height: root.height - 2 * root.pad + 2 * spread - 3
            radius: root.radius + spread
            color: "transparent"
            border.width: 3
            border.color: Qt.rgba(0, 0, 0, (root.active ? 0.13 : 0.07) / (index + 1))
        }
    }

    // The window without the shadow margin
    Item {
        id: frame
        x: root.pad
        y: root.pad
        width: root.width - 2 * root.pad
        height: root.height - 2 * root.pad

        // Background and outline: rounded corners at the top, square at the bottom (the window content
        // covers the bottom part and has no rounded corners)
        Rectangle {
            anchors.fill: parent
            radius: root.radius
            color: root.active ? theme.surface : theme.bg
            border.width: root.maximized ? 0 : 1
            border.color: theme.border
        }
        Rectangle {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            height: Math.max(0, parent.height - root.titleHeight)
            color: root.active ? theme.surface : theme.bg
            border.width: root.maximized ? 0 : 1
            border.color: theme.border
        }

        // Title bar
        Item {
            id: titleBar
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            height: root.titleHeight

            Text {
                anchors.centerIn: parent
                width: Math.min(implicitWidth, parent.width - 2 * (buttons.width + 24))
                text: decoration.client.caption
                elide: Text.ElideMiddle
                horizontalAlignment: Text.AlignHCenter
                color: root.active ? theme.text : theme.dim
                font.family: theme.font
                font.pixelSize: 12
                font.weight: Font.DemiBold
            }

            Row {
                id: buttons
                anchors.right: parent.right
                anchors.rightMargin: 10
                anchors.verticalCenter: parent.verticalCenter
                spacing: 6

                WindowButton {
                    buttonType: DecorationOptions.DecorationButtonMinimize
                    visible: decoration.client.minimizeable
                    glyph: "remove"
                    colors: theme
                    iconFont: icons.name
                }
                WindowButton {
                    buttonType: DecorationOptions.DecorationButtonMaximizeRestore
                    visible: decoration.client.maximizeable
                    glyph: root.maximized ? "filter_none" : "crop_square"
                    colors: theme
                    iconFont: icons.name
                }
                WindowButton {
                    buttonType: DecorationOptions.DecorationButtonClose
                    visible: decoration.client.closeable
                    glyph: "close"
                    danger: true
                    colors: theme
                    iconFont: icons.name
                }
            }

            // Line between the bar and the content
            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.leftMargin: 1
                anchors.rightMargin: 1
                height: 1
                color: theme.border
            }
        }
    }
}
