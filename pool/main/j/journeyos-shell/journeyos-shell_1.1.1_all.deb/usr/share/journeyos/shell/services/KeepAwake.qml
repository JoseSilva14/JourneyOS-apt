pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// "Keep awake": no suspending, screen blanking or locking while on
// (scripts/keep-awake.py holds KDE's inhibitions; stopping it releases
// them). Not saved: each session starts with normal power management.
Singleton {
    id: root

    property bool enabled: false
    readonly property bool active: helper.running

    function toggle() { enabled = !enabled; }

    Process {
        id: helper
        running: root.enabled
        command: [Quickshell.shellPath("scripts/keep-awake.py")]
        // Failed (no powerdevil or ScreenSaver): turn the switch off
        onExited: code => {
            if (root.enabled && code !== 0)
                root.enabled = false;
        }
    }

    IpcHandler {
        target: "keepawake"
        function toggle(): void { root.toggle(); }
        function status(): bool { return root.active; }
    }
}
