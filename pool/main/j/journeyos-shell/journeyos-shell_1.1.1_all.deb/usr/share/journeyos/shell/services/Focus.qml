pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Focus modes: profiles (Work, Gaming, Rest…) that change several things at once — Do not disturb,
// Keep awake, power profile, light/dark theme and wallpaper — and restore them on exit. Each mode
// can have a schedule (enters and exits on its own on the chosen days). Everything in config.json
// (focus): the modes, the active one and the previous state (survives restarts).
Singleton {
    id: root

    readonly property var cfg: Config.options.focus
    readonly property var modes: cfg.modes
    readonly property string active: cfg.active
    readonly property var current: modes.find(m => m.id === active) ?? null

    readonly property var profileNames: ({ "": Tr.t("Same"), "power-saver": Tr.t("Power saver"), balanced: Tr.t("Balanced"), performance: Tr.t("Performance") })

    function mode(id) { return modes.find(m => m.id === id) ?? null; }

    // Changes a mode (JsonAdapter only saves lists that are replaced as a whole)
    function update(id, changes) {
        const before = mode(id);
        cfg.modes = modes.map(m => m.id === id ? Object.assign({}, m, changes) : m);
        // Active: apply what changed right away (the previous state is already saved)
        if (id === active && before)
            apply(Object.assign({}, before, changes));
    }

    function toggle(id) {
        if (active === id)
            deactivate();
        else
            activate(id, false);
    }

    // The last one used (the panel button)
    function toggleLast() {
        if (active)
            deactivate();
        else
            activate(mode(cfg.last) ? cfg.last : modes[0]?.id, false);
    }

    function activate(id, bySchedule) {
        const m = mode(id);
        if (!m || active === id)
            return;
        if (active)
            restore();
        // What was there before, to restore on exit
        cfg.saved = {
            dnd: Notifs.dnd,
            keepAwake: KeepAwake.enabled,
            profile: Power.profile,
            theme: Config.options.theme.mode,
            wallpaper: Config.options.wallpaper
        };
        cfg.active = id;
        cfg.auto = bySchedule;
        cfg.last = id;
        apply(m);
        Events.push({ icon: m.icon, title: Tr.t(m.name), text: bySchedule ? Tr.t("Focus mode (scheduled)") : Tr.t("Focus mode"), duration: 2000 });
    }

    function apply(m) {
        if (m.dnd)
            Notifs.setDnd(true);
        if (m.keepAwake)
            KeepAwake.enabled = true;
        if (m.profile && Power.profiles.includes(m.profile))
            Power.setProfile(m.profile);
        if (m.theme)
            Config.options.theme.mode = m.theme;
        if (m.wallpaper)
            Config.options.wallpaper = m.wallpaper;
    }

    // Restores only what the mode changed
    function restore() {
        const m = current, s = cfg.saved ?? {};
        if (m) {
            if (m.dnd && s.dnd !== undefined)
                Notifs.setDnd(s.dnd);
            if (m.keepAwake && s.keepAwake !== undefined)
                KeepAwake.enabled = s.keepAwake;
            if (m.profile && s.profile)
                Power.setProfile(s.profile);
            if (m.theme && s.theme)
                Config.options.theme.mode = s.theme;
            if (m.wallpaper && s.wallpaper !== undefined)
                Config.options.wallpaper = s.wallpaper;
        }
        cfg.saved = {};
        cfg.active = "";
        cfg.auto = false;
    }

    function deactivate() {
        const m = current;
        if (!m)
            return;
        // Exited manually during the schedule: does not re-enter until the schedule ends
        const end = windowEnd(m, new Date());
        if (end)
            cfg.skipUntil = end.getTime();
        restore();
        Events.push({ icon: "do_not_disturb_off", title: Tr.t("End of mode ") + Tr.t(m.name), text: "", duration: 2000 });
    }

    // --- Schedule ---
    function minutes(hhmm) {
        const p = String(hhmm).split(":");
        return Number(p[0]) * 60 + Number(p[1] ?? 0);
    }

    // End of the period "now" is in (null if outside). Periods may cross
    // midnight (23:00–07:00): the day that counts is the start day.
    function windowEnd(m, now) {
        const s = m.schedule;
        if (!s?.enabled)
            return null;
        const from = minutes(s.from), to = minutes(s.to);
        const nowMin = now.getHours() * 60 + now.getMinutes();
        const days = s.days ?? [1, 2, 3, 4, 5, 6, 7];
        const dayOf = d => d.getDay() === 0 ? 7 : d.getDay();   // 1 = Monday … 7 = Sunday
        const at = (base, mins, addDays) => {
            const d = new Date(base);
            d.setDate(d.getDate() + addDays);
            d.setHours(Math.floor(mins / 60), mins % 60, 0, 0);
            return d;
        };
        if (from < to)
            return days.includes(dayOf(now)) && nowMin >= from && nowMin < to ? at(now, to, 0) : null;
        // Crosses midnight
        if (nowMin >= from && days.includes(dayOf(now)))
            return at(now, to, 1);
        const yesterday = new Date(now);
        yesterday.setDate(now.getDate() - 1);
        if (nowMin < to && days.includes(dayOf(yesterday)))
            return at(now, to, 0);
        return null;
    }

    function check() {
        if (!Config.ready)
            return;
        const now = new Date();
        // Has the scheduled active mode ended?
        if (current && cfg.auto && !windowEnd(current, now)) {
            const name = current.name;
            restore();
            Events.push({ icon: "do_not_disturb_off", title: Tr.t("End of mode ") + name, text: "", duration: 2000 });
        }
        if (active || now.getTime() < (cfg.skipUntil ?? 0))
            return;
        const due = modes.find(m => windowEnd(m, now) !== null);
        if (due)
            activate(due.id, true);
    }

    Timer {
        running: Config.ready
        interval: 30000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.check()
    }

    // The schedules changed: check right away
    onModesChanged: Qt.callLater(check)

    Component.onCompleted: {
        Power.refresh();
        if (Config.ready)
            migrateNames();
    }

    IpcHandler {
        target: "focus"
        function toggle(id: string): void { id ? root.toggle(id) : root.toggleLast(); }
        function off(): void { root.deactivate(); }
        function status(): string { return root.active; }
    }

    // The default modes used to be named in Portuguese: rename them (only if still unchanged)
    function migrateNames() {
        const old = { work: "Trabalho", game: "Jogo", rest: "Descanso" };
        const now = { work: "Work", game: "Gaming", rest: "Rest" };
        const modes = Config.options.focus.modes;
        if (!modes.some(m => old[m.id] === m.name))
            return;
        Config.options.focus.modes = modes.map(m => old[m.id] === m.name ? Object.assign({}, m, { name: now[m.id] }) : m);
    }
    Connections {
        target: Config
        function onReadyChanged() { if (Config.ready) root.migrateNames(); }
    }
}
