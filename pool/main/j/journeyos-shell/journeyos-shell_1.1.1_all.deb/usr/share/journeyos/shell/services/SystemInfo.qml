pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Computer information (About tab), read once, and the pending updates.
Singleton {
    id: root

    property string hostname: ""
    property string os: ""
    property string kernel: ""
    property string cpu: ""
    property int cores: 0
    property string gpu: ""
    property real memGiB: 0
    property string desktop: ""
    property int packages: 0
    property int updates: -1         // -1 = not known yet

    readonly property string script: `
echo "host:$(cat /proc/sys/kernel/hostname)"
. /etc/os-release 2>/dev/null; echo "os:$PRETTY_NAME"
echo "kernel:$(uname -r)"
echo "cpu:$(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2- | sed 's/^ *//')"
echo "cores:$(nproc)"
echo "gpu:$(lspci 2>/dev/null | grep -i -E 'vga|3d|display' | head -n1 | cut -d: -f3- | sed 's/^ *//')"
echo "mem:$(grep MemTotal /proc/meminfo | awk '{print $2}')"
if command -v plasmashell >/dev/null; then
    echo "desktop:KDE Plasma $(plasmashell --version 2>/dev/null | awk '{print $2}')"
else
    echo "desktop:KWin $(kwin_wayland --version 2>/dev/null | awk '{print $2}')"
fi
echo "packages:$(dpkg-query -f '.\\n' -W 2>/dev/null | wc -l)"
`

    function checkUpdates() {
        if (!updatesProc.running)
            updatesProc.running = true;
    }

    // Opens a terminal with the upgrade (asks for the password there)
    function upgrade() {
        Apps.run(["konsole", "-e", "sh", "-c",
            "sudo apt update && sudo apt full-upgrade; echo; read -p '" + Tr.t("Press Enter to close") + " ' x"]);
    }

    Process {
        running: true
        command: ["sh", "-c", root.script]
        stdout: StdioCollector {
            onStreamFinished: {
                for (const line of text.trim().split("\n")) {
                    const i = line.indexOf(":");
                    const k = line.slice(0, i), v = line.slice(i + 1).trim();
                    if (k === "host") root.hostname = v;
                    else if (k === "os") root.os = v;
                    else if (k === "kernel") root.kernel = v;
                    else if (k === "cpu") root.cpu = v;
                    else if (k === "cores") root.cores = Number(v);
                    else if (k === "gpu") root.gpu = v;
                    else if (k === "mem") root.memGiB = Number(v) / 1048576;
                    else if (k === "desktop") root.desktop = v;
                    else if (k === "packages") root.packages = Number(v);
                }
            }
        }
    }

    // The apt list already downloaded (asks for no authorization and does not go online)
    Process {
        id: updatesProc
        command: ["sh", "-c", "apt list --upgradable 2>/dev/null | grep -c upgradable"]
        stdout: StdioCollector {
            onStreamFinished: root.updates = Number(text.trim()) || 0
        }
    }

    Timer {
        interval: 60 * 60 * 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.checkUpdates()
    }
}
