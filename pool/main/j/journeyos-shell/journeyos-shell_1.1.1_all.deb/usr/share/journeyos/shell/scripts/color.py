#!/usr/bin/env python3
"""Pixel colours of an image, for the shell's colour picker (capture/CaptureOverlay).

Usage: color.py <image.png>
Converts the image once to RGB in memory (with ImageMagick: the system Python has no
Pillow) and answers requests on stdin, one per line:
    x y      →  "x y #rrggbb"   (real pixels; outside the image, the colour of the nearest one)
Writes "ready <width> <height>" when ready. Exits when stdin closes.
"""
import subprocess
import sys


def main():
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        return 1
    path = sys.argv[1]
    size = subprocess.run(["magick", "identify", "-format", "%w %h", path + "[0]"],
                          capture_output=True, text=True, check=True).stdout.split()
    width, height = int(size[0]), int(size[1])
    data = subprocess.run(["magick", path + "[0]", "-depth", "8", "rgb:-"],
                          capture_output=True, check=True).stdout
    if len(data) < width * height * 3:
        print("incomplete image", file=sys.stderr)
        return 1
    print(f"ready {width} {height}", flush=True)

    for line in sys.stdin:
        parts = line.split()
        if len(parts) != 2:
            continue
        try:
            x = min(max(int(float(parts[0])), 0), width - 1)
            y = min(max(int(float(parts[1])), 0), height - 1)
        except ValueError:
            continue
        i = (y * width + x) * 3
        r, g, b = data[i], data[i + 1], data[i + 2]
        print(f"{parts[0]} {parts[1]} #{r:02x}{g:02x}{b:02x}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
