#!/usr/bin/env python3
"""Keeps the computer awake while this process is running.

Asks KDE not to suspend nor turn off the screen (powerdevil, PolicyAgent) and
not to lock (org.freedesktop.ScreenSaver). Both inhibitions are tied to the
D-Bus connection: ending the process releases them.
"""

import signal
import sys

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

APP = "shadow-kde"
REASON = "Keep awake"

# PolicyAgent types: 1 = suspend/log out, 4 = screen settings (turn off)
POLICY_TYPES = 1 | 4


def call(conn, bus, path, iface, method, args, ret):
    return conn.call_sync(bus, path, iface, method, args, GLib.VariantType(ret),
                          Gio.DBusCallFlags.NONE, -1, None).unpack()[0]


def main():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)
    ok = False
    try:
        call(conn, "org.kde.Solid.PowerManagement.PolicyAgent",
             "/org/kde/Solid/PowerManagement/PolicyAgent",
             "org.kde.Solid.PowerManagement.PolicyAgent", "AddInhibition",
             GLib.Variant("(uss)", (POLICY_TYPES, APP, REASON)), "(u)")
        ok = True
    except GLib.Error as e:
        print(f"powerdevil: {e.message}", file=sys.stderr)
    try:
        call(conn, "org.freedesktop.ScreenSaver", "/ScreenSaver",
             "org.freedesktop.ScreenSaver", "Inhibit",
             GLib.Variant("(ss)", (APP, REASON)), "(u)")
        ok = True
    except GLib.Error as e:
        print(f"screensaver: {e.message}", file=sys.stderr)
    if not ok:
        sys.exit(1)

    loop = GLib.MainLoop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, sig, loop.quit)
    print("active", flush=True)
    loop.run()


if __name__ == "__main__":
    main()
