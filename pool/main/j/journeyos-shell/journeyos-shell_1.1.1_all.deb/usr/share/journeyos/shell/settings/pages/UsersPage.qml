import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Users: the computer's accounts, create a new one, make administrator and delete
// (these ask for authorization). Deleting needs a second click.
Page {
    id: root

    Component.onCompleted: Users.refresh()

    property string confirming: ""

    Repeater {
        model: Users.users

        SettingRow {
            id: row
            required property var modelData
            title: modelData.name + (modelData.me ? Tr.t(" (you)") : "")
            description: modelData.login + " · " + (modelData.admin ? Tr.t("Administrator") : Tr.t("Standard user"))
            icon: "person"

            Row {
                visible: !row.modelData.me
                spacing: 8

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: Tr.t("Administrator")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Toggle {
                    anchors.verticalCenter: parent.verticalCenter
                    checked: row.modelData.admin
                    onToggled: on => Users.setAdmin(row.modelData, on)
                }
                PillButton {
                    anchors.verticalCenter: parent.verticalCenter
                    text: Tr.t("Password")
                    onClicked: Users.setPassword(row.modelData.login)
                }
                PillButton {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.confirming === row.modelData.login ? Tr.t("Confirm") : Tr.t("Delete")
                    danger: root.confirming === row.modelData.login
                    onClicked: {
                        if (root.confirming === row.modelData.login) {
                            root.confirming = "";
                            Users.remove(row.modelData);
                        } else {
                            root.confirming = row.modelData.login;
                            confirmTimeout.restart();
                        }
                    }
                }
            }
        }
    }

    Timer {
        id: confirmTimeout
        interval: 4000
        onTriggered: root.confirming = ""
    }

    SectionLabel { text: Tr.t("New account") }

    Rectangle {
        Layout.fillWidth: true
        implicitHeight: form.implicitHeight + 28
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        ColumnLayout {
            id: form
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 14
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                TextField {
                    id: fullName
                    Layout.fillWidth: true
                    placeholder: Tr.t("Full name")
                    acceptOnBlur: false
                }
                TextField {
                    id: login
                    Layout.preferredWidth: 180
                    placeholder: Tr.t("Username")
                    acceptOnBlur: false
                    // Only lowercase letters, digits, - and _
                    onTextChanged: {
                        const clean = text.toLowerCase().replace(/[^a-z0-9_-]/g, "");
                        if (clean !== text)
                            text = clean;
                    }
                }
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    text: Tr.t("Administrator")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Toggle {
                    id: newAdmin
                    onToggled: on => checked = on
                }
                Item { Layout.fillWidth: true }
                PillButton {
                    text: Tr.t("Create")
                    accent: true
                    enabled: /^[a-z_][a-z0-9_-]*$/.test(login.text) && fullName.text.trim() !== ""
                    onClicked: {
                        Users.create(login.text, fullName.text.trim(), newAdmin.checked);
                        login.text = "";
                        fullName.text = "";
                        newAdmin.checked = false;
                    }
                }
            }
            Text {
                Layout.fillWidth: true
                text: Tr.t("After creating it, a terminal opens to choose the new account's password.")
                wrapMode: Text.Wrap
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }
}
