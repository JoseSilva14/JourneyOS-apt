pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Notifications

// Notification server: centre list, popups, "Do not disturb" and IPC. Each
// notification lives in a stable Entry { n, time }, so the lists do not
// flicker; n becomes null (and notifies) when the notification is destroyed.
Singleton {
    id: root

    property var list: []           // centre, most recent first
    property var popups: []         // on screen now
    property int unread: 0
    property bool centerOpen: false

    // A new one arrived for the pill to show (notifications.where: corner | pill | both)
    signal arrived(var entry, bool critical)
    property var centerScreen: null

    readonly property bool dnd: Config.options.notifications.dnd

    function setDnd(on) { Config.options.notifications.dnd = on; }

    function toggleCenter(screen) {
        if (centerOpen && (!screen || screen === centerScreen)) {
            centerOpen = false;
            return;
        }
        centerScreen = screen ?? Windows.activeScreen;
        centerOpen = true;
    }

    onCenterOpenChanged: {
        if (centerOpen) {
            unread = 0;
            popups = [];
        }
    }

    // Removes from the screen without deleting from the centre (transient ones do not stay in the centre)
    function hidePopup(entry) {
        popups = popups.filter(e => e !== entry);
        if (entry.n?.transient)
            entry.n.expire();
    }

    function dismiss(entry) { entry.n?.dismiss(); }

    function clearAll() {
        for (const e of list.slice())
            e.n?.dismiss();
    }

    // Click on the card: the default action, if any
    function activate(entry) {
        if (!entry.n)
            return;
        const def = entry.n.actions.find(a => a.identifier === "default");
        if (def)
            def.invoke();
        else
            entry.n.dismiss();
    }

    function add(n, isNew) {
        // A replacement (same id) updates the same object, without going through here
        const entry = entryComponent.createObject(null, { n: n, time: new Date() });
        list = [entry, ...list];
        n.closed.connect(() => {
            list = list.filter(e => e !== entry);
            popups = popups.filter(e => e !== entry);
        });
        if (!isNew)
            return;
        if (!centerOpen)
            unread++;
        const critical = n.urgency === NotificationUrgency.Critical;
        if (dnd && !critical)
            return;
        // Urgent ones always also go to the corner (they stay until you close them)
        const where = Config.options.notifications.where;
        if (!centerOpen && (where !== "pill" || critical))
            popups = [entry, ...popups];
        if (where !== "corner")
            arrived(entry, critical);
        playSound(critical);
    }

    Component {
        id: entryComponent

        QtObject {
            property Notification n
            property date time
        }
    }

    // Ocean theme sound (urgent ones have their own); one at a time, no stacking
    readonly property string soundDir: "/usr/share/sounds/ocean/stereo/"
    function playSound(critical) {
        if (!Config.options.notifications.sound || sound.running)
            return;
        sound.command = ["pw-play", soundDir + (critical ? "message-attention.oga" : "message-new-instant.oga")];
        sound.running = true;
    }

    Process {
        id: sound
    }

    NotificationServer {
        id: server
        keepOnReload: true
        persistenceSupported: true
        bodySupported: true
        bodyMarkupSupported: true
        bodyHyperlinksSupported: true
        actionsSupported: true
        imageSupported: true

        onNotification: n => {
            n.tracked = true;
            root.add(n, true);
        }
    }

    // After a reload, the notifications are still in the server
    Component.onCompleted: {
        for (const n of server.trackedNotifications.values)
            add(n, false);
    }

    IpcHandler {
        target: "notifications"
        function toggle(): void { root.toggleCenter(null); }
        function clear(): void { root.clearAll(); }
        function dnd(): void { root.setDnd(!root.dnd); }
        function count(): int { return root.list.length; }
    }
}
