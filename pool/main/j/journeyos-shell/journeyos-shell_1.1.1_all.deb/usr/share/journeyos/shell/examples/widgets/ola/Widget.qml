import QtQuick
import qs
import qs.components

// The simplest widget: a card (Card already has "plain", the transparent style) with text.
Card {
    id: root

    // Comes from manifest.json (and from Settings → Desktop)
    property var options: ({})

    width: 300
    height: 110

    Row {
        anchors.centerIn: parent
        spacing: 14

        MIcon {
            anchors.verticalCenter: parent.verticalCenter
            icon: "waving_hand"
            size: 34
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Hello, " + (root.options.nome || "world") + "!"
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontLarge
            font.weight: Font.Bold
        }
    }
}
