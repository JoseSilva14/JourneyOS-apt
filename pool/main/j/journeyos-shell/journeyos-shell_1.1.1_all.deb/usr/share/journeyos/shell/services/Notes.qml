pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Notes (the dashboard's Notes tab): ~/.local/state/shadow-kde/notes.json { notes: [{ id,
// text, pinned, created, updated }] } (ms). The first line is the title; pinned ones stay
// on top, then the most recent. A corrupted JSON is not overwritten ("broken").
Singleton {
    id: root

    property var notes: []
    property bool loaded: false
    property bool broken: false

    readonly property var sorted: notes.slice().sort((a, b) => (b.pinned - a.pinned) || (b.updated - a.updated))

    function title(note) {
        const first = (note?.text ?? "").split("\n").find(l => l.trim() !== "") ?? "";
        return first.trim().replace(/^#+\s*/, "") || "Nota vazia";
    }

    // The rest of the text on one line (for the list)
    function preview(note) {
        const lines = (note?.text ?? "").split("\n").filter(l => l.trim() !== "");
        return lines.slice(1).join(" · ").slice(0, 120);
    }

    function norm(t) { return t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

    function search(query) {
        const words = norm(query.trim()).split(/\s+/).filter(w => w);
        return words.length ? sorted.filter(n => words.every(w => norm(n.text).includes(w))) : sorted;
    }

    function find(id) { return notes.find(n => n.id === id) ?? null; }

    function add(text) {
        const now = Date.now();
        const note = { id: now.toString(36) + Math.random().toString(36).slice(2, 6), text: text ?? "", pinned: false,
            created: now, updated: now };
        notes = [note, ...notes];
        save();
        return note.id;
    }

    function setText(id, text) {
        const n = find(id);
        if (!n || n.text === text)
            return;
        notes = notes.map(x => x.id === id ? Object.assign({}, x, { text, updated: Date.now() }) : x);
        save();
    }

    function togglePin(id) {
        notes = notes.map(x => x.id === id ? Object.assign({}, x, { pinned: !x.pinned }) : x);
        save();
    }

    function remove(id) {
        notes = notes.filter(x => x.id !== id);
        save();
    }

    // A note with no text is not kept (on leaving it)
    function dropIfEmpty(id) {
        const n = find(id);
        if (n && n.text.trim() === "")
            remove(id);
    }

    function save() {
        if (!loaded || broken)
            return;
        file.setText(JSON.stringify({ notes }, null, 1) + "\n");
    }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/notes.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const list = JSON.parse(text()).notes;
                root.notes = Array.isArray(list) ? list.filter(n => n && typeof n.text === "string") : [];
                root.broken = false;
            } catch (e) {
                root.broken = true;
                console.warn("notes.json is corrupt: not overwriting it", e);
            }
            root.loaded = true;
        }
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                root.loaded = true;
        }
    }

    IpcHandler {
        target: "notes"
        function add(text: string): string { return root.add(text); }
        function list(): string { return root.sorted.map(n => n.id + " " + root.title(n)).join("\n"); }
        function remove(id: string): void { root.remove(id); }
    }
}
