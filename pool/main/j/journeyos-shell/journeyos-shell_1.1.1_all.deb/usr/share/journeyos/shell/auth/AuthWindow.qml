import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Authorization dialog (polkit), on the active window's screen: the app's message, the account and the
// password. Esc or "Cancel" gives up; a wrong password shakes the field.
PanelWindow {
    id: root

    readonly property var flow: Auth.flow
    readonly property bool open: Auth.active && flow !== null

    screen: Windows.activeScreen
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open
    WlrLayershell.namespace: "shadow-auth"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open) {
            password.text = "";
            password.forceActiveFocus();
        }
    }

    Connections {
        target: root.flow
        function onAuthenticationFailed() {
            password.text = "";
            shake.restart();
            password.forceActiveFocus();
        }
    }

    function submit() {
        if (root.flow && root.flow.isResponseRequired)
            root.flow.submit(password.text);
    }

    // Dims the rest (the request is important)
    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
    }

    MouseArea {
        anchors.fill: parent
    }

    Rectangle {
        id: box

        anchors.centerIn: parent
        width: Math.min(420, parent.width - Theme.gap * 4)
        height: column.implicitHeight + Theme.cardPadding * 2 + 8
        radius: Theme.radiusCard + 6
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        transform: Translate {
            id: shift
        }

        SequentialAnimation {
            id: shake
            NumberAnimation { target: shift; property: "x"; to: -12; duration: 50 }
            NumberAnimation { target: shift; property: "x"; to: 12; duration: 70 }
            NumberAnimation { target: shift; property: "x"; to: -8; duration: 60 }
            NumberAnimation { target: shift; property: "x"; to: 0; duration: 50 }
        }

        ColumnLayout {
            id: column
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: Theme.cardPadding + 4
            spacing: 12

            Rectangle {
                Layout.alignment: Qt.AlignHCenter
                implicitWidth: 52
                implicitHeight: 52
                radius: 26
                color: Theme.button

                MIcon {
                    anchors.centerIn: parent
                    icon: "admin_panel_settings"
                    size: 28
                }
            }

            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: Tr.t("Authorization required")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge
                font.weight: Font.Bold
            }

            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: root.flow?.message ?? ""
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
            }

            // The account that authorizes
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 4
                spacing: 10

                RoundImage {
                    id: face
                    implicitWidth: 32
                    implicitHeight: 32
                    radius: 16
                    source: User.face
                    Text {
                        anchors.centerIn: parent
                        visible: !face.ready
                        text: User.name.charAt(0).toUpperCase()
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.Bold
                    }
                }
                Text {
                    text: User.name
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    font.weight: Font.DemiBold
                }
            }

            // Password
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 44
                radius: height / 2
                color: Theme.surfaceCard
                border.width: 1
                border.color: password.activeFocus ? Theme.accent : Theme.surfaceBorder

                TextInput {
                    id: password
                    anchors.fill: parent
                    anchors.leftMargin: 18
                    anchors.rightMargin: 18
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: root.flow?.responseVisible ? TextInput.Normal : TextInput.Password
                    passwordCharacter: "●"
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    clip: true
                    enabled: root.flow?.isResponseRequired ?? false
                    onAccepted: root.submit()
                    Keys.onEscapePressed: root.flow?.cancelAuthenticationRequest()

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !password.text
                        text: (root.flow?.inputPrompt ?? "").replace(/:\s*$/, "") || "Palavra-passe"
                        color: Theme.dim
                        font: password.font
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                visible: text !== ""
                horizontalAlignment: Text.AlignHCenter
                text: root.flow?.supplementaryMessage ?? ""
                wrapMode: Text.Wrap
                color: root.flow?.supplementaryIsError ? Theme.privacyMic : Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: Tr.t("Cancel")
                    onClicked: root.flow?.cancelAuthenticationRequest()
                }
                Button {
                    Layout.fillWidth: true
                    text: Tr.t("Authorize")
                    accent: true
                    onClicked: root.submit()
                }
            }
        }
    }

    component Button: Rectangle {
        id: button
        property string text: ""
        property bool accent: false
        signal clicked

        implicitHeight: 40
        radius: height / 2
        color: accent ? Theme.accent : buttonMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: buttonMouse.pressed ? 0.97 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Text {
            anchors.centerIn: parent
            text: button.text
            color: button.accent ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }
        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }
}
