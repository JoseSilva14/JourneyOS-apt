import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Example tab: the processes using the most (ps every 3 s, only while the tab is open).
// On hover, end (SIGTERM; asks for a second click). Only yours can be ended.
Item {
    id: root

    property var options: ({})
    property string place: "notch"

    readonly property bool compact: place === "notch"
    // The user's uid (the USER environment variable does not reach the shell when it runs as a service,
    // and ps truncates names longer than 8 letters: compare by number)
    property string me: ""
    Component.onCompleted: Run.cmd(["id", "-u"], (code, out) => {
        root.me = out.trim();
        root.refresh();
    })
    // 4 rows fit in the pill
    readonly property int rows: compact ? 4 : 11
    property var list: []
    property int confirm: 0

    function refresh() {
        if (!root.me)
            return;
        const sort = root.options.ordem === "mem" ? "-pmem" : "-pcpu";
        Run.cmd(["ps", "-eo", "pid=,uid=,user=,pcpu=,pmem=,comm=", "--sort=" + sort], (code, out) => {
            if (code !== 0)
                return;
            root.list = out.trim().split("\n").map(l => l.trim().split(/\s+/))
                .map(f => ({ pid: Number(f[0]), uid: f[1], user: f[2], cpu: Number(f[3]), mem: Number(f[4]), name: f.slice(5).join(" ") }))
                // Without ps itself
                .filter(p => p.name !== "ps" && (root.options.todos || p.uid === root.me))
                .slice(0, root.rows);
        });
    }

    Timer {
        running: true
        repeat: true
        triggeredOnStart: true
        interval: 3000
        onTriggered: root.refresh()
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 2

        Repeater {
            model: root.list

            Rectangle {
                id: row
                required property var modelData
                readonly property bool mine: modelData.uid === root.me
                readonly property bool hovered: hover.hovered
                Layout.fillWidth: true
                Layout.preferredHeight: root.compact ? 32 : 34
                radius: Theme.radiusSmall
                color: hovered ? Theme.buttonHover : "transparent"

                HoverHandler {
                    id: hover
                    onHoveredChanged: if (!hovered && root.confirm === row.modelData.pid) root.confirm = 0
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 10
                    anchors.rightMargin: 6
                    spacing: 10

                    Text {
                        Layout.fillWidth: true
                        text: row.modelData.name + (row.mine ? "" : "  (" + row.modelData.user + ")")
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                    // CPU (or memory) bar
                    Rectangle {
                        visible: !root.compact
                        Layout.preferredWidth: 160
                        implicitHeight: 4
                        radius: 2
                        color: Theme.ringTrack
                        Rectangle {
                            width: parent.width * Math.min(1, (root.options.ordem === "mem" ? row.modelData.mem : row.modelData.cpu) / 100)
                            height: parent.height
                            radius: 2
                            color: Theme.accent
                        }
                    }
                    Text {
                        Layout.preferredWidth: 56
                        horizontalAlignment: Text.AlignRight
                        text: row.modelData.cpu.toFixed(1) + "%"
                        color: root.options.ordem === "mem" ? Theme.subtext : Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.preferredWidth: 56
                        horizontalAlignment: Text.AlignRight
                        text: row.modelData.mem.toFixed(1) + "%"
                        color: root.options.ordem === "mem" ? Theme.text : Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                    // End (only yours)
                    Rectangle {
                        Layout.preferredWidth: 24
                        Layout.preferredHeight: 24
                        radius: 12
                        opacity: row.hovered && row.mine ? 1 : 0
                        color: root.confirm === row.modelData.pid ? Theme.privacyMic : killMouse.containsMouse ? Theme.surfaceCardHover : Theme.button
                        MIcon {
                            anchors.centerIn: parent
                            icon: root.confirm === row.modelData.pid ? "dangerous" : "close"
                            size: 14
                            color: root.confirm === row.modelData.pid ? "#ffffff" : Theme.subtext
                        }
                        MouseArea {
                            id: killMouse
                            anchors.fill: parent
                            enabled: row.mine
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (root.confirm !== row.modelData.pid) {
                                    root.confirm = row.modelData.pid;
                                    return;
                                }
                                root.confirm = 0;
                                Run.cmd(["kill", String(row.modelData.pid)], () => root.refresh());
                            }
                        }
                    }
                }
            }
        }

        Item { Layout.fillHeight: true }
    }
}
