pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// App store: Flatpak apps from Flathub, installed for the user (scripts/store.py), shown in the
// dashboard Apps tab ("Store"). Also notices an NVIDIA card without NVIDIA's driver.
Singleton {
    id: root

    property bool flatpak: false        // flatpak is installed
    property bool ready: false          // Flathub added and its catalogue downloaded
    property bool loaded: false         // status read at least once
    property var installed: []          // [{ id, name, version }]
    property var updates: []            // [id]
    property var nvidia: ({ present: false })
    property var catalog: []            // [{ id, name, summary, icon, kw }]

    // The running job: setup | install | remove | update (one at a time, flatpak locks)
    property string job: ""
    property string jobApp: ""
    property int progress: -1
    property string progressText: ""
    property string error: ""
    property var queue: []

    // Shown with no search: well-known apps
    readonly property var featuredIds: [
        "org.libreoffice.LibreOffice", "org.videolan.VLC", "com.spotify.Client", "com.discordapp.Discord",
        "org.telegram.desktop", "org.signal.Signal", "com.obsproject.Studio", "org.gimp.GIMP", "org.kde.krita",
        "org.inkscape.Inkscape", "org.blender.Blender", "org.kde.kdenlive", "com.visualstudio.code",
        "md.obsidian.Obsidian", "com.valvesoftware.Steam", "com.bitwarden.desktop", "org.chromium.Chromium",
        "com.github.tchx84.Flatseal"
    ]
    readonly property var featured: featuredIds.map(id => catalog.find(a => a.id === id)).filter(a => a)
    readonly property var installedIds: installed.map(a => a.id)

    function isInstalled(id) { return installedIds.includes(id); }
    function busyWith(id) { return jobApp === id || queue.some(j => j.app === id); }

    // Catalogue search: name start > word in name > name > keywords/summary
    function search(q) {
        const t = q.trim().toLowerCase();
        if (!t)
            return [];
        const scored = [];
        for (const a of catalog) {
            const n = a.name.toLowerCase();
            let s = 0;
            if (n === t) s = 100;
            else if (n.startsWith(t)) s = 80;
            else if (n.split(/[\s\-.]+/).some(w => w.startsWith(t))) s = 60;
            else if (n.includes(t)) s = 40;
            else if (a.kw.includes(t) || a.id.toLowerCase().includes(t)) s = 20;
            else if (a.summary.toLowerCase().includes(t)) s = 10;
            if (s)
                scored.push({ a, s });
        }
        return scored.sort((x, y) => y.s - x.s || x.a.name.localeCompare(y.a.name)).slice(0, 60).map(x => x.a);
    }

    // The installed ones with their catalogue info (name, icon), alphabetical
    readonly property var installedApps: installed.map(i => catalog.find(a => a.id === i.id)
            ?? ({ id: i.id, name: i.name, summary: i.version, icon: "", kw: "" }))
        .sort((x, y) => x.name.localeCompare(y.name))

    function refresh() {
        if (!status.running)
            status.running = true;
    }

    function enqueue(kind, app) {
        queue = [...queue, { kind, app }];
        next();
    }
    function setup() { enqueue("setup", ""); }
    function install(id) { enqueue("install", id); }
    function remove(id) { enqueue("remove", id); }
    function updateAll() { enqueue("update", ""); }

    function next() {
        if (job || queue.length === 0)
            return;
        const j = queue[0];
        queue = queue.slice(1);
        job = j.kind;
        jobApp = j.app;
        progress = -1;
        progressText = "";
        error = "";
        runner.command = ["env", "SHADOW_LANG=" + Tr.lang, Quickshell.shellPath("scripts/store.py"), j.kind, ...(j.app ? [j.app] : [])];
        runner.running = true;
    }

    function open(id) {
        Apps.run(["flatpak", "run", id]);
    }

    function installNvidia() {
        Apps.run(["konsole", "-e", "env", "SHADOW_LANG=" + Tr.lang, Quickshell.shellPath("scripts/nvidia-driver.sh")]);
    }

    Process {
        id: status
        command: [Quickshell.shellPath("scripts/store.py"), "status"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const s = JSON.parse(text);
                    root.flatpak = s.flatpak;
                    root.ready = s.ready;
                    root.installed = s.installed ?? [];
                    root.updates = s.updates ?? [];
                    root.nvidia = s.nvidia ?? { present: false };
                } catch (e) {}
                root.loaded = true;
                if (root.ready)
                    catalogFile.reload();
            }
        }
    }

    Process {
        id: runner
        stdout: SplitParser {
            onRead: line => {
                let r;
                try {
                    r = JSON.parse(line);
                } catch (e) {
                    return;
                }
                if (r.done) {
                    if (!r.ok)
                        root.error = r.error || Tr.t("Something went wrong");
                    return;
                }
                root.progress = r.progress ?? -1;
                root.progressText = r.text ?? "";
            }
        }
        onExited: code => {
            const finished = root.job, app = root.jobApp;
            if (!root.error && (finished === "install" || finished === "remove")) {
                const name = root.catalog.find(a => a.id === app)?.name ?? app;
                Events.push({
                    icon: finished === "install" ? "download_done" : "delete",
                    title: finished === "install" ? Tr.t("App installed") : Tr.t("App removed"),
                    text: name, duration: 2500
                });
            }
            root.job = "";
            root.jobApp = "";
            root.refresh();
            root.next();
        }
    }

    FileView {
        id: catalogFile
        path: (Quickshell.env("XDG_CACHE_HOME") || Quickshell.env("HOME") + "/.cache") + "/journeyos/store.json"
        printErrors: false
        blockLoading: false
        onLoaded: {
            try {
                root.catalog = JSON.parse(text());
            } catch (e) {
                root.catalog = [];
            }
        }
    }

    // Updates are looked for again every 6 h
    Timer {
        interval: 6 * 3600 * 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // An NVIDIA card without its driver: say so once per session (the store has the button)
    property bool nvidiaAnnounced: false
    onNvidiaChanged: if (nvidia.present && !nvidia.driver && !nvidiaAnnounced) announce.start()
    Timer {
        id: announce
        interval: 15000        // not right at startup (the pill ignores alerts then)
        onTriggered: {
            root.nvidiaAnnounced = true;
            Events.push({ icon: "memory", title: Tr.t("NVIDIA driver available"),
                text: Tr.t("Install it in Dashboard → Apps → Store"), duration: 6000 });
        }
    }

    IpcHandler {
        target: "store"
        function status(): string {
            return JSON.stringify({ flatpak: root.flatpak, ready: root.ready, catalog: root.catalog.length,
                installed: root.installedIds, updates: root.updates, job: root.job, app: root.jobApp,
                progress: root.progress, text: root.progressText, error: root.error, nvidia: root.nvidia });
        }
        function setup(): void { root.setup(); }
        function install(id: string): void { root.install(id); }
        function remove(id: string): void { root.remove(id); }
        function search(q: string): string { return root.search(q).slice(0, 5).map(a => a.id).join(" "); }
    }
}
