import QtQuick
import qs.dashboard

// About: same as the dashboard's About tab.
AboutTab {}
