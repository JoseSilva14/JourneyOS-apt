pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Services.Mpris

// Current music player (MPRIS): the one playing, otherwise the last one that played.
Singleton {
    id: root

    readonly property var players: Mpris.players.values
    property var last: null

    readonly property var player: players.find(p => p.isPlaying)
        ?? (players.includes(last) ? last : null)
        ?? players[0]
        ?? null

    readonly property bool playing: player?.isPlaying ?? false
    readonly property string title: player?.trackTitle || player?.identity || ""
    readonly property string artist: player?.trackArtist ?? ""
    readonly property string art: player?.trackArtUrl ?? ""

    // Remembers the last one that played, so it does not jump to another on pause
    onPlayerChanged: if (player?.isPlaying) last = player
    onPlayingChanged: if (playing) last = player

    function toggle() { if (player?.canTogglePlaying) player.togglePlaying(); }
    function next() { if (player?.canGoNext) player.next(); }
    function previous() { if (player?.canGoPrevious) player.previous(); }
}
