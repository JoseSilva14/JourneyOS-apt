import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.services

// Example tab (WIDGETS.md, "Tabs in the pill and the dashboard"): the same QML in both places,
// more compact in the pill (place === "notch"). The times come from `date` with each city's TZ.
Item {
    id: root

    // Given by the shell
    property var options: ({})
    property string place: "notch"

    readonly property bool compact: place === "notch"
    // "Lisbon=Europe/Lisbon, Tokyo=Asia/Tokyo" → [{ name, zone }]
    readonly property var cities: String(options.cidades || "").split(",").map(s => s.trim()).filter(s => s.includes("="))
        .map(s => ({ name: s.split("=")[0].trim(), zone: s.split("=")[1].trim() }))
    // Per zone: { time, day, offset }
    property var times: ({})
    readonly property var weekdays: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]

    function refresh() {
        // %u = day of the week (1 = Monday): the name comes from here, not from the locale
        const fmt = (root.options.segundos ? "%H:%M:%S" : "%H:%M") + "|%u|%d|%z";
        for (const c of cities) {
            const zone = c.zone;
            Run.cmd(["env", "TZ=" + zone, "date", "+" + fmt], (code, out) => {
                if (code !== 0)
                    return;
                const [time, weekday, date, offset] = out.trim().split("|");
                const day = root.weekdays[Number(weekday) - 1] + " " + Number(date);
                root.times = Object.assign({}, root.times, { [zone]: { time, day, offset } });
            });
        }
    }

    // Difference from here, in hours ("+9 h", "−5 h", "here")
    function diff(offset) {
        if (!offset)
            return "";
        const toMin = o => (o[0] === "-" ? -1 : 1) * (Number(o.slice(1, 3)) * 60 + Number(o.slice(3, 5)));
        const here = -new Date().getTimezoneOffset();
        const d = (toMin(offset) - here) / 60;
        return d === 0 ? "here" : (d > 0 ? "+" : "−") + Math.abs(d) + " h";
    }

    onCitiesChanged: refresh()
    Timer {
        running: true
        repeat: true
        interval: root.options.segundos ? 1000 : 20000
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    GridLayout {
        anchors.fill: parent
        columns: Math.max(1, root.cities.length)
        columnSpacing: root.compact ? 8 : Theme.gap

        Repeater {
            model: root.cities

            Rectangle {
                id: card
                required property var modelData
                readonly property var t: root.times[modelData.zone]
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: root.compact ? Theme.radius : Theme.radiusCard
                color: root.compact ? Theme.button : Theme.surfaceCard
                border.width: root.compact ? 0 : 1
                border.color: Theme.surfaceBorder

                ColumnLayout {
                    anchors.centerIn: parent
                    spacing: root.compact ? 2 : 6

                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: card.modelData.name
                        color: Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: root.compact ? Theme.fontSmall : Theme.fontNormal
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: card.t?.time ?? "…"
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: root.compact ? Theme.fontLarge + 4 : Theme.fontStat * 2
                        font.weight: Font.Bold
                    }
                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: [card.t?.day ?? "", root.diff(card.t?.offset)].filter(s => s).join(" · ")
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall - (root.compact ? 1 : 0)
                    }
                }
            }
        }
    }
}
