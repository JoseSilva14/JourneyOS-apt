import QtQuick
import qs

// Widget card: dark grey, wide corners, almost invisible outline.
// plain = no background or outline ("transparent" widget style).
Rectangle {
    property bool plain: false

    color: plain ? "transparent" : Theme.card
    radius: Theme.radiusCard
    border.width: plain ? 0 : 1
    border.color: Theme.cardBorder
}
