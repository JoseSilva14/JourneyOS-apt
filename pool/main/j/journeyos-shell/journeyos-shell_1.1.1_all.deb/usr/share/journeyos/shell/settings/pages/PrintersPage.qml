import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Printers: the installed ones (default, test page, remove) and adding network printers.
Page {
    id: root

    Component.onCompleted: Printers.refresh()

    Text {
        visible: Printers.printers.length === 0
        Layout.fillWidth: true
        text: Tr.t("No printers yet. Connect the printer to the network (or USB) and search for it below.")
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: Printers.printers

        SettingRow {
            id: printerRow
            required property var modelData
            readonly property bool isDefault: modelData.name === Printers.defaultPrinter
            title: modelData.name.replace(/_/g, " ")
            description: modelData.state + (isDefault ? Tr.t(" · default") : "")
            icon: "print"

            Row {
                spacing: 6
                PillButton {
                    visible: !printerRow.isDefault
                    text: Tr.t("Default")
                    onClicked: Printers.setDefault(modelData.name)
                }
                PillButton {
                    text: Tr.t("Test")
                    onClicked: Printers.testPage(modelData.name)
                }
                PillButton {
                    text: Tr.t("Remove##tirar")
                    onClicked: Printers.remove(modelData.name)
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Add##juntar") }

    SettingRow {
        title: Printers.searching ? Tr.t("Searching…") : Tr.t("Search the network")
        description: Tr.t("Printers that work without a driver (most recent ones).")
        icon: "travel_explore"
        PillButton {
            text: Tr.t("Search")
            enabled: !Printers.searching
            onClicked: Printers.search()
        }
    }

    Repeater {
        model: Printers.found

        SettingRow {
            required property var modelData
            title: modelData.name.replace(/_/g, " ")
            description: modelData.uri
            icon: "local_printshop"
            PillButton {
                text: Tr.t("Add##juntar")
                accent: true
                onClicked: Printers.add(modelData)
            }
        }
    }

    Text {
        visible: !Printers.searching && Printers.found.length === 0
        Layout.fillWidth: true
        Layout.leftMargin: 4
        text: Tr.t("None found yet.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }
}
