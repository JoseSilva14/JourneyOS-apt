import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Actions tab: capture, eyedropper, recording, Keep awake, Do not disturb, lock and settings.
Item {
    id: root

    signal done

    function later(cmd) {
        root.done();
        Apps.runLater(cmd, Theme.animNormal + 250);
    }

    GridLayout {
        anchors.fill: parent
        columns: 4
        rowSpacing: 8
        columnSpacing: 8

        Action {
            icon: "crop"
            label: Tr.t("Screenshot")
            onClicked: {
                root.done();
                Capture.start("region");
            }
        }
        Action {
            icon: "colorize"
            label: Tr.t("Color")
            onClicked: {
                root.done();
                Capture.start("color");
            }
        }
        Action { icon: "fiber_manual_record"; label: Tr.t("Record"); onClicked: root.later(["spectacle", "-R", "r"]) }
        Action {
            icon: "coffee"
            label: Tr.t("Awake")
            active: KeepAwake.enabled
            onClicked: KeepAwake.toggle()
        }
        Action {
            icon: Notifs.dnd ? "notifications_off" : "notifications"
            label: Tr.t("Silent")
            active: Notifs.dnd
            onClicked: Notifs.setDnd(!Notifs.dnd)
        }
        Action {
            icon: Theme.light ? "dark_mode" : "light_mode"
            label: Theme.light ? Tr.t("Dark") : Tr.t("Light")
            onClicked: Config.options.theme.mode = Theme.light ? "dark" : "light"
        }
        Action {
            icon: "lock"
            label: Tr.t("Lock")
            onClicked: root.later(["loginctl", "lock-session"])
        }
        Action {
            icon: "settings"
            label: Tr.t("Settings")
            onClicked: {
                root.done();
                SettingsApp.show("home");
            }
        }
    }

    component Action: Rectangle {
        id: action

        property string icon: ""
        property string label: ""
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        Layout.fillHeight: true
        radius: Theme.radius
        color: active ? Theme.accent : actionMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: actionMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Column {
            anchors.centerIn: parent
            spacing: 3

            MIcon {
                anchors.horizontalCenter: parent.horizontalCenter
                icon: action.icon
                size: 19
                color: action.active ? Theme.accentText : Theme.text
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: action.label
                color: action.active ? Theme.accentText : Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall - 1
            }
        }

        MouseArea {
            id: actionMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: action.clicked()
        }
    }
}
