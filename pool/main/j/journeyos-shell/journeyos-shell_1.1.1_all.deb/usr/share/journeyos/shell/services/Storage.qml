pragma Singleton

import QtQuick
import Quickshell

// Disks and partitions (lsblk), mount/unmount/eject (udisksctl) and the trash.
Singleton {
    id: root

    property var disks: []              // from lsblk -J, with the partitions in children
    property real trashBytes: 0

    function refresh() {
        Run.cmd(["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINT,FSUSED,FSSIZE,RM,HOTPLUG,MODEL,TRAN"], (code, out) => {
            try {
                root.disks = JSON.parse(out).blockdevices.filter(d => d.type === "disk" || (d.type === "rom" && d.children?.length));
            } catch (e) {
            }
        });
        Run.sh("du -sb \"${XDG_DATA_HOME:-$HOME/.local/share}/Trash\" 2>/dev/null | cut -f1", (code, out) => root.trashBytes = Number(out.trim()) || 0);
    }

    function size(bytes) {
        const units = ["B", "KB", "MB", "GB", "TB"];
        let i = 0, v = bytes;
        while (v >= 1000 && i < units.length - 1) {
            v /= 1000;
            i++;
        }
        return v.toLocaleString(Tr.locale, "f", i < 2 || v >= 100 ? 0 : 1) + " " + units[i];
    }

    // What can be mounted: partitions with a file system (or the whole disk, without partitions)
    function volumes(d) {
        const parts = (d.children ?? []).filter(p => p.fstype && p.fstype !== "swap");
        if (!parts.length && d.fstype && d.fstype !== "swap")
            return [d];
        return parts;
    }

    function mount(path) { Run.cmd(["udisksctl", "mount", "-b", path], () => refresh()); }
    function unmount(path) { Run.cmd(["udisksctl", "unmount", "-b", path], () => refresh()); }
    // Eject: unmounts everything and powers off the disk (to remove the USB stick safely)
    function eject(disk) {
        const mounted = volumes(disk).filter(v => v.mountpoint).map(v => "udisksctl unmount -b " + v.path);
        Run.sh([...mounted, "udisksctl power-off -b " + disk.path].join(" && "), () => refresh());
    }

    function open(path) { Apps.run(["xdg-open", path]); }
    function emptyTrash() { Run.cmd(["gio", "trash", "--empty"], () => refresh()); }
}
