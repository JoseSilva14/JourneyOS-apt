#!/usr/bin/env python3
"""Owns the org.kde.LogoutPrompt name on the session D-Bus, so Ctrl+Alt+Del and the log-out
requests from KDE apps open the shell's log-out screen instead of KDE's.

Writes one line per request to stdout (logout | reboot | shutdown | all), which the shell reads.
Runs as a child of the shell: when the shell stops, the name goes back to KDE (its service is
started by D-Bus activation)."""
import sys
from gi.repository import Gio, GLib

XML = """
<node>
  <interface name="org.kde.LogoutPrompt">
    <method name="promptLogout"/>
    <method name="promptShutDown"/>
    <method name="promptReboot"/>
    <method name="promptAll"/>
  </interface>
</node>
"""

KINDS = {"promptLogout": "logout", "promptShutDown": "shutdown", "promptReboot": "reboot", "promptAll": "all"}


def on_call(conn, sender, path, iface, method, params, invocation):
    print(KINDS.get(method, "all"), flush=True)
    invocation.return_value(None)


def main():
    loop = GLib.MainLoop()
    bus = Gio.bus_get_sync(Gio.BusType.SESSION)
    node = Gio.DBusNodeInfo.new_for_xml(XML)
    bus.register_object("/LogoutPrompt", node.interfaces[0], on_call)

    def lost(*_):
        print("lost", file=sys.stderr, flush=True)
        loop.quit()

    # No queue: if KDE's is open right now, exit and the shell tries again later
    Gio.bus_own_name_on_connection(bus, "org.kde.LogoutPrompt",
                                   Gio.BusNameOwnerFlags.REPLACE | Gio.BusNameOwnerFlags.DO_NOT_QUEUE,
                                   None, lost)
    loop.run()
    sys.exit(1)


if __name__ == "__main__":
    main()
