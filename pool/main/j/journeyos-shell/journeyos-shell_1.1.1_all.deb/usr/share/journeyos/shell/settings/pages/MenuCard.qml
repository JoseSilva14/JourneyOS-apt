import QtQuick
import QtQuick.Layouts
import qs

// Card that wraps one of the bar menus (sound, network, Bluetooth) inside a page.
Rectangle {
    id: root

    default property alias content: holder.data

    Layout.fillWidth: true
    implicitHeight: holder.childrenRect.height + 28
    radius: Theme.radius
    color: Theme.surfaceCard
    border.width: 1
    border.color: Theme.surfaceBorder

    Item {
        id: holder
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 14
    }
}
