pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Weather via wttr.in, every 30 min. The city is searched by name (Open-Meteo's free geocoding, no key)
// and saved as coordinates (weather.location "lat,lon") + its name (weather.place); without one
// the location comes from the IP address.
Singleton {
    id: root

    property bool ready: false
    property string wttrArea: ""
    // The chosen city's name (wttr.in's nearest area for coordinates can be a small place nearby)
    readonly property string area: Config.options.weather.place || wttrArea
    readonly property bool automatic: !Config.options.weather.location
    property int temp: 0
    property int feels: 0
    property int humidity: 0
    property int wind: 0
    property string desc: ""
    property string icon: "cloud"
    property var days: []            // [{ date, max, min, icon }]

    readonly property string location: Config.options.weather.location

    // wttr.in codes (the WWO ones) → Material Icons icons
    function iconFor(code, night) {
        const c = Number(code);
        if (c === 113) return night ? "nightlight" : "wb_sunny";
        if (c === 116) return night ? "nights_stay" : "wb_cloudy";
        if (c === 119 || c === 122) return "cloud";
        if ([143, 248, 260].includes(c)) return "dehaze";
        if ([200, 386, 389, 392, 395].includes(c)) return "thunderstorm";
        if ([179, 227, 230, 323, 326, 329, 332, 335, 338, 368, 371, 374, 377, 350].includes(c)) return "ac_unit";
        return "water_drop";
    }

    // City search: done(list of { name, region, country, lat, lon }) - empty on no network
    function search(query, done) {
        const q = query.trim();
        if (q.length < 2) {
            done([]);
            return;
        }
        const url = "https://geocoding-api.open-meteo.com/v1/search?count=8&format=json&language="
            + (Tr.en ? "en" : "pt") + "&name=" + encodeURIComponent(q);
        Run.cmd(["curl", "-s", "-m", "10", url], (code, out) => {
            let list = [];
            try {
                list = (JSON.parse(out).results ?? []).map(r => ({
                    name: r.name, region: r.admin1 ?? "", country: r.country ?? "",
                    lat: r.latitude, lon: r.longitude
                }));
            } catch (e) {}
            done(list);
        });
    }

    function choose(city) {
        Config.options.weather.place = city.name;
        Config.options.weather.location = city.lat.toFixed(4) + "," + city.lon.toFixed(4);
    }

    function useAutomatic() {
        Config.options.weather.place = "";
        Config.options.weather.location = "";
    }

    // A request while another is running (e.g. the city changed mid-request, wttr.in takes a few
    // seconds) runs right after it; it used to be dropped and the old city's weather stayed
    property bool again: false
    function refresh() {
        if (fetch.running)
            again = true;
        else
            fetch.running = true;
    }

    // Later: the handler ran before the Process command binding saw the new location, so the
    // request went out for the old city
    onLocationChanged: Qt.callLater(refresh)

    Process {
        id: fetch
        onExited: {
            if (root.again) {
                root.again = false;
                Qt.callLater(() => fetch.running = true);
            }
        }
        command: ["curl", "-s", "-m", "15", "https://wttr.in/" + encodeURIComponent(root.location) + "?format=j1&lang=" + (Tr.en ? "en" : "pt")]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const d = JSON.parse(text);
                    const now = d.current_condition[0];
                    const hour = new Date().getHours();
                    const night = hour < 7 || hour >= 20;
                    root.wttrArea = d.nearest_area?.[0]?.areaName?.[0]?.value ?? "";
                    root.temp = Number(now.temp_C);
                    root.feels = Number(now.FeelsLikeC);
                    root.humidity = Number(now.humidity);
                    root.wind = Number(now.windspeedKmph);
                    root.desc = (Tr.en ? null : now.lang_pt?.[0]?.value) ?? now.weatherDesc?.[0]?.value ?? "";
                    root.icon = root.iconFor(now.weatherCode, night);
                    root.days = d.weather.map(w => ({
                        date: w.date,
                        max: Number(w.maxtempC),
                        min: Number(w.mintempC),
                        icon: root.iconFor(w.hourly[4]?.weatherCode ?? 113, false)
                    }));
                    root.ready = true;
                } catch (e) {
                    // No network or the service is down: keep what was there
                }
            }
        }
    }

    Timer {
        interval: 30 * 60 * 1000
        running: Config.ready
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // Another language: the description comes again, in that language
    Connections {
        target: Tr
        function onLangChanged() { root.refresh(); }
    }
}
