#!/usr/bin/env python3
"""User widgets: lists the folders with a valid manifest.json.

Usage: widgets.py exemplos <folder>   (examples) copies the examples that are not installed yet
       widgets.py ver <file.zip>      (view) what a .zip contains (manifest, places, what it can do), without installing
       widgets.py instalar <file.zip> [--substituir]   (install [--replace])
       widgets.py remover <id>        (remove) deletes the folder (for a symlink: only the link)
       widgets.py exportar <id> <file.zip>              (export)
       widgets.py listar      → (list) JSON [{ id, dir, main, name, icon, description, author, version,
                                       style, options, places, error? }]

places: where it shows and with which QML ({ "desktop": "Widget.qml", "notch": "…", "dashboard": "…" }).
In the manifest it can be a list (["desktop", "notch"]: all with the "main") or an object with the QML
for each place; without it, only the desktop.

Looks in ~/.local/share/shadow-kde/widgets/<id>/ (and in $SHADOW_WIDGETS_DIRS, separated by
":"). The id is the folder name (letters, numbers, "-" and "_"). A folder with errors is listed
with "error", so the shell can show why. The format is described in WIDGETS.md.
"""
import json
import os
import re
import sys

DIRS = [os.path.expanduser("~/.local/share/shadow-kde/widgets")] + \
    [d for d in os.environ.get("SHADOW_WIDGETS_DIRS", "").split(":") if d]
ID = re.compile(r"^[A-Za-z0-9_-]+$")
OPTION_TYPES = {"string", "number", "bool", "choice"}
PLACES = ("desktop", "notch", "dashboard")


def option(o):
    if not isinstance(o, dict) or not isinstance(o.get("key"), str):
        raise ValueError("every option needs a \"key\"")
    kind = o.get("type", "string")
    if kind not in OPTION_TYPES:
        raise ValueError(f"option {o['key']}: unknown type \"{kind}\"")
    out = {"key": o["key"], "type": kind, "label": str(o.get("label", o["key"])),
           "description": str(o.get("description", ""))}
    default = o.get("default")
    if kind == "choice":
        choices = o.get("choices")
        if not isinstance(choices, list) or not choices:
            raise ValueError(f"option {o['key']}: missing \"choices\"")
        out["choices"] = [c if isinstance(c, dict) else {"id": str(c), "label": str(c)} for c in choices]
        default = default if default is not None else out["choices"][0]["id"]
    elif kind == "bool":
        default = bool(default)
    elif kind == "number":
        default = float(default or 0)
        for k in ("min", "max", "step"):
            if k in o:
                out[k] = float(o[k])
    else:
        default = "" if default is None else str(default)
    out["default"] = default
    return out


def read(folder, wid):
    entry = {"id": wid, "dir": folder, "main": "Widget.qml", "name": wid, "icon": "widgets",
             "description": "", "author": "", "version": "", "style": "card", "options": [], "places": {}}
    try:
        with open(os.path.join(folder, "manifest.json"), encoding="utf-8") as f:
            m = json.load(f)
        if not isinstance(m, dict):
            raise ValueError("manifest.json must be an object")
        for k in ("name", "icon", "description", "author", "version", "main"):
            if k in m:
                entry[k] = str(m[k])
        if m.get("style") in ("card", "plain"):
            entry["style"] = m["style"]
        entry["options"] = [option(o) for o in m.get("options", [])]
        places = m.get("places", ["desktop"])
        if isinstance(places, list):
            places = {p: entry["main"] for p in places}
        if not isinstance(places, dict) or not places:
            raise ValueError("\"places\" must be a list or an object")
        for place, qml in places.items():
            if place not in PLACES:
                raise ValueError(f"unknown place \"{place}\" (desktop, notch or dashboard)")
            qml = str(qml or entry["main"])
            if os.path.normpath(qml).startswith(".."):
                raise ValueError(f"the QML for \"{place}\" must be inside the folder")
            if not os.path.isfile(os.path.join(folder, qml)):
                raise ValueError(f"{qml} is missing")
            entry["places"][place] = qml
    except FileNotFoundError:
        entry["error"] = "manifest.json is missing"
    except json.JSONDecodeError as e:
        entry["error"] = f"invalid manifest.json (line {e.lineno}): {e.msg}"
    except ValueError as e:
        entry["error"] = str(e)
    return entry


def listar():
    out, seen = [], set()
    for base in DIRS:
        if not os.path.isdir(base):
            continue
        for wid in sorted(os.listdir(base)):
            folder = os.path.join(base, wid)
            if wid in seen or not os.path.isdir(folder) or wid.startswith("."):
                continue
            seen.add(wid)
            if not ID.match(wid):
                out.append({"id": wid, "dir": folder, "name": wid, "icon": "widgets", "options": [], "places": {},
                            "error": "invalid folder name (only letters, numbers, - and _)"})
                continue
            out.append(read(folder, wid))
    print(json.dumps(out, ensure_ascii=False))


def exemplos(src):
    import shutil
    os.makedirs(DIRS[0], exist_ok=True)
    copied = []
    for wid in sorted(os.listdir(src)):
        dest = os.path.join(DIRS[0], wid)
        if os.path.isdir(os.path.join(src, wid)) and not os.path.exists(dest):
            shutil.copytree(os.path.join(src, wid), dest)
            copied.append(wid)
    print(" ".join(copied))


# --- Install from a .zip, remove and export ----------------------------------------------

MAX_FILES = 500
MAX_BYTES = 30 << 20          # 30 MB uncompressed

# What an extension's QML/scripts can do (shown before installing)
CAPABILITIES = [
    ("comandos", "Runs commands on the computer", re.compile(r"\bRun\.(cmd|sh)\b|\bProcess\s*\{|\bApps\.run\b|execDetached")),
    ("internet", "Connects to the internet", re.compile(r"XMLHttpRequest|https?://|\bcurl\b|\bwget\b")),
    ("ficheiros", "Reads or writes files", re.compile(r"\bFileView\b|setText\(")),
    ("sockets", "Opens network connections (sockets)", re.compile(r"\bSocket\b|SocketServer")),
    ("dbus", "Talks to other apps over D-Bus", re.compile(r"\bbusctl\b|\bgdbus\b|\bdbus-send\b")),
]


def zip_root(names):
    """The folder inside the .zip that holds manifest.json ("" = at the root)."""
    if "manifest.json" in names:
        return ""
    tops = {n.split("/", 1)[0] for n in names if n.strip("/")}
    if len(tops) == 1:
        top = tops.pop()
        if f"{top}/manifest.json" in names:
            return top + "/"
    return None


def inspect(path):
    import zipfile
    out = {"ok": False, "zip": path}
    try:
        z = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile):
        out["error"] = "Not a valid .zip file."
        return out, None, None
    infos = [i for i in z.infolist() if not i.is_dir()]
    names = [i.filename for i in infos]
    for i in infos:
        n = i.filename
        # No absolute paths, "..", or symlinks (Unix bits in external_attr)
        if n.startswith("/") or ".." in n.split("/") or (i.external_attr >> 16) & 0o170000 == 0o120000:
            out["error"] = f"The .zip has an unsafe path: {n}"
            return out, None, None
    if len(infos) > MAX_FILES or sum(i.file_size for i in infos) > MAX_BYTES:
        out["error"] = "The .zip is too big for an extension (more than 500 files or 30 MB)."
        return out, None, None
    root = zip_root(names)
    if root is None:
        out["error"] = "manifest.json not found (it must be at the root of the .zip or in a single folder)."
        return out, None, None
    wid = root.rstrip("/") or os.path.splitext(os.path.basename(path))[0]
    wid = re.sub(r"[^A-Za-z0-9_-]", "-", wid).strip("-") or "extension"
    out.update({"id": wid, "files": len([n for n in names if n.startswith(root)]),
                "size": sum(i.file_size for i in infos)})
    return out, z, root


def ver(path):
    """Shows what a .zip contains, without installing."""
    import tempfile
    out, z, root = inspect(path)
    if z is None:
        print(json.dumps(out, ensure_ascii=False))
        return
    with tempfile.TemporaryDirectory() as tmp:
        folder = os.path.join(tmp, out["id"])
        extract(z, root, folder)
        entry = read(folder, out["id"])
        caps, scripts = [], []
        for base, _, files in os.walk(folder):
            for f in files:
                full = os.path.join(base, f)
                rel = os.path.relpath(full, folder)
                if os.access(full, os.X_OK) or f.endswith((".sh", ".py")):
                    scripts.append(rel)
                if f.endswith((".qml", ".js", ".sh", ".py")):
                    try:
                        text = open(full, encoding="utf-8", errors="replace").read()
                    except OSError:
                        continue
                    for key, label, rx in CAPABILITIES:
                        if rx.search(text) and key not in [c["id"] for c in caps]:
                            caps.append({"id": key, "label": label})
    out.update({k: entry.get(k) for k in ("name", "icon", "description", "author", "version", "places", "options")})
    out["capabilities"] = caps
    out["scripts"] = scripts
    out["exists"] = os.path.exists(os.path.join(DIRS[0], out["id"]))
    if entry.get("error"):
        out["error"] = entry["error"]
    else:
        out["ok"] = True
    print(json.dumps(out, ensure_ascii=False))


def extract(z, root, dest):
    os.makedirs(dest, exist_ok=True)
    for i in z.infolist():
        if i.is_dir() or not i.filename.startswith(root):
            continue
        rel = i.filename[len(root):]
        target = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with z.open(i) as src, open(target, "wb") as dst:
            dst.write(src.read())
        # Keeps only the "executable" bit (the extension's scripts)
        if (i.external_attr >> 16) & 0o111:
            os.chmod(target, 0o755)


def instalar(path, replace):
    import shutil
    import tempfile
    out, z, root = inspect(path)
    if z is None:
        print(json.dumps(out, ensure_ascii=False))
        return 1
    dest = os.path.join(DIRS[0], out["id"])
    if os.path.lexists(dest) and not replace:
        out["error"] = "There is already an extension with this name."
        print(json.dumps(out, ensure_ascii=False))
        return 1
    os.makedirs(DIRS[0], exist_ok=True)
    # Extracts alongside and swaps in one go (an extension is never left half-installed)
    tmp = tempfile.mkdtemp(prefix=".instalar-", dir=DIRS[0])
    try:
        folder = os.path.join(tmp, out["id"])
        extract(z, root, folder)
        entry = read(folder, out["id"])
        if entry.get("error"):
            out["error"] = entry["error"]
            print(json.dumps(out, ensure_ascii=False))
            return 1
        if os.path.islink(dest):
            os.unlink(dest)
        elif os.path.exists(dest):
            shutil.rmtree(dest)
        os.replace(folder, dest)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    out["ok"] = True
    out["name"] = entry["name"]
    print(json.dumps(out, ensure_ascii=False))
    return 0


def remover(wid):
    import shutil
    if not ID.match(wid):
        return 1
    dest = os.path.join(DIRS[0], wid)
    if os.path.islink(dest):
        os.unlink(dest)          # a linked folder (widget-dev.sh): only the link
    elif os.path.isdir(dest):
        shutil.rmtree(dest)
    return 0


def exportar(wid, target):
    import zipfile
    src = os.path.realpath(os.path.join(DIRS[0], wid))
    if not ID.match(wid) or not os.path.isdir(src):
        return 1
    tmp = target + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for base, dirs, files in os.walk(src):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for f in files:
                if f.startswith("."):
                    continue
                full = os.path.join(base, f)
                z.write(full, os.path.join(wid, os.path.relpath(full, src)))
    os.replace(tmp, target)
    print(target)
    return 0


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["listar"]:
        listar()
    elif len(a) == 2 and a[0] == "exemplos":
        exemplos(a[1])
    elif len(a) == 2 and a[0] == "ver":
        ver(a[1])
    elif len(a) >= 2 and a[0] == "instalar":
        sys.exit(instalar(a[1], "--substituir" in a))
    elif len(a) == 2 and a[0] == "remover":
        sys.exit(remover(a[1]))
    elif len(a) == 3 and a[0] == "exportar":
        sys.exit(exportar(a[1], a[2]))
    else:
        print(__doc__)
        sys.exit(1)
