#!/usr/bin/env python3
"""Makes the apps follow the shell theme.

Reads ~/.local/state/shadow-kde/theme.conf (exported by the shell) and generates:
  - a KDE colour scheme based on Breeze Dark/Light, with the shell's backgrounds, text and
    selection (the accent), applied with plasma-apply-colorscheme or, without Plasma (JourneyOS),
    written into kdeglobals here + the KGlobalSettings palette signal;
  - GTK: Breeze or Breeze-Dark in gtk-3.0/gtk-4.0 settings.ini (light/dark follows the shell;
    GTK apps and Firefox also get the light/dark preference through the portal);
  - a Konsole colour scheme and profile ("Shadow KDE"), chosen as the default profile;
  - a Kate/KWrite editor theme ("JourneyOS", KSyntaxHighlighting JSON in
    ~/.local/share/org.kde.syntax-highlighting/themes), selected in katerc/kwriterc.

Usage: kde-colors.py apply [--force] | reset
Only applies when the colours change (signature in ~/.local/state/shadow-kde/kde-colors.sig).
Reapplying the same scheme name does nothing: alternates between ShadowKDEA and ShadowKDEB.
"""

import configparser
import hashlib
import json
import os
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~")
STATE = os.path.join(HOME, ".local/state/shadow-kde")
THEME = os.path.join(STATE, "theme.conf")
SIG = os.path.join(STATE, "kde-colors.sig")
SCHEMES = os.path.join(HOME, ".local/share/color-schemes")
KONSOLE = os.path.join(HOME, ".local/share/konsole")
PROFILE = "Shadow KDE.profile"


def ini(path):
    p = configparser.ConfigParser(interpolation=None, strict=False)
    p.optionxform = str
    p.read(path, encoding="utf-8")
    return p


def write_atomic(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def rgb(color):
    """#rrggbb or #aarrggbb (alpha is ignored) → (r, g, b)."""
    c = color.strip().lstrip("#")
    if len(c) == 8:
        c = c[2:]
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def kde(c):
    return ",".join(str(v) for v in c)


def run(*cmd):
    return subprocess.run(cmd, capture_output=True, text=True).stdout.strip()


KDEGLOBALS = os.path.join(HOME, ".config/kdeglobals")
SCHEME_GROUPS = ("Colors:", "ColorEffects:", "WM")


def kconfig_text(p):
    out = []
    for sec in p.sections():
        out.append(f"[{sec}]")
        out += [f"{k}={v}" for k, v in p[sec].items()]
        out.append("")
    return "\n".join(out)


def apply_scheme(name):
    """What plasma-apply-colorscheme does: the scheme's colour groups go into kdeglobals, then
    running KDE/Qt apps (plasma-integration) are told the palette changed."""
    if shutil.which("plasma-apply-colorscheme"):
        run("plasma-apply-colorscheme", name)
        return
    own = os.path.join(SCHEMES, f"{name}.colors")
    scheme = ini(own if os.path.exists(own) else f"/usr/share/color-schemes/{name}.colors")
    g = ini(KDEGLOBALS)
    for sec in g.sections():
        if sec.startswith(SCHEME_GROUPS):
            g.remove_section(sec)
    for sec in scheme.sections():
        if sec.startswith(SCHEME_GROUPS):
            g[sec] = dict(scheme[sec])
    if not g.has_section("General"):
        g.add_section("General")
    g["General"]["ColorScheme"] = name
    write_atomic(KDEGLOBALS, kconfig_text(g))
    # KGlobalSettings::PaletteChanged (0)
    run("dbus-send", "--session", "--type=signal", "/KGlobalSettings",
        "org.kde.KGlobalSettings.notifyChange", "int32:0", "int32:0")


def gtk_colors(scheme):
    """Breeze GTK's named colours from a KDE scheme (what Plasma's gtkconfig writes to colors.css):
    the theme's rules use these names, so GTK apps (and Firefox) get the shell's exact colours."""
    def c(group, key, fallback=None):
        v = scheme.get(f"Colors:{group}", key, fallback=None) if scheme.has_section(f"Colors:{group}") else None
        if v is None:
            return fallback
        r, g, b = (int(x) for x in v.split(",")[:3])
        return (r, g, b)

    def hexc(t):
        return "#{:02x}{:02x}{:02x}".format(*t)

    win_bg, win_fg = c("Window", "BackgroundNormal"), c("Window", "ForegroundNormal")
    view_bg, view_fg = c("View", "BackgroundNormal", win_bg), c("View", "ForegroundNormal", win_fg)
    btn_bg, btn_fg = c("Button", "BackgroundNormal", win_bg), c("Button", "ForegroundNormal", win_fg)
    sel_bg, sel_fg = c("Selection", "BackgroundNormal"), c("Selection", "ForegroundNormal")
    head_bg, head_fg = c("Header", "BackgroundNormal", win_bg), c("Header", "ForegroundNormal", win_fg)
    inactive = c("Window", "ForegroundInactive", mix(win_fg, win_bg, 0.5))
    hover = c("Button", "DecorationHover", sel_bg)
    focus = c("Button", "DecorationFocus", sel_bg)
    borders = mix(win_bg, win_fg, 0.2)
    colors = {
        "theme_fg_color": win_fg, "theme_bg_color": win_bg,
        "theme_text_color": view_fg, "theme_base_color": view_bg,
        "theme_view_hover_decoration_color": c("View", "DecorationHover", hover),
        "theme_view_active_decoration_color": c("View", "DecorationFocus", focus),
        "theme_hovering_selected_bg_color": c("Selection", "DecorationHover", sel_bg),
        "theme_selected_bg_color": sel_bg, "theme_selected_fg_color": sel_fg,
        "theme_unfocused_fg_color": win_fg, "theme_unfocused_bg_color": win_bg,
        "theme_unfocused_text_color": view_fg, "theme_unfocused_base_color": view_bg,
        "theme_unfocused_selected_bg_color": sel_bg, "theme_unfocused_selected_bg_color_alt": mix(sel_bg, view_bg, 0.5),
        "theme_unfocused_selected_fg_color": sel_fg,
        "theme_button_background_normal": btn_bg, "theme_button_decoration_hover": hover,
        "theme_button_decoration_focus": focus, "theme_button_foreground_normal": btn_fg,
        "theme_button_foreground_active": sel_fg,
        "theme_button_background_backdrop": btn_bg, "theme_button_decoration_hover_backdrop": hover,
        "theme_button_decoration_focus_backdrop": focus, "theme_button_foreground_backdrop": btn_fg,
        "theme_button_foreground_active_backdrop": sel_fg,
        "theme_button_background_insensitive": btn_bg, "theme_button_foreground_insensitive": inactive,
        "theme_button_background_backdrop_insensitive": btn_bg,
        "theme_button_foreground_backdrop_insensitive": inactive,
        "theme_button_foreground_active_insensitive": inactive,
        "theme_button_foreground_active_backdrop_insensitive": inactive,
        "theme_button_decoration_hover_insensitive": hover, "theme_button_decoration_focus_insensitive": focus,
        "theme_button_decoration_hover_backdrop_insensitive": hover,
        "theme_button_decoration_focus_backdrop_insensitive": focus,
        "theme_titlebar_background": head_bg, "theme_titlebar_foreground": head_fg,
        "theme_titlebar_background_light": win_bg,
        "theme_titlebar_background_backdrop": head_bg, "theme_titlebar_foreground_backdrop": inactive,
        "theme_titlebar_foreground_insensitive": inactive, "theme_titlebar_foreground_insensitive_backdrop": inactive,
        "content_view_bg": view_bg, "borders": borders, "unfocused_borders": borders,
        "insensitive_fg_color": inactive, "insensitive_bg_color": win_bg,
        "insensitive_base_color": view_bg, "insensitive_base_fg_color": inactive, "insensitive_borders": borders,
        "insensitive_selected_bg_color": mix(sel_bg, win_bg, 0.5), "insensitive_selected_fg_color": sel_fg,
        "insensitive_unfocused_fg_color": inactive, "insensitive_unfocused_bg_color": win_bg,
        "insensitive_unfocused_selected_bg_color": mix(sel_bg, win_bg, 0.5),
        "insensitive_unfocused_selected_fg_color": sel_fg,
        "link_color": c("View", "ForegroundLink", sel_bg), "link_visited_color": c("View", "ForegroundVisited", sel_bg),
        "error_color": c("View", "ForegroundNegative", (218, 68, 83)),
        "success_color": c("View", "ForegroundPositive", (39, 174, 96)),
        "warning_color": c("View", "ForegroundNeutral", (246, 116, 0)),
        "tooltip_text": win_fg, "tooltip_background": win_bg, "tooltip_border": borders,
    }
    lines = ["/* Generated by JourneyOS (scripts/kde-colors.py) from the shell's colour scheme */"]
    for name, value in colors.items():
        if value is not None:
            lines.append(f"@define-color {name}_breeze {hexc(value)};")
    return "\n".join(lines) + "\n"


def apply_gtk(light, scheme=None):
    """Breeze GTK in the shell's light/dark mode (gtk-3.0 and gtk-4.0 settings.ini) and, with a
    scheme, its colours in colors.css (imported by gtk.css; without a scheme the import is removed)."""
    for v in ("gtk-3.0", "gtk-4.0"):
        d = os.path.join(HOME, ".config", v)
        path = os.path.join(d, "settings.ini")
        p = ini(path)
        if not p.has_section("Settings"):
            p.add_section("Settings")
        p["Settings"]["gtk-theme-name"] = "Breeze" if light else "Breeze-Dark"
        p["Settings"]["gtk-application-prefer-dark-theme"] = "false" if light else "true"
        p["Settings"]["gtk-icon-theme-name"] = "breeze-dark" if not light else "breeze"
        p["Settings"]["gtk-cursor-theme-name"] = "breeze_cursors"
        write_atomic(path, kconfig_text(p))

        gtk_css = os.path.join(d, "gtk.css")
        imp = "@import 'colors.css';"
        css = open(gtk_css, encoding="utf-8").read() if os.path.exists(gtk_css) else ""
        rest = "\n".join(l for l in css.splitlines() if l.strip() != imp).strip()
        if scheme is not None:
            write_atomic(os.path.join(d, "colors.css"), gtk_colors(scheme))
            write_atomic(gtk_css, imp + "\n" + (rest + "\n" if rest else ""))
        elif css:
            write_atomic(gtk_css, rest + "\n" if rest else "")
            if os.path.exists(os.path.join(d, "colors.css")):
                os.remove(os.path.join(d, "colors.css"))


def color_scheme(t, name):
    light = t["light"] == "true"
    base = ini(f"/usr/share/color-schemes/{'BreezeLight' if light else 'BreezeDark'}.colors")

    bg, surface, card = rgb(t["bg"]), rgb(t["surface"]), rgb(t["surfaceCard"])
    text, subtext, dim = rgb(t["text"]), rgb(t["subtext"]), rgb(t["dim"])
    accent, on_accent = rgb(t["accent"]), rgb(t["accentText"])
    hover = mix(card, text, 0.08)

    # (normal background, alternate background) per colour set
    sets = {
        "Colors:Window": (surface, mix(surface, text, 0.04)),
        "Colors:View": (bg, mix(bg, text, 0.03)),
        "Colors:Button": (card, mix(card, text, 0.04)),
        "Colors:Header": (surface, mix(surface, text, 0.04)),
        "Colors:Header][Inactive": (bg, mix(bg, text, 0.03)),
        "Colors:Tooltip": (card, mix(card, text, 0.04)),
        "Colors:Complementary": (surface, mix(surface, text, 0.04)),
    }
    for section, (normal, alternate) in sets.items():
        if not base.has_section(section):
            base.add_section(section)
        s = base[section]
        s["BackgroundNormal"] = kde(normal)
        s["BackgroundAlternate"] = kde(alternate)
        s["ForegroundNormal"] = kde(text)
        s["ForegroundInactive"] = kde(subtext)
        s["DecorationFocus"] = kde(accent)
        s["DecorationHover"] = kde(hover if accent == text else accent)

    sel = base["Colors:Selection"]
    sel["BackgroundNormal"] = kde(accent)
    sel["BackgroundAlternate"] = kde(mix(accent, bg, 0.3))
    sel["ForegroundNormal"] = kde(on_accent)
    sel["ForegroundInactive"] = kde(mix(on_accent, accent, 0.3))
    sel["DecorationFocus"] = kde(accent)
    sel["DecorationHover"] = kde(accent)

    if base.has_section("WM"):
        wm = base["WM"]
        wm["activeBackground"] = kde(surface)
        wm["activeForeground"] = kde(text)
        wm["inactiveBackground"] = kde(bg)
        wm["inactiveForeground"] = kde(dim)
        wm["activeBlend"] = kde(surface)
        wm["inactiveBlend"] = kde(bg)

    g = base["General"]
    g["ColorScheme"] = name
    g["Name"] = "Shadow KDE " + ("Light" if light else "Dark")

    out = []
    for section in base.sections():
        out.append(f"[{section}]")
        out.extend(f"{k}={v}" for k, v in base[section].items())
        out.append("")
    return "\n".join(out)


def konsole_scheme(t):
    """Konsole scheme: the shell's background and text, the 16 Breeze colours (dark/light)."""
    light = t["light"] == "true"
    bg, text, accent = rgb(t["bg"]), rgb(t["text"]), rgb(t["accent"])
    # ANSI palette (normal, intense): Breeze's, which reads well in both themes
    palette = [
        ((35, 38, 39), (127, 140, 141)), ((237, 21, 21), (192, 57, 43)),
        ((17, 209, 22), (28, 220, 154)), ((246, 116, 0), (253, 188, 75)),
        ((29, 153, 243), (61, 174, 233)), ((155, 89, 182), (142, 68, 173)),
        ((26, 188, 156), (22, 160, 133)), ((252, 252, 252), (255, 255, 255)),
    ]
    if light:
        palette[0] = ((35, 38, 39), (96, 104, 107))
        palette[7] = ((96, 104, 107), (35, 38, 39))
    lines = ["[General]", "Description=Shadow KDE", "Opacity=1", "Wallpaper=", "",
             "[Background]", f"Color={kde(bg)}", "", "[BackgroundIntense]", f"Color={kde(bg)}", "",
             "[Foreground]", f"Color={kde(text)}", "", "[ForegroundIntense]", f"Color={kde(text)}", ""]
    for i, (normal, intense) in enumerate(palette):
        lines += [f"[Color{i}]", f"Color={kde(normal)}", "", f"[Color{i}Intense]", f"Color={kde(intense)}", ""]
    return "\n".join(lines)


KATE_THEMES = os.path.join(HOME, ".local/share/org.kde.syntax-highlighting/themes")
KATE_THEME = "JourneyOS"
KATE_APPS = ("katerc", "kwriterc")


def kate_theme(t):
    """Kate/KWrite editor theme (KSyntaxHighlighting) with the shell's colours: its backgrounds and
    text tones, the accent for keywords, selection and search; monochrome with the mono scheme."""
    light = t["light"] == "true"
    bg, surface = rgb(t["bg"]), rgb(t["surface"])
    text, subtext, dim = rgb(t["text"]), rgb(t["subtext"]), rgb(t["dim"])
    accent = rgb(t["accent"])
    red, orange = ((192, 28, 40) if light else (237, 85, 90)), ((176, 88, 0) if light else (246, 152, 64))

    def h(c):
        return "#{:02x}{:02x}{:02x}".format(*c)

    def style(color, **flags):
        s = {"text-color": h(color), "selected-text-color": h(color)}
        s.update(flags)
        return s

    soft = mix(text, subtext, 0.45)           # between text and subtext
    styles = {
        "Normal": style(text),
        "Keyword": style(accent, bold=True),
        "ControlFlow": style(accent, bold=True),
        "Operator": style(soft),
        "BuiltIn": style(mix(accent, text, 0.5)),
        "Extension": style(mix(accent, text, 0.5), bold=True),
        "Preprocessor": style(subtext, bold=True),
        "Import": style(subtext, bold=True),
        "Function": style(text, bold=True),
        "Variable": style(soft),
        "Attribute": style(mix(accent, subtext, 0.5)),
        "DataType": style(mix(accent, text, 0.35), bold=True),
        "DecVal": style(mix(accent, text, 0.6)),
        "BaseN": style(mix(accent, text, 0.6)),
        "Float": style(mix(accent, text, 0.6)),
        "Constant": style(mix(accent, text, 0.6), bold=True),
        "Char": style(subtext),
        "SpecialChar": style(mix(accent, subtext, 0.5)),
        "String": style(subtext),
        "VerbatimString": style(subtext),
        "SpecialString": style(mix(accent, subtext, 0.5)),
        "Comment": style(dim, italic=True),
        "Documentation": style(mix(dim, subtext, 0.5), italic=True),
        "Annotation": style(mix(accent, dim, 0.5)),
        "CommentVar": style(mix(accent, dim, 0.5), bold=True),
        "RegionMarker": style(dim, **{"background-color": h(mix(bg, text, 0.06))}),
        "Information": style(mix(accent, text, 0.5)),
        "Warning": style(orange),
        "Alert": style(red, bold=True),
        "Error": style(red, underline=True),
        "Others": style(soft),
    }
    editor = {
        "BackgroundColor": h(bg),
        "CodeFolding": h(mix(bg, accent, 0.14)),
        "BracketMatching": h(mix(bg, accent, 0.25)),
        "CurrentLine": h(mix(bg, text, 0.045)),
        "IconBorder": h(bg),
        "IndentationLine": h(mix(bg, text, 0.12)),
        "LineNumbers": h(dim),
        "CurrentLineNumber": h(subtext),
        "MarkBookmark": h(accent),
        "MarkBreakpointActive": h(red),
        "MarkBreakpointReached": h(orange),
        "MarkBreakpointDisabled": h(mix(red, bg, 0.5)),
        "MarkExecution": h(mix(accent, text, 0.5)),
        "MarkWarning": h(orange),
        "MarkError": h(red),
        "ModifiedLines": h(accent),
        "ReplaceHighlight": h(mix(bg, accent, 0.55)),
        "SavedLines": h(mix(bg, text, 0.35)),
        "SearchHighlight": h(mix(bg, accent, 0.42)),
        "TextSelection": h(mix(bg, accent, 0.28)),
        "Separator": h(mix(bg, text, 0.10)),
        "SpellChecking": h(red),
        "TabMarker": h(mix(bg, text, 0.18)),
        "TemplateBackground": h(surface),
        "TemplatePlaceholder": h(mix(bg, accent, 0.2)),
        "TemplateFocusedPlaceholder": h(mix(bg, accent, 0.35)),
        "TemplateReadOnlyPlaceholder": h(mix(bg, text, 0.08)),
        "WordWrapMarker": h(mix(bg, text, 0.12)),
    }
    theme = {"metadata": {"name": KATE_THEME, "revision": 1, "license": "MIT",
                          "copyright": ["JourneyOS (generated from the shell theme)"]},
             "editor-colors": editor, "text-styles": styles}
    return json.dumps(theme, indent=2) + "\n"


def apply_kate(t):
    write_atomic(os.path.join(KATE_THEMES, KATE_THEME.lower() + ".theme"), kate_theme(t))
    for rc in KATE_APPS:
        run("kwriteconfig6", "--file", rc, "--group", "KTextEditor Renderer", "--key", "Auto Color Theme Selection", "false")
        run("kwriteconfig6", "--file", rc, "--group", "KTextEditor Renderer", "--key", "Color Theme", KATE_THEME)


def reset_kate():
    for rc in KATE_APPS:
        for key in ("Color Theme", "Auto Color Theme Selection"):
            run("kwriteconfig6", "--file", rc, "--group", "KTextEditor Renderer", "--key", key, "--delete")
    path = os.path.join(KATE_THEMES, KATE_THEME.lower() + ".theme")
    if os.path.exists(path):
        os.remove(path)


def konsole_profile():
    return "\n".join([
        "[Appearance]", "ColorScheme=ShadowKDE", "Font=JetBrains Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1", "",
        "[General]", "Name=Shadow KDE", "Parent=FALLBACK/", "TerminalMargin=8", "",
    ])


def apply(force):
    if not os.path.exists(THEME):
        print("theme.conf does not exist yet", file=sys.stderr)
        return 1
    t = dict(ini(THEME)["Theme"])

    sig = hashlib.sha1(repr(sorted(t.items())).encode()).hexdigest()
    if not force and os.path.exists(SIG) and open(SIG).read().strip() == sig:
        return 0

    # KDE scheme (alternating name so KDE reads it again)
    current = run("kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "ColorScheme")
    name = "ShadowKDEB" if current == "ShadowKDEA" else "ShadowKDEA"
    write_atomic(os.path.join(SCHEMES, f"{name}.colors"), color_scheme(t, name))
    apply_scheme(name)
    apply_gtk(t["light"] == "true", ini(os.path.join(SCHEMES, f"{name}.colors")))

    # Konsole: colour scheme and default profile
    write_atomic(os.path.join(KONSOLE, "ShadowKDE.colorscheme"), konsole_scheme(t))
    write_atomic(os.path.join(KONSOLE, PROFILE), konsole_profile())
    run("kwriteconfig6", "--file", "konsolerc", "--group", "Desktop Entry", "--key", "DefaultProfile", PROFILE)

    # Kate / KWrite: editor theme with the same colours
    apply_kate(t)

    write_atomic(SIG, sig + "\n")
    return 0


def reset():
    apply_scheme("BreezeLight")
    apply_gtk(True)
    run("kwriteconfig6", "--file", "konsolerc", "--group", "Desktop Entry", "--key", "DefaultProfile", "--delete")
    reset_kate()
    if os.path.exists(SIG):
        os.remove(SIG)
    return 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "apply":
        sys.exit(apply("--force" in sys.argv))
    if cmd == "reset":
        sys.exit(reset())
    print("usage: kde-colors.py apply [--force] | reset", file=sys.stderr)
    sys.exit(1)
