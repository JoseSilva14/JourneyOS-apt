import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Now playing (MPRIS): cover, title, artist and controls.
Section {
    id: root

    implicitHeight: 72

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 10
        spacing: 12

        RoundImage {
            id: art
            implicitWidth: 48
            implicitHeight: 48
            radius: Theme.radiusSmall + 2
            source: Media.art

            MIcon {
                anchors.centerIn: parent
                visible: !art.ready
                icon: "music_note"
                size: 22
                color: Theme.subtext
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 2

            Text {
                Layout.fillWidth: true
                text: Media.player ? Media.title : Tr.t("Nothing playing")
                elide: Text.ElideRight
                color: Media.player ? Theme.text : Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: Media.player ? (Media.artist || Media.player.identity) : ""
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        Row {
            visible: Media.player !== null
            spacing: 2

            Control {
                icon: "skip_previous"
                enabled: Media.player?.canGoPrevious ?? false
                onClicked: Media.previous()
            }
            Control {
                icon: Media.playing ? "pause" : "play_arrow"
                big: true
                onClicked: Media.toggle()
            }
            Control {
                icon: "skip_next"
                enabled: Media.player?.canGoNext ?? false
                onClicked: Media.next()
            }
        }
    }

    component Control: Rectangle {
        id: control

        property string icon: ""
        property bool big: false
        signal clicked

        anchors.verticalCenter: parent.verticalCenter
        implicitWidth: big ? 38 : 32
        implicitHeight: implicitWidth
        radius: width / 2
        color: big ? Theme.accent : controlMouse.containsMouse ? Theme.buttonHover : "transparent"
        opacity: enabled ? 1 : 0.35
        scale: controlMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: control.icon
            size: control.big ? 22 : 20
            color: control.big ? Theme.accentText : Theme.text
        }

        MouseArea {
            id: controlMouse
            anchors.fill: parent
            hoverEnabled: true
            enabled: control.enabled
            cursorShape: Qt.PointingHandCursor
            onClicked: control.clicked()
        }
    }
}
