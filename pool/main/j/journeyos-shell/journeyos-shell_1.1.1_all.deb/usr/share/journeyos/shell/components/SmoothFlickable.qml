import QtQuick
import QtQuick.Controls
import qs

// Scrollable area for the mouse: the wheel moves in steps with a short animation, the touchpad
// follows the finger, and there is a thin bar on the right (appears on hover or while scrolling).
// Content is not dragged with the mouse (as on a normal settings page).
Flickable {
    id: root

    property real step: 90              // pixels per wheel "click"

    clip: true
    interactive: false
    boundsBehavior: Flickable.StopAtBounds

    readonly property real maxY: Math.max(0, contentHeight - height)

    function scrollTo(y) {
        anim.stop();
        anim.from = contentY;
        anim.to = Math.max(0, Math.min(maxY, y));
        anim.start();
    }

    // If the content shrinks, it does not keep showing empty space at the end
    onMaxYChanged: if (contentY > maxY) contentY = maxY

    NumberAnimation {
        id: anim
        target: root
        property: "contentY"
        duration: Theme.animNormal
        easing.type: Easing.OutCubic
    }

    WheelHandler {
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        onWheel: event => {
            if (root.maxY <= 0)
                return;
            if (event.pixelDelta.y !== 0) {
                // Touchpad: follows the finger, no animation
                anim.stop();
                root.contentY = Math.max(0, Math.min(root.maxY, root.contentY - event.pixelDelta.y));
            } else {
                // Wheel: adds to the target of the running animation, so several clicks in a row go far
                const base = anim.running ? anim.to : root.contentY;
                root.scrollTo(base - event.angleDelta.y / 120 * root.step);
            }
            event.accepted = true;
        }
    }

    ScrollBar.vertical: ScrollBar {
        id: bar
        policy: root.maxY > 0 ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff
        width: 10
        padding: 2

        contentItem: Rectangle {
            implicitWidth: 6
            radius: 3
            color: bar.pressed ? Theme.subtext : Theme.dim
            opacity: bar.active || bar.hovered || bar.pressed ? 0.9 : 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animNormal }
            }
        }
        background: Item {}
    }
}
