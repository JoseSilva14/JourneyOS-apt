pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Colour schemes (config.json, theme.scheme): each gives the accent colour and a tint for
// the backgrounds, which Theme blends into black. "auto" takes them from the wallpaper.
Singleton {
    id: root

    // tint: background tint; strength: how much goes into the black; accent: accent;
    // accentLight: accent in the light theme (without it, Theme darkens light colours)
    readonly property var schemes: ({
        auto: { name: "Auto", group: "auto" },
        mono: { name: "Mono", group: "mono", tint: "#808080", strength: 0, accent: "#f2f2f2", accentLight: "#18181b" },
        slate: { name: "Slate", group: "mono", tint: "#64748b", strength: 0.12, accent: "#cbd5e1", accentLight: "#334155" },
        stone: { name: "Stone", group: "mono", tint: "#78716c", strength: 0.12, accent: "#e7e5e4", accentLight: "#44403c" },
        steel: { name: "Steel", group: "mono", tint: "#4b6584", strength: 0.14, accent: "#b8c7d9", accentLight: "#2c4361" },
        ash: { name: "Ash", group: "mono", tint: "#a1a1aa", strength: 0.1, accent: "#d4d4d8", accentLight: "#3f3f46" },
        ink: { name: "Ink", group: "mono", tint: "#1e3a5f", strength: 0.16, accent: "#e2e8f0", accentLight: "#1e3a5f" },
        navy: { name: "Navy", group: "color", accent: "#4c6ef5" },
        ocean: { name: "Ocean", group: "color", accent: "#228be6" },
        sky: { name: "Sky", group: "color", accent: "#4dabf7" },
        teal: { name: "Teal", group: "color", accent: "#20c997" },
        mint: { name: "Mint", group: "color", accent: "#63e6be" },
        forest: { name: "Forest", group: "color", accent: "#40c057" },
        lime: { name: "Lime", group: "color", accent: "#94d82d" },
        gold: { name: "Gold", group: "color", accent: "#fcc419" },
        sunset: { name: "Sunset", group: "color", accent: "#ff922b" },
        ember: { name: "Ember", group: "color", accent: "#fa5252" },
        rose: { name: "Rose", group: "color", accent: "#f06595" },
        orchid: { name: "Orchid", group: "color", accent: "#cc5de8" },
        violet: { name: "Violet", group: "color", accent: "#845ef7" }
    })
    readonly property var names: Object.keys(schemes)

    readonly property string current: schemes[Config.options.theme.scheme] ? Config.options.theme.scheme : "mono"
    readonly property var scheme: schemes[current]

    function set(name) {
        if (schemes[name])
            Config.options.theme.scheme = name;
    }

    // --- Auto: the most vivid wallpaper colour (without a wallpaper, mono stays) ---
    readonly property string wallpaper: Config.options.wallpaper
    property color autoAccent: "#f2f2f2"
    property color autoTint: "#808080"
    property bool autoColorful: false

    ColorQuantizer {
        id: quantizer
        source: root.wallpaper ? (root.wallpaper.startsWith("/") ? "file://" + root.wallpaper : root.wallpaper) : ""
        depth: 4
        rescaleSize: 64
        onColorsChanged: root.pickAuto(colors)
    }

    // Wallpaper colours usable as accent (vivid and of different hues),
    // best first; theme.wallColor picks one of them (empty = the best)
    property var wallColors: []
    readonly property string wallChoice: Config.options.theme.wallColor

    // A wallpaper colour as accent: saturated and bright enough to show on dark
    function usable(c) {
        return Qt.hsla(c.hslHue, Math.min(1, Math.max(0.55, c.hslSaturation)), Math.min(0.72, Math.max(0.58, c.hslLightness)), 1);
    }

    function pickAuto(colors) {
        const scored = (colors ?? []).filter(c => c.hslSaturation > 0.25)
            .map(c => ({ c, score: c.hslSaturation * (1 - Math.abs(c.hslLightness - 0.6) * 1.6) }))
            .sort((a, b) => b.score - a.score);
        // Hues more than 25° apart (otherwise it was six nearly identical blues)
        const picked = [];
        for (const s of scored) {
            const hue = s.c.hslHue;
            if (picked.every(p => Math.min(Math.abs(p.hslHue - hue), 1 - Math.abs(p.hslHue - hue)) > 25 / 360))
                picked.push(s.c);
            if (picked.length === 6)
                break;
        }
        wallColors = picked.map(c => usable(c).toString());
        applyAuto();
    }

    function applyAuto() {
        if (wallColors.length === 0) {
            autoAccent = "#f2f2f2";
            autoTint = "#808080";
            autoColorful = false;
            return;
        }
        // The chosen one, if it is still from this wallpaper; otherwise the best
        const chosen = wallColors.includes(wallChoice) ? wallChoice : wallColors[0];
        autoColorful = true;
        autoAccent = chosen;
        autoTint = chosen;
    }

    onWallChoiceChanged: applyAuto()

    // Picking one of the wallpaper colours (empty = the best) switches to the Auto scheme
    function setWallColor(color) {
        Config.options.theme.wallColor = color;
        set("auto");
    }

    // What Theme uses
    readonly property color accent: current === "auto" ? autoAccent : scheme.accent
    readonly property color tint: current === "auto" ? autoTint
        : scheme.group === "color" ? scheme.accent
        : scheme.tint
    readonly property var accentLight: current === "auto" ? (autoColorful ? null : "#18181b")
        : (scheme.accentLight ?? null)
    readonly property real strength: current === "auto" ? (autoColorful ? 0.09 : 0)
        : scheme.group === "color" ? 0.06
        : scheme.strength

    IpcHandler {
        target: "theme"
        function set(name: string): void { root.set(name); }
        function get(): string { return root.current; }
        function list(): string { return root.names.join(" "); }
        function wallColors(): string { return root.wallColors.join(" "); }
        function mode(value: string): void { Config.options.theme.mode = value; }
    }
}
