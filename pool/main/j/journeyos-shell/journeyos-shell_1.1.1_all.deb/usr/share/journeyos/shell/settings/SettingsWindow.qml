import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services
import "pages"

// Settings window: pages in the sidebar, the selected one on the right.
// It is a normal window (with the KWin decoration) inside the shell process.
FloatingWindow {
    id: root

    title: Tr.t("Settings")
    visible: SettingsApp.open
    implicitWidth: Theme.settingsWidth
    // Fits between the bar and the dock (including the window title bar); otherwise the end of
    // the pages would be hidden behind the dock
    implicitHeight: Math.min(Theme.settingsHeight, (Quickshell.screens[0]?.height ?? 800)
        - Theme.barZone - (Config.options.dock.enabled ? Theme.dockHeight + Theme.gap : 0)
        - Theme.windowTitleHeight - Theme.gap * 2)
    color: Theme.bg

    readonly property string query: search.text
    readonly property bool searching: query.trim() !== ""
    readonly property var shownPages: SettingsApp.search(query)

    // Closing the window (decoration button) counts too
    onVisibleChanged: if (!visible) SettingsApp.open = false

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // Sidebar
        Rectangle {
            Layout.fillHeight: true
            Layout.preferredWidth: Theme.settingsSidebar
            color: Theme.surface

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: Theme.gap
                spacing: 4

                // Account
                RowLayout {
                    Layout.fillWidth: true
                    Layout.margins: 6
                    Layout.bottomMargin: Theme.gap
                    spacing: 10

                    RoundImage {
                        id: avatar
                        implicitWidth: 40
                        implicitHeight: 40
                        radius: 20
                        source: User.face

                        Text {
                            anchors.centerIn: parent
                            visible: !avatar.ready
                            text: User.name.charAt(0).toUpperCase()
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontLarge
                            font.weight: Font.Bold
                        }
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0
                        Text {
                            Layout.fillWidth: true
                            text: User.name
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: Font.Bold
                        }
                        Text {
                            Layout.fillWidth: true
                            text: SystemInfo.os
                            elide: Text.ElideRight
                            color: Theme.dim
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                    }
                }

                // Search: filters the pages (by name and by their contents); Enter opens the first one
                TextField {
                    id: search
                    Layout.fillWidth: true
                    Layout.leftMargin: 2
                    Layout.rightMargin: 2
                    Layout.bottomMargin: 6
                    placeholder: Tr.t("Search settings")
                    acceptOnBlur: false
                    onAccepted: t => {
                        const first = root.shownPages[0];
                        if (t.trim() && first)
                            SettingsApp.page = first.id;
                    }
                }

                Text {
                    visible: root.shownPages.length === 0
                    Layout.fillWidth: true
                    Layout.leftMargin: 12
                    text: Tr.t("Nothing found")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }

                // On short screens not all pages fit: the list scrolls
                SmoothFlickable {
                    id: sideScroll
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    contentHeight: entries.implicitHeight
                    step: 60

                    ColumnLayout {
                        id: entries
                        width: sideScroll.width - 10
                        spacing: 4

                        Repeater {
                            model: root.shownPages

                            ColumnLayout {
                                id: slot
                                required property var modelData
                                required property int index
                                // Group title before the first page of each group
                                // (no titles while searching)
                                readonly property bool firstOfGroup: !root.searching && modelData.group !== ""
                                    && (index === 0 || root.shownPages[index - 1].group !== modelData.group)

                                Layout.fillWidth: true
                                spacing: 4

                                Text {
                                    visible: slot.firstOfGroup
                                    Layout.topMargin: 10
                                    Layout.leftMargin: 12
                                    text: slot.modelData.group
                                    color: Theme.dim
                                    font.family: Theme.font
                                    font.pixelSize: Theme.fontSmall
                                    font.weight: Font.Bold
                                }

                            Rectangle {
                                id: entry
                                readonly property var modelData: slot.modelData
                                readonly property bool active: SettingsApp.page === modelData.id

                                Layout.fillWidth: true
                                implicitHeight: 38
                                radius: Theme.radiusSmall + 2
                                // Active item inverted; no transition, as in menus
                                color: active ? Theme.accent : entryMouse.containsMouse ? Theme.button : "transparent"

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 12
                                    anchors.rightMargin: 12
                                    spacing: 12

                                    MIcon {
                                        icon: entry.modelData.icon
                                        size: 18
                                        color: entry.active ? Theme.accentText : Theme.subtext
                                    }
                                    Text {
                                        Layout.fillWidth: true
                                        text: entry.modelData.label
                                        elide: Text.ElideRight
                                        color: entry.active ? Theme.accentText : Theme.text
                                        font.family: Theme.font
                                        font.pixelSize: Theme.fontNormal
                                        font.weight: entry.active ? Font.Bold : Font.Normal
                                    }
                                }

                                MouseArea {
                                    id: entryMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: SettingsApp.page = entry.modelData.id
                                }
                            }
                            }
                        }
                    }
                }
            }
        }

        Rectangle {
            Layout.fillHeight: true
            implicitWidth: 1
            color: Theme.surfaceBorder
        }

        // Page
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: Theme.cardPadding + 4
            spacing: Theme.gap + 4

            Text {
                text: SettingsApp.pages.find(p => p.id === SettingsApp.page)?.label ?? ""
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 22
                font.weight: Font.Bold
            }

            Loader {
                Layout.fillWidth: true
                Layout.fillHeight: true
                active: root.visible
                source: {
                    const p = SettingsApp.page;
                    return p === "sound" ? "pages/SoundPage.qml"
                        : p === "display" ? "pages/DisplayPage.qml"
                        : p === "power" ? "pages/PowerPage.qml"
                        : p === "input" ? "pages/InputPage.qml"
                        : p === "datetime" ? "pages/DateTimePage.qml"
                        : p === "locale" ? "pages/LocalePage.qml"
                        : p === "account" ? "pages/AccountPage.qml"
                        : p === "look" ? "pages/LookPage.qml"
                        : p === "windows" ? "pages/WindowsPage.qml"
                        : p === "defaultapps" ? "pages/DefaultAppsPage.qml"
                        : p === "autostart" ? "pages/AutostartPage.qml"
                        : p === "storage" ? "pages/StoragePage.qml"
                        : p === "printers" ? "pages/PrintersPage.qml"
                        : p === "users" ? "pages/UsersPage.qml"
                        : p === "a11y" ? "pages/A11yPage.qml"
                        : p === "privacy" ? "pages/PrivacyPage.qml"
                        : p === "session" ? "pages/SessionPage.qml"
                        : p === "updates" ? "pages/UpdatesPage.qml"
                        : p === "snapshots" ? "pages/SnapshotsPage.qml"
                        : p === "network" ? "pages/NetworkPage.qml"
                        : p === "bluetooth" ? "pages/BluetoothPage.qml"
                        : p === "theme" ? "pages/ThemePage.qml"
                        : p === "bar" ? "pages/BarPage.qml"
                        : p === "dock" ? "pages/DockPage.qml"
                        : p === "desktop" ? "pages/DesktopPage.qml"
                        : p === "notifications" ? "pages/NotificationsPage.qml"
                        : p === "focus" ? "pages/FocusPage.qml"
                        : p === "dev" ? "pages/DevPage.qml"
                        : p === "tabs" ? "pages/TabsPage.qml"
                        : p === "launcherapps" ? "pages/LauncherAppsPage.qml"
                        : p === "calendar" ? "pages/CalendarPage.qml"
                        : p === "shortcuts" ? "pages/ShortcutsPage.qml"
                        : p === "weather" ? "pages/WeatherPage.qml"
                        : p === "about" ? "pages/AboutPage.qml"
                        : "pages/HomePage.qml";
                }
            }
        }
    }
}
