#!/bin/sh
# shadow-kde Alt+Tab in KWin.
#   apply    copies the package to ~/.local/share/kwin/tabbox/shadowkde and selects it in kwinrc
#   default  goes back to KDE's
set -e
dir=$(dirname "$(readlink -f "$0")")/..
dest="$HOME/.local/share/kwin/tabbox/shadowkde"

reconfigure() {
    gdbus call --session --dest org.kde.KWin --object-path /KWin --method org.kde.KWin.reconfigure >/dev/null
}

case "$1" in
    apply)
        mkdir -p "$(dirname "$dest")"
        rm -rf "$dest.tmp"
        cp -r "$dir/switcher" "$dest.tmp"
        rm -rf "$dest"
        mv "$dest.tmp" "$dest"
        for g in TabBox TabBoxAlternative; do
            kwriteconfig6 --file kwinrc --group "$g" --key LayoutName shadowkde
        done
        reconfigure
        ;;
    default)
        for g in TabBox TabBoxAlternative; do
            kwriteconfig6 --file kwinrc --group "$g" --key LayoutName --delete
        done
        reconfigure
        ;;
    *)
        echo "usage: $0 apply|default" >&2
        exit 1
        ;;
esac
