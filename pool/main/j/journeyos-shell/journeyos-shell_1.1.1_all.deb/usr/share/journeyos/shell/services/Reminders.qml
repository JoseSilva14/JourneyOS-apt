pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Reminders: "lembrar 20 min tirar o café" (Portuguese for "remind 20 min …") in the launcher. Stored in
// ~/.local/state/shadow-kde/reminders.json { reminders: [{ id, text, at, created }] } (ms), so
// they survive a shell restart (those that passed in the meantime fire right away, "late").
// At the time, a notification through the shell's own server (stays in the centre and plays the sound).
//
// When, at the start or end of the text (Portuguese input):
//   duration: "20 min", "2 horas", "30 s", "1 dia", "em 2h", "daqui a 1h30", "+45m"
//   time:     "18h", "18:30", "18h30", "às 9", "meio-dia" (already past today → tomorrow)
//   day:      "amanhã", "depois de amanhã", "sexta", "segunda às 10" (no time → 9h)
// "1h" without "em"/"daqui a" ("in") is a clock time (01:00); the preview always shows what was
// understood.
Singleton {
    id: root

    property var reminders: []
    property bool loaded: false
    property bool broken: false

    readonly property var pending: reminders.slice().sort((a, b) => a.at - b.at)

    // Lowercase and without accents, letter by letter (the length stays the same as the original)
    function fold(s) {
        let out = "";
        for (const c of s)
            out += c.normalize("NFD")[0].toLowerCase();
        return out;
    }

    // Understands Portuguese and English ("20 min", "in 2 hours", "tomorrow at 9", "amanhã às 9")
    readonly property var units: ({ s: 1000, seg: 1000, segundo: 1000, segundos: 1000, sec: 1000, secs: 1000, second: 1000, seconds: 1000,
        m: 60000, min: 60000, mins: 60000, minuto: 60000, minutos: 60000, minute: 60000, minutes: 60000,
        h: 3600000, hora: 3600000, horas: 3600000, hr: 3600000, hrs: 3600000, hour: 3600000, hours: 3600000,
        d: 86400000, dia: 86400000, dias: 86400000, day: 86400000, days: 86400000,
        semana: 604800000, semanas: 604800000, week: 604800000, weeks: 604800000 })
    readonly property var weekdays: ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"]
    readonly property var weekdaysEn: ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
    readonly property string unitRe: "segundos?|seg|secs?|seconds?|s|minutos?|minutes?|mins?|m|horas?|hours?|hrs?|h|dias?|days?|d|semanas?|weeks?"
    readonly property string unitReNoHD: "segundos?|seg|secs?|seconds?|s|minutos?|minutes?|mins?|m|horas?|hours?|hrs?|dias?|days?|semanas?|weeks?"

    // Reads a time expression at the start of s (already folded): { at, len } or null
    function when(s, now) {
        let pos = 0;
        const take = re => {
            const m = re.exec(s.slice(pos));
            if (m)
                pos += m[0].length;
            return m;
        };
        const end = "(?=\\s|$|,)";

        // Duration: with "em/daqui a/dentro de/+" ("in") any unit; without, not "h" or "d" alone
        let m = take(new RegExp("^(?:daqui a|dentro de|em|in|\\+)\\s*(\\d+(?:[.,]\\d+)?)\\s*(" + unitRe + ")"
            + "(?:\\s*(?:e|and)?\\s*(\\d+)\\s*(?:minutos?|minutes?|mins?|m)?)?" + end))
            || take(new RegExp("^(\\d+(?:[.,]\\d+)?)\\s*(" + unitReNoHD + ")"
            + "(?:\\s*(?:e|and)\\s*(\\d+)\\s*(?:minutos?|minutes?|mins?|m)?)?" + end));
        if (m) {
            const ms = parseFloat(m[1].replace(",", ".")) * units[m[2]] + (m[3] ? Number(m[3]) * 60000 : 0);
            return ms > 0 ? { at: now.getTime() + ms, len: pos } : null;
        }

        // Day, then time
        const day = take(new RegExp("^(depois de amanha|day after tomorrow|amanha|tomorrow|hoje|today|"
            + "(?:n[ao]\\s+|on\\s+)?(?:proxim[ao]\\s+|next\\s+)?(domingo|segunda|terca|quarta|quinta|sexta|sabado|"
            + "sunday|monday|tuesday|wednesday|thursday|friday|saturday)(?:-feira)?)" + end + "\\s*"));
        const at = take(/^(?:as|a|ao|at)\s+/);
        // 18h, 18:30, 18h30, 6pm, 6:30pm
        const clock = take(new RegExp("^(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)" + end))
            || take(new RegExp("^(\\d{1,2})(?::(\\d{2})|h(\\d{2})?)" + end))
            || ((at || day) ? take(new RegExp("^(\\d{1,2})" + end)) : null);
        const named = clock ? null : take(new RegExp("^(meio-dia|meio dia|meia-noite|meia noite|noon|midday|midnight)" + end));
        if (!day && !clock && !named)
            return null;

        let h = 9, min = 0;
        if (clock) {
            h = Number(clock[1]);
            const ampm = clock[3] === "am" || clock[3] === "pm" ? clock[3] : "";
            min = Number(clock[2] ?? (ampm ? 0 : clock[3]) ?? 0);
            if (ampm === "pm" && h < 12)
                h += 12;
            else if (ampm === "am" && h === 12)
                h = 0;
        } else if (named) {
            h = /^(meio|noon|midday)/.test(named[1]) ? 12 : 0;
        }
        if (h > 23 || min > 59)
            return null;

        const d = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, min);
        if (day) {
            const word = day[1];
            if (word === "amanha" || word === "tomorrow")
                d.setDate(d.getDate() + 1);
            else if (word === "depois de amanha" || word === "day after tomorrow")
                d.setDate(d.getDate() + 2);
            else if (word !== "hoje" && word !== "today") {
                const target = Math.max(weekdays.indexOf(day[2]), weekdaysEn.indexOf(day[2]));
                let add = (target - now.getDay() + 7) % 7;
                if (add === 0 && d <= now)
                    add = 7;
                d.setDate(d.getDate() + add);
            }
        } else if (d <= now) {
            d.setDate(d.getDate() + 1);
        }
        if (d <= now)
            return null;
        // A following space or comma counts as part of it
        const rest = /^[\s,]*/.exec(s.slice(pos));
        return { at: d.getTime(), len: pos + rest[0].length };
    }

    // "20 min tirar o café" / "tirar o café amanhã às 9" (Portuguese: "… tomorrow at 9") → { at, text } or null (no when)
    function parse(input, nowDate) {
        const now = nowDate ?? new Date();
        const original = input.trim();
        const s = fold(original);
        let w = when(s, now);
        if (w) {
            const text = original.slice(w.len).replace(/^(?:de|que|para|a|to)\s+/i, "").trim();
            return { at: w.at, text: text || Tr.t("Reminder") };
        }
        // At the end: the first point (from the left) from which everything is a "when"
        for (let i = 1; i < s.length; i++) {
            if (s[i - 1] !== " ")
                continue;
            w = when(s.slice(i), now);
            if (w && w.len >= s.length - i)
                return { at: w.at, text: original.slice(0, i).trim() || Tr.t("Reminder") };
        }
        return null;
    }

    readonly property var months: ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].map(m => Tr.t(m))
    readonly property var dayNames: ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"].map(d => Tr.t(d))

    // "hoje às 14:52 · daqui a 20 min" ("today at 14:52 · in 20 min")
    function whenText(at) {
        const d = new Date(at), now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - today) / 86400000);
        const hm = Qt.formatTime(d, Config.options.clock.use24h ? "HH:mm" : "h:mm AP");
        const dayText = days === 0 ? Tr.t("today") : days === 1 ? Tr.t("tomorrow") : days < 7 ? dayNames[d.getDay()]
            : d.getDate() + " " + months[d.getMonth()];
        const mins = Math.round((at - now.getTime()) / 60000);
        const rel = mins < 1 ? Tr.t("in less than 1 min") : mins < 60 ? Tr.t("in ") + mins + Tr.t(" min")
            : mins < 24 * 60 ? Tr.t("in ") + Math.floor(mins / 60) + Tr.t(" h") + (mins % 60 ? " " + (mins % 60) + Tr.t(" min") : "")
            : "";
        return dayText + Tr.t(" at ") + hm + (rel ? " · " + rel : "");
    }

    function add(text, at) {
        const now = Date.now();
        const r = { id: now.toString(36) + Math.random().toString(36).slice(2, 6), text, at, created: now };
        reminders = [...reminders, r];
        save();
        return r.id;
    }

    function remove(id) {
        reminders = reminders.filter(r => r.id !== id);
        save();
    }

    function save() {
        if (!loaded || broken)
            return;
        file.setText(JSON.stringify({ reminders }, null, 1) + "\n");
    }

    function notify(summary, body) {
        Quickshell.execDetached(["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
            "--object-path", "/org/freedesktop/Notifications", "--method", "org.freedesktop.Notifications.Notify",
            "--", "Reminders", "0", "kalarm", summary, body, "[]", "{}", "0"]);
    }

    // Those whose time has come
    function check() {
        const now = Date.now();
        const due = reminders.filter(r => r.at <= now);
        if (!due.length)
            return;
        for (const r of due) {
            const late = now - r.at > 2 * 60000;
            notify(r.text, late ? Tr.t("Late: was due at ") + Qt.formatTime(new Date(r.at), Config.options.clock.use24h ? "HH:mm" : "h:mm AP") + "." : "Lembrete");
        }
        reminders = reminders.filter(r => r.at > now);
        save();
    }

    Timer {
        running: root.loaded && !root.broken && root.reminders.length > 0
        interval: 5000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.check()
    }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/reminders.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const list = JSON.parse(text()).reminders;
                root.reminders = Array.isArray(list) ? list.filter(r => r && typeof r.text === "string" && typeof r.at === "number") : [];
                root.broken = false;
            } catch (e) {
                root.broken = true;
                console.warn("reminders.json is corrupt: not overwriting it", e);
            }
            root.loaded = true;
        }
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                root.loaded = true;
        }
    }

    IpcHandler {
        target: "reminders"
        // "20 min tirar o café" (as in the launcher, without the "lembrar")
        function add(text: string): string {
            const p = root.parse(text);
            return p ? root.add(p.text, p.at) + " " + root.whenText(p.at) : Tr.t("couldn't tell when");
        }
        function parse(text: string): string {
            const p = root.parse(text);
            return p ? p.text + " | " + root.whenText(p.at) : "";
        }
        function list(): string { return root.pending.map(r => r.id + " " + root.whenText(r.at) + " " + r.text).join("\n"); }
        function remove(id: string): void { root.remove(id); }
    }
}
