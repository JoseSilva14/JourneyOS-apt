pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Dashboard state (slides up from the bottom of the screen). Opening it closes the other panels.
Singleton {
    id: root

    // .desktop entry (for the dock and the launcher): the shell writes it at startup
    readonly property string desktopId: "shadow-kde-dashboard"

    readonly property var tabs: ["home", "agenda", "notes", "apps", "web", ...(Dev.enabled ? ["dev"] : []), ...Widgets.dashboardTabs.map(t => t.id), "wallpapers", "theme", "performance", "about"]

    property bool open: false
    property string tab: "home"
    // Dev UI turned off with the Dev tab selected: go back to the start
    readonly property bool devTab: Dev.enabled
    onDevTabChanged: if (!devTab && tab === "dev") tab = "home"
    // An extension tab turned off (or uninstalled) while selected: same thing
    onTabsChanged: if (!tabs.includes(tab)) tab = "home"
    property var screen: null

    // The same tab again closes; another tab while open switches
    function toggle(tab, screen) {
        if (open && (!tab || tab === root.tab)) {
            open = false;
            return;
        }
        if (tab)
            root.tab = tab;
        if (!open)
            root.screen = screen ?? Windows.activeScreen;
        open = true;
    }

    onOpenChanged: {
        if (open) {
            QuickPanel.open = false;
            Notifs.centerOpen = false;
            Launcher.open = false;
        }
    }

    FileView {
        path: Quickshell.env("HOME") + "/.local/share/applications/" + root.desktopId + ".desktop"
        atomicWrites: true
        printErrors: false
        // Exec is only used outside the shell; the dock and the launcher open it directly (Apps.launch)
        // In the shell language; rewritten when the language changes
        readonly property string entryText: `[Desktop Entry]
Type=Application
Name=Dashboard
GenericName=${Tr.t("Shell dashboard")}
Comment=${Tr.t("Weather, calendar, wallpapers, theme and performance")}
Icon=${Quickshell.shellPath("assets/icons/dashboard.svg")}
Exec=qs -p ${Quickshell.shellPath("")} ipc call dashboard toggle home
Categories=Utility;
Keywords=dashboard;painel;agenda;calendário;tempo;wallpapers;tema;desempenho;calendar;weather;
StartupNotify=false
`
        onEntryTextChanged: setText(entryText)
        Component.onCompleted: setText(entryText)
    }

    IpcHandler {
        target: "dashboard"
        function toggle(tab: string): void { root.toggle(tab || "home", null); }
    }
}
