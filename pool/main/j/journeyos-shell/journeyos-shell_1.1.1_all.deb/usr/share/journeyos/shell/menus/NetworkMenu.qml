import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Networking
import qs
import qs.components
import qs.services

// Network menu: Wi-Fi (on/off, networks, connection form right there) and wired.
// Scans for networks while open (paused while the form is open: the list reorders on every scan).
// The form (WifiForm, state in WifiConnect) sits outside the list: inside a delegate it was
// recreated on scans and the password field lost focus.
ColumnLayout {
    id: root

    spacing: 8

    // Inside the settings page: no title or "Settings…", taller list
    property bool embedded: false
    property int listHeight: Theme.menuListHeight

    readonly property var devices: Networking.devices.values
    // The ones NetworkManager manages first (an unmanaged card - e.g. used as an access point - has no networks)
    function pick(type) {
        return devices.find(d => d.type === type && d.nmManaged) ?? devices.find(d => d.type === type) ?? null;
    }
    readonly property var wired: pick(DeviceType.Wired)
    readonly property var wifi: pick(DeviceType.Wifi)

    // Connected first, then saved ones, then by signal
    readonly property var networks: (wifi?.networks.values ?? [])
        .filter(n => n.name)
        .slice()
        .sort((a, b) => (b.connected - a.connected) || (b.known - a.known) || (b.signalStrength - a.signalStrength))

    property string failed: ""          // network where the last connection failed
    readonly property bool formOpen: WifiConnect.active

    // Scan on the chosen card only; the choice can change after opening (cards and their
    // "managed" state arrive asynchronously), so the previous card stops scanning
    readonly property bool scanning: wifi !== null && !formOpen
    property var scanned: null
    function updateScan() {
        const want = scanning ? wifi : null;
        if (scanned && scanned !== want)
            scanned.scannerEnabled = false;
        if (want)
            want.scannerEnabled = true;
        scanned = want;
    }
    onScanningChanged: updateScan()
    onWifiChanged: updateScan()
    Component.onCompleted: updateScan()
    Component.onDestruction: if (scanned) scanned.scannerEnabled = false

    function secured(n) { return n.security !== WifiSecurityType.Open; }

    function signalIcon(n) {
        const s = n.signalStrength;
        return s >= 0.66 ? "wifi" : s >= 0.33 ? "wifi_2_bar" : "wifi_1_bar";
    }

    function tap(n) {
        failed = "";
        if (n.connected)
            return;
        if (n.known || !secured(n)) {
            WifiConnect.cancel();
            n.connect();
        } else {
            WifiConnect.begin(n);
        }
    }

    // Header: title and the Wi-Fi switch
    RowLayout {
        Layout.fillWidth: true
        Layout.bottomMargin: 4

        Text {
            Layout.fillWidth: true
            text: root.embedded ? Tr.t("Connections") : Tr.t("Network")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontLarge
            font.weight: Font.Bold
        }
        Text {
            visible: root.wifi !== null
            text: "Wi-Fi"
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
        Toggle {
            visible: root.wifi !== null
            checked: Networking.wifiEnabled
            onToggled: on => Networking.wifiEnabled = on
        }
    }

    // --- Wired ---
    MenuRow {
        visible: root.wired !== null
        icon: "lan"
        // The connection name ("Wired connection 1") instead of the device's
        title: (Net.kind === "ethernet" && Net.name) ? Net.name : Tr.t("Wired")
        subtitle: !root.wired?.hasLink ? Tr.t("No cable connected")
            : root.wired?.connected ? Tr.t("On") + (root.wired.linkSpeed > 0 ? " · " + root.wired.linkSpeed + Tr.t(" Mb/s") : "")
            : Tr.t("Off")
        active: root.wired?.connected ?? false
        busy: root.wired?.network?.stateChanging ?? false
        onClicked: {
            if (!root.wired?.hasLink)
                return;
            if (root.wired.connected)
                root.wired.disconnect();
            else
                root.wired.network?.connect();
        }
    }

    // --- Wi-Fi ---
    Text {
        visible: root.wifi === null
        Layout.fillWidth: true
        Layout.topMargin: 4
        text: Tr.t("This computer has no Wi-Fi.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Text {
        visible: root.wifi !== null && !Networking.wifiEnabled
        Layout.fillWidth: true
        Layout.topMargin: 4
        text: Networking.wifiHardwareEnabled ? Tr.t("Wi-Fi is off.") : Tr.t("Wi-Fi is off at the computer's switch.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Text {
        visible: root.wifi !== null && Networking.wifiEnabled && root.networks.length === 0 && !root.formOpen
        Layout.fillWidth: true
        Layout.topMargin: 4
        text: Tr.t("Looking for networks…")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // Connection form (password, enterprise account, hidden network)
    Loader {
        Layout.fillWidth: true
        active: root.formOpen && root.wifi !== null && Networking.wifiEnabled
        visible: active
        sourceComponent: WifiForm {
            embedded: root.embedded
        }
    }

    ListView {
        id: list
        Layout.fillWidth: true
        implicitHeight: Math.min(contentHeight, root.listHeight)
        visible: root.wifi !== null && Networking.wifiEnabled && count > 0 && !root.formOpen
        clip: true
        spacing: 2
        boundsBehavior: Flickable.StopAtBounds
        model: ScriptModel {
            values: root.networks
        }

        delegate: ColumnLayout {
            id: item
            required property var modelData
            readonly property var n: modelData

            width: list.width
            spacing: 4

            MenuRow {
                id: row
                icon: root.signalIcon(item.n)
                title: item.n.name
                subtitle: item.n.connected ? Tr.t("Connected")
                    : item.n.stateChanging ? Tr.t("Connecting…")
                    : root.failed === item.n.name ? Tr.t("Couldn't connect")
                    : item.n.known ? Tr.t("Saved")
                    : root.secured(item.n) ? Tr.t("Secured") : Tr.t("Open##f")
                active: item.n.connected
                busy: item.n.stateChanging
                onClicked: root.tap(item.n)

                MIcon {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: root.secured(item.n) && !row.hovered
                    icon: "lock"
                    size: 14
                    color: Theme.dim
                }
                MenuButton {
                    visible: item.n.connected && row.hovered
                    icon: "link_off"
                    onClicked: item.n.disconnect()
                }
                MenuButton {
                    visible: item.n.known && row.hovered
                    icon: "delete"
                    onClicked: item.n.forget()
                }
            }

            Connections {
                target: item.n
                function onConnectionFailed(reason) {
                    root.failed = item.n.name;
                    if (reason === ConnectionFailReason.NoSecrets)
                        WifiConnect.failed(item.n);
                }
            }
        }
    }

    MenuRow {
        visible: root.wifi !== null && Networking.wifiEnabled && !root.formOpen
        icon: "wifi_find"
        title: Tr.t("Hidden network…")
        subtitle: Tr.t("Connect by name")
        onClicked: WifiConnect.begin(null)
    }

    Rectangle {
        visible: !root.embedded
        Layout.fillWidth: true
        Layout.topMargin: 4
        implicitHeight: 1
        color: Theme.surfaceBorder
    }

    MenuRow {
        visible: !root.embedded
        icon: "settings"
        title: Tr.t("Network settings…")
        onClicked: {
            BarMenu.open = "";
            SettingsApp.show("network");
        }
    }
}
