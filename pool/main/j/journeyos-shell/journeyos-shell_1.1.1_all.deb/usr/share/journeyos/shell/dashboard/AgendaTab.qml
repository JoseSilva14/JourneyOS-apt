import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services
import qs.desktop.widgets

// Agenda tab: the month with dots on days with events and, beside it, the chosen day's events;
// below, add an event to that day (kept only on this computer). Internet calendars
// are added in Settings → Calendars.
RowLayout {
    id: root

    spacing: Theme.gap

    readonly property date day: Agenda.focusDay
    readonly property var dayEvents: Agenda.eventsOn(day)

    Component.onCompleted: Agenda.refresh()

    CalendarWidget {
        Layout.fillHeight: true
        Layout.preferredWidth: height
        color: Theme.surfaceCard
        border.color: Theme.surfaceBorder
        selectable: true
        selected: root.day
        onPicked: day => Agenda.focusDay = day
    }

    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true

        ColumnLayout {
            anchors.fill: parent
            spacing: 10

            RowLayout {
                Layout.fillWidth: true

                Text {
                    Layout.fillWidth: true
                    text: {
                        const today = new Date();
                        const d = Tr.locale.toString(root.day, Tr.t("dddd, d MMMM"));
                        const label = d.charAt(0).toUpperCase() + d.slice(1);
                        return root.day.toDateString() === today.toDateString() ? Tr.t("Today · ") + label : label;
                    }
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontMedium
                    font.weight: Font.Bold
                }
                MIcon {
                    visible: Agenda.loading
                    icon: "sync"
                    size: 16
                    color: Theme.dim
                }
            }

            // Events of the day
            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 6
                model: root.dayEvents
                boundsBehavior: Flickable.StopAtBounds

                delegate: Rectangle {
                    id: event
                    required property var modelData
                    width: list.width
                    height: 48
                    radius: Theme.radius
                    color: Theme.button

                    Rectangle {
                        x: 8
                        anchors.verticalCenter: parent.verticalCenter
                        width: 4
                        height: parent.height - 16
                        radius: 2
                        color: event.modelData.color || Theme.accent
                    }

                    ColumnLayout {
                        anchors.left: parent.left
                        anchors.right: remove.left
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.leftMargin: 20
                        anchors.rightMargin: 8
                        spacing: 1

                        Text {
                            Layout.fillWidth: true
                            text: event.modelData.title
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: Font.DemiBold
                        }
                        Text {
                            Layout.fillWidth: true
                            text: Agenda.timeText(event.modelData)
                                + (event.modelData.location ? " · " + event.modelData.location : "")
                                + (event.modelData.source ? " · " + event.modelData.source : "")
                            elide: Text.ElideRight
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                    }

                    // Only local ones can be deleted here (the others belong to the source calendar)
                    Rectangle {
                        id: remove
                        visible: event.modelData.local === true
                        anchors.right: parent.right
                        anchors.rightMargin: 8
                        anchors.verticalCenter: parent.verticalCenter
                        width: visible ? 28 : 0
                        height: 28
                        radius: 14
                        color: removeMouse.containsMouse ? Theme.buttonHover : "transparent"

                        MIcon {
                            anchors.centerIn: parent
                            icon: "delete"
                            size: 16
                            color: Theme.subtext
                        }
                        MouseArea {
                            id: removeMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Agenda.remove(event.modelData.id)
                        }
                    }
                }

                Text {
                    anchors.centerIn: parent
                    visible: list.count === 0
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    text: Config.options.calendar.sources.length === 0
                        ? Tr.t("Nothing on this day.\nAdd your calendars in Settings → Calendars.")
                        : Tr.t("Nothing on this day.")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }

            // New event on this day
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                TextField {
                    id: titleField
                    Layout.fillWidth: true
                    implicitWidth: 100
                    placeholder: Tr.t("New event")
                    acceptOnBlur: false
                    onAccepted: root.add()
                }
                TextField {
                    id: fromField
                    visible: !allDay.checked
                    implicitWidth: 70
                    placeholder: "10:00"
                    acceptOnBlur: false
                    onAccepted: root.add()
                }
                TextField {
                    id: toField
                    visible: !allDay.checked
                    implicitWidth: 70
                    placeholder: "11:00"
                    acceptOnBlur: false
                    onAccepted: root.add()
                }
                Text {
                    text: Tr.t("All day")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Toggle {
                    id: allDay
                    onToggled: on => checked = on
                }
                Rectangle {
                    implicitWidth: 36
                    implicitHeight: 36
                    radius: 18
                    color: Theme.accent
                    opacity: titleField.text.trim() ? 1 : 0.4

                    MIcon {
                        anchors.centerIn: parent
                        icon: "add"
                        size: 20
                        color: Theme.accentText
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.add()
                    }
                }
            }
        }
    }

    // "10", "10:30" or "1030" → minutes; invalid → -1
    function minutes(text, fallback) {
        const m = /^(\d{1,2})(?::?(\d{2}))?$/.exec(text.trim() || fallback);
        if (!m || Number(m[1]) > 23 || Number(m[2] ?? 0) > 59)
            return -1;
        return Number(m[1]) * 60 + Number(m[2] ?? 0);
    }

    function add() {
        const name = titleField.text.trim();
        if (!name)
            return;
        const d = root.day;
        if (allDay.checked) {
            Agenda.add(name, new Date(d.getFullYear(), d.getMonth(), d.getDate()),
                new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1), true);
        } else {
            const a = minutes(fromField.text, fromField.placeholder);
            let b = minutes(toField.text, "");
            if (a < 0)
                return;
            if (b < 0 || b <= a)
                b = a + 60;
            Agenda.add(name, new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, a),
                new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, b), false);
        }
        titleField.text = "";
        fromField.text = "";
        toField.text = "";
    }
}
