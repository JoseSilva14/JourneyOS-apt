import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Dev tab (only with UI Dev on): busy ports and Docker containers, read every 3 s
// while the tab is open. Hovering a row shows the actions: open in the
// browser, copy the address and kill the process (second click) for ports; start/stop,
// restart, logs, terminal and open for containers.
RowLayout {
    id: root

    signal closeRequested

    spacing: Theme.gap

    property string confirmKill: ""

    Timer {
        running: true
        interval: 3000
        repeat: true
        triggeredOnStart: true
        onTriggered: Dev.refresh()
    }

    // --- Ports ---
    Tile {
        Layout.preferredWidth: 4
        Layout.fillWidth: true
        Layout.fillHeight: true

        ColumnLayout {
            anchors.fill: parent
            spacing: 8

            Header {
                glyph: "lan"
                title: Tr.t("Ports in use")
                detail: Dev.loaded ? Dev.ports.length + "" : ""
            }

            ListView {
                id: portList
                Layout.fillWidth: true
                Layout.fillHeight: true
                // Empty: hidden, otherwise it took half the card and pushed "No ports listening" off centre
                visible: Dev.ports.length > 0
                clip: true
                spacing: 2
                boundsBehavior: Flickable.StopAtBounds
                model: Dev.ports

                delegate: Row_ {
                    id: portRow
                    required property var modelData
                    readonly property var p: modelData
                    readonly property string key: p.proto + p.port
                    width: portList.width

                    Text {
                        Layout.preferredWidth: 58
                        text: portRow.p.port
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontMedium
                        font.weight: Font.Bold
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0

                        Text {
                            Layout.fillWidth: true
                            text: portRow.p.container || portRow.p.process || portRow.p.service || "sistema"
                            elide: Text.ElideRight
                            color: portRow.p.process || portRow.p.container ? Theme.text : Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            font.weight: Font.DemiBold
                        }
                        Text {
                            Layout.fillWidth: true
                            text: (portRow.p.container ? Tr.t("container · ") : "") + portRow.p.proto + " · " + (portRow.p.scope === "rede" ? Tr.t("open to the network") : Tr.t("local only"))
                                + (portRow.p.process && portRow.p.service ? " · " + portRow.p.service : "")
                                + (portRow.p.pid ? Tr.t(" · pid ") + portRow.p.pid : "")
                            elide: Text.ElideRight
                            color: Theme.dim
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall - 1
                        }
                    }
                    Action_ {
                        visible: portRow.hovered && portRow.p.proto === "tcp"
                        glyph: "open_in_new"
                        tip: Tr.t("Open in browser")
                        onClicked: {
                            Dev.openUrl("http://localhost:" + portRow.p.port);
                            root.closeRequested();
                        }
                    }
                    Action_ {
                        visible: portRow.hovered
                        glyph: "content_copy"
                        onClicked: Dev.copy("localhost:" + portRow.p.port)
                    }
                    Action_ {
                        visible: portRow.hovered && portRow.p.pid > 0 && !portRow.p.container
                        glyph: root.confirmKill === portRow.key ? "dangerous" : "stop_circle"
                        danger: root.confirmKill === portRow.key
                        onClicked: {
                            if (root.confirmKill === portRow.key) {
                                root.confirmKill = "";
                                Dev.kill(portRow.p);
                            } else {
                                root.confirmKill = portRow.key;
                            }
                        }
                    }
                    onHoveredChanged: if (!hovered && root.confirmKill === key) root.confirmKill = ""
                }
            }

            Empty {
                visible: Dev.loaded && Dev.ports.length === 0
                glyph: "lan"
                title: Tr.t("No ports listening")
            }
        }
    }

    // --- Containers ---
    Tile {
        Layout.preferredWidth: 6
        Layout.fillWidth: true
        Layout.fillHeight: true

        ColumnLayout {
            anchors.fill: parent
            spacing: 8

            Header {
                glyph: "view_in_ar"
                title: Tr.t("Docker containers")
                detail: Dev.dockerState === "ok" && Dev.containers.length
                    ? Dev.running + Tr.t(" running · ") + (Dev.containers.length - Dev.running) + Tr.t(" stopped") : ""
            }

            ListView {
                id: containerList
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: Dev.dockerState === "ok" && Dev.containers.length > 0
                clip: true
                spacing: 2
                boundsBehavior: Flickable.StopAtBounds
                model: Dev.containers

                delegate: Row_ {
                    id: cRow
                    required property var modelData
                    readonly property var c: modelData
                    readonly property bool on: c.state === "running"
                    readonly property bool working: !!Dev.pending[c.id]
                    width: containerList.width

                    Rectangle {
                        implicitWidth: 9
                        implicitHeight: 9
                        radius: 5
                        color: cRow.c.state === "running" ? "#3ecf8e"
                            : cRow.c.state === "restarting" || cRow.c.state === "paused" ? "#f5a524"
                            : Theme.faint
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0

                        RowLayout {
                            id: nameRow
                            Layout.fillWidth: true
                            spacing: 6

                            Text {
                                Layout.maximumWidth: nameRow.width - (projectChip.visible ? projectChip.implicitWidth + 6 : 0)
                                text: cRow.c.name
                                elide: Text.ElideRight
                                color: cRow.on ? Theme.text : Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                                font.weight: Font.DemiBold
                            }
                            Rectangle {
                                id: projectChip
                                visible: cRow.c.project !== ""
                                implicitWidth: projectText.implicitWidth + 12
                                implicitHeight: 16
                                radius: 8
                                color: Theme.button

                                Text {
                                    id: projectText
                                    anchors.centerIn: parent
                                    text: cRow.c.project
                                    color: Theme.subtext
                                    font.family: Theme.font
                                    font.pixelSize: Theme.fontSmall - 2
                                }
                            }
                            Item { Layout.fillWidth: true }
                        }
                        Text {
                            Layout.fillWidth: true
                            text: [cRow.working ? Tr.t("working…") : cRow.c.status, cRow.c.image,
                                cRow.c.ports.length ? cRow.c.ports.map(p => ":" + p).join(" ") : ""].filter(t => t).join(" · ")
                            elide: Text.ElideRight
                            color: Theme.dim
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall - 1
                        }
                    }
                    Action_ {
                        visible: cRow.hovered && cRow.c.url !== "" && cRow.on
                        glyph: "open_in_new"
                        onClicked: {
                            Dev.openUrl(cRow.c.url);
                            root.closeRequested();
                        }
                    }
                    Action_ {
                        visible: cRow.hovered && cRow.on
                        glyph: "article"
                        onClicked: {
                            Dev.logs(cRow.c);
                            root.closeRequested();
                        }
                    }
                    Action_ {
                        visible: cRow.hovered && cRow.on
                        glyph: "terminal"
                        onClicked: {
                            Dev.shell(cRow.c);
                            root.closeRequested();
                        }
                    }
                    Action_ {
                        visible: cRow.hovered && cRow.on
                        glyph: "restart_alt"
                        enabled: !cRow.working
                        onClicked: Dev.container("restart", cRow.c)
                    }
                    Action_ {
                        visible: cRow.hovered || cRow.working
                        glyph: cRow.working ? "hourglass_top" : cRow.on ? "stop" : "play_arrow"
                        enabled: !cRow.working
                        accent: !cRow.on && !cRow.working
                        onClicked: Dev.container(cRow.on ? "stop" : "start", cRow.c)
                    }
                }
            }

            // No Docker, no access, stopped or no containers
            Empty {
                visible: Dev.loaded && !containerList.visible
                glyph: Dev.dockerState === "ok" ? "view_in_ar" : "warning"
                title: Dev.dockerState === "missing" ? Tr.t("Docker isn't installed")
                    : Dev.dockerState === "permission" ? Tr.t("No access to Docker")
                    : Dev.dockerState === "down" ? Tr.t("The Docker service is stopped")
                    : Tr.t("No containers")
                text: Dev.dockerState === "missing" ? Tr.t("Install it to see containers here:")
                    : Dev.dockerState === "permission" ? Tr.t("Add your account to the docker group and log in again:")
                    : Dev.dockerState === "down" ? Tr.t("Start it with:")
                    : Tr.t("Containers you create (docker run, docker compose up) show up here.")
                command: Dev.dockerState === "missing" ? "sudo apt install docker.io"
                    : Dev.dockerState === "permission" ? "sudo usermod -aG docker $USER"
                    : Dev.dockerState === "down" ? "sudo systemctl start docker"
                    : ""
            }
        }
    }

    // Card title with a number on the right
    component Header: RowLayout {
        property string glyph: ""
        property string title: ""
        property string detail: ""
        Layout.fillWidth: true
        spacing: 6

        MIcon {
            icon: parent.glyph
            size: 15
            color: Theme.subtext
        }
        Text {
            Layout.fillWidth: true
            text: parent.title
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
        Text {
            text: parent.detail
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    // List row, highlighted on hover (no transition, as in the launcher)
    component Row_: Rectangle {
        id: rowItem
        default property alias content: rowLayout.data
        readonly property bool hovered: rowHover.hovered
        implicitHeight: 44
        radius: Theme.radiusSmall + 2
        color: hovered ? Theme.buttonHover : "transparent"

        HoverHandler {
            id: rowHover
        }
        RowLayout {
            id: rowLayout
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 6
            spacing: 8
        }
    }

    component Action_: Rectangle {
        id: action
        property string glyph: ""
        property string tip: ""
        property bool danger: false
        property bool accent: false
        signal clicked
        implicitWidth: 28
        implicitHeight: 28
        radius: 14
        opacity: enabled ? 1 : 0.5
        color: danger ? "#e5484d" : accent ? Theme.accent : actionMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
        border.width: danger || accent ? 0 : 1
        border.color: Theme.surfaceBorder
        scale: actionMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: action.glyph
            size: 15
            color: action.danger ? "#ffffff" : action.accent ? Theme.accentText : Theme.subtext
        }
        MouseArea {
            id: actionMouse
            anchors.fill: parent
            enabled: action.enabled
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: action.clicked()
        }
    }

    // Empty state, with a command to copy
    component Empty: ColumnLayout {
        id: empty
        property string glyph: ""
        property string title: ""
        property string text: ""
        property string command: ""
        Layout.fillWidth: true
        Layout.fillHeight: true
        spacing: 8

        Item { Layout.fillHeight: true }
        MIcon {
            Layout.alignment: Qt.AlignHCenter
            icon: empty.glyph
            size: 34
            color: Theme.dim
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: empty.title
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.DemiBold
        }
        Text {
            Layout.fillWidth: true
            visible: empty.text !== ""
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: empty.text
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
        // The command: clicking copies
        Rectangle {
            Layout.alignment: Qt.AlignHCenter
            visible: empty.command !== ""
            implicitWidth: cmdRow.implicitWidth + 28
            implicitHeight: 32
            radius: 16
            color: cmdMouse.containsMouse ? Theme.buttonHover : Theme.button

            Row {
                id: cmdRow
                anchors.centerIn: parent
                spacing: 8
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: empty.command
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                MIcon {
                    anchors.verticalCenter: parent.verticalCenter
                    icon: "content_copy"
                    size: 14
                    color: Theme.subtext
                }
            }
            MouseArea {
                id: cmdMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Dev.copy(empty.command)
            }
        }
        Item { Layout.fillHeight: true }
    }
}
