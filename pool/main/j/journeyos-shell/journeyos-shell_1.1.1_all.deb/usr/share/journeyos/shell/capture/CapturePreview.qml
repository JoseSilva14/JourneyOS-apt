import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Thumbnail of the last capture in the bottom-right corner (on the active screen): clicking opens it,
// the buttons open the folder, copy again or move it to the trash. Disappears after 6 s, except
// with the mouse over it. The capture has already been saved and copied.
PanelWindow {
    id: root

    readonly property bool open: Capture.previewOpen
    // Keeps the last one until the exit animation finishes
    property string shown: ""

    screen: Windows.activeScreen
    anchors {
        bottom: true
        right: true
    }
    margins {
        bottom: Theme.gap
        right: Theme.gap
    }
    exclusionMode: ExclusionMode.Ignore
    implicitWidth: 300
    implicitHeight: card.implicitHeight + 8
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-capture-preview"
    WlrLayershell.layer: WlrLayer.Overlay

    onOpenChanged: {
        if (open) {
            shown = Capture.last;
            hide.restart();
        } else {
            closing.restart();
        }
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    Timer {
        id: hide
        interval: 6000
        onTriggered: {
            if (hover.hovered)
                restart();
            else
                Capture.previewOpen = false;
        }
    }

    HoverHandler {
        id: hover
    }

    Rectangle {
        id: card
        width: parent.width
        implicitHeight: column.implicitHeight + 20
        radius: Theme.radiusCard
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        opacity: root.open ? 1 : 0
        y: root.open ? 0 : 16

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
        Behavior on y {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        ColumnLayout {
            id: column
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Thumbnail {
                Layout.fillWidth: true
                Layout.preferredHeight: 160
                source: root.shown ? "file://" + root.shown : ""
                background: Theme.surface

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        Capture.open(root.shown);
                        Capture.previewOpen = false;
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                Text {
                    Layout.fillWidth: true
                    text: Tr.t("Copied and saved")
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Action {
                    glyph: "folder_open"
                    onClicked: {
                        Capture.showInFolder(root.shown);
                        Capture.previewOpen = false;
                    }
                }
                Action {
                    glyph: "content_copy"
                    onClicked: {
                        Capture.copy(root.shown);
                        Events.push({ icon: "content_copy", title: Tr.t("Screenshot copied"), text: "", duration: 1500 });
                    }
                }
                Action {
                    glyph: "delete"
                    onClicked: Capture.remove(root.shown)
                }
                Action {
                    glyph: "close"
                    onClicked: Capture.previewOpen = false
                }
            }
        }
    }

    component Action: Rectangle {
        id: action
        property string glyph: ""
        signal clicked

        implicitWidth: 30
        implicitHeight: 30
        radius: 15
        color: actionMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: actionMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: action.glyph
            size: 16
        }
        MouseArea {
            id: actionMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: action.clicked()
        }
    }
}
