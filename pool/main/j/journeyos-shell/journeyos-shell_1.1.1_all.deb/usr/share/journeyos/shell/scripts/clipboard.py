#!/usr/bin/env python3
"""Clipboard history (text only) in ~/.local/state/shadow-kde/clipboard.json.

  clipboard.py watch          watches (wl-paste --watch … add); runs while the shell runs
  clipboard.py add            adds the text from stdin (called by wl-paste)
  clipboard.py pin|unpin <id>
  clipboard.py delete <id>
  clipboard.py clear          deletes everything except the pinned ones

Does not save what password managers mark (x-kde-passwordManagerHint), nor empty text
or text over 100 KB. Keeps the 100 most recent and the pinned ones.
"""

import fcntl
import json
import os
import subprocess
import sys
import time

PATH = os.path.expanduser("~/.local/state/shadow-kde/clipboard.json")
LIMIT = 100
MAX_BYTES = 100_000


def load():
    try:
        with open(PATH, encoding="utf-8") as fh:
            return json.load(fh).get("items", [])
    except (OSError, ValueError):
        return []


def save(items):
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    tmp = PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"items": items}, fh, ensure_ascii=False)
    os.replace(tmp, PATH)


def locked(fn):
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with open(PATH + ".lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return fn()


def add():
    data = sys.stdin.buffer.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        return 0
    text = data.decode("utf-8", errors="replace")
    if not text.strip():
        return 0
    types = subprocess.run(["wl-paste", "--list-types"], capture_output=True, text=True).stdout
    if "x-kde-passwordManagerHint" in types:
        return 0

    def do():
        items = [i for i in load() if i["text"] != text]
        pinned = any(i.get("pinned") for i in load() if i["text"] == text)
        items.insert(0, {"id": str(time.time_ns()), "text": text, "pinned": pinned, "time": int(time.time() * 1000)})
        keep, count = [], 0
        for i in items:
            if i.get("pinned"):
                keep.append(i)
            elif count < LIMIT:
                keep.append(i)
                count += 1
        save(keep)
    locked(do)
    return 0


def change(item_id, fn):
    def do():
        items = load()
        save([x for x in (fn(i) if i["id"] == item_id else i for i in items) if x is not None])
    locked(do)
    return 0


def main():
    cmd = sys.argv[1:2]
    arg = sys.argv[2] if len(sys.argv) > 2 else ""
    if cmd == ["watch"]:
        # A shell reload starts another watcher: stop the previous one (if it is still one of ours)
        pidfile = os.path.join(os.path.dirname(PATH), "clipboard-watch.pid")
        try:
            old = int(open(pidfile).read())
            with open(f"/proc/{old}/cmdline", "rb") as fh:
                cmdline = fh.read()
            if b"wl-paste" in cmdline and b"clipboard.py" in cmdline:
                os.kill(old, 15)
        except (OSError, ValueError):
            pass
        os.makedirs(os.path.dirname(pidfile), exist_ok=True)
        with open(pidfile, "w") as fh:
            fh.write(str(os.getpid()))
        # exec keeps the PID (the one in the file becomes wl-paste's)
        os.execvp("wl-paste", ["wl-paste", "--type", "text", "--watch", os.path.abspath(__file__), "add"])
    if cmd == ["add"]:
        return add()
    if cmd == ["pin"] and arg:
        return change(arg, lambda i: {**i, "pinned": True})
    if cmd == ["unpin"] and arg:
        return change(arg, lambda i: {**i, "pinned": False})
    if cmd == ["delete"] and arg:
        return change(arg, lambda i: None)
    if cmd == ["clear"]:
        locked(lambda: save([i for i in load() if i.get("pinned")]))
        return 0
    print(__doc__, file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
