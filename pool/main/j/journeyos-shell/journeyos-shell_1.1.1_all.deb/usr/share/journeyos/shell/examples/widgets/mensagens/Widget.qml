import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Receives data from outside: another app or a script sends to a channel
//   scripts/widget-send.sh status '{"title":"Build","text":"Compiling…","icon":"build","progress":0.4}'
// and the widget shows the title, the text, the icon and a bar (progress from 0 to 1). Plain text
// works too. On start it shows the last message on that channel.
Card {
    id: root

    property var options: ({})
    readonly property string channel: options.alvo || "status"

    width: 320
    height: column.implicitHeight + Theme.cardPadding * 2

    // (not "data": it is a property of every Item)
    property var payload: Widgets.lastMessage(channel)
    readonly property var msg: typeof payload === "object" && payload !== null ? payload : { text: payload ?? "" }

    Connections {
        target: Widgets
        function onMessage(target, value) {
            if (target === root.channel)
                root.payload = value;
        }
    }
    onChannelChanged: payload = Widgets.lastMessage(channel)

    ColumnLayout {
        id: column
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: Theme.cardPadding
        spacing: 8

        RowLayout {
            spacing: 10
            MIcon {
                icon: root.msg.icon || "inbox"
                size: 22
            }
            Text {
                Layout.fillWidth: true
                text: root.msg.title || root.channel
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
        }

        Text {
            Layout.fillWidth: true
            text: root.msg.text || (root.payload === undefined ? "Waiting for messages on channel \"" + root.channel + "\"." : "")
            visible: text !== ""
            wrapMode: Text.Wrap
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall + 1
        }

        // Progress bar (only with "progress")
        Rectangle {
            Layout.fillWidth: true
            visible: typeof root.msg.progress === "number"
            implicitHeight: 6
            radius: 3
            color: Theme.button

            Rectangle {
                width: parent.width * Math.max(0, Math.min(1, root.msg.progress ?? 0))
                height: parent.height
                radius: parent.radius
                color: Theme.accent
                Behavior on width {
                    NumberAnimation { duration: Theme.animNormal }
                }
            }
        }
    }
}
