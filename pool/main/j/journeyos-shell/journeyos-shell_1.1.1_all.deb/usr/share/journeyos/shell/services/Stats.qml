pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// CPU, memory, GPU, disk and network usage, read from /proc and /sys
// every 2 s (disk every 30), with the last 60 readings for the graphs.
Singleton {
    id: root

    // Every 2 s with the dashboard open (where the graphs are); every 6 the rest of the
    // time: each reading redraws the Resources widget and, with the software renderer, the
    // whole desktop (~50 ms). Measured idle: 3.1 % of a core at 2 s, ~1 % at 6 s.
    readonly property int interval: Dashboard.open ? 2000 : 6000
    readonly property int historySize: 60

    property real cpu: 0            // 0–1
    property real ram: 0
    property real gpu: 0
    property bool hasGpu: false
    property real ramUsedGiB: 0
    property real ramTotalGiB: 0
    property real swap: 0
    property real disk: 0
    property real diskUsedGiB: 0
    property real diskTotalGiB: 0
    property real netDown: 0        // bytes/s
    property real netUp: 0
    property int uptime: 0          // seconds

    property var cpuHistory: []
    property var ramHistory: []
    property var downHistory: []
    property var upHistory: []

    property var lastCpu: null
    property var lastNet: null

    // Read without spawning processes (every 2 s, that weighed on the idle shell):
    // /proc/stat (1st line), meminfo, net/dev and uptime via FileView; the GPU via
    // sysfs (AMD/Intel) or, only if present, via nvidia-smi; the disk (df) every 30 s.
    property string gpuPath: ""
    property bool nvidia: false

    function push(arr, v) {
        const out = arr.length >= historySize ? arr.slice(1) : arr.slice();
        out.push(v);
        return out;
    }

    // One or more lines read; withMem: the lines are the memory (to compute RAM)
    function parse(text, withMem) {
        const mem = {};
        for (const line of text.trim().split("\n")) {
            const f = line.trim().split(/\s+/);
            if (f[0] === "cpu") {
                const v = f.slice(1).map(Number);
                const idle = v[3] + (v[4] || 0);
                const total = v.reduce((a, b) => a + b, 0);
                if (lastCpu) {
                    const dt = total - lastCpu.total;
                    if (dt > 0)
                        cpu = Math.max(0, Math.min(1, 1 - (idle - lastCpu.idle) / dt));
                }
                lastCpu = { idle, total };
            } else if (f[0].endsWith(":")) {
                mem[f[0].slice(0, -1)] = Number(f[1]);
            } else if (f[0] === "gpu") {
                hasGpu = f[1] !== "-";
                gpu = hasGpu ? Math.max(0, Math.min(1, Number(f[1]) / 100)) : 0;
            } else if (f[0] === "disk") {
                const size = Number(f[1]), used = Number(f[2]);
                if (size > 0) {
                    disk = used / size;
                    diskTotalGiB = size / 1073741824;
                    diskUsedGiB = used / 1073741824;
                }
            } else if (f[0] === "net") {
                const rx = Number(f[1]), tx = Number(f[2]), t = Date.now();
                if (lastNet) {
                    const dt = (t - lastNet.t) / 1000;
                    if (dt > 0) {
                        netDown = Math.max(0, (rx - lastNet.rx) / dt);
                        netUp = Math.max(0, (tx - lastNet.tx) / dt);
                    }
                }
                lastNet = { rx, tx, t };
            } else if (f[0] === "uptime") {
                uptime = Math.floor(Number(f[1]));
            }
        }
        if (!withMem)
            return;
        if (mem.MemTotal > 0) {
            ram = 1 - mem.MemAvailable / mem.MemTotal;
            ramTotalGiB = mem.MemTotal / 1048576;
            ramUsedGiB = (mem.MemTotal - mem.MemAvailable) / 1048576;
        }
        swap = mem.SwapTotal > 0 ? 1 - mem.SwapFree / mem.SwapTotal : 0;
    }

    // "1,2 MB/s"
    function rate(bytes) {
        const units = ["B/s", "KB/s", "MB/s", "GB/s"];
        let i = 0, v = bytes;
        while (v >= 1000 && i < units.length - 1) {
            v /= 1000;
            i++;
        }
        return v.toLocaleString(Tr.locale, "f", i === 0 || v >= 100 ? 0 : 1) + " " + units[i];
    }

    // "3 d 4 h", "2 h 15 min", "12 min"
    function duration(s) {
        const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
        if (d > 0) return d + Tr.t(" d ") + h + Tr.t(" h");
        if (h > 0) return h + Tr.t(" h ") + m + Tr.t(" min");
        return m + Tr.t(" min");
    }

    function finish() {
        cpuHistory = push(cpuHistory, cpu);
        ramHistory = push(ramHistory, ram);
        downHistory = push(downHistory, netDown);
        upHistory = push(upHistory, netUp);
    }

    FileView {
        id: statFile
        path: "/proc/stat"
        printErrors: false
        onLoaded: root.parse(text().split("\n")[0])
    }
    FileView {
        id: memFile
        path: "/proc/meminfo"
        printErrors: false
        onLoaded: root.parse(text().split("\n").filter(l => /^(MemTotal|MemAvailable|SwapTotal|SwapFree):/.test(l)).join("\n"), true)
    }
    FileView {
        id: netFile
        path: "/proc/net/dev"
        printErrors: false
        onLoaded: {
            let rx = 0, tx = 0;
            for (const line of text().split("\n").slice(2)) {
                const f = line.trim().split(/[:\s]+/);
                if (f.length > 10 && f[0] !== "lo") {
                    rx += Number(f[1]);
                    tx += Number(f[9]);
                }
            }
            root.parse("net " + rx + " " + tx);
        }
    }
    FileView {
        id: uptimeFile
        path: "/proc/uptime"
        printErrors: false
        onLoaded: root.parse("uptime " + text().split(" ")[0])
    }
    FileView {
        id: gpuFile
        path: root.gpuPath
        printErrors: false
        onLoaded: root.parse("gpu " + text().trim())
    }

    // The GPU: look once for where to read
    Component.onCompleted: Run.cmd(["sh", "-c", "for f in /sys/class/drm/card*/device/gpu_busy_percent; do [ -r \"$f\" ] && echo \"$f\" && exit; done; command -v nvidia-smi >/dev/null && echo nvidia"],
        (code, out) => {
            const r = out.trim();
            if (r === "nvidia")
                root.nvidia = true;
            else if (r)
                root.gpuPath = r;
            else
                root.parse("gpu -");
        })

    Timer {
        interval: root.interval
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            statFile.reload();
            memFile.reload();
            netFile.reload();
            uptimeFile.reload();
            if (root.gpuPath)
                gpuFile.reload();
            else if (root.nvidia)
                Run.cmd(["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                    (code, out) => root.parse("gpu " + (code === 0 ? out.trim().split("\n")[0] : "-")));
            // Once per reading: the history moves at the same pace as before
            Qt.callLater(root.finish);
        }
    }

    // The disk changes slowly
    Timer {
        interval: 30000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: Run.cmd(["df", "-B1", "--output=size,used", "/"], (code, out) => {
            if (code === 0)
                root.parse("disk " + out.trim().split("\n").pop());
        })
    }
}
