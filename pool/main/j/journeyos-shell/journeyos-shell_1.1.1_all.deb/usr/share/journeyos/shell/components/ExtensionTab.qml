import QtQuick
import QtQuick.Layouts
import qs
import qs.services

// A tab of an extension (widget folder with "places": notch/dashboard; see WIDGETS.md).
// Loads that place's QML filling the whole space and gives it, if declared: options, place,
// widgetDir and widgetId. If the QML has a done() signal, emitting it closes the pill/dashboard.
// On errors, shows them instead of staying blank.
Item {
    id: root

    property string type: ""
    property string place: "notch"
    signal closeRequested

    readonly property var info: Widgets.types[type]

    Loader {
        id: loader
        anchors.fill: parent
        source: Widgets.sourceFor(root.type, root.place)

        onLoaded: {
            if ("options" in item)
                item.options = Qt.binding(() => Widgets.tabOptions(root.place, root.type));
            if ("place" in item)
                item.place = root.place;
            if ("widgetDir" in item && root.info?.dir)
                item.widgetDir = root.info.dir;
            if ("widgetId" in item)
                item.widgetId = root.place + "-" + root.type.replace("/", "-");
            if (item.done)
                item.done.connect(root.closeRequested);
        }
    }

    // Error loading the QML
    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(parent.width - 32, 420)
        visible: loader.status === Loader.Error || !root.info || !!root.info.error
        spacing: 6

        MIcon {
            Layout.alignment: Qt.AlignHCenter
            icon: "extension_off"
            size: 30
            color: Theme.dim
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: !root.info ? Tr.t("This extension is no longer installed") : Tr.t("This tab has an error")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.DemiBold
        }
        Text {
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: Tr.t(root.info?.error ?? "")
                || (loader.status === Loader.Error ? Tr.t("The QML didn't load: check the shell log (scripts/widget-dev.sh shows it).") : "")
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
