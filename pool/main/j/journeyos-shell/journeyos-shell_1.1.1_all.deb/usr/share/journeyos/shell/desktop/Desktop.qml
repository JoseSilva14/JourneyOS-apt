import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Background of each screen: wallpaper and, on top, the widgets (while editing they move to the
// Editor, above the windows). Right click on the background opens a menu: edit widgets,
// change the wallpaper and the desktop settings.
PanelWindow {
    id: root

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: Theme.bg
    WlrLayershell.namespace: "shadow-desktop"
    WlrLayershell.layer: WlrLayer.Background

    Wallpaper {
        anchors.fill: parent
    }

    // Below the widgets: only catches clicks on the background (and on widgets that do not use them)
    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: m => {
            if (m.button === Qt.RightButton)
                menu.openAt(m.x, m.y);
            else
                menu.shown = false;
        }
    }

    WidgetLayer {
        anchors.fill: parent
        visible: !Widgets.editing
    }

    Rectangle {
        id: menu

        property bool shown: false

        function openAt(px, py) {
            x = Math.max(Theme.gap, Math.min(root.width - width - Theme.gap, px));
            y = Math.max(Theme.gap, Math.min(root.height - height - Theme.gap, py));
            shown = true;
        }

        function run(action) {
            shown = false;
            action();
        }

        visible: opacity > 0
        opacity: shown ? 1 : 0
        scale: shown ? 1 : 0.96
        transformOrigin: Item.TopLeft
        width: 300
        height: column.implicitHeight + 12
        radius: Theme.radius
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        Behavior on opacity {
            NumberAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast; easing.type: Easing.OutCubic }
        }

        // Closes when the mouse leaves the menu (windows on top keep the click from reaching here)
        HoverHandler {
            id: menuHover
        }
        Timer {
            running: menu.shown && !menuHover.hovered
            interval: 1500
            onTriggered: menu.shown = false
        }

        ColumnLayout {
            id: column
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 6
            spacing: 0

            MenuItem {
                icon: "widgets"
                text: Tr.t("Edit widgets")
                keys: Config.options.shortcuts.widgets
                onClicked: menu.run(() => Widgets.editing = true)
            }
            MenuItem {
                icon: "wallpaper"
                text: Tr.t("Change wallpaper")
                keys: Config.options.shortcuts.wallpapers
                onClicked: menu.run(() => Dashboard.toggle("wallpapers", root.screen))
            }
            MenuItem {
                icon: "shuffle"
                text: Tr.t("Random wallpaper")
                onClicked: menu.run(() => Wallpapers.random())
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.topMargin: 4
                Layout.bottomMargin: 4
                implicitHeight: 1
                color: Theme.surfaceBorder
            }

            MenuItem {
                icon: "tune"
                text: Tr.t("Desktop…")
                onClicked: menu.run(() => SettingsApp.show("desktop"))
            }
        }
    }

    component MenuItem: Rectangle {
        id: item

        property string icon: ""
        property string text: ""
        property string keys: ""
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 32
        radius: Theme.radiusSmall
        // No transition, as in menus
        color: itemMouse.containsMouse ? Theme.buttonHover : "transparent"

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            spacing: 10

            MIcon {
                icon: item.icon
                size: 16
                color: Theme.subtext
            }
            Text {
                Layout.fillWidth: true
                text: item.text
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
            Text {
                visible: item.keys !== ""
                text: item.keys
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        MouseArea {
            id: itemMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: item.clicked()
        }
    }
}
