import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Tabs: extension tabs (widget folders with "places" notch/dashboard; WIDGETS.md) in the pill and
// the dashboard. Enabling one appends it to the tabs; the manifest options sit below it.
Page {
    id: root

    readonly property var places: [
        { id: "notch", title: Tr.t("In the pill"), icon: "smart_button", empty: Tr.t("No extension has a tab for the pill.") },
        { id: "dashboard", title: Tr.t("In the dashboard"), icon: "space_dashboard", empty: Tr.t("No extension has a tab for the dashboard.") }
    ]

    Repeater {
        model: root.places

        ColumnLayout {
            id: placeColumn
            required property var modelData
            readonly property string place: modelData.id
            readonly property var available: Widgets.tabTypes(place)
            Layout.fillWidth: true
            spacing: 4

            SectionLabel { text: placeColumn.modelData.title }

            SettingRow {
                visible: placeColumn.available.length === 0
                title: placeColumn.modelData.empty
                description: Tr.t("Extensions are folders in ~/.local/share/shadow-kde/widgets with \"places\" in manifest.json. Install the examples (below) to see one.")
                icon: placeColumn.modelData.icon
            }

            Repeater {
                model: placeColumn.available

                ColumnLayout {
                    id: tabRow
                    required property string modelData
                    readonly property var info: Widgets.types[modelData]
                    readonly property bool on: Widgets.tabEnabled(placeColumn.place, modelData)
                    readonly property var values: Widgets.tabOptions(placeColumn.place, modelData)
                    Layout.fillWidth: true
                    spacing: 4

                    SettingRow {
                        title: tabRow.info?.name ?? tabRow.modelData
                        description: tabRow.info?.description || Tr.t("Extension ") + tabRow.modelData.slice(5)
                        icon: tabRow.info?.icon ?? "extension"
                        Toggle {
                            checked: tabRow.on
                            onToggled: on => Widgets.setTab(placeColumn.place, tabRow.modelData, on)
                        }
                    }

                    // Manifest options (each place has its own values)
                    Repeater {
                        model: tabRow.on ? (tabRow.info?.options ?? []) : []

                        SettingRow {
                            id: optionRow
                            required property var modelData
                            readonly property var value: tabRow.values[modelData.key]
                            Layout.leftMargin: 28
                            title: modelData.label
                            description: modelData.description

                            function set(v) { Widgets.setTabOption(placeColumn.place, tabRow.modelData, optionRow.modelData.key, v); }

                            Loader {
                                sourceComponent: optionRow.modelData.type === "bool" ? boolControl
                                    : optionRow.modelData.type === "choice" ? choiceControl
                                    : textControl
                            }
                            Component {
                                id: boolControl
                                Toggle {
                                    checked: optionRow.value === true
                                    onToggled: on => optionRow.set(on)
                                }
                            }
                            Component {
                                id: choiceControl
                                Select {
                                    options: optionRow.modelData.choices
                                    current: String(optionRow.value)
                                    onSelected: id => optionRow.set(id)
                                }
                            }
                            Component {
                                id: textControl
                                TextField {
                                    implicitWidth: 260
                                    text: String(optionRow.value ?? "")
                                    placeholder: String(optionRow.modelData.default ?? "")
                                    onAccepted: t => {
                                        if (optionRow.modelData.type !== "number") {
                                            optionRow.set(t);
                                            return;
                                        }
                                        let n = Number(t.replace(",", "."));
                                        if (isNaN(n))
                                            return;
                                        if (optionRow.modelData.min !== undefined)
                                            n = Math.max(optionRow.modelData.min, n);
                                        if (optionRow.modelData.max !== undefined)
                                            n = Math.min(optionRow.modelData.max, n);
                                        optionRow.set(n);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Your extensions") }

    ExtensionManager {}

    SettingRow {
        title: Tr.t("Make a tab")
        description: Tr.t("A tab is the same as a widget: a folder with a manifest.json and a QML file. With \"places\" in the manifest, it shows here for the pill and/or the dashboard. The guide explains everything.")
        icon: "menu_book"

        Row {
            spacing: 6
            PillButton {
                text: Tr.t("Open the guide")
                onClicked: Apps.run(["xdg-open", Quickshell.shellPath("TABS.md")])
            }
            PillButton {
                text: Tr.t("Open folder")
                onClicked: Run.cmd(["mkdir", "-p", Widgets.userDir], () => Apps.run(["xdg-open", Widgets.userDir]))
            }
        }
    }

    SettingRow {
        title: Tr.t("Rescan")
        description: Tr.t("After copying or changing an extension. The examples include four tabs: World clocks, Quick commands, Processes and Repositories.")
        icon: "refresh"

        Row {
            spacing: 6
            PillButton {
                text: Tr.t("Rescan")
                onClicked: Widgets.reload()
            }
            PillButton {
                text: Tr.t("Install the examples")
                onClicked: Run.cmd([Quickshell.shellPath("scripts/widgets.py"), "exemplos", Quickshell.shellPath("examples/widgets")], () => Widgets.reload())
            }
        }
    }

}
