#!/bin/sh
# Starts the shell. Without a GPU (llvmpipe/softpipe) it uses the software renderer:
# much lighter and without shader-based effects.
# SHADOW_RENDERER=gpu|software forces one of the two.
#
# If the configuration fails to load (an error in a QML file), starts the last one that loaded
# fine (~/.local/state/shadow-kde/last-good, saved by the shell itself) and warns.
dir=$(readlink -f "$(dirname "$(readlink -f "$0")")/..")
lastgood="$HOME/.local/state/shadow-kde/last-good"

mode=${SHADOW_RENDERER:-}
if [ -z "$mode" ]; then
    if eglinfo -B 2>/dev/null | grep -q -i -E 'renderer.*(llvmpipe|softpipe)'; then
        mode=software
    else
        mode=gpu
    fi
fi
[ "$mode" = software ] && export QT_QUICK_BACKEND=software

log="${XDG_RUNTIME_DIR:-/tmp}/shadow-kde-start.log"
: > "$log"
qs -p "$dir" >"$log" 2>&1 &
pid=$!
# The log still goes to the journal
tail -n +1 -f "$log" --pid=$pid &

# Up to 15 s to load
i=0
while [ $i -lt 60 ]; do
    if grep -q "Configuration Loaded" "$log"; then
        wait $pid
        exit $?
    fi
    if grep -q "Failed to load configuration" "$log"; then
        kill $pid 2>/dev/null
        if [ -f "$lastgood/shell.qml" ]; then
            echo "shadow-kde: the configuration has errors; starting with the last good one"
            # Notify after the shell (which is the notification server) has started
            (sleep 8; gdbus call --session --dest org.freedesktop.Notifications --object-path /org/freedesktop/Notifications \
                --method org.freedesktop.Notifications.Notify -- "Shell" 0 "dialog-warning" \
                "The shell started with the last good version" \
                "The configuration in $dir has errors. See the log: journalctl --user -u shadow-kde" '[]' '{}' 0 >/dev/null) &
            exec qs -p "$lastgood"
        fi
        exit 1
    fi
    sleep 0.25
    i=$((i + 1))
done
wait $pid
