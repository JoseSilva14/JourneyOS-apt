#!/usr/bin/env python3
"""Tiles the windows of the current screen and virtual desktop (KWin script).

Usage: tile.py metades|colunas|principal|grelha [gap in px]
  metades    (halves) two columns; with more windows, the others stack in the right one
  colunas    (columns) up to three columns side by side (the rest stack in the last one)
  principal  (main) the active one on the left (60 %), the others stacked on the right
  grelha     (grid) equal rows and columns

Only normal, non-minimised, resizable windows; the active one goes first.
The area is KWin's "MaximizeArea" (without the bar or the dock). KWin has no protocol for
this: a short script is run (like scripts/windows.py) and removed right after.
"""
import os
import sys
import tempfile
import time

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

LAYOUTS = ("metades", "colunas", "principal", "grelha")
NAME = "shadow-kde-tile"

JS = r"""
const layout = "%(layout)s";
const gap = %(gap)d;
const output = workspace.activeWindow ? workspace.activeWindow.output : workspace.activeScreen;
const desktop = workspace.currentDesktop;
const area = workspace.clientArea(KWin.MaximizeArea, output, desktop);

const wins = workspace.stackingOrder
    .filter(w => w.normalWindow && !w.minimized && !w.skipTaskbar && w.resizeable && !w.fullScreen
        && w.output === output && (w.onAllDesktops || w.desktops.includes(desktop)))
    .reverse();     // topmost first
const active = workspace.activeWindow;
if (active && wins.includes(active)) {
    wins.splice(wins.indexOf(active), 1);
    wins.unshift(active);
}

// Rectangles as fractions of the area: [x, y, width, height]
function stack(n, x, w) {
    const out = [];
    for (let i = 0; i < n; i++)
        out.push([x, i / n, w, 1 / n]);
    return out;
}
function cells(n) {
    if (n === 1)
        return [[0, 0, 1, 1]];
    if (layout === "metades")
        return [[0, 0, 0.5, 1]].concat(stack(n - 1, 0.5, 0.5));
    if (layout === "principal")
        return [[0, 0, 0.6, 1]].concat(stack(n - 1, 0.6, 0.4));
    if (layout === "colunas") {
        const cols = Math.min(n, 3);
        const out = [];
        for (let i = 0; i < cols - 1; i++)
            out.push([i / cols, 0, 1 / cols, 1]);
        return out.concat(stack(n - cols + 1, (cols - 1) / cols, 1 / cols));
    }
    // grid: columns = ⌈√n⌉; the last row stretches so there are no gaps
    const cols = Math.ceil(Math.sqrt(n));
    const rows = Math.ceil(n / cols);
    const out = [];
    for (let i = 0; i < n; i++) {
        const r = Math.floor(i / cols);
        const inRow = r === rows - 1 ? n - cols * (rows - 1) : cols;
        const c = i - r * cols;
        out.push([c / inRow, r / rows, 1 / inRow, 1 / rows]);
    }
    return out;
}

const rects = cells(wins.length);
wins.forEach((w, i) => {
    const [fx, fy, fw, fh] = rects[i];
    // Half the gap on each side between windows, the full gap at the edges
    const x = area.x + Math.round(fx * area.width) + (fx === 0 ? gap : gap / 2);
    const y = area.y + Math.round(fy * area.height) + (fy === 0 ? gap : gap / 2);
    const right = area.x + Math.round((fx + fw) * area.width) - (fx + fw >= 0.999 ? gap : gap / 2);
    const bottom = area.y + Math.round((fy + fh) * area.height) - (fy + fh >= 0.999 ? gap : gap / 2);
    w.setMaximize(false, false);
    w.frameGeometry = { x: x, y: y, width: right - x, height: bottom - y };
});
"""


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in LAYOUTS:
        print(__doc__)
        return 1
    gap = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def kwin(method, args, ret=None, path="/Scripting", iface="org.kde.kwin.Scripting"):
        res = conn.call_sync("org.kde.KWin", path, iface, method, args,
                             GLib.VariantType(ret) if ret else None,
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack() if res else None

    runtime = os.environ.get("XDG_RUNTIME_DIR", tempfile.gettempdir())
    path = os.path.join(runtime, NAME + ".js")
    with open(path + ".tmp", "w", encoding="utf-8") as fh:
        fh.write(JS % {"layout": sys.argv[1], "gap": max(0, min(gap, 64))})
    os.replace(path + ".tmp", path)

    kwin("unloadScript", GLib.Variant("(s)", (NAME,)), "(b)")
    sid = kwin("loadScript", GLib.Variant("(ss)", (path, NAME)), "(i)")[0]
    if sid < 0:
        print("KWin did not load the script", file=sys.stderr)
        return 1
    kwin("run", None, path=f"/Scripting/Script{sid}", iface="org.kde.kwin.Script")
    time.sleep(0.5)
    kwin("unloadScript", GLib.Variant("(s)", (NAME,)), "(b)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
