#!/bin/sh
# "Share on the local network" in the right-click menu of Dolphin (and others that use KIO).
# servicemenu.sh apply|remove
set -e
dir=$(cd "$(dirname "$0")/.." && pwd)
menus="${XDG_DATA_HOME:-$HOME/.local/share}/kio/servicemenus"
file="$menus/shadow-kde-share.desktop"

case "$1" in
apply)
    mkdir -p "$menus"
    tmp="$file.tmp"
    cat > "$tmp" <<DESKTOP
[Desktop Entry]
Type=Service
MimeType=all/allfiles;inode/directory;
Actions=share
X-KDE-Priority=TopLevel

[Desktop Action share]
Name=Partilhar na rede local
Icon=document-share
Exec=qs ipc -p "$dir" call share file %f
DESKTOP
    # KIO only accepts executable menus
    chmod +x "$tmp"
    mv "$tmp" "$file"
    ;;
remove)
    rm -f "$file"
    ;;
*)
    echo "usage: $0 apply|remove" >&2
    exit 2
    ;;
esac
