import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Snapshots (snapper on btrfs): automatic ones (hourly/daily and before/after every update), manual
// ones, deleting, and undoing an update (asks for authorization). services/Snapshots.
Page {
    id: root

    property string confirm: ""          // key of the entry waiting for a second click

    Component.onCompleted: {
        Snapshots.message = "";
        Snapshots.refresh();
    }

    function when(date) {
        // "2026-11-15 10:42:03" → local format
        const d = new Date(date.replace(" ", "T"));
        return isNaN(d) ? date : d.toLocaleString(Qt.locale(Tr.locale.name), Locale.ShortFormat);
    }

    // --- Status / create ---
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: 92
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        RowLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 14

            MIcon {
                icon: Snapshots.state === "ok" ? "history" : "history_toggle_off"
                size: 34
                color: Snapshots.state === "ok" ? Theme.accent : Theme.subtext
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text {
                    Layout.fillWidth: true
                    text: Snapshots.state === "ok" ? Snapshots.entries.length + Tr.t(" snapshots")
                        : Snapshots.state === "missing" ? Tr.t("Snapshots are not installed")
                        : Snapshots.state === "denied" ? Tr.t("Only administrators can see the snapshots")
                        : Snapshots.state === "noconfig" ? Tr.t("Snapshots are off")
                        : Tr.t("Checking…")
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    text: Snapshots.message ? Snapshots.message
                        : Snapshots.state === "ok" ? Tr.t("Automatic: every hour and before/after every update. Your files in /home are not included.")
                        : Snapshots.state === "noconfig" ? Tr.t("They need the system on btrfs (the installer's default). This system uses another file system.")
                        : Snapshots.state === "missing" ? "sudo apt install snapper" : ""
                    wrapMode: Text.Wrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
            PillButton {
                visible: Snapshots.state === "ok"
                text: Tr.t("Create now")
                accent: true
                enabled: !Snapshots.busy
                onClicked: Snapshots.create(Tr.t("Manual snapshot"))
            }
        }
    }

    SectionLabel {
        visible: Snapshots.entries.length > 0
        text: Tr.t("History")
    }

    Repeater {
        model: Snapshots.entries.slice(0, 60)

        Rectangle {
            id: row
            required property var modelData
            readonly property bool pair: modelData.kind === "pair"
            readonly property string key: pair ? "p" + modelData.post : "s" + modelData.number

            Layout.fillWidth: true
            implicitHeight: 52
            radius: Theme.radiusSmall + 2
            color: rowMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard

            MouseArea {
                id: rowMouse
                anchors.fill: parent
                hoverEnabled: true
                onExited: if (root.confirm === row.key) root.confirm = ""
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 14
                anchors.rightMargin: 10
                spacing: 12

                MIcon {
                    icon: row.pair ? "system_update" : row.modelData.cleanup === "timeline" ? "schedule"
                        : row.modelData.important ? "flag" : "bookmark"
                    size: 20
                    color: Theme.subtext
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Text {
                        Layout.fillWidth: true
                        text: row.pair ? Tr.t("System update") + (row.modelData.description && row.modelData.description !== "apt" ? " · " + row.modelData.description : "")
                            : row.modelData.cleanup === "timeline" ? Tr.t("Automatic")
                            : row.modelData.description || Tr.t("Snapshot")
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.fillWidth: true
                        text: root.when(row.modelData.date) + (row.pair ? "  ·  #" + row.modelData.pre + "–" + row.modelData.post : "  ·  #" + row.modelData.number)
                        elide: Text.ElideRight
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
                // Update: undo it (second click confirms)
                PillButton {
                    visible: row.pair
                    text: root.confirm === row.key ? Tr.t("Undo? Click again") : Tr.t("Undo update")
                    danger: root.confirm === row.key
                    enabled: !Snapshots.busy
                    onClicked: {
                        if (root.confirm === row.key) {
                            root.confirm = "";
                            Snapshots.undo(row.modelData.pre, row.modelData.post);
                        } else {
                            root.confirm = row.key;
                        }
                    }
                }
                // Delete (second click confirms)
                PillButton {
                    text: root.confirm === row.key + "d" ? Tr.t("Delete? Click again") : Tr.t("Delete")
                    danger: root.confirm === row.key + "d"
                    enabled: !Snapshots.busy
                    onClicked: {
                        if (root.confirm === row.key + "d") {
                            root.confirm = "";
                            Snapshots.remove(row.pair ? [row.modelData.pre, row.modelData.post] : [row.modelData.number]);
                        } else {
                            root.confirm = row.key + "d";
                        }
                    }
                }
            }
        }
    }
}
