#!/usr/bin/env python3
"""Tr.t("…") texts in the code without a Portuguese translation in i18n/pt.json (and unused ones).
i18n-check.py [--unused]   — exits with 1 if any translation is missing."""
import glob
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
RX = re.compile(r'Tr\.t\("((?:[^"\\\n]|\\.)*)"\)')


def unescape(s):
    return json.loads('"' + s + '"')


used = {}
for f in glob.glob(os.path.join(ROOT, "**", "*.qml"), recursive=True):
    rel = os.path.relpath(f, ROOT)
    for m in RX.finditer(open(f, encoding="utf-8").read()):
        used.setdefault(unescape(m.group(1)), rel)
d = json.load(open(os.path.join(ROOT, "i18n", "pt.json"), encoding="utf-8"))
missing = sorted(k for k in used if k not in d)
for k in missing:
    print(f"missing: {json.dumps(k, ensure_ascii=False)}  ({used[k]})")
if "--unused" in sys.argv:
    for k in sorted(set(d) - set(used)):
        print(f"unused: {json.dumps(k, ensure_ascii=False)}")
print(f"{len(used)} texts, {len(missing)} without translation")
sys.exit(1 if missing else 0)
