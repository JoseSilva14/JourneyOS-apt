pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Desktop widgets (config.json, widgets.items) and edit mode.
// Each one: { id, type, x, y, scale, style, options? }. x and y go from 0 to 1 in the free space of the
// screen (0 = against the left/top, 1 = right/bottom), so they work at any resolution.
// Besides the shell's, there are the user's: folders in ~/.local/share/shadow-kde/widgets/<id>/
// with manifest.json + Widget.qml (type "user/<id>"; see WIDGETS.md), and a message channel
// for other apps to send them data (IPC "widgets send <target> <json>").
// A folder can also provide tabs for the pill and the dashboard ("places" in the manifest): they go in
// widgets.notchTabs / widgets.dashboardTabs ([{ type, options }]) and are enabled in Settings → Tabs.
Singleton {
    id: root

    property bool editing: false

    readonly property var items: Config.options.widgets.items
    readonly property string userDir: Quickshell.env("HOME") + "/.local/share/shadow-kde/widgets"

    readonly property var builtin: ({
        clock: { name: Tr.t("Clock"), icon: "schedule", source: "widgets/ClockWidget.qml" },
        resources: { name: Tr.t("Resources"), icon: "memory", source: "widgets/ResourcesWidget.qml" },
        user: { name: Tr.t("User"), icon: "person", source: "widgets/UserCard.qml" },
        calendar: { name: Tr.t("Calendar##calendario"), icon: "calendar_month", source: "widgets/CalendarWidget.qml" },
        weather: { name: Tr.t("Weather"), icon: "wb_sunny", source: "widgets/WeatherWidget.qml" },
        media: { name: Tr.t("Music"), icon: "music_note", source: "widgets/MediaWidget.qml" },
        visualizer: { name: Tr.t("Visualizer"), icon: "graphic_eq", source: "widgets/VisualizerWidget.qml", style: "plain" }
    })

    // The user's, as scripts/widgets.py read them (with "error" when they have problems)
    property var userList: []
    property bool scanned: false

    readonly property var types: {
        const out = Object.assign({}, builtin);
        for (const w of userList)
            out["user/" + w.id] = Object.assign({}, w, { user: true });
        return out;
    }
    // In the add menu: the shell's and the user's without errors (that have a desktop version)
    readonly property var typeList: Object.keys(types).filter(t => !types[t].error && (!types[t].user || types[t].places?.desktop))

    // --- Tabs (place: "notch" | "dashboard") ---
    function tabConfig(place) { return place === "notch" ? Config.options.widgets.notchTabs : Config.options.widgets.dashboardTabs; }
    function saveTabs(place, list) {
        if (place === "notch")
            Config.options.widgets.notchTabs = list;
        else
            Config.options.widgets.dashboardTabs = list;
    }
    // The extensions that can be a tab in that place
    function tabTypes(place) {
        return userList.filter(w => !w.error && w.places?.[place]).map(w => "user/" + w.id);
    }
    // The enabled tabs that exist: [{ id, type, label, icon }] (the tab id is the type)
    function tabsFor(place) {
        return tabConfig(place).filter(t => types[t.type] && !types[t.type].error && types[t.type].places?.[place])
            .map(t => ({ id: t.type, type: t.type, label: types[t.type].name, icon: types[t.type].icon }));
    }
    readonly property var notchTabs: tabsFor("notch")
    readonly property var dashboardTabs: tabsFor("dashboard")

    function tabEnabled(place, type) { return tabConfig(place).some(t => t.type === type); }
    function setTab(place, type, on) {
        const list = tabConfig(place).filter(t => t.type !== type);
        if (on) {
            const old = tabConfig(place).find(t => t.type === type);
            list.push(old ?? { type, options: {} });
        }
        saveTabs(place, list);
    }
    function tabOptions(place, type) {
        const out = {};
        for (const o of types[type]?.options ?? [])
            out[o.key] = o.default;
        return Object.assign(out, tabConfig(place).find(t => t.type === type)?.options ?? {});
    }
    function setTabOption(place, type, key, value) {
        saveTabs(place, tabConfig(place).map(t => t.type === type
            ? Object.assign({}, t, { options: Object.assign({}, t.options ?? {}, { [key]: value }) }) : t));
    }

    function rescan() {
        Run.cmd([Quickshell.shellPath("scripts/widgets.py"), "listar"], (code, out) => {
            if (code !== 0)
                return;
            try {
                root.userList = JSON.parse(out);
                root.scanned = true;
            } catch (e) {
                console.warn("widgets:", e);
            }
        });
    }

    // Re-read the folders and reload the QML (after changing a widget)
    function reload() {
        generation += 1;
        rescan();
    }

    // A type's QML: relative to desktop/ (the shell's) or the folder's file (the user's). The
    // "?v=" changes on each re-read, so the Loader does not use the old cached copy.
    property int generation: 0
    function sourceFor(type, place) {
        const t = types[type];
        if (!t || t.error)
            return "";
        // The shell's also get the "?v=": without it they stayed cached and did not reload on save
        if (!t.user)
            return t.source + "?v=" + generation;
        const qml = t.places?.[place ?? "desktop"] ?? t.main;
        return "file://" + t.dir + "/" + qml + "?v=" + generation;
    }

    // A widget's options: the manifest's with the defaults, overlaid with the chosen ones
    function optionsFor(item) {
        const out = {};
        for (const o of types[item.type]?.options ?? [])
            out[o.key] = o.default;
        return Object.assign(out, item.options ?? {});
    }

    // They come in at the centre, cascading, with the style the type asks for (card by default)
    function add(type) {
        if (!types[type])
            return;
        const id = type.replace("/", "-") + "-" + Date.now().toString(36);
        const n = items.length % 5;
        save([...items, { id, type, x: 0.4 + n * 0.05, y: 0.2 + n * 0.12, scale: 1,
            style: types[type].style ?? "card" }]);
    }

    function remove(id) { save(items.filter(i => i.id !== id)); }

    function update(id, patch) {
        save(items.map(i => i.id === id ? Object.assign({}, i, patch) : i));
    }

    function setOption(id, key, value) {
        const item = items.find(i => i.id === id);
        if (item)
            update(id, { options: Object.assign({}, item.options ?? {}, { [key]: value }) });
    }

    function save(list) { Config.options.widgets.items = list; }

    function toggleEditing() {
        editing = !editing;
    }

    onEditingChanged: {
        if (editing) {
            QuickPanel.open = false;
            Notifs.centerOpen = false;
            Launcher.open = false;
            Dashboard.open = false;
            rescan();
        }
    }

    // --- Messages from outside (other apps, scripts) to the widgets ---
    // A widget listens with Connections { target: Widgets; function onMessage(target, data) { … } }
    // and reads the last one with Widgets.lastMessage(target) at startup.
    signal message(string target, var data)
    property var messages: ({})

    function lastMessage(target) { return messages[target]; }

    function send(target, data) {
        messages = Object.assign({}, messages, { [target]: data });
        message(target, data);
    }

    Component.onCompleted: rescan()

    IpcHandler {
        target: "widgets"
        function edit(): void { root.toggleEditing(); }
        function add(type: string): void { root.add(type); }
        function remove(id: string): void { root.remove(id); }
        function list(): string { return JSON.stringify(root.items); }
        function types(): string { return root.typeList.join(" "); }
        // Tabs: tab notch|dashboard user/<id> true|false; tabs → the enabled ones
        function tab(place: string, type: string, on: bool): void { root.setTab(place, type, on); }
        function tabs(): string { return JSON.stringify({ notch: root.notchTabs.map(t => t.type), dashboard: root.dashboardTabs.map(t => t.type) }); }
        // Re-reads the folders and reloads the user's widgets
        function rescan(): void { root.reload(); }
        // Data for the widgets: the text is parsed as JSON when it is JSON (otherwise it stays text)
        function send(target: string, data: string): void {
            let value = data;
            try {
                value = JSON.parse(data);
            } catch (e) {}
            root.send(target, value);
        }
    }
}
