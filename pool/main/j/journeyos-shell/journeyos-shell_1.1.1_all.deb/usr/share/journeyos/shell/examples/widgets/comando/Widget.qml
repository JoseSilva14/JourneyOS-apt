import QtQuick
import QtQuick.Layouts
import Quickshell.Io
import qs
import qs.components

// Connects the widget to any command-line program: runs the command (sh -c) every few
// seconds and shows the first lines of what it prints.
Card {
    id: root

    property var options: ({})

    width: 340
    height: column.implicitHeight + Theme.cardPadding * 2

    property string output: ""
    property bool failed: false

    Process {
        id: proc
        command: ["sh", "-c", root.options.comando ?? ""]
        stdout: StdioCollector {
            id: out
        }
        stderr: StdioCollector {
            id: err
        }
        onExited: code => {
            root.failed = code !== 0;
            const text = (root.failed && err.text.trim() ? err.text : out.text).trim();
            root.output = text.split("\n").slice(0, root.options.linhas ?? 4).join("\n");
        }
    }

    // Runs now and then every few seconds (and again when the command changes)
    Timer {
        running: (root.options.comando ?? "") !== ""
        interval: Math.max(1, root.options.intervalo ?? 60) * 1000
        repeat: true
        triggeredOnStart: true
        onTriggered: if (!proc.running) proc.running = true
    }

    ColumnLayout {
        id: column
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: Theme.cardPadding
        spacing: 8

        RowLayout {
            spacing: 8
            MIcon {
                icon: root.options.icone || "terminal"
                size: 18
                color: Theme.subtext
            }
            Text {
                Layout.fillWidth: true
                text: root.options.titulo ?? ""
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }
        }

        Text {
            Layout.fillWidth: true
            text: root.output || "…"
            wrapMode: Text.Wrap
            color: root.failed ? Theme.privacyMic : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }
    }
}
