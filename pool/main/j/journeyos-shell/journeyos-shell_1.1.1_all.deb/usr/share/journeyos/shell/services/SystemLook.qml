pragma Singleton

import QtQuick
import Quickshell

// App appearance: fonts (kdeglobals), icons (plasma-changeicons), cursor
// (plasma-apply-cursortheme) and animation speed (kdeglobals [KDE] AnimationDurationFactor).
Singleton {
    id: root

    property string font: ""            // "Noto Sans"
    property int fontSize: 10
    property string fixedFont: ""       // monospace
    property var families: []
    property string iconTheme: ""
    property var iconThemes: []
    property string cursorTheme: ""
    property int cursorSize: 24
    property var cursorThemes: []
    property real animationFactor: 1

    readonly property string changeIcons: "/usr/lib/x86_64-linux-gnu/libexec/plasma-changeicons"

    // Qt 6 font description: family, size and the rest default
    function fontSpec(family, size) { return family + "," + size + ",-1,5,400,0,0,0,0,0,0,0,0,0,0,1"; }

    function refresh() {
        Kcfg.readMany("kdeglobals", [
            { group: "General", key: "font", fallback: "Noto Sans,10" },
            { group: "General", key: "fixed", fallback: "Hack,10" },
            { group: "Icons", key: "Theme", fallback: "breeze" },
            { group: "KDE", key: "AnimationDurationFactor", fallback: "1" }
        ], v => {
            const f = v["General/font"].split(",");
            root.font = f[0];
            root.fontSize = Number(f[1]) || 10;
            root.fixedFont = v["General/fixed"].split(",")[0];
            root.iconTheme = v["Icons/Theme"];
            root.animationFactor = Number(v["KDE/AnimationDurationFactor"]);
        });
        Kcfg.readMany("kcminputrc", [
            { group: "Mouse", key: "cursorTheme", fallback: "breeze_cursors" },
            { group: "Mouse", key: "cursorSize", fallback: "24" }
        ], v => {
            root.cursorTheme = v["Mouse/cursorTheme"];
            root.cursorSize = Number(v["Mouse/cursorSize"]) || 24;
        });
        if (!families.length)
            Run.sh("fc-list : family | cut -d, -f1 | sort -u", (code, out) => {
                root.families = out.trim().split("\n").filter(f => f && !f.startsWith("."));
            });
        // Themes: icon themes have Directories= in index.theme, cursor themes a cursors folder
        Run.sh("for d in /usr/share/icons/*/ ~/.local/share/icons/*/ ~/.icons/*/; do [ -d \"$d\" ] || continue; "
            + "n=$(basename \"$d\"); name=$(grep -m1 '^Name=' \"$d/index.theme\" 2>/dev/null | cut -d= -f2); "
            + "grep -q '^Directories=' \"$d/index.theme\" 2>/dev/null && [ \"$n\" != hicolor ] && echo \"icons\t$n\t${name:-$n}\"; "
            + "[ -d \"$d/cursors\" ] && echo \"cursor\t$n\t${name:-$n}\"; done", (code, out) => {
            const icons = [], cursors = [];
            for (const line of out.trim().split("\n")) {
                const [kind, id, name] = line.split("\t");
                if (kind === "icons") icons.push({ id, label: name });
                else if (kind === "cursor") cursors.push({ id, label: name });
            }
            root.iconThemes = icons;
            root.cursorThemes = cursors;
        });
    }

    function setFont(family) {
        Kcfg.write("kdeglobals", "General", "font", fontSpec(family, fontSize), () => notify());
    }
    function setFontSize(size) {
        Kcfg.write("kdeglobals", "General", "font", fontSpec(font, size), () => notify());
    }
    function setFixedFont(family) {
        Kcfg.write("kdeglobals", "General", "fixed", fontSpec(family, fontSize), () => notify());
    }

    // KDE apps re-read the fonts on this signal
    function notify() {
        Run.cmd(["dbus-send", "--session", "--type=signal", "/KGlobalSettings", "org.kde.KGlobalSettings.notifyChange",
            "int32:2", "int32:0"], () => refresh());
    }

    function setIconTheme(name) {
        Run.cmd([changeIcons, name], () => refresh());
    }

    function setCursor(name, size) {
        Run.cmd(["plasma-apply-cursortheme", name, "--size", String(size)], () => refresh());
    }

    function setAnimationFactor(f) {
        Kcfg.write("kdeglobals", "KDE", "AnimationDurationFactor", String(f), () => {
            Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/KWin",
                "--method", "org.kde.KWin.reconfigure"], () => refresh());
        });
    }
}
