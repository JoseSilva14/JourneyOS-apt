pragma Singleton

import QtQuick
import Quickshell

// Other users of the computer (AccountsService, asks for authorization): list, create, make
// administrator and delete. A new user's password is set with passwd in a terminal.
Singleton {
    id: root

    property var users: []              // [{ path, login, name, admin, icon, me }]

    function busctl(args, callback) { Run.cmd(["busctl", "--system", ...args], callback); }

    function refresh() {
        busctl(["-j", "call", "org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts", "ListCachedUsers"], (code, out) => {
            let paths = [];
            try {
                paths = JSON.parse(out).data[0];
            } catch (e) {
                return;
            }
            const result = [];
            let pending = paths.length;
            for (const path of paths) {
                busctl(["-j", "call", "org.freedesktop.Accounts", path, "org.freedesktop.DBus.Properties", "GetAll", "s",
                    "org.freedesktop.Accounts.User"], (c, o) => {
                    try {
                        const p = JSON.parse(o).data[0];
                        result.push({ path, login: p.UserName.data, name: p.RealName.data || p.UserName.data,
                            admin: p.AccountType.data === 1, icon: p.IconFile.data, me: p.UserName.data === Quickshell.env("USER") });
                    } catch (e) {
                    }
                    if (--pending === 0)
                        root.users = result.sort((a, b) => (b.me - a.me) || a.name.localeCompare(b.name));
                });
            }
        });
    }

    function create(login, name, admin) {
        busctl(["call", "org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
            "CreateUser", "ssi", login, name, admin ? "1" : "0"], code => {
            refresh();
            if (code === 0)
                setPassword(login);
        });
    }

    function setPassword(login) {
        Apps.run(["konsole", "-e", "sh", "-c", "echo '" + Tr.t("Password for ") + login + "'; echo; pkexec passwd " + login + "; echo; read -p '" + Tr.t("Press Enter to close") + " ' x"]);
    }

    function setAdmin(u, on) {
        busctl(["call", "org.freedesktop.Accounts", u.path, "org.freedesktop.Accounts.User", "SetAccountType", "i", on ? "1" : "0"], () => refresh());
    }

    // Deletes the account and its files
    function remove(u) {
        const uid = u.path.replace(/.*User/, "");
        busctl(["call", "org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
            "DeleteUser", "xb", uid, "true"], () => refresh());
    }
}
