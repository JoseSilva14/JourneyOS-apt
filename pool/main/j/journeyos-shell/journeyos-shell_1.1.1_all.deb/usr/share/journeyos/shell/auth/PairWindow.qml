import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Bluetooth pairing (BtAgent): confirm the code both devices show, type a PIN, show a code to type
// on the device, or allow a connection. Same look as the authorization dialog.
PanelWindow {
    id: root

    readonly property var req: BtAgent.request
    readonly property bool open: req !== null
    readonly property string kind: req?.type ?? ""
    readonly property bool typing: kind === "pin" || kind === "passkey"

    screen: Windows.activeScreen
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open
    WlrLayershell.namespace: "shadow-pair"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onReqChanged: {
        code.text = "";
        focusLater.restart();
    }

    // Focus only once the window is mapped (the request arrives before it is visible)
    Timer {
        id: focusLater
        interval: 80
        onTriggered: {
            if (root.typing)
                code.forceActiveFocus();
            else
                box.forceActiveFocus();
        }
    }

    function accept() {
        if (typing && !code.text)
            return;
        BtAgent.answer(true, code.text);
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
    }

    MouseArea {
        anchors.fill: parent
    }

    Rectangle {
        id: box

        anchors.centerIn: parent
        width: Math.min(420, parent.width - Theme.gap * 4)
        height: column.implicitHeight + Theme.cardPadding * 2 + 8
        radius: Theme.radiusCard + 6
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        focus: true
        Keys.onEscapePressed: BtAgent.answer(false)
        Keys.onReturnPressed: root.kind === "display" ? BtAgent.answer(true) : root.accept()

        ColumnLayout {
            id: column
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: Theme.cardPadding + 4
            spacing: 12

            Rectangle {
                Layout.alignment: Qt.AlignHCenter
                implicitWidth: 52
                implicitHeight: 52
                radius: 26
                color: Theme.button

                MIcon {
                    anchors.centerIn: parent
                    icon: "bluetooth"
                    size: 28
                }
            }

            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: root.kind === "service" ? Tr.t("Allow the connection?")
                    : root.kind === "authorize" ? Tr.t("Pair this device?")
                    : root.kind === "display" ? Tr.t("Type the code on the device")
                    : Tr.t("Bluetooth pairing")
                wrapMode: Text.Wrap
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge
                font.weight: Font.Bold
            }

            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: {
                    const n = root.req?.name ?? "";
                    switch (root.kind) {
                    case "confirm": return Tr.t("Check that ") + n + Tr.t(" shows the same code.");
                    case "authorize": return n + Tr.t(" wants to pair with this computer.");
                    case "service": return n + (root.req?.service
                        ? Tr.t(" wants to use: ") + Tr.t(root.req.service) + "."
                        : Tr.t(" wants to connect to this computer."));
                    case "pin": return Tr.t("Type the PIN for ") + n + Tr.t(" (often 0000 or 1234, or the one in its manual).");
                    case "passkey": return Tr.t("Type the code shown on ") + n + ".";
                    case "display": return Tr.t("On ") + n + Tr.t(", type this code and press Enter.");
                    default: return "";
                    }
                }
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
            }

            // The code (confirm / show)
            Text {
                Layout.fillWidth: true
                visible: root.kind === "confirm" || root.kind === "display"
                horizontalAlignment: Text.AlignHCenter
                text: (root.req?.passkey ?? "").replace(/^(\d{3})(\d{3})$/, "$1 $2")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 34
                font.weight: Font.Bold
                font.letterSpacing: 4
            }

            // Typing a PIN / code
            Rectangle {
                Layout.fillWidth: true
                visible: root.typing
                implicitHeight: 44
                radius: height / 2
                color: Theme.surfaceCard
                border.width: 1
                border.color: code.activeFocus ? Theme.accent : Theme.surfaceBorder

                TextInput {
                    id: code
                    anchors.fill: parent
                    anchors.leftMargin: 18
                    anchors.rightMargin: 18
                    verticalAlignment: TextInput.AlignVCenter
                    horizontalAlignment: TextInput.AlignHCenter
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontMedium
                    font.letterSpacing: 2
                    maximumLength: root.kind === "passkey" ? 6 : 16
                    validator: RegularExpressionValidator {
                        regularExpression: root.kind === "passkey" ? /[0-9]{0,6}/ : /.{0,16}/
                    }
                    clip: true
                    onAccepted: root.accept()
                    Keys.onEscapePressed: BtAgent.answer(false)
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    visible: root.kind !== "display"
                    text: root.kind === "service" ? Tr.t("Deny") : Tr.t("Cancel")
                    onClicked: BtAgent.answer(false)
                }
                Button {
                    Layout.fillWidth: true
                    text: root.kind === "display" ? Tr.t("Close")
                        : root.kind === "service" ? Tr.t("Allow")
                        : Tr.t("Pair")
                    accent: true
                    onClicked: root.kind === "display" ? BtAgent.answer(true) : root.accept()
                }
            }
        }
    }

    component Button: Rectangle {
        id: button
        property string text: ""
        property bool accent: false
        signal clicked

        implicitHeight: 40
        radius: height / 2
        color: accent ? Theme.accent : buttonMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: buttonMouse.pressed ? 0.97 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Text {
            anchors.centerIn: parent
            text: button.text
            color: button.accent ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }
        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }
}
