import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Widget editing, above the windows: dims the screen, shows the widgets with
// handles and a bar at the bottom (where the dock is, no widgets) with "Add" and
// "Done". Esc also finishes.
PanelWindow {
    id: root

    property bool adding: false

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: Widgets.editing
    WlrLayershell.namespace: "shadow-widgets-editor"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Widgets.editing ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onVisibleChanged: adding = false

    // The desktop without windows: the wallpaper, slightly dimmed
    Rectangle {
        anchors.fill: parent
        color: Theme.bg
    }

    Wallpaper {
        anchors.fill: parent
    }

    Rectangle {
        anchors.fill: parent
        color: Theme.scrim

        // Clicking on empty space closes the type list
        MouseArea {
            anchors.fill: parent
            onClicked: root.adding = false
        }
    }

    WidgetLayer {
        anchors.fill: parent
        editing: true
    }

    // Edit bar
    Rectangle {
        id: toolbar

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Theme.gap + (Theme.dockHeight - height) / 2
        width: toolbarRow.implicitWidth + 16
        height: 46
        radius: height / 2
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        focus: Widgets.editing
        Keys.onEscapePressed: {
            if (root.adding)
                root.adding = false;
            else
                Widgets.editing = false;
        }

        RowLayout {
            id: toolbarRow
            anchors.centerIn: parent
            spacing: 8

            MIcon {
                Layout.leftMargin: 8
                icon: "widgets"
                size: 18
                color: Theme.subtext
            }
            Text {
                Layout.rightMargin: 6
                text: Tr.t("Edit widgets")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }

            Pill {
                icon: "add"
                text: Tr.t("Add")
                active: root.adding
                onClicked: root.adding = !root.adding
            }
            Pill {
                icon: "check"
                text: Tr.t("Finish")
                accent: true
                onClicked: Widgets.editing = false
            }
        }
    }

    // Widget types
    Rectangle {
        visible: root.adding
        anchors.horizontalCenter: toolbar.horizontalCenter
        anchors.bottom: toolbar.top
        anchors.bottomMargin: 8
        width: 240
        height: typesColumn.implicitHeight + 12
        radius: Theme.radius
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        ColumnLayout {
            id: typesColumn
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 6
            spacing: 0

            Repeater {
                model: Widgets.typeList

                Rectangle {
                    id: typeItem
                    required property string modelData
                    readonly property var meta: Widgets.types[modelData]

                    Layout.fillWidth: true
                    implicitHeight: 34
                    radius: Theme.radiusSmall
                    // No transition, as in menus
                    color: typeMouse.containsMouse ? Theme.buttonHover : "transparent"

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 8
                        anchors.rightMargin: 8
                        spacing: 10

                        MIcon {
                            icon: typeItem.meta.icon
                            size: 17
                            color: Theme.subtext
                        }
                        Text {
                            Layout.fillWidth: true
                            text: typeItem.meta.name
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                        }
                    }

                    MouseArea {
                        id: typeMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            Widgets.add(typeItem.modelData);
                            root.adding = false;
                        }
                    }
                }
            }
        }
    }

    component Pill: Rectangle {
        id: pill

        property string icon: ""
        property string text: ""
        property bool accent: false
        property bool active: false
        signal clicked

        implicitWidth: pillRow.implicitWidth + 24
        implicitHeight: 32
        radius: height / 2
        color: accent ? Theme.accent : active || pillMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: pillMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Row {
            id: pillRow
            anchors.centerIn: parent
            spacing: 5

            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                icon: pill.icon
                size: 16
                color: pill.accent ? Theme.accentText : Theme.text
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: pill.text
                color: pill.accent ? Theme.accentText : Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }
        }

        MouseArea {
            id: pillMouse
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            hoverEnabled: true
            onClicked: pill.clicked()
        }
    }
}
