import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Wi-Fi connection form (state in services/WifiConnect): password for WPA/WPA3 Personal and WEP,
// user and password for LEAP, and 802.1X/Enterprise (PEAP, TTLS, TLS, PWD with certificates).
// For a hidden network, also the name and the security type.
ColumnLayout {
    id: root

    // Inside Settings → Network (certificates can be picked right there)
    property bool embedded: false

    readonly property var w: WifiConnect
    readonly property var securityOptions: [
        { id: "open", label: Tr.t("Open##f") },
        { id: "psk", label: "WPA" },
        { id: "wep", label: "WEP" },
        { id: "eap", label: "802.1X" }
    ]

    spacing: 8

    Component.onCompleted: focusFirst.restart()

    // First field ready to type (after the layout settles)
    Timer {
        id: focusFirst
        interval: 50
        onTriggered: {
            if (WifiConnect.hidden)
                ssidField.grab();
            else if (WifiConnect.enterprise)
                identityField.grab();
            else if (WifiConnect.security !== "open")
                passwordField.grab();
        }
    }

    // --- Title: network name (typed when hidden) and close ---
    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        MIcon {
            icon: WifiConnect.hidden ? "wifi_find" : WifiConnect.security === "open" ? "wifi" : "wifi_lock"
            size: 20
            color: Theme.text
        }
        Text {
            visible: !WifiConnect.hidden
            Layout.fillWidth: true
            text: WifiConnect.ssid
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontMedium
            font.weight: Font.Bold
        }
        TextField {
            id: ssidField
            visible: WifiConnect.hidden
            Layout.fillWidth: true
            placeholder: Tr.t("Network name (SSID)")
            text: WifiConnect.ssid
            onTextChanged: WifiConnect.ssid = text
            acceptOnBlur: false
            onAccepted: WifiConnect.submit()
        }
        RoundButton {
            icon: "close"
            onClicked: WifiConnect.cancel()
        }
    }

    Text {
        visible: !WifiConnect.hidden
        Layout.fillWidth: true
        text: WifiConnect.security === "eap" ? Tr.t("Enterprise network (802.1X): sign in with your account.")
            : WifiConnect.security === "leap" ? Tr.t("LEAP network: sign in with your account.")
            : WifiConnect.security === "wep" ? Tr.t("WEP network (old and insecure).")
            : WifiConnect.security === "open" ? Tr.t("Open network.")
            : Tr.t("Secured network (WPA/WPA2/WPA3).")
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // Hidden network: which security
    Segmented {
        visible: WifiConnect.hidden
        Layout.fillWidth: true
        model: root.securityOptions
        current: WifiConnect.security === "sae" ? "psk" : WifiConnect.security === "leap" ? "eap" : WifiConnect.security
        onSelected: id => WifiConnect.security = id
    }
    RowLayout {
        visible: WifiConnect.hidden && (WifiConnect.security === "psk" || WifiConnect.security === "sae")
        Layout.fillWidth: true
        Text {
            Layout.fillWidth: true
            text: Tr.t("WPA3 only (SAE)")
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
        Toggle {
            checked: WifiConnect.security === "sae"
            onToggled: on => WifiConnect.security = on ? "sae" : "psk"
        }
    }

    // --- Enterprise: method and inner authentication ---
    Label {
        visible: WifiConnect.security === "eap"
        text: Tr.t("Authentication")
    }
    Segmented {
        visible: WifiConnect.security === "eap"
        Layout.fillWidth: true
        model: [
            { id: "peap", label: "PEAP" }, { id: "ttls", label: "TTLS" },
            { id: "tls", label: "TLS" }, { id: "pwd", label: "PWD" }
        ]
        current: WifiConnect.eap
        onSelected: id => {
            WifiConnect.eap = id;
            if (!WifiConnect.phase2Options.some(o => o.id === WifiConnect.phase2))
                WifiConnect.phase2 = WifiConnect.phase2Options[0].id;
        }
    }
    Label {
        visible: WifiConnect.security === "eap" && (WifiConnect.eap === "peap" || WifiConnect.eap === "ttls")
        text: Tr.t("Inner authentication")
    }
    Segmented {
        visible: WifiConnect.security === "eap" && (WifiConnect.eap === "peap" || WifiConnect.eap === "ttls")
        Layout.fillWidth: true
        model: WifiConnect.phase2Options
        current: WifiConnect.phase2
        onSelected: id => WifiConnect.phase2 = id
    }

    // --- Account ---
    TextField {
        id: identityField
        visible: WifiConnect.enterprise
        Layout.fillWidth: true
        placeholder: Tr.t("Username")
        text: WifiConnect.identity
        onTextChanged: WifiConnect.identity = text
        acceptOnBlur: false
        onAccepted: WifiConnect.submit()
    }

    RowLayout {
        visible: WifiConnect.security !== "open" && !(WifiConnect.security === "eap" && WifiConnect.eap === "tls")
        Layout.fillWidth: true
        spacing: 6

        TextField {
            id: passwordField
            Layout.fillWidth: true
            placeholder: WifiConnect.security === "wep" ? Tr.t("WEP key or passphrase") : Tr.t("Password")
            text: WifiConnect.password
            onTextChanged: WifiConnect.password = text
            echoMode: reveal.shown ? TextInput.Normal : TextInput.Password
            acceptOnBlur: false
            onAccepted: WifiConnect.submit()
        }
        RoundButton {
            id: reveal
            property bool shown: false
            icon: shown ? "visibility_off" : "visibility"
            onClicked: shown = !shown
        }
    }

    // Optional (PEAP/TTLS)
    TextField {
        visible: WifiConnect.security === "eap" && (WifiConnect.eap === "peap" || WifiConnect.eap === "ttls")
        Layout.fillWidth: true
        placeholder: Tr.t("Anonymous identity (optional)")
        text: WifiConnect.anonymous
        onTextChanged: WifiConnect.anonymous = text
        acceptOnBlur: false
    }

    // --- Certificates ---
    CertRow {
        visible: WifiConnect.security === "eap" && WifiConnect.eap !== "pwd"
        field: "caCert"
        label: Tr.t("CA certificate")
        empty: Tr.t("None (not verified)")
    }
    TextField {
        visible: WifiConnect.security === "eap" && WifiConnect.eap !== "pwd"
        Layout.fillWidth: true
        placeholder: Tr.t("Server domain (optional)")
        text: WifiConnect.domain
        onTextChanged: WifiConnect.domain = text
        acceptOnBlur: false
    }
    CertRow {
        visible: WifiConnect.security === "eap" && WifiConnect.eap === "tls"
        field: "clientCert"
        label: Tr.t("User certificate")
        empty: Tr.t("Required")
    }
    CertRow {
        visible: WifiConnect.security === "eap" && WifiConnect.eap === "tls"
        field: "privateKey"
        label: Tr.t("Private key")
        empty: Tr.t("Required")
    }
    TextField {
        visible: WifiConnect.security === "eap" && WifiConnect.eap === "tls"
        Layout.fillWidth: true
        placeholder: Tr.t("Private key password")
        text: WifiConnect.keyPassword
        onTextChanged: WifiConnect.keyPassword = text
        echoMode: TextInput.Password
        acceptOnBlur: false
        onAccepted: WifiConnect.submit()
    }

    // --- Error and actions ---
    RowLayout {
        visible: WifiConnect.error !== ""
        Layout.fillWidth: true
        spacing: 6

        MIcon {
            Layout.alignment: Qt.AlignTop
            icon: "error"
            size: 16
            color: Theme.text
        }
        Text {
            Layout.fillWidth: true
            text: WifiConnect.error
            wrapMode: Text.Wrap
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    RowLayout {
        Layout.fillWidth: true
        Layout.topMargin: 2
        spacing: 8

        Item { Layout.fillWidth: true }

        Button {
            label: Tr.t("Cancel")
            available: !WifiConnect.busy
            onClicked: WifiConnect.cancel()
        }
        Button {
            label: WifiConnect.busy ? Tr.t("Connecting…") : Tr.t("Connect")
            primary: true
            available: WifiConnect.ready
            onClicked: WifiConnect.submit()
        }
    }

    component RoundButton: MenuButton {
        Layout.preferredWidth: 32
        Layout.preferredHeight: 32
        width: 32
        height: 32
        radius: 16
    }

    component Label: Text {
        Layout.fillWidth: true
        Layout.topMargin: 2
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // A certificate: label, chosen file (or what "nothing" means), Choose and Clear
    component CertRow: RowLayout {
        id: cert
        property string field: ""
        property string label: ""
        property string empty: ""
        readonly property string value: WifiConnect[field] ?? ""

        Layout.fillWidth: true
        spacing: 6

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 0

            Text {
                text: cert.label
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Text {
                Layout.fillWidth: true
                text: cert.value ? cert.value.split("/").pop() : cert.empty
                elide: Text.ElideMiddle
                color: cert.value ? Theme.text : Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
        }
        RoundButton {
            visible: cert.value !== ""
            icon: "close"
            onClicked: WifiConnect[cert.field] = ""
        }
        Button {
            label: Tr.t("Choose…")
            onClicked: WifiConnect.pick(cert.field)
        }
    }

    component Button: Rectangle {
        id: btn
        property string label: ""
        property bool primary: false
        property bool available: true
        signal clicked

        implicitWidth: btnText.implicitWidth + 28
        implicitHeight: 34
        radius: height / 2
        opacity: available ? 1 : 0.4
        color: primary ? Theme.accent : btnMouse.containsMouse && available ? Theme.buttonHover : Theme.button

        Text {
            id: btnText
            anchors.centerIn: parent
            text: btn.label
            color: btn.primary ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.DemiBold
        }
        MouseArea {
            id: btnMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: btn.available ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: if (btn.available) btn.clicked()
        }
    }
}
