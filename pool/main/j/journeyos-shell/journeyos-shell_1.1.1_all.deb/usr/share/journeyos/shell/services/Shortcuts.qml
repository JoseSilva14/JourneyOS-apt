pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Global shortcuts via kglobalaccel (scripts/shortcuts.py). Keys come
// from config.json; those owned by another app go into "conflicts".
Singleton {
    id: root

    property var conflicts: ({})     // { action: owning component }

    function dispatch(action) {
        if (action === "launcher")
            Launcher.toggle(null);
        else if (action === "panel")
            QuickPanel.toggle(null);
        else if (action === "notifications")
            Notifs.toggleCenter(null);
        else if (action === "dashboard")
            Dashboard.toggle("home", null);
        else if (action === "wallpapers")
            Dashboard.toggle("wallpapers", null);
        else if (action === "widgets")
            Widgets.toggleEditing();
        else if (action === "settings")
            SettingsApp.toggle();
        else if (action === "clipboard")
            Clipboard.toggle(null);
        else if (action === "captureRegion")
            Capture.start("region");
        else if (action === "captureScreen")
            Capture.start("screen");
        else if (action === "captureWindow")
            Capture.start("window");
        else if (action === "colorPicker")
            Capture.start("color");
        else {
            const tile = Tiling.layouts.find(l => l.shortcut === action);
            if (tile)
                Tiling.apply(tile.id);
        }
    }

    readonly property var keys: Config.options.shortcuts

    Process {
        id: helper
        running: Config.ready
        command: [Quickshell.shellPath("scripts/shortcuts.py"),
            "launcher=" + root.keys.launcher,
            "panel=" + root.keys.panel,
            "notifications=" + root.keys.notifications,
            "dashboard=" + root.keys.dashboard,
            "wallpapers=" + root.keys.wallpapers,
            "widgets=" + root.keys.widgets,
            "settings=" + root.keys.settings,
            "clipboard=" + root.keys.clipboard,
            "captureRegion=" + root.keys.captureRegion,
            "captureScreen=" + root.keys.captureScreen,
            "captureWindow=" + root.keys.captureWindow,
            "colorPicker=" + root.keys.colorPicker,
            "tileHalves=" + root.keys.tileHalves,
            "tileColumns=" + root.keys.tileColumns,
            "tileMain=" + root.keys.tileMain,
            "tileGrid=" + root.keys.tileGrid]
        stdinEnabled: true
        stdout: SplitParser {
            onRead: line => {
                const f = line.split(" ");
                if (f[0] === "pressed")
                    root.dispatch(f[1]);
                else if (f[0] === "conflict")
                    root.conflicts = Object.assign({}, root.conflicts, { [f[1]]: f[2] });
            }
        }
        onExited: restart.start()
        // Each registration starts with no conflicts (they come again from the helper)
        onRunningChanged: if (running) root.conflicts = {}
    }

    // Crashed (kglobalaccel restarted, for example): relaunch
    Timer {
        id: restart
        interval: 3000
        onTriggered: helper.running = true
    }

    // Keys changed in config.json: register again (onExited relaunches)
    Connections {
        target: root.keys
        function onLauncherChanged() { helper.running = false; }
        function onPanelChanged() { helper.running = false; }
        function onNotificationsChanged() { helper.running = false; }
        function onDashboardChanged() { helper.running = false; }
        function onWallpapersChanged() { helper.running = false; }
        function onWidgetsChanged() { helper.running = false; }
        function onSettingsChanged() { helper.running = false; }
        function onClipboardChanged() { helper.running = false; }
        function onCaptureRegionChanged() { helper.running = false; }
        function onCaptureScreenChanged() { helper.running = false; }
        function onCaptureWindowChanged() { helper.running = false; }
        function onColorPickerChanged() { helper.running = false; }
        function onTileHalvesChanged() { helper.running = false; }
        function onTileColumnsChanged() { helper.running = false; }
        function onTileMainChanged() { helper.running = false; }
        function onTileGridChanged() { helper.running = false; }
    }
}
