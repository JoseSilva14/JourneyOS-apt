import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Dock always visible at the bottom, centred (reserves the space: maximized windows
// stop above it): on the left the dashboard button (the shell's own, not an app) and, after
// a separator, the pinned apps and, after another, the open ones.
// The window is taller than the dock to fit the app name and the menu; the mask only
// catches the dock and the menu.
PanelWindow {
    id: root

    property string menuKey: ""        // app with the menu open
    property Item menuAnchor: null
    property Item hoverCell: null

    readonly property var apps: DockApps.apps.filter(a => a.key !== Dashboard.desktopId)
    readonly property bool dashButton: Config.options.dock.dashboard
    readonly property var menuApp: apps.find(a => a.key === menuKey) ?? null
    readonly property int pinnedCount: apps.filter(a => a.pinned).length

    anchors {
        bottom: true
        left: true
        right: true
    }
    implicitHeight: Theme.dockHeight + Theme.gap + Theme.dockOverlay
    exclusionMode: ExclusionMode.Normal
    exclusiveZone: Theme.dockHeight + Theme.gap
    color: "transparent"
    visible: Config.options.dock.enabled
    WlrLayershell.namespace: "shadow-dock"
    WlrLayershell.layer: WlrLayer.Top

    mask: Region {
        item: body
        Region {
            item: root.menuApp ? menu : null
        }
    }

    // The menu closes when the mouse leaves the dock and the menu
    Timer {
        running: root.menuApp !== null && !bodyHover.hovered && !menuHover.hovered
        interval: 700
        onTriggered: root.menuKey = ""
    }

    Rectangle {
        id: body

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Theme.gap
        width: row.width + Theme.dockPadding * 2
        height: Theme.dockHeight
        radius: Theme.radiusCard
        color: Theme.barBg
        border.width: 1
        border.color: Theme.cardBorder
        visible: root.apps.length > 0 || root.dashButton

        Behavior on width {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        HoverHandler {
            id: bodyHover
        }

        Row {
            id: row
            x: Theme.dockPadding
            anchors.bottom: parent.bottom
            anchors.bottomMargin: (Theme.dockHeight - Theme.dockCell) / 2

            DashButton {
                visible: root.dashButton
            }

            Repeater {
                model: ScriptModel {
                    values: root.apps.map(a => a.key)
                }

                delegate: AppCell {}
            }
        }
    }

    // Name of the app under the mouse
    Rectangle {
        id: tip

        readonly property var app: root.hoverCell?.app ?? null
        readonly property string text: root.hoverCell?.tip ?? app?.name ?? app?.entry?.name ?? app?.windows[0]?.title ?? ""

        visible: root.hoverCell !== null && text !== "" && !root.menuApp
        width: tipText.implicitWidth + 20
        height: 26
        radius: Theme.radiusSmall
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        y: body.y - height - 8
        x: {
            if (!root.hoverCell)
                return 0;
            const p = root.hoverCell.mapToItem(root.contentItem, root.hoverCell.width / 2, 0);
            return Math.max(Theme.gap, Math.min(root.width - width - Theme.gap, p.x - width / 2));
        }

        Text {
            id: tipText
            anchors.centerIn: parent
            text: tip.text
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
    }

    // Right-click menu
    Rectangle {
        id: menu

        visible: root.menuApp !== null
        width: Theme.dockMenuWidth
        height: menuColumn.implicitHeight + 12
        radius: Theme.radius
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        y: body.y - height - 10
        x: {
            if (!root.menuAnchor)
                return 0;
            const p = root.menuAnchor.mapToItem(root.contentItem, root.menuAnchor.width / 2, 0);
            return Math.max(Theme.gap, Math.min(root.width - width - Theme.gap, p.x - width / 2));
        }

        HoverHandler {
            id: menuHover
        }

        ColumnLayout {
            id: menuColumn
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 6
            spacing: 0

            Text {
                Layout.fillWidth: true
                Layout.margins: 8
                Layout.bottomMargin: 4
                text: root.menuApp?.name ?? root.menuApp?.entry?.name ?? root.menuApp?.key ?? ""
                elide: Text.ElideRight
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.Bold
            }

            // The open windows (with more than one)
            Repeater {
                model: (root.menuApp?.windows.length ?? 0) > 1 ? root.menuApp.windows : []

                MenuItem {
                    required property var modelData
                    icon: modelData.active ? "radio_button_checked" : modelData.minimized ? "minimize" : "radio_button_unchecked"
                    text: modelData.title
                    onClicked: {
                        Windows.activate(modelData.id);
                        root.menuKey = "";
                    }
                }
            }

            MenuItem {
                visible: !!root.menuApp?.entry
                icon: "add"
                text: (root.menuApp?.windows.length ?? 0) > 0 ? Tr.t("New window") : Tr.t("Open")
                onClicked: {
                    Apps.launch(root.menuApp.entry);
                    root.menuKey = "";
                }
            }

            MenuItem {
                visible: !!root.menuApp?.entry
                icon: "push_pin"
                text: root.menuApp?.pinned ? Tr.t("Unpin from dock") : Tr.t("Pin to dock")
                onClicked: {
                    DockApps.setPinned(root.menuApp.key, !root.menuApp.pinned);
                    root.menuKey = "";
                }
            }

            MenuItem {
                visible: (root.menuApp?.windows.length ?? 0) > 0
                icon: "close"
                text: (root.menuApp?.windows.length ?? 0) > 1 ? Tr.t("Close all") : Tr.t("Close")
                onClicked: {
                    DockApps.closeAll(root.menuApp);
                    root.menuKey = "";
                }
            }
        }
    }

    // An app: icon (rises a little on hover), indicator below, click and menu.
    // The first open one that is not pinned gets a separator on the left.
    component AppCell: Item {
        id: cell

        required property string modelData
        required property int index
        readonly property var app: root.apps.find(a => a.key === modelData) ?? null
        readonly property var windows: app?.windows ?? []
        readonly property bool running: windows.length > 0
        readonly property bool active: windows.some(w => w.active)
        // Separator before the open unpinned ones (and before the first, with the dashboard button)
        readonly property bool separated: (index === root.pinnedCount && index > 0) || (index === 0 && root.dashButton)
        readonly property string iconSource: {
            const name = app?.icon ?? app?.entry?.icon ?? "";
            return !name ? "" : name.startsWith("/") ? "file://" + name : Quickshell.iconPath(name, true);
        }

        // Entering: grows from 0
        property real appear: 0
        Component.onCompleted: appear = 1
        Behavior on appear {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        // Opening: bounces until a window appears (or gives up after 8 s)
        property bool launching: false
        onRunningChanged: if (running) launching = false

        width: ((separated ? Theme.dockSeparator : 0) + Theme.dockCell) * appear
        height: Theme.dockCell
        opacity: appear

        Timer {
            running: cell.launching
            interval: 8000
            onTriggered: cell.launching = false
        }

        // Separator between pinned and open
        Rectangle {
            visible: cell.separated
            x: (Theme.dockSeparator - width) / 2
            anchors.verticalCenter: parent.verticalCenter
            width: 1
            height: Theme.dockCell * 0.5
            color: Theme.faint
        }

        Item {
            id: iconBox

            x: cell.separated ? Theme.dockSeparator : 0
            width: Theme.dockCell
            height: Theme.dockCell

            Item {
                id: lift

                property real bounce: 0
                property real hoverLift: mouse.containsMouse ? Theme.dockHoverLift : 0

                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: 6 + bounce + hoverLift
                width: Theme.dockIcon
                height: width

                Behavior on hoverLift {
                    NumberAnimation { duration: Theme.animFast; easing.type: Easing.OutCubic }
                }

                SequentialAnimation on bounce {
                    running: cell.launching
                    loops: Animation.Infinite
                    alwaysRunToEnd: true
                    NumberAnimation { to: 10; duration: 260; easing.type: Easing.OutQuad }
                    NumberAnimation { to: 0; duration: 260; easing.type: Easing.InQuad }
                }

                IconImage {
                    id: image
                    anchors.fill: parent
                    source: cell.iconSource
                    visible: cell.iconSource !== "" && status === Image.Ready
                    // Monochrome outside: closed pinned ones are faded
                    opacity: cell.running || mouse.containsMouse ? 1 : 0.55
                    scale: mouse.pressed ? 0.9 : 1

                    Behavior on opacity {
                        NumberAnimation { duration: Theme.animNormal }
                    }
                    Behavior on scale {
                        NumberAnimation { duration: Theme.animFast }
                    }
                }

                // No icon in the theme: the initial
                Rectangle {
                    anchors.fill: parent
                    visible: !image.visible
                    radius: width * 0.28
                    color: Theme.button

                    Text {
                        anchors.centerIn: parent
                        text: (cell.app?.name ?? cell.app?.entry?.name ?? cell.modelData).charAt(0).toUpperCase()
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: parent.width * 0.45
                        font.weight: Font.Bold
                    }
                }
            }

            // Indicator: dot if open, pill if active
            Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: -1
                width: cell.active ? 14 : 4
                height: 3
                radius: 1.5
                color: cell.windows.every(w => w.minimized) ? Theme.dim : Theme.accent
                opacity: cell.running ? 1 : 0

                Behavior on width {
                    NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
                }
                Behavior on opacity {
                    NumberAnimation { duration: Theme.animNormal }
                }
            }

            MouseArea {
                id: mouse
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                cursorShape: Qt.PointingHandCursor
                onContainsMouseChanged: {
                    if (containsMouse)
                        root.hoverCell = cell;
                    else if (root.hoverCell === cell)
                        root.hoverCell = null;
                }
                onClicked: m => {
                    if (!cell.app)
                        return;
                    if (m.button === Qt.RightButton) {
                        root.menuAnchor = cell;
                        root.menuKey = root.menuKey === cell.modelData ? "" : cell.modelData;
                        return;
                    }
                    root.menuKey = "";
                    if (m.button === Qt.MiddleButton || !cell.running) {
                        // Middle button or closed app: opens (and bounces until it appears)
                        if (cell.app.entry) {
                            if (!cell.running)
                                cell.launching = true;
                            Apps.launch(cell.app.entry, root.screen);
                        }
                    } else {
                        DockApps.activate(cell.app);
                    }
                }
            }
        }
    }

    // Dashboard button: a square in the shell's style (not an app icon) with the dashboard's
    // cards; when open, it inverts the colours and the arrow points down (the dashboard slides down to close)
    component DashButton: Item {
        id: dash

        readonly property string tip: Dashboard.open ? Tr.t("Close the dashboard") : "Dashboard"
        readonly property bool open: Dashboard.open && Dashboard.screen === root.screen

        width: Theme.dockCell
        height: Theme.dockCell

        Rectangle {
            id: tile

            property real hoverLift: dashMouse.containsMouse ? Theme.dockHoverLift : 0

            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 6 + hoverLift
            width: Theme.dockIcon
            height: width
            radius: width * 0.3
            color: dash.open ? Theme.accent : dashMouse.containsMouse ? Theme.buttonHover : Theme.button
            border.width: 1
            border.color: dash.open ? "transparent" : Theme.surfaceBorder
            scale: dashMouse.pressed ? 0.9 : 1

            Behavior on hoverLift {
                NumberAnimation { duration: Theme.animFast; easing.type: Easing.OutCubic }
            }
            Behavior on color {
                ColorAnimation { duration: Theme.animNormal }
            }
            Behavior on scale {
                NumberAnimation { duration: Theme.animFast }
            }

            // The two icons swap with a short rotation
            MIcon {
                anchors.centerIn: parent
                icon: "space_dashboard"
                size: 20
                color: Theme.text
                opacity: dash.open ? 0 : 1
                rotation: dash.open ? 90 : 0
                Behavior on opacity {
                    NumberAnimation { duration: Theme.animNormal }
                }
                Behavior on rotation {
                    NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
                }
            }
            MIcon {
                anchors.centerIn: parent
                icon: "keyboard_arrow_down"
                size: 22
                color: Theme.accentText
                opacity: dash.open ? 1 : 0
                rotation: dash.open ? 0 : -90
                Behavior on opacity {
                    NumberAnimation { duration: Theme.animNormal }
                }
                Behavior on rotation {
                    NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
                }
            }
        }

        MouseArea {
            id: dashMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onContainsMouseChanged: {
                if (containsMouse)
                    root.hoverCell = dash;
                else if (root.hoverCell === dash)
                    root.hoverCell = null;
            }
            onClicked: {
                root.menuKey = "";
                // Open on another screen: moves to this one
                if (Dashboard.open && Dashboard.screen !== root.screen)
                    Dashboard.open = false;
                Dashboard.toggle("", root.screen);
            }
        }
    }

    component MenuItem: Rectangle {
        id: item

        property string icon: ""
        property string text: ""
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 32
        radius: Theme.radiusSmall
        // No transition, as in menus
        color: itemMouse.containsMouse ? Theme.buttonHover : "transparent"

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            spacing: 10

            MIcon {
                icon: item.icon
                size: 16
                color: Theme.subtext
            }
            Text {
                Layout.fillWidth: true
                text: item.text
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
        }

        MouseArea {
            id: itemMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: item.clicked()
        }
    }
}
