import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Autostart: the apps that open on login (essential session components are hidden).
Page {
    id: root

    Component.onCompleted: Autostart.refresh()

    readonly property var apps: DesktopEntries.applications.values.filter(e => !e.noDisplay)
        .filter(e => !Autostart.list.some(a => a.id === e.id + ".desktop" || a.id === e.id))
        .map(e => ({ id: e.id.endsWith(".desktop") ? e.id : e.id + ".desktop", label: e.name }))
        .sort((a, b) => a.label.localeCompare(b.label))

    Text {
        Layout.fillWidth: true
        text: Tr.t("Turning an app off here only stops it from starting on login. Essential session parts don't appear in this list.")
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: Autostart.list

        SettingRow {
            required property var modelData
            title: modelData.name
            description: modelData.system ? Tr.t("System##do") : Tr.t("Added by you")
            icon: "play_circle"

            Row {
                spacing: 8
                Rectangle {
                    visible: !modelData.system
                    anchors.verticalCenter: parent.verticalCenter
                    width: 32
                    height: 32
                    radius: 16
                    color: removeMouse.containsMouse ? Theme.buttonHover : Theme.button
                    MIcon {
                        anchors.centerIn: parent
                        icon: "delete"
                        size: 16
                    }
                    MouseArea {
                        id: removeMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Autostart.remove(modelData.id)
                    }
                }
                Toggle {
                    anchors.verticalCenter: parent.verticalCenter
                    checked: modelData.enabled
                    onToggled: on => Autostart.setEnabled(modelData.id, on)
                }
            }
        }
    }

    SettingRow {
        title: Tr.t("Add an app")
        icon: "add"
        Select {
            options: root.apps
            placeholder: Tr.t("Choose…")
            searchable: true
            onSelected: id => Autostart.add(id)
        }
    }
}
