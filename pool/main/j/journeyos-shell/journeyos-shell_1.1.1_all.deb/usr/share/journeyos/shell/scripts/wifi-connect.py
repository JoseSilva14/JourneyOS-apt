#!/usr/bin/env python3
"""Connects to a Wi-Fi network through NetworkManager (D-Bus), for the security types
Quickshell's connectWithPsk does not cover: WEP, LEAP, 802.1X/Enterprise (PEAP, TTLS, TLS,
PWD; WPA, WPA2/3 and Suite B 192) and hidden networks (also WPA/WPA3 Personal and open).

The request is one JSON line on stdin (so passwords never show up in `ps`):
  { "ssid", "security": open|psk|sae|wep|leap|eap, "hidden": bool, "iface": "" (any Wi-Fi),
    "keyMgmt": "wpa-eap" | "wpa-eap-suite-b-192" | "ieee8021x" (eap only),
    "password", "identity", "anonymous", "eap": peap|ttls|tls|pwd, "phase2": mschapv2|pap|...,
    "caCert", "domain", "clientCert", "privateKey", "keyPassword" }
Replies with one JSON line: {"ok": true} or {"ok": false, "error": "<text>"}.
Older connections with the same SSID are replaced; a connection that fails to activate
is deleted (wrong password: nothing broken is left saved).
"""

import json
import sys
import time

from gi.repository import Gio, GLib

NM = "org.freedesktop.NetworkManager"
NM_PATH = "/org/freedesktop/NetworkManager"
SETTINGS_PATH = "/org/freedesktop/NetworkManager/Settings"
TIMEOUT = 45          # s waiting for the connection to come up
CALL_MS = 180000      # D-Bus calls (the authorization dialog may be in the way)

bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)


def call(path, iface, method, args=None, reply=None):
    return bus.call_sync(NM, path, iface, method, args, GLib.VariantType(reply) if reply else None,
                         Gio.DBusCallFlags.ALLOW_INTERACTIVE_AUTHORIZATION, CALL_MS, None).unpack()


def prop(path, iface, name):
    return call(path, "org.freedesktop.DBus.Properties", "Get",
                GLib.Variant("(ss)", (iface, name)), "(v)")[0]


def reply(ok, error=""):
    print(json.dumps({"ok": ok, "error": error} if not ok else {"ok": True}), flush=True)
    sys.exit(0 if ok else 1)


def wifi_device(iface):
    for dev in call(NM_PATH, NM, "GetDevices", None, "(ao)")[0]:
        if prop(dev, NM + ".Device", "DeviceType") != 2:      # NM_DEVICE_TYPE_WIFI
            continue
        if not iface and not prop(dev, NM + ".Device", "Managed"):
            continue
        if not iface or prop(dev, NM + ".Device", "Interface") == iface:
            return dev
    return None


def remove_same_ssid(ssid):
    for path in call(SETTINGS_PATH, NM + ".Settings", "ListConnections", None, "(ao)")[0]:
        try:
            s = call(path, NM + ".Settings.Connection", "GetSettings", None, "(a{sa{sv}})")[0]
        except GLib.Error:
            continue
        w = s.get("802-11-wireless")
        if w and bytes(w.get("ssid", b"")) == ssid:
            try:
                call(path, NM + ".Settings.Connection", "Delete")
            except GLib.Error:
                pass


def cert(path):
    """NM wants certificate paths as a NUL-terminated file:// byte array."""
    return GLib.Variant("ay", b"file://" + path.encode() + b"\0")


def s(v):
    return GLib.Variant("s", v)


def build(r):
    ssid = r["ssid"].encode()
    sec = r.get("security", "psk")
    settings = {
        "connection": {"id": s(r["ssid"]), "type": s("802-11-wireless"),
                       "autoconnect": GLib.Variant("b", True)},
        "802-11-wireless": {"ssid": GLib.Variant("ay", ssid), "mode": s("infrastructure")},
        "ipv4": {"method": s("auto")},
        "ipv6": {"method": s("auto")},
    }
    if r.get("hidden"):
        settings["802-11-wireless"]["hidden"] = GLib.Variant("b", True)
    pw = r.get("password", "")

    if sec == "open":
        return settings
    wsec = {}
    if sec in ("psk", "sae"):
        wsec = {"key-mgmt": s("sae" if sec == "sae" else "wpa-psk"), "psk": s(pw)}
    elif sec == "wep":
        # 5/13 characters or 10/26 hex digits = the key itself; anything else = passphrase
        is_key = len(pw) in (5, 13) or (len(pw) in (10, 26) and all(c in "0123456789abcdefABCDEF" for c in pw))
        wsec = {"key-mgmt": s("none"), "wep-key0": s(pw),
                "wep-key-type": GLib.Variant("u", 1 if is_key else 2), "wep-tx-keyidx": GLib.Variant("u", 0)}
    elif sec == "leap":
        wsec = {"key-mgmt": s("ieee8021x"), "auth-alg": s("leap"),
                "leap-username": s(r.get("identity", "")), "leap-password": s(pw)}
    elif sec == "eap":
        wsec = {"key-mgmt": s(r.get("keyMgmt") or "wpa-eap")}
        eap = r.get("eap", "peap")
        x = {"eap": GLib.Variant("as", [eap]), "identity": s(r.get("identity", ""))}
        if eap == "tls":
            if r.get("clientCert"):
                x["client-cert"] = cert(r["clientCert"])
            if r.get("privateKey"):
                x["private-key"] = cert(r["privateKey"])
            if r.get("keyPassword"):
                x["private-key-password"] = s(r["keyPassword"])
        else:
            x["password"] = s(pw)
        if eap in ("peap", "ttls"):
            x["phase2-auth"] = s(r.get("phase2") or "mschapv2")
            if r.get("anonymous"):
                x["anonymous-identity"] = s(r["anonymous"])
        if eap != "pwd":
            if r.get("caCert"):
                x["ca-cert"] = cert(r["caCert"])
            if r.get("domain"):
                x["domain-suffix-match"] = s(r["domain"])
        settings["802-1x"] = x
    else:
        reply(False, f"unknown security type: {sec}")
    settings["802-11-wireless-security"] = wsec
    settings["802-11-wireless"]["security"] = s("802-11-wireless-security")
    return settings


def main():
    try:
        r = json.loads(sys.stdin.readline())
    except ValueError:
        reply(False, "invalid request")
    if not r.get("ssid"):
        reply(False, "no network name")
    dev = wifi_device(r.get("iface", ""))
    if not dev:
        reply(False, "no Wi-Fi device")

    try:
        remove_same_ssid(r["ssid"].encode())
        conn, active = call(NM_PATH, NM, "AddAndActivateConnection",
                            GLib.Variant("(a{sa{sv}}oo)", (build(r), dev, "/")), "(oo)")
    except GLib.Error as e:
        Gio.DBusError.strip_remote_error(e)
        reply(False, e.message)

    # NM_ACTIVE_CONNECTION_STATE: 2 activated, 4 deactivated
    end = time.time() + TIMEOUT
    state = 0
    while time.time() < end:
        try:
            state = prop(active, NM + ".Connection.Active", "State")
        except GLib.Error:
            state = 4          # the active connection disappeared: it failed
        if state in (2, 4):
            break
        time.sleep(0.5)
    if state == 2:
        reply(True)
    try:
        call(conn, NM + ".Settings.Connection", "Delete")
    except GLib.Error:
        pass
    reply(False, "timeout" if state != 4 else "failed")


if __name__ == "__main__":
    main()
