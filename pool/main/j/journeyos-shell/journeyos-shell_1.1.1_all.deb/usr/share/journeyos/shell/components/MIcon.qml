import QtQuick
import qs

// Material Icons Round icon, by name (ligature): MIcon { icon: "wifi" }
Text {
    property string icon: ""
    property real size: Theme.barIcon

    text: icon
    font.family: Theme.iconFont
    font.pixelSize: size
    color: Theme.text
    renderType: Text.NativeRendering
    verticalAlignment: Text.AlignVCenter
    horizontalAlignment: Text.AlignHCenter

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }
}
