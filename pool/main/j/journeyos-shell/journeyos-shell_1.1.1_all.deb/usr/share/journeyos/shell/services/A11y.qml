pragma Singleton

import QtQuick
import Quickshell

// Accessibility: magnifier (KWin zoom effect), screen reader (Orca, via kaccess), sticky keys
// (kaccessrc) and reduced motion in the shell (config.json, a11y.reduceMotion; in Theme).
Singleton {
    id: root

    property bool zoom: false
    property bool screenReader: false
    property bool stickyKeys: false
    readonly property bool reduceMotion: Config.options.a11y.reduceMotion

    function refresh() {
        // The magnifier is on by default in Plasma 6
        Kcfg.readMany("kwinrc", [{ group: "Plugins", key: "zoomEnabled", fallback: "true" }], v => root.zoom = v["Plugins/zoomEnabled"] === "true");
        Kcfg.readMany("kaccessrc", [
            { group: "ScreenReader", key: "Enabled", fallback: "false" },
            { group: "Keyboard", key: "StickyKeys", fallback: "false" }
        ], v => {
            root.screenReader = v["ScreenReader/Enabled"] === "true";
            root.stickyKeys = v["Keyboard/StickyKeys"] === "true";
        });
    }

    function effect(name, on) {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/Effects",
            "--method", on ? "org.kde.kwin.Effects.loadEffect" : "org.kde.kwin.Effects.unloadEffect", name], () => refresh());
    }

    function setZoom(on) {
        Kcfg.write("kwinrc", "Plugins", "zoomEnabled", on, () => effect("zoom", on));
    }

    function setScreenReader(on) {
        Kcfg.write("kaccessrc", "ScreenReader", "Enabled", on, () => {
            if (on)
                Apps.run(["orca", "--replace"]);
            else
                Run.cmd(["pkill", "-x", "orca"]);
            refresh();
        });
    }

    // kaccess only reads sticky keys at startup: relaunch it
    function setStickyKeys(on) {
        Kcfg.write("kaccessrc", "Keyboard", "StickyKeys", on, () => {
            Run.sh("pkill -x kaccess; sleep 0.3", () => {
                Apps.run(["kaccess"]);
                refresh();
            });
        });
    }

    function setReduceMotion(on) { Config.options.a11y.reduceMotion = on; }
}
