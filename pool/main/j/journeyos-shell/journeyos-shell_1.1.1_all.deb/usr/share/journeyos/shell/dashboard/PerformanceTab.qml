import QtQuick
import QtQuick.Layouts
import Quickshell.Services.UPower
import qs
import qs.components
import qs.services

// Performance tab: CPU, memory and network with charts; disk, GPU and battery.
GridLayout {
    id: root

    columns: 3
    rowSpacing: Theme.gap
    columnSpacing: Theme.gap

    readonly property var battery: UPower.displayDevice
    readonly property bool hasBattery: battery?.isLaptopBattery ?? false
    // Quickshell gives the percentage in 0–1
    readonly property real batteryLevel: battery ? (battery.percentage > 1 ? battery.percentage / 100 : battery.percentage) : 0

    function gib(v) { return v.toLocaleString(Tr.locale, "f", 1) + " GiB"; }

    // CPU
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("Processor")
        icon: "memory"

        ColumnLayout {
            anchors.fill: parent
            spacing: 4

            Big { text: Math.round(Stats.cpu * 100) + "%" }
            Small { text: SystemInfo.cpu + (SystemInfo.cores ? " · " + SystemInfo.cores + Tr.t(" cores") : "") }
            Graph {
                Layout.fillWidth: true
                Layout.fillHeight: true
                values: Stats.cpuHistory
                capacity: Stats.historySize
            }
        }
    }

    // Memory
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("Memory")
        icon: "developer_board"

        ColumnLayout {
            anchors.fill: parent
            spacing: 4

            Big { text: Math.round(Stats.ram * 100) + "%" }
            Small { text: root.gib(Stats.ramUsedGiB) + Tr.t(" of ") + root.gib(Stats.ramTotalGiB) + Tr.t(" · swap ") + Math.round(Stats.swap * 100) + "%" }
            Graph {
                Layout.fillWidth: true
                Layout.fillHeight: true
                values: Stats.ramHistory
                capacity: Stats.historySize
            }
        }
    }

    // Network
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("Network")
        icon: "swap_vert"

        ColumnLayout {
            anchors.fill: parent
            spacing: 4

            RowLayout {
                spacing: 14
                Row {
                    spacing: 4
                    MIcon { icon: "download"; size: 18; anchors.verticalCenter: parent.verticalCenter }
                    Big { text: Stats.rate(Stats.netDown); font.pixelSize: Theme.fontLarge }
                }
                Row {
                    spacing: 4
                    MIcon { icon: "upload"; size: 18; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                    Big { text: Stats.rate(Stats.netUp); font.pixelSize: Theme.fontLarge; color: Theme.subtext }
                }
            }
            Small { text: Net.name || (Net.kind === "none" ? Tr.t("No connection") : "") }
            // Download in light, upload in grey, on the same scale
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                readonly property real peak: Math.max(1024, ...Stats.downHistory, ...Stats.upHistory)

                Graph {
                    anchors.fill: parent
                    values: Stats.downHistory
                    max: parent.peak
                    capacity: Stats.historySize
                }
                Graph {
                    anchors.fill: parent
                    values: Stats.upHistory
                    max: parent.peak
                    capacity: Stats.historySize
                    lineColor: Theme.dim
                    fillColor: "transparent"
                }
            }
        }
    }

    // Disk
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("Disk (/)")
        icon: "storage"

        RowLayout {
            anchors.fill: parent
            spacing: 14

            Ring {
                implicitWidth: 72
                implicitHeight: 72
                thickness: 5
                icon: "storage"
                value: Stats.disk
            }
            ColumnLayout {
                spacing: 2
                Big { text: Math.round(Stats.disk * 100) + "%" }
                Small { text: root.gib(Stats.diskUsedGiB) + Tr.t(" of ") + root.gib(Stats.diskTotalGiB) }
                Small { text: root.gib(Stats.diskTotalGiB - Stats.diskUsedGiB) + Tr.t(" free") }
            }
        }
    }

    // GPU
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("Graphics")
        icon: "monitor"

        RowLayout {
            anchors.fill: parent
            spacing: 14

            Ring {
                implicitWidth: 72
                implicitHeight: 72
                thickness: 5
                icon: "monitor"
                value: Stats.gpu
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Big { text: Stats.hasGpu ? Math.round(Stats.gpu * 100) + "%" : "—" }
                Small {
                    Layout.fillWidth: true
                    text: SystemInfo.gpu || Tr.t("No graphics card")
                    wrapMode: Text.Wrap
                    maximumLineCount: 3
                    elide: Text.ElideRight
                }
            }
        }
    }

    // Battery (or uptime, without a battery)
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: root.hasBattery ? Tr.t("Battery") : Tr.t("Uptime")
        icon: root.hasBattery ? "battery_full" : "schedule"

        RowLayout {
            anchors.fill: parent
            spacing: 14

            Ring {
                visible: root.hasBattery
                implicitWidth: 72
                implicitHeight: 72
                thickness: 5
                icon: "battery_full"
                value: root.batteryLevel
            }
            ColumnLayout {
                spacing: 2
                Big { text: root.hasBattery ? Math.round(root.batteryLevel * 100) + "%" : Stats.duration(Stats.uptime) }
                Small {
                    text: root.hasBattery
                        ? (root.battery.state === UPowerDeviceState.Charging ? Tr.t("Charging") : UPower.onBattery ? Tr.t("On battery") : Tr.t("Plugged in"))
                        : Tr.t("since last boot")
                }
            }
        }
    }

    component Big: Text {
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: 26
        font.weight: Font.Bold
    }

    component Small: Text {
        Layout.fillWidth: true
        elide: Text.ElideRight
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }
}
