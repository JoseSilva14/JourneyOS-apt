import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Calendars: online ones by ICS/webcal address (in Google: Calendar settings →
// "Secret address in iCal format"; in Nextcloud and Outlook: "Publish/share" → ICS) or
// a .ics file; and the reminder before each event.
Page {
    id: root

    SectionLabel { text: Tr.t("Calendars") }

    Repeater {
        model: Config.options.calendar.sources

        SettingRow {
            required property var modelData
            required property int index
            title: modelData.name
            description: modelData.url.replace(/^(https?|webcal):\/\//, "").slice(0, 60) + (modelData.url.length > 70 ? "…" : "")
            icon: "event"

            RowLayout {
                spacing: 10
                Rectangle {
                    implicitWidth: 14
                    implicitHeight: 14
                    radius: 7
                    color: modelData.color
                }
                PillButton {
                    text: Tr.t("Remove##tirar")
                    onClicked: Agenda.removeSource(index)
                }
            }
        }
    }

    Text {
        Layout.fillWidth: true
        visible: Config.options.calendar.sources.length === 0
        text: Tr.t("No calendars yet. Events you add in the Calendar (dashboard) stay on this computer only.")
        wrapMode: Text.Wrap
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // Add
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: form.implicitHeight + 32
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        ColumnLayout {
            id: form
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.margins: 16
            spacing: 10

            Text {
                Layout.fillWidth: true
                text: Tr.t("Add a calendar")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
            Text {
                Layout.fillWidth: true
                text: Tr.t("The ICS address (starts with https:// or webcal://) or the path of an .ics file. In Google Calendar: calendar settings → \"Secret address in iCal format\".")
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: name
                    implicitWidth: 150
                    placeholder: Tr.t("Name")
                    acceptOnBlur: false
                }
                TextField {
                    id: url
                    Layout.fillWidth: true
                    placeholder: "https://…/basic.ics"
                    acceptOnBlur: false
                    onAccepted: add.clicked()
                }
                PillButton {
                    id: add
                    text: Tr.t("Add##juntar")
                    accent: true
                    enabled: url.text.trim() !== ""
                    onClicked: {
                        if (!url.text.trim())
                            return;
                        Agenda.addSource(name.text.trim(), url.text);
                        name.text = "";
                        url.text = "";
                    }
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Alerts") }

    SettingRow {
        title: Tr.t("Remind before")
        description: Tr.t("An alert in the pill before each event (all-day ones don't alert).")
        icon: "notifications_active"
        Segmented {
            model: [
                { id: "0", label: Tr.t("No") },
                { id: "5", label: Tr.t("5 min") },
                { id: "10", label: Tr.t("10 min") },
                { id: "15", label: Tr.t("15 min") },
                { id: "30", label: Tr.t("30 min") }
            ]
            current: String(Config.options.calendar.remind)
            onSelected: id => Config.options.calendar.remind = Number(id)
        }
    }

    SettingRow {
        title: Tr.t("Next event in the pill")
        description: Tr.t("Shows the title and time left, from those minutes before until 5 min after it starts. Hover for time and place.")
        icon: "event_upcoming"
        Toggle {
            checked: Config.options.calendar.pill
            onToggled: on => Config.options.calendar.pill = on
        }
    }

    SettingRow {
        title: Agenda.loading ? Tr.t("Reading calendars…") : Agenda.events.length + Tr.t(" events in the coming weeks")
        description: Tr.t("Online calendars are read every 15 minutes (offline, the last copy stays).")
        icon: "sync"
        PillButton {
            text: Tr.t("Refresh now")
            enabled: !Agenda.loading
            onClicked: Agenda.refresh()
        }
    }
}
