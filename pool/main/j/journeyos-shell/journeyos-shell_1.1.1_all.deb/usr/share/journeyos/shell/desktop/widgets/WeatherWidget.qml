import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Current weather: icon, temperature, description and location.
Card {
    id: root

    width: 260
    height: 118

    RowLayout {
        anchors.fill: parent
        anchors.margins: Theme.cardPadding
        spacing: 14
        visible: Weather.ready

        MIcon {
            icon: Weather.icon
            size: 50
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 1

            Text {
                text: Weather.temp + "°"
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 34
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                text: Weather.desc
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
            Text {
                Layout.fillWidth: true
                text: Weather.area
                elide: Text.ElideRight
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }

    Text {
        anchors.centerIn: parent
        visible: !Weather.ready
        text: Tr.t("No weather data")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontNormal
    }
}
