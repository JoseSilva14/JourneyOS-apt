import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Web tab: web apps (sites with a name and icon that open in their own window). Clicking opens;
// on hover, edit and delete (delete asks for a second click). "+" opens the form on the
// right: name and address; the site icon is looked up automatically while typing the address and, if there
// there is none, pick one from the theme, an image, or go without (the initial).
RowLayout {
    id: root

    signal closeRequested

    spacing: Theme.gap

    // --- Form ---
    property bool editing: false
    property string editId: ""          // "" = new
    property string iconState: "idle"   // idle | searching | site | missing | custom | none
    property string icon: ""
    property string suggested: ""       // page title, for the name
    property var made: []               // PNGs created in this form (deleted if not kept)
    property string confirmDelete: ""

    function startAdd() {
        cancel();
        editId = "";
        nameInput.text = "";
        urlInput.text = "";
        icon = "";
        iconState = "idle";
        suggested = "";
        editing = true;
        urlInput.forceActiveFocus();
    }

    function startEdit(app) {
        cancel();
        editId = app.id;
        nameInput.text = app.name;
        urlInput.text = app.url;
        icon = app.icon;
        iconState = app.icon ? "custom" : "none";
        suggested = "";
        editing = true;
        nameInput.forceActiveFocus();
    }

    function cleanUp(keep) {
        for (const p of made)
            if (p !== keep)
                Webapps.dropIcon(p);
        made = [];
    }

    function cancel() {
        if (editing)
            cleanUp("");
        editing = false;
        searchTimer.stop();
    }

    readonly property bool canSave: Webapps.valid(urlInput.text) && iconState !== "searching"

    function submit() {
        if (!canSave)
            return;
        const old = Webapps.apps.find(a => a.id === editId);
        Webapps.save({ id: editId, name: nameInput.text || suggested, url: urlInput.text, icon: icon,
            created: old?.created });
        cleanUp(icon);
        editing = false;
    }

    function searchIcon() {
        const url = urlInput.text;
        if (!Webapps.valid(url))
            return;
        iconState = "searching";
        Webapps.findIcon(url, r => {
            if (!root.editing || urlInput.text !== url)
                return;
            if (r.icon)
                root.made = [...root.made, r.icon];
            root.icon = r.icon;
            root.iconState = r.icon ? "site" : "missing";
            root.suggested = r.title || Webapps.guessName(url);
        });
    }

    // While typing the address, looks up the icon (unless one was chosen by hand)
    Timer {
        id: searchTimer
        interval: 800
        onTriggered: root.searchIcon()
    }

    // --- List ---
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true

        ColumnLayout {
            anchors.fill: parent
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                MIcon {
                    icon: "language"
                    size: 15
                    color: Theme.subtext
                }
                Text {
                    Layout.fillWidth: true
                    text: Tr.t("Web apps")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                    font.weight: Font.DemiBold
                }
                RoundButton {
                    visible: Webapps.apps.length > 0
                    glyph: "add"
                    accent: !root.editing || root.editId !== ""
                    onClicked: root.startAdd()
                }
            }

            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: Webapps.apps.length > 0
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                readonly property int columns: Math.max(3, Math.floor(width / 112))
                cellWidth: width / columns
                cellHeight: 112
                model: Webapps.sorted

                delegate: Item {
                    id: cell
                    required property var modelData
                    readonly property bool selected: root.editing && root.editId === modelData.id
                    readonly property bool hovered: cellMouse.containsMouse || editMouse.containsMouse || deleteMouse.containsMouse

                    width: grid.cellWidth
                    height: grid.cellHeight

                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 4
                        radius: Theme.radius
                        color: cell.hovered || cell.selected ? Theme.buttonHover : "transparent"
                        border.width: cell.selected ? 1 : 0
                        border.color: Theme.accent
                        scale: cellMouse.pressed ? 0.95 : 1

                        Behavior on scale {
                            NumberAnimation { duration: Theme.animFast }
                        }

                        ColumnLayout {
                            anchors.fill: parent
                            anchors.margins: 8
                            anchors.topMargin: 12
                            spacing: 4

                            AppIcon {
                                Layout.alignment: Qt.AlignHCenter
                                icon: cell.modelData.icon
                                name: cell.modelData.name
                                size: 44
                            }
                            Text {
                                Layout.fillWidth: true
                                text: cell.modelData.name
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                            Text {
                                Layout.fillWidth: true
                                text: Webapps.host(cell.modelData.url)
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                                color: Theme.dim
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall - 2
                            }
                        }

                        MouseArea {
                            id: cellMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            cursorShape: Qt.PointingHandCursor
                            onClicked: m => {
                                if (m.button === Qt.RightButton) {
                                    root.startEdit(cell.modelData);
                                } else {
                                    Webapps.open(cell.modelData);
                                    root.closeRequested();
                                }
                            }
                            onExited: if (root.confirmDelete === cell.modelData.id && !deleteMouse.containsMouse) root.confirmDelete = ""
                        }

                        // Edit and delete, on hover
                        Row {
                            anchors.top: parent.top
                            anchors.right: parent.right
                            anchors.margins: 4
                            spacing: 2
                            visible: cell.hovered

                            CornerButton {
                                id: editButton
                                glyph: "edit"
                                MouseArea {
                                    id: editMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: root.startEdit(cell.modelData)
                                }
                                hot: editMouse.containsMouse
                            }
                            CornerButton {
                                glyph: root.confirmDelete === cell.modelData.id ? "delete_forever" : "close"
                                danger: root.confirmDelete === cell.modelData.id
                                hot: deleteMouse.containsMouse
                                MouseArea {
                                    id: deleteMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        if (root.confirmDelete === cell.modelData.id) {
                                            if (root.editId === cell.modelData.id)
                                                root.cancel();
                                            Webapps.remove(cell.modelData.id);
                                            root.confirmDelete = "";
                                        } else {
                                            root.confirmDelete = cell.modelData.id;
                                        }
                                    }
                                    onExited: if (!cellMouse.containsMouse) root.confirmDelete = ""
                                }
                            }
                        }
                    }
                }
            }

            // None at all
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: Webapps.apps.length === 0

            ColumnLayout {
                anchors.centerIn: parent
                width: Math.min(parent.width, 400)
                spacing: 10
                MIcon {
                    Layout.alignment: Qt.AlignHCenter
                    icon: "language"
                    size: 40
                    color: Theme.dim
                }
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: Tr.t("No web apps yet")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontMedium
                    font.weight: Font.DemiBold
                }
                Text {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: Tr.t("Add the sites you use as apps (mail, chat, music…): they get their own icon, in the launcher and the dock.")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                TextButton {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: 4
                    visible: !root.editing
                    text: Tr.t("Add web app")
                    glyph: "add"
                    accent: true
                    onClicked: root.startAdd()
                }
            }
            }
        }
    }

    // --- Form (on the right, when adding or editing) ---
    Tile {
        Layout.preferredWidth: 320
        Layout.minimumWidth: 320
        Layout.maximumWidth: 320
        Layout.fillHeight: true
        visible: root.editing

        ColumnLayout {
            anchors.fill: parent
            spacing: 10

            Text {
                text: root.editId ? Tr.t("Edit web app") : Tr.t("New web app")
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }

            // Icon and what is known about it
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    implicitWidth: 64
                    implicitHeight: 64
                    radius: Theme.radius
                    color: Theme.button

                    AppIcon {
                        anchors.centerIn: parent
                        visible: root.iconState !== "searching"
                        icon: root.icon
                        name: nameInput.text || root.suggested || Webapps.host(urlInput.text) || "?"
                        size: 44
                    }
                    MIcon {
                        anchors.centerIn: parent
                        visible: root.iconState === "searching"
                        icon: "hourglass_top"
                        size: 24
                        color: Theme.dim
                    }
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    text: root.iconState === "searching" ? Tr.t("Looking for the site icon…")
                        : root.iconState === "site" ? Tr.t("Site icon.")
                        : root.iconState === "missing" ? Tr.t("This site has no icon. Choose one or leave it without (shows the initial).")
                        : root.iconState === "custom" ? Tr.t("Chosen icon.")
                        : root.iconState === "none" ? Tr.t("No icon: shows the initial.")
                        : Tr.t("The site icon appears as you type the address.")
                    color: root.iconState === "missing" ? Theme.text : Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }

            Flow {
                Layout.fillWidth: true
                spacing: 6

                TextButton {
                    text: Tr.t("From site")
                    glyph: "travel_explore"
                    small: true
                    visible: root.iconState !== "site" && root.iconState !== "searching"
                    enabled: Webapps.valid(urlInput.text)
                    onClicked: root.searchIcon()
                }
                TextButton {
                    text: Tr.t("Icon…")
                    glyph: "interests"
                    small: true
                    onClicked: Webapps.pickThemeIcon(name => {
                        root.icon = name;
                        root.iconState = "custom";
                    })
                }
                TextButton {
                    text: Tr.t("Image…")
                    glyph: "image"
                    small: true
                    onClicked: Webapps.pickImage(path => {
                        if (!path)
                            return;
                        root.made = [...root.made, path];
                        root.icon = path;
                        root.iconState = "custom";
                    })
                }
                TextButton {
                    text: Tr.t("No icon")
                    glyph: "block"
                    small: true
                    visible: root.icon !== ""
                    onClicked: {
                        root.icon = "";
                        root.iconState = "none";
                    }
                }
            }

            Field {
                id: urlField
                Layout.fillWidth: true
                glyph: "link"
                TextInput {
                    id: urlInput
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    clip: true
                    inputMethodHints: Qt.ImhUrlCharactersOnly
                    onTextEdited: {
                        // A new address: the icon comes from the site again (unless one was chosen)
                        if (root.iconState !== "custom") {
                            root.iconState = "idle";
                            root.icon = "";
                            searchTimer.restart();
                        }
                    }
                    onAccepted: root.submit()
                    KeyNavigation.tab: nameInput
                    Keys.onEscapePressed: root.cancel()

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !urlInput.text
                        text: Tr.t("Address (e.g. web.whatsapp.com)")
                        color: Theme.dim
                        font: urlInput.font
                    }
                }
            }

            Field {
                Layout.fillWidth: true
                glyph: "badge"
                TextInput {
                    id: nameInput
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    clip: true
                    maximumLength: 40
                    onAccepted: root.submit()
                    KeyNavigation.tab: urlInput
                    Keys.onEscapePressed: root.cancel()

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !nameInput.text
                        text: root.suggested || Tr.t("Name")
                        color: Theme.dim
                        font: nameInput.font
                    }
                }
            }

            Item { Layout.fillHeight: true }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Item { Layout.fillWidth: true }
                TextButton {
                    text: Tr.t("Cancel")
                    onClicked: root.cancel()
                }
                TextButton {
                    text: root.editId ? Tr.t("Save") : Tr.t("Add##juntar")
                    accent: true
                    enabled: root.canSave
                    onClicked: root.submit()
                }
            }
        }
    }

    // Web app icon: PNG, theme icon, or the initial
    component AppIcon: Item {
        id: appIcon
        property string icon: ""
        property string name: ""
        property int size: 44
        implicitWidth: size
        implicitHeight: size

        IconImage {
            id: themed
            anchors.fill: parent
            source: Webapps.iconSource(appIcon.icon)
            visible: appIcon.icon !== "" && status === Image.Ready
        }
        Rectangle {
            anchors.fill: parent
            visible: !themed.visible
            radius: 12
            color: Theme.accent

            Text {
                anchors.centerIn: parent
                text: appIcon.name.charAt(0).toUpperCase()
                color: Theme.accentText
                font.family: Theme.font
                font.pixelSize: appIcon.size * 0.45
                font.weight: Font.Bold
            }
        }
    }

    component Field: Rectangle {
        id: field
        property string glyph: ""
        default property alias content: fieldRow.data
        implicitHeight: 36
        radius: height / 2
        color: Theme.button

        RowLayout {
            id: fieldRow
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 14
            spacing: 8

            MIcon {
                icon: field.glyph
                size: 16
                color: Theme.subtext
            }
        }
    }

    component CornerButton: Rectangle {
        property string glyph: ""
        property bool hot: false
        property bool danger: false
        width: 26
        height: 26
        radius: 13
        color: danger ? "#e5484d" : hot ? Theme.surfaceCardHover : Theme.surfaceCard
        border.width: danger ? 0 : 1
        border.color: Theme.surfaceBorder

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: parent.glyph
            size: 14
            color: parent.danger ? "#ffffff" : Theme.subtext
        }
    }

    component RoundButton: Rectangle {
        id: button
        property string glyph: ""
        property bool accent: false
        signal clicked
        implicitWidth: 30
        implicitHeight: 30
        radius: 15
        color: accent ? Theme.accent : buttonMouse.containsMouse ? Theme.buttonHover : "transparent"
        scale: buttonMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: button.glyph
            size: 17
            color: button.accent ? Theme.accentText : Theme.subtext
        }
        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }

    component TextButton: Rectangle {
        id: tb
        property string text: ""
        property string glyph: ""
        property bool accent: false
        property bool small: false
        signal clicked
        implicitHeight: small ? 28 : 34
        implicitWidth: tbRow.implicitWidth + (small ? 20 : 28)
        radius: height / 2
        opacity: enabled ? 1 : 0.4
        color: accent ? Theme.accent : tbMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: tbMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Row {
            id: tbRow
            anchors.centerIn: parent
            spacing: 6

            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                visible: tb.glyph !== ""
                icon: tb.glyph
                size: tb.small ? 14 : 16
                color: tb.accent ? Theme.accentText : Theme.subtext
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: tb.text
                color: tb.accent ? Theme.accentText : Theme.text
                font.family: Theme.font
                font.pixelSize: tb.small ? Theme.fontSmall : Theme.fontNormal
                font.weight: Font.DemiBold
            }
        }
        MouseArea {
            id: tbMouse
            anchors.fill: parent
            enabled: tb.enabled
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tb.clicked()
        }
    }
}
