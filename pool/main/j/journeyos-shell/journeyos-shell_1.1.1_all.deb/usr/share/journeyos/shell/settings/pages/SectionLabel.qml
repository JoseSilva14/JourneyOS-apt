import QtQuick
import QtQuick.Layouts
import qs

// Title of a group of rows.
Text {
    Layout.fillWidth: true
    Layout.topMargin: 10
    Layout.bottomMargin: 2
    color: Theme.subtext
    font.family: Theme.font
    font.pixelSize: Theme.fontSmall
    font.weight: Font.Bold
}
