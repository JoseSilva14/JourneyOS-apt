import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Launcher apps: hide those the shell replaces (KCalc → Calculator, Spectacle → Capture,
// System Settings → Settings…) and those the user has hidden. Nothing is uninstalled.
Page {
    id: root

    readonly property var all: Launcher.allApps.slice().sort((a, b) => a.name.localeCompare(b.name))
    readonly property var replacedApps: all.filter(e => e.id in ShellApps.replaced)
    readonly property var otherApps: all.filter(e => ShellApps.otherDesktops.includes(e.id))
    readonly property var userHidden: all.filter(e => Config.options.launcher.hidden.includes(e.id) && !(e.id in ShellApps.replaced))

    SectionLabel { text: Tr.t("Apps replaced by the shell") }

    SettingRow {
        title: Tr.t("Hide apps the shell replaces")
        description: Tr.t("They don't show in the launcher or the Apps tab (they stay installed). ") + root.replacedApps.length + Tr.t(" apps.")
        icon: "visibility_off"
        Toggle {
            checked: Config.options.launcher.hideReplaced
            onToggled: on => Config.options.launcher.hideReplaced = on
        }
    }

    Repeater {
        model: root.replacedApps

        SettingRow {
            id: row
            required property var modelData
            readonly property bool hidden: ShellApps.isHidden(modelData.id)
            Layout.leftMargin: 28
            title: modelData.name
            description: ShellApps.replaced[modelData.id]
            iconSource: modelData.icon
            Toggle {
                // On = shown
                checked: !row.hidden
                onToggled: on => ShellApps.setHidden(row.modelData.id, !on)
            }
        }
    }

    SectionLabel { text: Tr.t("Hidden by you") }

    SettingRow {
        visible: root.userHidden.length === 0
        title: Tr.t("None##f")
        description: Tr.t("In the dashboard's Apps tab, hover an app and click the eye to hide it.")
        icon: "visibility"
    }

    Repeater {
        model: root.userHidden

        SettingRow {
            id: urow
            required property var modelData
            title: modelData.name
            description: modelData.genericName || modelData.comment || ""
            iconSource: modelData.icon
            PillButton {
                text: Tr.t("Show")
                onClicked: ShellApps.setHidden(urow.modelData.id, false)
            }
        }
    }

    SectionLabel {
        visible: root.otherApps.length > 0
        text: Tr.t("Made for other desktops")
    }

    SettingRow {
        visible: root.otherApps.length > 0
        title: root.otherApps.map(e => e.name).join(", ")
        description: Tr.t("These entries say they're not for KDE (they're the GNOME, XFCE… versions): always hidden.")
        icon: "block"
    }
}
