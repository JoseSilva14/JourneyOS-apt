import QtQuick
import Quickshell
import qs
import qs.components
import qs.services
import "widgets"

// The widgets from config.json, at their positions. While editing: dashed outline,
// drag to move, the corner to resize, and buttons for style and remove.
// User widgets are loaded from file (Widgets.sourceFor) and receive, if they declare them,
// the contract properties (WIDGETS.md): plain, options, editing, widgetId, widgetDir.
Item {
    id: root

    property bool editing: false

    // Widgets grow with the screen height (reference: 1080 px)
    readonly property real uiScale: Math.max(0.8, Math.min(1.4, height / 1080))

    // Free space: below the bar and away from the edges
    readonly property real areaLeft: Theme.edge
    readonly property real areaTop: Theme.barZone + Math.round(Theme.edge * 0.6)
    readonly property real areaRight: width - Theme.edge
    readonly property real areaBottom: height - Theme.edge

    Repeater {
        model: ScriptModel {
            values: Widgets.items.map(i => i.id)
        }

        delegate: Item {
            id: frame

            required property string modelData
            readonly property var cfg: Widgets.items.find(i => i.id === modelData) ?? ({})
            readonly property real s: root.uiScale * (cfg.scale ?? 1)

            // While dragging/resizing: local values until release
            property bool dragging: false
            property real dragX: 0
            property real dragY: 0
            property real liveScale: 1
            property bool resizing: false

            readonly property real shownScale: resizing ? root.uiScale * liveScale : s
            readonly property real rangeX: Math.max(1, root.areaRight - root.areaLeft - width)
            readonly property real rangeY: Math.max(1, root.areaBottom - root.areaTop - height)
            readonly property real posX: dragging ? dragX : (cfg.x ?? 0.5)
            readonly property real posY: dragging ? dragY : (cfg.y ?? 0.5)

            // What is shown: the widget or, if missing or with errors, the warning card
            readonly property bool broken: loader.status === Loader.Error
                || (Widgets.scanned && loader.source.toString() === "" && frame.cfg.type !== undefined)
            readonly property Item content: broken ? missing : loader.item

            width: (content?.width ?? 0) * shownScale
            height: (content?.height ?? 0) * shownScale
            x: root.areaLeft + Math.max(0, Math.min(1, posX)) * rangeX
            y: root.areaTop + Math.max(0, Math.min(1, posY)) * rangeY

            Loader {
                id: loader
                scale: frame.shownScale
                transformOrigin: Item.TopLeft
                source: Widgets.sourceFor(frame.cfg.type)
                // Only the properties the widget declares (transparent style on those that are cards)
                onLoaded: {
                    const t = Widgets.types[frame.cfg.type];
                    if ("plain" in item)
                        item.plain = Qt.binding(() => frame.cfg.style === "plain");
                    if ("options" in item)
                        item.options = Qt.binding(() => Widgets.optionsFor(frame.cfg));
                    if ("editing" in item)
                        item.editing = Qt.binding(() => root.editing);
                    if ("widgetId" in item)
                        item.widgetId = frame.modelData;
                    if ("widgetDir" in item && t?.user)
                        item.widgetDir = t.dir;
                }
            }

            // Type that no longer exists, with errors in the manifest or the QML
            Card {
                id: missing
                visible: frame.broken
                scale: frame.shownScale
                transformOrigin: Item.TopLeft
                width: 300
                height: 96

                readonly property var info: Widgets.types[frame.cfg.type]

                Row {
                    anchors.fill: parent
                    anchors.margins: Theme.cardPadding
                    spacing: 12

                    MIcon {
                        anchors.verticalCenter: parent.verticalCenter
                        icon: "extension_off"
                        size: 26
                        color: Theme.subtext
                    }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 38
                        spacing: 3
                        Text {
                            width: parent.width
                            text: missing.info?.name ?? (frame.cfg.type ?? "").replace("user/", "")
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: Font.Bold
                        }
                        Text {
                            width: parent.width
                            text: !missing.info ? Tr.t("This widget is no longer installed.")
                                : missing.info.error ? missing.info.error
                                : Tr.t("The QML has errors (check the shell log).")
                            wrapMode: Text.Wrap
                            maximumLineCount: 2
                            elide: Text.ElideRight
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                    }
                }
            }

            // --- Editing ---

            // Dashed outline
            Canvas {
                id: outline
                anchors.fill: parent
                anchors.margins: -6
                visible: root.editing
                onWidthChanged: requestPaint()
                onHeightChanged: requestPaint()
                onVisibleChanged: requestPaint()
                property bool hot: move.containsMouse || frame.dragging || frame.resizing
                onHotChanged: requestPaint()
                onPaint: {
                    const ctx = getContext("2d");
                    ctx.reset();
                    ctx.strokeStyle = hot ? Theme.accent : Theme.subtext;
                    ctx.lineWidth = 1.5;
                    ctx.setLineDash([5, 4]);
                    const r = Theme.radiusCard + 4;
                    ctx.beginPath();
                    ctx.roundedRect(1, 1, width - 2, height - 2, r, r);
                    ctx.stroke();
                }
            }

            // Move: drag the widget
            MouseArea {
                id: move
                anchors.fill: parent
                visible: root.editing
                hoverEnabled: true
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor

                property point start
                property real startX
                property real startY

                onPressed: m => {
                    const p = mapToItem(root, m.x, m.y);
                    start = p;
                    startX = frame.posX;
                    startY = frame.posY;
                    frame.dragX = startX;
                    frame.dragY = startY;
                    frame.dragging = true;
                }
                onPositionChanged: m => {
                    if (!pressed)
                        return;
                    const p = mapToItem(root, m.x, m.y);
                    frame.dragX = Math.max(0, Math.min(1, startX + (p.x - start.x) / frame.rangeX));
                    frame.dragY = Math.max(0, Math.min(1, startY + (p.y - start.y) / frame.rangeY));
                }
                onReleased: {
                    Widgets.update(frame.modelData, { x: frame.dragX, y: frame.dragY });
                    frame.dragging = false;
                }
            }

            // Buttons at the top: style and remove
            Row {
                visible: root.editing
                anchors.right: parent.right
                anchors.bottom: parent.top
                anchors.bottomMargin: 10
                spacing: 6

                EditButton {
                    visible: !frame.broken && (loader.item ? ("plain" in loader.item) : false)
                    icon: frame.cfg.style === "plain" ? "layers" : "opacity"
                    onClicked: Widgets.update(frame.modelData, { style: frame.cfg.style === "plain" ? "card" : "plain" })
                }
                // Options (from the user widgets' manifest): in Settings
                EditButton {
                    visible: (Widgets.types[frame.cfg.type]?.options?.length ?? 0) > 0
                    icon: "tune"
                    onClicked: {
                        Widgets.editing = false;
                        SettingsApp.show("desktop");
                    }
                }
                EditButton {
                    icon: "delete"
                    onClicked: Widgets.remove(frame.modelData)
                }
            }

            // Resize: the bottom-right corner
            Rectangle {
                visible: root.editing
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.margins: -14
                width: 24
                height: 24
                radius: 12
                color: Theme.accent

                MIcon {
                    anchors.centerIn: parent
                    icon: "open_in_full"
                    size: 14
                    color: Theme.accentText
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.SizeFDiagCursor

                    property real startW
                    property real startScale
                    property real startX

                    onPressed: m => {
                        startX = mapToItem(root, m.x, m.y).x;
                        startW = frame.width;
                        startScale = frame.cfg.scale ?? 1;
                        frame.liveScale = startScale;
                        frame.resizing = true;
                    }
                    onPositionChanged: m => {
                        if (!pressed)
                            return;
                        const dx = mapToItem(root, m.x, m.y).x - startX;
                        frame.liveScale = Math.max(0.5, Math.min(2, startScale * (startW + dx) / Math.max(1, startW)));
                    }
                    onReleased: {
                        Widgets.update(frame.modelData, { scale: Math.round(frame.liveScale * 100) / 100 });
                        frame.resizing = false;
                    }
                }
            }
        }
    }

    component EditButton: Rectangle {
        id: button

        property string icon: ""
        signal clicked

        width: 30
        height: 30
        radius: 15
        color: buttonMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: button.icon
            size: 16
        }

        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }
}
