import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Month calendar, with arrows to change month and today in a circle; a dot on days
// with events (services/Agenda). Clicking a day: "picked" (with selection) or opens the Agenda on that day.
Card {
    id: root

    width: 340
    height: 340

    // With selection (the Agenda tab): the chosen day gets a ring
    property bool selectable: false
    property date selected: new Date()
    signal picked(date day)

    readonly property var locale: Tr.locale

    SystemClock {
        id: clock
        precision: SystemClock.Hours
    }

    // Displayed month (relative to the current one)
    property int offset: 0
    readonly property date today: clock.date
    readonly property date month: new Date(today.getFullYear(), today.getMonth() + offset, 1)

    // 42 days starting on the Monday before day 1
    readonly property var days: {
        const first = new Date(month.getFullYear(), month.getMonth(), 1);
        const lead = (first.getDay() + 6) % 7;
        const out = [];
        for (let i = 0; i < 42; i++) {
            const d = new Date(first.getFullYear(), first.getMonth(), 1 - lead + i);
            out.push({
                date: d,
                day: d.getDate(),
                inMonth: d.getMonth() === first.getMonth(),
                today: d.toDateString() === today.toDateString()
            });
        }
        return out;
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Theme.cardPadding
        spacing: 10

        RowLayout {
            Layout.fillWidth: true

            Text {
                Layout.fillWidth: true
                text: {
                    const m = root.locale.standaloneMonthName(root.month.getMonth());
                    return m.charAt(0).toUpperCase() + m.slice(1) + " " + root.month.getFullYear();
                }
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontMedium
                font.weight: Font.Bold
            }

            NavButton {
                icon: "chevron_left"
                onClicked: root.offset--
            }
            NavButton {
                icon: "chevron_right"
                onClicked: root.offset++
            }
        }

        GridLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            columns: 7
            rowSpacing: 0
            columnSpacing: 0

            // Mon … Sun
            Repeater {
                model: 7
                Text {
                    required property int index
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    text: {
                        const n = root.locale.dayName((index + 1) % 7, Locale.ShortFormat).replace(".", "");
                        return n.charAt(0).toUpperCase() + n.slice(1, 3);
                    }
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }

            Repeater {
                model: root.days

                Item {
                    id: cell
                    required property var modelData
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    Rectangle {
                        anchors.centerIn: parent
                        width: Math.min(parent.width, parent.height) - 4
                        height: width
                        radius: width / 2
                        color: Theme.accent
                        visible: cell.modelData.today
                    }

                    // The chosen one (if not today): a ring
                    Rectangle {
                        anchors.centerIn: parent
                        width: Math.min(parent.width, parent.height) - 4
                        height: width
                        radius: width / 2
                        color: "transparent"
                        border.width: 1.5
                        border.color: Theme.accent
                        visible: root.selectable && !cell.modelData.today
                            && cell.modelData.date.toDateString() === root.selected.toDateString()
                    }

                    // Day with events: a dot below the number
                    Rectangle {
                        readonly property string busy: Agenda.busy(cell.modelData.date)
                        visible: busy !== ""
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: dayText.bottom
                        anchors.topMargin: 1
                        width: 4
                        height: 4
                        radius: 2
                        color: cell.modelData.today ? Theme.accentText : busy === "accent" ? Theme.accent : busy
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            if (root.selectable) {
                                root.picked(cell.modelData.date);
                            } else {
                                Agenda.focusDay = cell.modelData.date;
                                Dashboard.toggle("agenda", null);
                            }
                        }
                    }

                    Text {
                        id: dayText
                        anchors.centerIn: parent
                        text: cell.modelData.day
                        color: cell.modelData.today ? Theme.accentText
                            : cell.modelData.inMonth ? Theme.text : Theme.faint
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: cell.modelData.today ? Font.Bold : Font.Normal
                    }
                }
            }
        }
    }

    // Clicking the title goes back to the current month
    MouseArea {
        x: Theme.cardPadding
        y: Theme.cardPadding
        width: parent.width / 2
        height: 28
        cursorShape: root.offset !== 0 ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: root.offset = 0
    }

    component NavButton: Rectangle {
        id: nav

        property string icon: ""
        signal clicked

        implicitWidth: 30
        implicitHeight: 30
        radius: width / 2
        color: navMouse.containsMouse ? Theme.buttonHover : Theme.button

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: nav.icon
            size: 18
            color: Theme.subtext
        }

        MouseArea {
            id: navMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: nav.clicked()
        }
    }
}
