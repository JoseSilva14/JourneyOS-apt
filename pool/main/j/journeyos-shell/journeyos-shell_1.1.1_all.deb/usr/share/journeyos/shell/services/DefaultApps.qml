pragma Singleton

import QtQuick
import Quickshell

// Default apps (scripts/default-apps.py: xdg-mime and, for the terminal, kdeglobals).
Singleton {
    id: root

    property var data: ({})             // { category: { current, candidates } }

    readonly property var categories: [
        { id: "browser", label: Tr.t("Browser"), icon: "public" },
        { id: "email", label: "Email", icon: "mail" },
        { id: "files", label: Tr.t("Files"), icon: "folder" },
        { id: "terminal", label: "Terminal", icon: "terminal" },
        { id: "text", label: Tr.t("Text editor"), icon: "edit_note" },
        { id: "image", label: Tr.t("Images"), icon: "image" },
        { id: "video", label: Tr.t("Video"), icon: "movie" },
        { id: "music", label: Tr.t("Music"), icon: "music_note" },
        { id: "pdf", label: "PDF", icon: "picture_as_pdf" }
    ]

    function refresh() {
        Run.cmd([Quickshell.shellPath("scripts/default-apps.py"), "list"], (code, out) => {
            try {
                root.data = JSON.parse(out);
            } catch (e) {
            }
        });
    }

    function set(category, id) {
        Run.cmd([Quickshell.shellPath("scripts/default-apps.py"), "set", category, id], () => refresh());
    }
}
