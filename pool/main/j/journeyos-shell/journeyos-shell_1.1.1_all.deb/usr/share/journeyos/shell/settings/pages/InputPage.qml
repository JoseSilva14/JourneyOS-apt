import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Keyboard and mouse: keyboard layouts and repeat; mouse speed, natural scrolling and
// left-handed mode; and the touchpad, if there is one.
Page {
    id: root

    Component.onCompleted: Input.refresh()

    // --- Keyboard ---
    SectionLabel { text: Tr.t("Keyboard") }

    Repeater {
        model: Input.layouts

        SettingRow {
            required property string modelData
            required property int index
            title: Input.layoutName(modelData)
            description: index === 0 ? Tr.t("Default") : Tr.t("Switch layout with Meta+Alt+K")
            icon: "keyboard"

            Row {
                spacing: 6
                SmallButton {
                    visible: index > 0
                    icon: "arrow_upward"
                    onClicked: {
                        const l = Input.layouts.slice();
                        [l[index - 1], l[index]] = [l[index], l[index - 1]];
                        Input.setLayouts(l);
                    }
                }
                SmallButton {
                    visible: Input.layouts.length > 1
                    icon: "remove_circle_outline"
                    onClicked: Input.setLayouts(Input.layouts.filter((_, i) => i !== index))
                }
            }
        }
    }

    SettingRow {
        title: Input.layouts.length ? Tr.t("Add a layout") : Tr.t("Keyboard layout")
        description: Input.layouts.length ? "" : Tr.t("With none chosen, uses the system's.")
        icon: "add"
        Select {
            options: Input.allLayouts.filter(l => !Input.layouts.includes(l.id)).map(l => ({ id: l.id, label: l.name }))
            placeholder: Tr.t("Choose…")
            onSelected: id => Input.setLayouts([...Input.layouts, id])
        }
    }

    SettingRow {
        title: Tr.t("Delay before repeat · ") + Input.repeatDelay + Tr.t(" ms")
        description: Tr.t("How long a held key waits before it starts repeating.")
        icon: "hourglass_empty"
        Slider {
            implicitWidth: 220
            value: (Input.repeatDelay - 150) / (1000 - 150)
            onMoved: v => delay.restartWith(Math.round(150 + v * 850))
            Timer {
                id: delay
                property int target: 0
                function restartWith(t) { target = t; restart(); }
                interval: 400
                onTriggered: Input.setRepeat("RepeatDelay", target)
            }
        }
    }

    SettingRow {
        title: Tr.t("Repeat rate · ") + Input.repeatRate + Tr.t(" per second")
        icon: "fast_forward"
        Slider {
            implicitWidth: 220
            value: (Input.repeatRate - 5) / (60 - 5)
            onMoved: v => rate.restartWith(Math.round(5 + v * 55))
            Timer {
                id: rate
                property int target: 0
                function restartWith(t) { target = t; restart(); }
                interval: 400
                onTriggered: Input.setRepeat("RepeatRate", target)
            }
        }
    }

    // --- Mouse ---
    SectionLabel {
        visible: Input.mice.length > 0
        text: Tr.t("Mouse")
    }

    PointerSettings {
        visible: Input.mice.length > 0
        list: Input.mice
    }

    // --- Touchpad ---
    SectionLabel {
        visible: Input.touchpads.length > 0
        text: "Touchpad"
    }

    PointerSettings {
        visible: Input.touchpads.length > 0
        list: Input.touchpads
        touchpad: true
    }

    // Settings shared by mice and touchpads (applied to every device of that type)
    component PointerSettings: ColumnLayout {
        id: ps

        property var list: []
        property bool touchpad: false
        readonly property var first: list[0] ?? ({})

        Layout.fillWidth: true
        spacing: 8

        SettingRow {
            title: Tr.t("Speed")
            icon: "speed"
            Slider {
                implicitWidth: 220
                // KWin acceleration ranges from -1 to 1
                value: ((ps.first.pointerAcceleration ?? 0) + 1) / 2
                onMoved: v => speed.restartWith(Math.round((v * 2 - 1) * 100) / 100)
                Timer {
                    id: speed
                    property real target: 0
                    function restartWith(t) { target = t; restart(); }
                    interval: 300
                    onTriggered: Input.setAll(ps.list, "pointerAcceleration", target)
                }
            }
        }
        SettingRow {
            title: Tr.t("Acceleration")
            description: Tr.t("When on, the pointer moves further when the mouse moves fast.")
            icon: "trending_up"
            Toggle {
                checked: !(ps.first.pointerAccelerationProfileFlat ?? false)
                onToggled: on => Input.setAll(ps.list, "pointerAccelerationProfileFlat", !on)
            }
        }
        SettingRow {
            title: Tr.t("Natural scrolling")
            description: Tr.t("Content follows your finger, like on a phone.")
            icon: "swap_vert"
            Toggle {
                checked: ps.first.naturalScroll ?? false
                onToggled: on => Input.setAll(ps.list, "naturalScroll", on)
            }
        }
        SettingRow {
            visible: ps.touchpad
            title: Tr.t("Tap to click")
            icon: "touch_app"
            Toggle {
                checked: ps.first.tapToClick ?? false
                onToggled: on => Input.setAll(ps.list, "tapToClick", on)
            }
        }
        SettingRow {
            visible: ps.touchpad && (ps.first.supportsDisableWhileTyping ?? false)
            title: Tr.t("Disable while typing")
            icon: "keyboard_hide"
            Toggle {
                checked: ps.first.disableWhileTyping ?? false
                onToggled: on => Input.setAll(ps.list, "disableWhileTyping", on)
            }
        }
        SettingRow {
            visible: !ps.touchpad
            title: Tr.t("Left-handed")
            description: Tr.t("Swaps the left and right buttons.")
            icon: "back_hand"
            Toggle {
                checked: ps.first.leftHanded ?? false
                onToggled: on => Input.setAll(ps.list, "leftHanded", on)
            }
        }
    }

    component SmallButton: Rectangle {
        id: sb
        property string icon: ""
        signal clicked
        width: 32
        height: 32
        radius: 16
        color: sbMouse.containsMouse ? Theme.buttonHover : Theme.button
        MIcon {
            anchors.centerIn: parent
            icon: sb.icon
            size: 17
        }
        MouseArea {
            id: sbMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sb.clicked()
        }
    }
}
