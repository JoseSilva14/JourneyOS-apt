import QtQuick
import QtQuick.Window
import org.kde.kwin 3.0 as KWin
import org.kde.kirigami 2.20 as Kirigami

// shadow-kde Alt+Tab: only connects KWin (window model, thumbnails, icons) to the visuals
// in Switcher.qml, which imports nothing from KWin (tested separately, with fake data).
KWin.TabBoxSwitcher {
    id: tabBox

    Instantiator {
        active: tabBox.visible

        delegate: Window {
            id: window

            visible: true
            flags: Qt.Popup | Qt.FramelessWindowHint | Qt.X11BypassWindowManagerHint
            color: "transparent"
            width: switcher.implicitWidth
            height: switcher.implicitHeight
            x: tabBox.screenGeometry.x + (tabBox.screenGeometry.width - width) / 2
            y: tabBox.screenGeometry.y + (tabBox.screenGeometry.height - height) / 2

            Switcher {
                id: switcher
                anchors.fill: parent
                model: tabBox.model
                currentIndex: tabBox.currentIndex
                maxWidth: tabBox.screenGeometry.width * 0.9
                onActivated: index => tabBox.model.activate(index)

                thumbnail: Component {
                    KWin.WindowThumbnail {
                        wId: parent.windowModel.windowId
                    }
                }
                icon: Component {
                    Kirigami.Icon {
                        source: parent.windowModel.icon
                    }
                }
            }
        }
    }
}
