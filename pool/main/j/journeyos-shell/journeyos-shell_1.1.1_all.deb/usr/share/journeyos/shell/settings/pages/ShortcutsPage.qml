import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Shortcuts: click the shortcut and press the new keys (Esc cancels, Backspace clears).
Page {
    id: root

    readonly property var actions: [
        { id: "launcher", title: Tr.t("App launcher"), icon: "apps" },
        { id: "panel", title: Tr.t("Quick panel"), icon: "tune" },
        { id: "notifications", title: Tr.t("Notification center"), icon: "notifications" },
        { id: "dashboard", title: "Dashboard", icon: "dashboard" },
        { id: "wallpapers", title: "Wallpapers", icon: "wallpaper" },
        { id: "widgets", title: Tr.t("Edit widgets"), icon: "widgets" },
        { id: "settings", title: Tr.t("Settings"), icon: "tune" },
        { id: "clipboard", title: Tr.t("Clipboard"), icon: "content_paste" },
        { id: "captureRegion", title: Tr.t("Screenshot of a region"), icon: "crop" },
        { id: "captureScreen", title: Tr.t("Screenshot of the screen"), icon: "fullscreen" },
        { id: "captureWindow", title: Tr.t("Screenshot of active window"), icon: "web_asset" },
        { id: "colorPicker", title: Tr.t("Color picker"), icon: "colorize" },
        ...Tiling.layouts.map(l => ({ id: l.shortcut, title: Tr.t("Windows: ") + l.title.toLowerCase(), icon: l.icon }))
    ]

    property string recording: ""      // action waiting for keys

    // Qt key → name in shortcut format ("Meta+Alt+D")
    function keyName(event) {
        const k = event.key;
        let name = "";
        if (k >= Qt.Key_A && k <= Qt.Key_Z) name = String.fromCharCode(k);
        else if (k >= Qt.Key_0 && k <= Qt.Key_9) name = String.fromCharCode(k);
        else if (k >= Qt.Key_F1 && k <= Qt.Key_F12) name = "F" + (k - Qt.Key_F1 + 1);
        else if (k === Qt.Key_Space) name = "Space";
        else if (k === Qt.Key_Return) name = "Return";
        else if (k === Qt.Key_Print) name = "Print";
        else if (k === Qt.Key_Delete) name = "Delete";
        else return "";
        const m = event.modifiers;
        const mods = [];
        if (m & Qt.MetaModifier) mods.push("Meta");
        if (m & Qt.ControlModifier) mods.push("Ctrl");
        if (m & Qt.AltModifier) mods.push("Alt");
        if (m & Qt.ShiftModifier) mods.push("Shift");
        return [...mods, name].join("+");
    }

    Text {
        Layout.fillWidth: true
        text: Tr.t("Click a shortcut and press the new keys. Esc cancels, Backspace removes the shortcut.")
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: root.actions

        SettingRow {
            id: row
            required property var modelData
            readonly property string keys: Config.options.shortcuts[modelData.id] ?? ""
            readonly property string conflict: Shortcuts.conflicts[modelData.id] ?? ""
            readonly property bool waiting: root.recording === modelData.id

            title: modelData.title
            description: conflict ? Tr.t("This key belongs to “") + conflict + Tr.t("”: choose another.") : ""
            icon: modelData.icon

            Rectangle {
                id: keyBox
                implicitWidth: Math.max(140, keyText.implicitWidth + 28)
                implicitHeight: 34
                radius: Theme.radiusSmall + 2
                color: row.waiting ? Theme.accent : keyMouse.containsMouse ? Theme.buttonHover : Theme.button
                focus: row.waiting

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                Text {
                    id: keyText
                    anchors.centerIn: parent
                    text: row.waiting ? Tr.t("Press the keys…") : (row.keys || Tr.t("No shortcut"))
                    color: row.waiting ? Theme.accentText : row.keys ? Theme.text : Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    font.weight: Font.Bold
                }

                MouseArea {
                    id: keyMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        root.recording = row.waiting ? "" : row.modelData.id;
                        keyBox.forceActiveFocus();
                    }
                }

                Keys.onPressed: event => {
                    if (!row.waiting)
                        return;
                    event.accepted = true;
                    if (event.key === Qt.Key_Escape) {
                        root.recording = "";
                    } else if (event.key === Qt.Key_Backspace) {
                        Config.options.shortcuts[row.modelData.id] = "";
                        root.recording = "";
                    } else {
                        const name = root.keyName(event);
                        if (name) {
                            Config.options.shortcuts[row.modelData.id] = name;
                            root.recording = "";
                        }
                    }
                }
            }
        }
    }
}
