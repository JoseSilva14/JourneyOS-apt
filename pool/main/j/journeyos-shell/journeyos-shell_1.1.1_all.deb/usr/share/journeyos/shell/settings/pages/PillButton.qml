import QtQuick
import qs

// Pill button for the pages (accent = filled with the accent colour; danger = red, for deleting).
Rectangle {
    id: root

    property string text: ""
    property bool accent: false
    property bool danger: false
    signal clicked

    implicitWidth: label.implicitWidth + 28
    implicitHeight: 32
    radius: height / 2
    color: danger ? Theme.privacyMic : accent ? Theme.accent : mouse.containsMouse ? Theme.buttonHover : Theme.button
    opacity: enabled ? 1 : 0.4
    scale: mouse.pressed ? 0.95 : 1

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }
    Behavior on scale {
        NumberAnimation { duration: Theme.animFast }
    }

    Text {
        id: label
        anchors.centerIn: parent
        text: root.text
        color: root.accent ? Theme.accentText : Theme.text
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall + 1
        font.weight: Font.Bold
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        enabled: root.enabled
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
