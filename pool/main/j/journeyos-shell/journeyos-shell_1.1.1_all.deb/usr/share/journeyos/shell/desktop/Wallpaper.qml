import QtQuick
import qs
import qs.services

// Image chosen in config.json or, without one, a dark gradient.
Item {
    id: root

    readonly property string path: Config.options.wallpaper

    // Soft light in the centre, as in screenshots without an image
    Rectangle {
        anchors.fill: parent
        visible: image.status !== Image.Ready
        gradient: Gradient {
            GradientStop { position: 0.0; color: Theme.wallTop }
            GradientStop { position: 0.55; color: Theme.bg }
            GradientStop { position: 1.0; color: Theme.wallBottom }
        }
    }

    Image {
        id: image
        anchors.fill: parent
        source: root.path ? (root.path.startsWith("/") ? "file://" + root.path : root.path) : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false
        sourceSize.width: root.width
        sourceSize.height: root.height
        opacity: status === Image.Ready ? 1 : 0

        Behavior on opacity {
            NumberAnimation { duration: Theme.animSlow }
        }
    }
}
