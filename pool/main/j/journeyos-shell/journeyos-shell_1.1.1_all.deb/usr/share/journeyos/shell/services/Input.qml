pragma Singleton

import QtQuick
import Quickshell

// Keyboard (layouts in kxkbrc, repeat in kcminputrc) and mice/touchpads (D-Bus
// properties of KWin's devices, via scripts/input.py; KWin applies and saves).
Singleton {
    id: root

    property var devices: []
    readonly property var mice: devices.filter(d => d.pointer && !d.touchpad)
    readonly property var touchpads: devices.filter(d => d.touchpad)

    property var layouts: []            // ["pt", "us"] (the first is the default)
    property var allLayouts: []         // [{ id, name }] from /usr/share/X11/xkb/rules/evdev.lst
    property int repeatDelay: 600       // ms
    property int repeatRate: 25         // per second

    function refresh() {
        Run.cmd([Quickshell.shellPath("scripts/input.py"), "list"], (code, out) => {
            try {
                root.devices = JSON.parse(out);
            } catch (e) {
            }
        });
        Kcfg.readMany("kxkbrc", [{ group: "Layout", key: "LayoutList", fallback: "" }], v => {
            root.layouts = v["Layout/LayoutList"] ? v["Layout/LayoutList"].split(",") : [];
        });
        Kcfg.readMany("kcminputrc", [
            { group: "Keyboard", key: "RepeatDelay", fallback: "600" },
            { group: "Keyboard", key: "RepeatRate", fallback: "25" }
        ], v => {
            root.repeatDelay = Number(v["Keyboard/RepeatDelay"]) || 600;
            root.repeatRate = Number(v["Keyboard/RepeatRate"]) || 25;
        });
        if (!allLayouts.length) {
            Run.sh("awk '/^! layout/{on=1;next} /^!/{on=0} on && NF {id=$1; $1=\"\"; sub(/^ +/,\"\"); print id \"\\t\" $0}' /usr/share/X11/xkb/rules/evdev.lst", (code, out) => {
                root.allLayouts = out.trim().split("\n").map(l => {
                    const [id, name] = l.split("\t");
                    return { id, name };
                }).sort((a, b) => a.name.localeCompare(b.name));
            });
        }
    }

    function layoutName(id) { return allLayouts.find(l => l.id === id)?.name ?? id; }

    function setDevice(sys, prop, value) {
        Run.cmd([Quickshell.shellPath("scripts/input.py"), "set", sys, prop, String(value)], () => refresh());
    }

    // Applies to all mice (or touchpads) at once
    function setAll(list, prop, value) {
        for (const d of list)
            setDevice(d.sys, prop, value);
    }

    function setLayouts(list) {
        root.layouts = list;
        Kcfg.write("kxkbrc", "Layout", "Use", true, () => {
            Kcfg.write("kxkbrc", "Layout", "LayoutList", list.join(","), () => {
                // KDE re-reads the layouts on this signal
                Run.cmd(["dbus-send", "--session", "--type=signal", "/Layouts", "org.kde.keyboard.reloadConfig"]);
            });
        });
    }

    function setRepeat(key, value) {
        Kcfg.write("kcminputrc", "Keyboard", key, String(value), () => {
            Kcfg.write("kcminputrc", "Keyboard", "KeyRepeat", "repeat", () => {
                Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/KWin",
                    "--method", "org.kde.KWin.reconfigure"], () => refresh());
            });
        });
    }
}
