import QtQuick
import qs

// Bar button: icon (and optional text) with a background on hover.
Rectangle {
    id: root

    property string icon: ""
    property string label: ""
    property color iconColor: Theme.text
    property alias hovered: mouse.containsMouse

    signal clicked(var mouse)
    signal wheel(var wheel)

    implicitHeight: Theme.barHeight - 8
    implicitWidth: row.implicitWidth + (label ? 14 : 10)
    radius: Theme.radiusSmall
    color: mouse.containsMouse ? Theme.button : "transparent"

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 5

        MIcon {
            anchors.verticalCenter: parent.verticalCenter
            icon: root.icon
            color: root.iconColor
            visible: root.icon !== ""
        }

        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.label !== ""
            text: root.label
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.DemiBold
        }
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
        cursorShape: Qt.PointingHandCursor
        onClicked: m => root.clicked(m)
        onWheel: w => root.wheel(w)
        // Sinks when pressed
        onPressed: root.scale = 0.94
        onReleased: root.scale = 1
        onCanceled: root.scale = 1
    }

    Behavior on scale {
        NumberAnimation { duration: Theme.animFast }
    }
}
