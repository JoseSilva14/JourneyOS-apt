import QtQuick
import Quickshell
import qs
import qs.services

// Big clock: hours above minutes (hours light, minutes grey).
Column {
    id: root

    spacing: -size * 0.22
    // Negative letter spacing lets the text overflow the box: right margin
    width: implicitWidth + size * 0.12

    readonly property int size: 150

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    Text {
        text: DateTime.hours(clock.date)
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: root.size
        font.weight: Font.ExtraBold
        font.letterSpacing: -root.size * 0.04
    }

    Text {
        text: Qt.formatTime(clock.date, "mm")
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: root.size
        font.weight: Font.ExtraBold
        font.letterSpacing: -root.size * 0.04
    }
}
