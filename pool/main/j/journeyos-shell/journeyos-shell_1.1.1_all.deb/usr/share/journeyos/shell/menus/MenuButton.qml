import QtQuick
import qs
import qs.components

// Small round button in menu rows (disconnect, forget…).
Rectangle {
    id: root

    property string icon: ""
    signal clicked

    width: 28
    height: 28
    radius: 14
    color: mouse.containsMouse ? Theme.buttonHover : Theme.button

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }

    MIcon {
        anchors.centerIn: parent
        icon: root.icon
        size: 15
        color: Theme.subtext
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
