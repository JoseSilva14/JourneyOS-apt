pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// System updates: check (pkcon refresh), the list (apt list --upgradable) and install
// (pkcon -y update, with progress; asks for authorization). Notifies at the end.
Singleton {
    id: root

    property var packages: []           // [{ name, from, to }]
    property bool checking: false
    property bool installing: false
    property int progress: 0
    property string status: ""
    property string lastChecked: ""

    function list() {
        Run.sh("apt list --upgradable 2>/dev/null | grep upgradable", (code, out) => {
            root.packages = out.trim().split("\n").filter(l => l).map(l => {
                // name/archive new-version arch [upgradable from: old-version]
                const m = l.match(/^([^/]+)\/\S+ (\S+) \S+ \[upgradable from: ([^\]]+)\]/);
                return m ? { name: m[1], to: m[2], from: m[3] } : { name: l, to: "", from: "" };
            });
        });
    }

    function check() {
        if (checking || installing)
            return;
        checking = true;
        Run.cmd(["pkcon", "refresh"], () => {
            root.checking = false;
            root.lastChecked = Qt.formatTime(new Date(), "HH:mm");
            list();
            SystemInfo.checkUpdates();
        });
    }

    function install() {
        if (installing || !packages.length)
            return;
        installing = true;
        progress = 0;
        status = Tr.t("Preparing…");
        installer.running = true;
    }

    Process {
        id: installer
        command: ["pkcon", "-y", "--plain", "update"]
        stdout: SplitParser {
            onRead: line => {
                const p = line.match(/Percentage:\s*(\d+)/);
                if (p)
                    root.progress = Number(p[1]);
                const s = line.match(/Status:\s*(.+)/);
                if (s)
                    root.status = s[1].trim();
            }
        }
        onExited: code => {
            root.installing = false;
            root.status = code === 0 ? Tr.t("Up to date") : Tr.t("Couldn't update");
            Quickshell.execDetached(["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
                "--object-path", "/org/freedesktop/Notifications", "--method", "org.freedesktop.Notifications.Notify",
                "--", Tr.t("Updates"), "0", "system-software-update", root.status,
                code === 0 ? Tr.t("The system is up to date.") : Tr.t("See the details in a terminal with: sudo apt full-upgrade"),
                "[]", "{}", "8000"]);
            root.list();
            SystemInfo.checkUpdates();
        }
    }
}
