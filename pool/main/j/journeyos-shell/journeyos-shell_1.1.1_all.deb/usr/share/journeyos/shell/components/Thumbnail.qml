import QtQuick
import qs

// Lightweight rounded-corner thumbnail: the image is decoded small (sourceSize)
// and the corners are covered with the background colour (no shaders, for the software renderer).
Item {
    id: root

    property alias source: image.source
    property real radius: Theme.radius
    property color background: Theme.surface
    readonly property bool ready: image.status === Image.Ready

    Image {
        id: image
        anchors.fill: parent
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        sourceSize.width: Math.ceil(root.width)
        sourceSize.height: Math.ceil(root.height)
        opacity: root.ready ? 1 : 0

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
    }

    Canvas {
        anchors.fill: parent
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            const ctx = getContext("2d");
            const w = width, h = height, r = Math.min(root.radius, w / 2, h / 2);
            ctx.reset();
            ctx.fillStyle = root.background;
            // Each corner: from the vertex along one side, the corner curve and back
            for (const [cx, cy, dx, dy] of [[0, 0, 1, 1], [w, 0, -1, 1], [0, h, 1, -1], [w, h, -1, -1]]) {
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx + dx * r, cy);
                ctx.arcTo(cx, cy, cx, cy + dy * r, r);
                ctx.closePath();
                ctx.fill();
            }
        }
    }
}
