pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Wallpapers from the config.json folders (wallpaperDirs), the user's own folder and the current one.
Singleton {
    id: root

    property var list: []            // [{ path, name }]
    // The user's folder: <Pictures>/Wallpapers (xdg-user-dirs: ~/Imagens in Portuguese), created at startup
    property string userDir: ""
    readonly property var dirs: userDir ? [userDir, ...Config.options.wallpaperDirs] : Config.options.wallpaperDirs

    // Opens the user's folder in the file manager (to add images)
    function openFolder() {
        if (userDir)
            Apps.run(["xdg-open", userDir]);
    }
    readonly property string current: Config.options.wallpaper

    function set(path) { Config.options.wallpaper = path; }

    function random() {
        const others = list.filter(w => w.path !== current);
        if (others.length)
            set(others[Math.floor(Math.random() * others.length)].path);
    }

    function refresh() {
        if (!scan.running)
            scan.running = true;
    }

    IpcHandler {
        target: "wallpaper"
        function random(): void { root.random(); }
        function set(path: string): void { root.set(path); }
        function get(): string { return root.current; }
    }

    Component.onCompleted: Run.cmd(["sh", "-c",
        'd="$(xdg-user-dir PICTURES 2>/dev/null)"; [ -n "$d" ] && [ "$d" != "$HOME" ] || d="$HOME/Pictures"; mkdir -p "$d/Wallpapers" && echo "$d/Wallpapers"'],
        (code, out) => {
            if (code === 0 && out.trim())
                root.userDir = out.trim();
            root.refresh();
        })

    Process {
        id: scan
        running: Config.ready
        command: [Quickshell.shellPath("scripts/wallpapers.py"), ...root.dirs]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    root.list = JSON.parse(text);
                } catch (e) {
                    console.warn("wallpapers: invalid reply");
                }
            }
        }
    }
}
