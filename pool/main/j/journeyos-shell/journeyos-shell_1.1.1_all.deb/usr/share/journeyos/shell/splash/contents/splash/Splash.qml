import QtQuick
import QtCore

// Session startup screen (KSplash, ksplashrc [KSplash] Theme=org.shadowkde.splash).
// Plasma raises `stage` from 1 to 6 while the session starts and closes it at the end. Runs as the
// user and reads the theme the shell exports (~/.local/state/shadow-kde/theme.conf), with the
// same background as the lock screen so the transition to the desktop is seamless.
Rectangle {
    id: root

    property int stage

    readonly property url conf: "file://" + StandardPaths.writableLocation(StandardPaths.HomeLocation)
        .toString().replace("file://", "") + "/.local/state/shadow-kde/theme.conf"

    color: theme.bg

    Settings {
        id: theme
        location: root.conf
        category: "Theme"
        property string bg: "#111112"
        property string button: "#0fffffff"
        property string text: "#ececec"
        property string subtext: "#9a9a9c"
        property string accent: "#f2f2f2"
        property string wallTop: "#161618"
        property string wallBottom: "#0b0b0c"
        property string font: "JetBrains Mono"
        property string logo: ""
    }

    // Texts in the shell language (services/LockTheme.qml)
    Settings {
        id: strings
        location: root.conf
        category: "Strings"
        property string hello: "Hello, "
        property string starting: "Starting"
    }

    Settings {
        id: desktop
        location: root.conf
        category: "Desktop"
        property string wallpaper: ""
    }

    Settings {
        id: user
        location: root.conf
        category: "User"
        property string name: ""
    }

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: theme.wallTop }
            GradientStop { position: 0.55; color: theme.bg }
            GradientStop { position: 1.0; color: theme.wallBottom }
        }
    }

    Image {
        anchors.fill: parent
        source: desktop.wallpaper ? "file://" + desktop.wallpaper : ""
        fillMode: Image.PreserveAspectCrop
        sourceSize.width: root.width
        sourceSize.height: root.height
    }

    Rectangle {
        anchors.fill: parent
        color: theme.bg
        opacity: desktop.wallpaper ? 0.55 : 0
    }

    Column {
        id: content
        anchors.centerIn: parent
        spacing: 28
        opacity: 0

        Component.onCompleted: opacity = 1
        Behavior on opacity {
            NumberAnimation { duration: 500; easing.type: Easing.OutCubic }
        }

        Image {
            anchors.horizontalCenter: parent.horizontalCenter
            height: 72
            fillMode: Image.PreserveAspectFit
            source: theme.logo ? "file://" + theme.logo : ""
            sourceSize.height: 144
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: user.name ? strings.hello + user.name : strings.starting
            color: theme.subtext
            font.family: theme.font
            font.pixelSize: 15
        }

        // Progress: thin pill that fills with the startup stages
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 180
            height: 4
            radius: 2
            color: theme.button

            Rectangle {
                width: parent.width * Math.min(1, root.stage / 6)
                height: parent.height
                radius: parent.radius
                color: theme.accent

                Behavior on width {
                    NumberAnimation { duration: 400; easing.type: Easing.OutCubic }
                }
            }
        }
    }
}
