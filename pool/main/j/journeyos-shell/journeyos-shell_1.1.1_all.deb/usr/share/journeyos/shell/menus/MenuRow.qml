import QtQuick
import QtQuick.Layouts
import qs
import qs.components

// Bar menu row: icon, title, status and, on the right, actions (appear on hover).
Rectangle {
    id: root

    property string icon: ""
    property string title: ""
    property string subtitle: ""
    property bool active: false        // connected: icon with the accent
    property bool busy: false          // connecting/pairing: the icon pulses
    property alias hovered: mouse.containsMouse
    default property alias actions: slot.data
    signal clicked

    Layout.fillWidth: true
    implicitHeight: 48
    radius: Theme.radius
    // No transition, as in menus
    color: mouse.containsMouse ? Theme.button : "transparent"

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 8
        spacing: 10

        Rectangle {
            implicitWidth: 32
            implicitHeight: 32
            radius: 16
            color: root.active ? Theme.accent : Theme.button

            Behavior on color {
                ColorAnimation { duration: Theme.animFast }
            }

            MIcon {
                anchors.centerIn: parent
                icon: root.icon
                size: 17
                color: root.active ? Theme.accentText : Theme.text

                SequentialAnimation on opacity {
                    running: root.busy
                    loops: Animation.Infinite
                    alwaysRunToEnd: true
                    NumberAnimation { to: 0.3; duration: 500 }
                    NumberAnimation { to: 1; duration: 500 }
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 0

            Text {
                Layout.fillWidth: true
                text: root.title
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: root.active ? Font.Bold : Font.Normal
            }
            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: root.subtitle
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        Row {
            id: slot
            spacing: 4
        }
    }
}
