import QtQuick
import QtQuick.Layouts
import qs
import qs.components

// Settings page: scrollable column; the children are the rows.
SmoothFlickable {
    id: root

    default property alias content: column.data

    contentHeight: column.implicitHeight + 8

    ColumnLayout {
        id: column
        // Space on the right so the scrollbar doesn't cover the rows
        width: root.width - 14
        spacing: 8
    }
}
