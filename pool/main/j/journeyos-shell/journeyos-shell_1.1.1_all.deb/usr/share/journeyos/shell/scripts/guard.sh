#!/bin/sh
# Shell protection.
#   save      saves the current configuration as "last good" (the shell calls it after loading)
#   watchdog  if the shell fails to respond twice in a row, restarts the service (60 s timer)
#   check     pre-commit check: script syntax, JSON and, with the shell running,
#             reloads it and checks that it loaded without errors
dir=$(readlink -f "$(dirname "$(readlink -f "$0")")/..")
state="$HOME/.local/state/shadow-kde"
lastgood="$state/last-good"

case "$1" in
    save)
        # Only from the project folder (not from the copy itself, when the shell was started from it)
        [ "$dir" = "$(readlink -f "$lastgood")" ] && exit 0
        mkdir -p "$lastgood"
        rsync -a --delete --exclude .git --exclude __pycache__ "$dir/" "$lastgood/"
        ;;

    watchdog)
        systemctl --user is-active -q shadow-kde.service || exit 0
        fails="$state/watchdog-fails"
        if timeout 5 qs -p "$dir" ipc call shell ping >/dev/null 2>&1 \
            || timeout 5 qs -p "$lastgood" ipc call shell ping >/dev/null 2>&1; then
            rm -f "$fails"
            exit 0
        fi
        n=$(( $(cat "$fails" 2>/dev/null || echo 0) + 1 ))
        echo $n > "$fails"
        if [ $n -ge 2 ]; then
            echo "shadow-kde: not responding for $n checks; restarting"
            rm -f "$fails"
            systemctl --user restart shadow-kde.service
        fi
        ;;

    check)
        status=0
        for f in "$dir"/scripts/*.py; do
            python3 -m py_compile "$f" 2>&1 || { echo "syntax error: $f"; status=1; }
        done
        for f in "$dir"/scripts/*.sh; do
            sh -n "$f" || { echo "syntax error: $f"; status=1; }
        done
        for f in "$dir"/lockscreen/metadata.json "$dir"/decoration/metadata.json; do
            python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$f" 2>/dev/null || { echo "invalid JSON: $f"; status=1; }
        done
        find "$dir" -name '*.qml' -size 0 -not -path '*/.git/*' | while read -r f; do echo "empty QML: $f"; done
        # With the shell running: reload and see whether errors show up
        if timeout 5 qs -p "$dir" ipc call shell ping >/dev/null 2>&1; then
            since=$(date '+%Y-%m-%d %H:%M:%S')
            timeout 5 qs -p "$dir" ipc call shell reload >/dev/null 2>&1
            sleep 4
            errors=$(journalctl --user -u shadow-kde --since "$since" --no-pager -o cat 2>/dev/null \
                | grep -E 'ERROR|caused by|Failed to load' | grep -v -E 'bluez')
            if [ -n "$errors" ]; then
                echo "the shell does not load:"
                echo "$errors" | head -20
                status=1
            else
                echo "shell: reloaded without errors"
            fi
        else
            echo "warning: the shell is not running; QML was not checked"
        fi
        exit $status
        ;;

    *)
        echo "usage: $0 save|watchdog|check" >&2
        exit 1
        ;;
esac
