import QtQuick
import qs
import qs.services

// Four dancing bars: cava's if available, otherwise random heights.
Row {
    id: bars

    property bool running: false
    property var levels: [0.3, 0.6, 0.4, 0.8]

    spacing: 2
    height: 14

    Timer {
        running: bars.running && !(Cava.available && Cava.values.length)
        interval: 160
        repeat: true
        onTriggered: bars.levels = bars.levels.map(() => 0.2 + Math.random() * 0.8)
    }

    Repeater {
        model: 4

        Rectangle {
            required property int index
            readonly property real level: !bars.running ? 0.2
                : Cava.available && Cava.values.length ? (Cava.values[index * 5] ?? 0)
                : bars.levels[index]

            anchors.bottom: parent.bottom
            width: 3
            height: Math.max(3, bars.height * level)
            radius: 1.5
            color: Theme.accent

            Behavior on height {
                NumberAnimation { duration: 150 }
            }
        }
    }
}
