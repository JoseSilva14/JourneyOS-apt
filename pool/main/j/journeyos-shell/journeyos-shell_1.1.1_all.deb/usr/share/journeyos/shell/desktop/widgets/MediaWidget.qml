import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Now playing: cover, title, artist, progress and controls.
Card {
    id: root

    readonly property var player: Media.player
    readonly property bool hasLength: (player?.lengthSupported ?? false) && player.length > 0

    width: 340
    height: 132

    // Quickshell does not update the position by itself: it is requested every second
    Timer {
        running: Media.playing && root.hasLength && root.visible
        interval: 1000
        repeat: true
        onTriggered: root.player.positionChanged()
    }

    function time(s) {
        s = Math.max(0, Math.floor(s));
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
    }

    RowLayout {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 14

        RoundImage {
            id: art
            implicitWidth: 96
            implicitHeight: 96
            radius: Theme.radius
            source: Media.art

            MIcon {
                anchors.centerIn: parent
                visible: !art.ready
                icon: "music_note"
                size: 36
                color: Theme.subtext
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 3

            Text {
                Layout.fillWidth: true
                text: root.player ? Media.title : Tr.t("Nothing playing")
                elide: Text.ElideRight
                color: root.player ? Theme.text : Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontMedium
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                visible: text !== ""
                text: root.player ? (Media.artist || root.player.identity) : ""
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            Item { Layout.fillHeight: true }

            // Progress
            ColumnLayout {
                Layout.fillWidth: true
                visible: root.hasLength
                spacing: 3

                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 4
                    radius: 2
                    color: Theme.buttonHover

                    Rectangle {
                        width: parent.width * Math.min(1, (root.player?.position ?? 0) / Math.max(1, root.player?.length ?? 1))
                        height: parent.height
                        radius: 2
                        color: Theme.accent

                        Behavior on width {
                            NumberAnimation { duration: Theme.animSlow }
                        }
                    }
                }
                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        Layout.fillWidth: true
                        text: root.time(root.player?.position ?? 0)
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall - 1
                    }
                    Text {
                        text: root.time(root.player?.length ?? 0)
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall - 1
                    }
                }
            }

            Row {
                visible: root.player !== null
                spacing: 4

                Control {
                    icon: "skip_previous"
                    enabled: root.player?.canGoPrevious ?? false
                    onClicked: Media.previous()
                }
                Control {
                    icon: Media.playing ? "pause" : "play_arrow"
                    big: true
                    onClicked: Media.toggle()
                }
                Control {
                    icon: "skip_next"
                    enabled: root.player?.canGoNext ?? false
                    onClicked: Media.next()
                }
            }
        }
    }

    component Control: Rectangle {
        id: control

        property string icon: ""
        property bool big: false
        signal clicked

        anchors.verticalCenter: parent.verticalCenter
        implicitWidth: big ? 34 : 28
        implicitHeight: implicitWidth
        radius: width / 2
        color: big ? Theme.accent : controlMouse.containsMouse ? Theme.buttonHover : "transparent"
        opacity: enabled ? 1 : 0.35
        scale: controlMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: control.icon
            size: control.big ? 20 : 18
            color: control.big ? Theme.accentText : Theme.text
        }

        MouseArea {
            id: controlMouse
            anchors.fill: parent
            hoverEnabled: true
            enabled: control.enabled
            cursorShape: Qt.PointingHandCursor
            onClicked: control.clicked()
        }
    }
}
