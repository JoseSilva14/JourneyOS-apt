import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// User extensions (widgets and tabs): install from a .zip (button or drag the file
// here), with a review first (what it contains, where it appears and what it can do), and the
// installed ones with Export (.zip to share) and Remove. Used in Settings → Tabs and → Desktop.
ColumnLayout {
    id: root

    Layout.fillWidth: true
    spacing: 8

    readonly property string script: Quickshell.shellPath("scripts/widgets.py")
    property var review: null          // what widgets.py ver returned
    property bool busy: false
    property string confirmRemove: ""

    readonly property var placeNames: ({ desktop: Tr.t("Desktop"), notch: Tr.t("Pill"), dashboard: "Dashboard" })
    function placesText(places) {
        return Object.keys(places ?? {}).map(p => placeNames[p] ?? p).join(" · ");
    }

    function check(path) {
        let p = String(path);
        if (p.startsWith("file://"))
            p = decodeURIComponent(p.slice(7));
        busy = true;
        Run.cmd([script, "ver", p], (code, out) => {
            root.busy = false;
            try {
                root.review = JSON.parse(out);
            } catch (e) {
                root.review = { ok: false, error: Tr.t("Couldn't read the file.") };
            }
        });
    }

    function pick() {
        Run.cmd(["kdialog", "--title", Tr.t("Install an extension"), "--getopenfilename", Quickshell.env("HOME"), Tr.t("Extensions (*.zip)")],
            (code, out) => {
                if (code === 0 && out.trim())
                    root.check(out.trim());
            });
    }

    function install() {
        const r = review;
        busy = true;
        Run.cmd([script, "instalar", r.zip, ...(r.exists ? ["--substituir"] : [])], (code, out) => {
            root.busy = false;
            let res = {};
            try {
                res = JSON.parse(out);
            } catch (e) {}
            if (code === 0 && res.ok) {
                Widgets.reload();
                Events.push({ icon: r.icon || "extension", title: r.exists ? Tr.t("Extension updated") : Tr.t("Extension installed"), text: res.name || r.name, duration: 2500 });
                root.review = null;
            } else {
                root.review = Object.assign({}, r, { ok: false, error: res.error || Tr.t("Couldn't install.") });
            }
        });
    }

    function remove(w) {
        const type = "user/" + w.id;
        // Also remove it from the desktop and the tabs
        Widgets.save(Widgets.items.filter(i => i.type !== type));
        Widgets.setTab("notch", type, false);
        Widgets.setTab("dashboard", type, false);
        Run.cmd([script, "remover", w.id], () => Widgets.reload());
        Events.push({ icon: "delete", title: Tr.t("Extension removed"), text: w.name, duration: 2000 });
    }

    function exportZip(w) {
        Run.cmd(["kdialog", "--title", Tr.t("Export the extension"), "--getsavefilename", Quickshell.env("HOME") + "/" + w.id + ".zip", Tr.t("Extensions (*.zip)")],
            (code, out) => {
                const dest = out.trim();
                if (code !== 0 || !dest)
                    return;
                Run.cmd([root.script, "exportar", w.id, dest.endsWith(".zip") ? dest : dest + ".zip"], c => {
                    Events.push(c === 0 ? { icon: "ios_share", title: Tr.t("Extension exported"), text: dest.split("/").pop(), duration: 2500 }
                        : { icon: "error", title: Tr.t("Couldn't export"), text: w.name, duration: 2500 });
                });
            });
    }

    // --- Install (also by dropping a .zip here) ---
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: installRow.implicitHeight + 28
        radius: Theme.radius
        color: drop.containsDrag ? Theme.buttonHover : Theme.surfaceCard
        border.width: 1
        border.color: drop.containsDrag ? Theme.accent : Theme.surfaceBorder

        DropArea {
            id: drop
            anchors.fill: parent
            onEntered: drag => drag.accepted = drag.hasUrls && drag.urls[0].toString().toLowerCase().endsWith(".zip")
            onDropped: drop => {
                if (drop.hasUrls) {
                    drop.accept(Qt.CopyAction);
                    root.check(drop.urls[0].toString());
                }
            }
        }

        RowLayout {
            id: installRow
            anchors.fill: parent
            anchors.margins: 14
            spacing: 12

            MIcon {
                icon: drop.containsDrag ? "file_download" : "unarchive"
                size: 22
                color: drop.containsDrag ? Theme.accent : Theme.subtext
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text {
                    text: drop.containsDrag ? Tr.t("Drop to see what's inside") : Tr.t("Install an extension")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    font.weight: Font.DemiBold
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    text: Tr.t("Choose or drag here the .zip of a widget or tab. Before installing, you see what it contains and what it can do.")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
            PillButton {
                text: root.busy ? Tr.t("Reading…") : Tr.t("Choose .zip…")
                enabled: !root.busy
                onClicked: root.pick()
            }
        }
    }

    // --- Review before installing ---
    Rectangle {
        Layout.fillWidth: true
        visible: root.review !== null
        implicitHeight: reviewColumn.implicitHeight + 32
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: root.review?.ok ? Theme.accent : Theme.privacyMic

        ColumnLayout {
            id: reviewColumn
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            // Error
            RowLayout {
                visible: !root.review?.ok
                spacing: 10
                MIcon {
                    icon: "error"
                    size: 20
                    color: Theme.privacyMic
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    text: Tr.t(root.review?.error ?? "")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                }
            }

            // What it contains
            RowLayout {
                visible: !!root.review?.ok
                spacing: 12

                Rectangle {
                    implicitWidth: 44
                    implicitHeight: 44
                    radius: 12
                    color: Theme.button
                    MIcon {
                        anchors.centerIn: parent
                        icon: root.review?.icon || "extension"
                        size: 22
                        color: Theme.text
                    }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: (root.review?.name ?? "") + (root.review?.version ? Tr.t("  ·  v") + root.review.version : "")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.Bold
                    }
                    Text {
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        visible: text !== ""
                        text: [root.review?.description ?? "", root.review?.author ? Tr.t("by ") + root.review.author : ""].filter(t => t).join(" · ")
                        color: Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            Detail {
                visible: !!root.review?.ok
                glyph: "place"
                text: Tr.t("Shows in: ") + root.placesText(root.review?.places)
            }
            Detail {
                visible: !!root.review?.ok
                glyph: "description"
                text: (root.review?.files ?? 0) + Tr.t(" files · ") + Math.max(1, Math.round((root.review?.size ?? 0) / 1024)) + Tr.t(" KB")
                    + ((root.review?.options?.length ?? 0) ? " · " + root.review.options.length + Tr.t(" options") : "")
            }
            // What it can do (read from the code, so you can decide whether to trust it)
            Repeater {
                model: root.review?.ok ? root.review.capabilities : []
                Detail {
                    required property var modelData
                    glyph: modelData.id === "comandos" ? "terminal" : modelData.id === "internet" ? "public"
                        : modelData.id === "ficheiros" ? "folder" : modelData.id === "dbus" ? "hub" : "lan"
                    text: Tr.t(modelData.label)
                    strong: true
                }
            }
            Detail {
                visible: !!root.review?.ok && (root.review?.scripts?.length ?? 0) > 0
                glyph: "code"
                text: Tr.t("Includes scripts: ") + (root.review?.scripts ?? []).join(", ")
                strong: true
            }
            Detail {
                visible: !!root.review?.ok && (root.review?.capabilities?.length ?? 0) === 0
                glyph: "verified_user"
                text: Tr.t("Display only: doesn't run commands or use the internet or files.")
            }
            Detail {
                visible: !!root.review?.exists
                glyph: "sync"
                text: Tr.t("Already installed: it will replace your version.")
                strong: true
            }

            Text {
                Layout.fillWidth: true
                visible: !!root.review?.ok
                wrapMode: Text.WordWrap
                text: Tr.t("An extension runs with your permissions. Only install ones from people you trust.")
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall - 1
            }

            RowLayout {
                spacing: 8
                Item { Layout.fillWidth: true }
                PillButton {
                    text: root.review?.ok ? Tr.t("Cancel") : Tr.t("Close")
                    onClicked: root.review = null
                }
                PillButton {
                    visible: !!root.review?.ok
                    text: root.busy ? Tr.t("Installing…") : root.review?.exists ? Tr.t("Replace") : Tr.t("Install")
                    accent: true
                    enabled: !root.busy
                    onClicked: root.install()
                }
            }
        }
    }

    // --- Installed ---
    Repeater {
        model: Widgets.userList

        SettingRow {
            id: row
            required property var modelData
            readonly property bool confirming: root.confirmRemove === modelData.id
            title: modelData.name + (modelData.version ? Tr.t("  ·  v") + modelData.version : "")
            description: modelData.error ? Tr.t("With errors: ") + Tr.t(modelData.error)
                : root.placesText(modelData.places) + (modelData.author ? Tr.t(" · by ") + modelData.author : "")
            icon: modelData.error ? "error" : (modelData.icon || "extension")

            Row {
                spacing: 6
                PillButton {
                    text: Tr.t("Export")
                    visible: !row.modelData.error
                    onClicked: root.exportZip(row.modelData)
                }
                PillButton {
                    text: row.confirming ? Tr.t("Really remove") : Tr.t("Remove")
                    danger: row.confirming
                    onClicked: {
                        if (row.confirming) {
                            root.confirmRemove = "";
                            root.remove(row.modelData);
                        } else {
                            root.confirmRemove = row.modelData.id;
                        }
                    }
                }
            }
        }
    }

    component Detail: RowLayout {
        property string glyph: ""
        property string text: ""
        property bool strong: false
        Layout.fillWidth: true
        spacing: 8
        MIcon {
            icon: parent.glyph
            size: 15
            color: parent.strong ? Theme.text : Theme.subtext
        }
        Text {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            text: parent.text
            color: parent.strong ? Theme.text : Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
