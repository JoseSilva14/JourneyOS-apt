import QtQuick
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Frozen screen to choose the capture region (one per screen): dragging selects, a click
// without dragging takes the whole screen, Esc gives up. At the bottom, a pill with the modes.
// Colour mode (eyedropper): a magnifier follows the mouse with the colour underneath; clicking copies it (Shift+click
// copies and continues), the arrows nudge one pixel (Shift: 10) and Enter copies the one under the magnifier.
PanelWindow {
    id: root

    required property var modelScreen
    readonly property bool open: Capture.selecting
    readonly property bool active: Windows.activeScreen === modelScreen
    readonly property bool picking: Capture.mode === "color"

    // Eyedropper: magnifier position (this window's coordinates) and whether it is on this screen
    property real px: modelScreen.width / 2
    property real py: modelScreen.height / 2
    property bool here: false
    readonly property real realX: (modelScreen.x + px) * Capture.scale
    readonly property real realY: (modelScreen.y + py) * Capture.scale
    onRealXChanged: if (picking && here) Capture.query(realX, realY)
    onRealYChanged: if (picking && here) Capture.query(realX, realY)

    function moveBy(dx, dy) {
        here = true;
        px = Math.max(0, Math.min(width - 1, px + dx));
        py = Math.max(0, Math.min(height - 1, py + dy));
    }

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "black"
    visible: open
    WlrLayershell.namespace: "shadow-capture"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open && active ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        sel.reset();
        // The magnifier starts in the middle of the active screen (there is no way to know where the mouse is)
        here = active;
        px = modelScreen.width / 2;
        py = modelScreen.height / 2;
        if (open)
            keys.forceActiveFocus();
    }
    onPickingChanged: if (picking && here) Capture.query(realX, realY)
    // The pixel reader takes a while to start: asks for the colour once it is ready
    Connections {
        target: Capture
        function onPickerReadyChanged() {
            if (Capture.pickerReady && root.picking && root.here)
                Capture.query(root.realX, root.realY);
        }
    }

    // This screen's part of the all-screens image (in real pixels)
    Image {
        anchors.fill: parent
        source: root.open ? "file://" + Capture.frozen + "?" + Capture.frozenStamp : ""
        cache: false
        smooth: true
        sourceClipRect: Qt.rect(root.modelScreen.x * Capture.scale, root.modelScreen.y * Capture.scale,
            root.modelScreen.width * Capture.scale, root.modelScreen.height * Capture.scale)
    }

    // Selection (this window's coordinates)
    QtObject {
        id: sel
        property real x0: 0
        property real y0: 0
        property real x1: 0
        property real y1: 0
        property bool dragging: false
        readonly property real x: Math.min(x0, x1)
        readonly property real y: Math.min(y0, y1)
        readonly property real w: Math.abs(x1 - x0)
        readonly property real h: Math.abs(y1 - y0)
        readonly property bool has: w > 3 && h > 3

        function reset() {
            x0 = y0 = x1 = y1 = 0;
            dragging = false;
        }
    }

    // Dims outside the selection (four rectangles around it)
    readonly property color veil: Qt.rgba(0, 0, 0, root.picking ? 0 : 0.45)
    Rectangle { color: root.veil; x: 0; y: 0; width: parent.width; height: sel.has ? sel.y : parent.height }
    Rectangle { visible: sel.has; color: root.veil; x: 0; y: sel.y + sel.h; width: parent.width; height: parent.height - sel.y - sel.h }
    Rectangle { visible: sel.has; color: root.veil; x: 0; y: sel.y; width: sel.x; height: sel.h }
    Rectangle { visible: sel.has; color: root.veil; x: sel.x + sel.w; y: sel.y; width: parent.width - sel.x - sel.w; height: sel.h }

    Rectangle {
        visible: sel.has
        x: sel.x - 1
        y: sel.y - 1
        width: sel.w + 2
        height: sel.h + 2
        color: "transparent"
        border.width: 1
        border.color: "white"
    }

    // Selection size, below it (in real pixels)
    Rectangle {
        visible: sel.has
        x: Math.min(sel.x, parent.width - width - 8)
        y: sel.y + sel.h + 8 + height > parent.height ? sel.y - height - 8 : sel.y + sel.h + 8
        width: sizeText.implicitWidth + 16
        height: 24
        radius: 12
        color: Theme.surface

        Text {
            id: sizeText
            anchors.centerIn: parent
            text: Math.round(sel.w * Capture.scale) + Tr.t(" × ") + Math.round(sel.h * Capture.scale)
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    MouseArea {
        anchors.fill: parent
        visible: !root.picking
        cursorShape: Qt.CrossCursor
        onPressed: mouse => {
            sel.x0 = sel.x1 = mouse.x;
            sel.y0 = sel.y1 = mouse.y;
            sel.dragging = true;
        }
        onPositionChanged: mouse => {
            if (!sel.dragging)
                return;
            sel.x1 = Math.max(0, Math.min(width, mouse.x));
            sel.y1 = Math.max(0, Math.min(height, mouse.y));
        }
        onReleased: {
            sel.dragging = false;
            if (sel.has)
                Capture.cropRegion(root.modelScreen.x + sel.x, root.modelScreen.y + sel.y, sel.w, sel.h);
            else
                Capture.cropScreen(root.modelScreen);
        }
    }

    // Eyedropper: the mouse moves the magnifier, clicking copies
    MouseArea {
        anchors.fill: parent
        visible: root.picking
        hoverEnabled: true
        cursorShape: Qt.BlankCursor
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onEntered: root.here = true
        onExited: root.here = false
        onPositionChanged: mouse => {
            root.here = true;
            root.px = mouse.x;
            root.py = mouse.y;
        }
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton)
                Capture.cancel();
            else
                Capture.pickAt(root.realX, root.realY, (mouse.modifiers & Qt.ShiftModifier) !== 0);
        }
    }

    Item {
        id: keys
        focus: true
        Keys.onEscapePressed: Capture.cancel()
        Keys.onPressed: event => {
            if (!root.picking) {
                if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                    Capture.cropScreen(root.modelScreen);
                    event.accepted = true;
                }
                return;
            }
            const step = (event.modifiers & Qt.ShiftModifier) ? 10 : 1;
            if (event.key === Qt.Key_Left) root.moveBy(-step, 0);
            else if (event.key === Qt.Key_Right) root.moveBy(step, 0);
            else if (event.key === Qt.Key_Up) root.moveBy(0, -step);
            else if (event.key === Qt.Key_Down) root.moveBy(0, step);
            else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter)
                Capture.pickAt(root.realX, root.realY, (event.modifiers & Qt.ShiftModifier) !== 0);
            else if (event.key === Qt.Key_Tab) {
                const f = Colors.formats;
                Colors.setFormat(f[(f.findIndex(x => x.id === Colors.format) + 1) % f.length].id);
            } else
                return;
            event.accepted = true;
        }
    }

    // Magnifier: the surrounding pixels, enlarged without smoothing, with the centre one marked and the colour below
    Item {
        id: loupe
        readonly property int zoom: 10
        readonly property int size: 150
        visible: root.picking && root.here
        // Next to the cursor; flips to the other side near the edges
        x: root.px + 24 + size > root.width ? root.px - 24 - size : root.px + 24
        y: root.py + 24 + height > root.height ? root.py - 24 - height : root.py + 24
        width: size
        height: size + 8 + 30

        Rectangle {
            id: lens
            width: loupe.size
            height: loupe.size
            radius: Theme.radius
            color: "black"
            clip: true

            Image {
                source: root.open && root.picking ? "file://" + Capture.frozen + "?" + Capture.frozenStamp : ""
                cache: false
                smooth: false
                // The real pixel under the cursor stays at the centre of the lens
                x: loupe.size / 2 - (Math.floor(root.realX) + 0.5) * loupe.zoom
                y: loupe.size / 2 - (Math.floor(root.realY) + 0.5) * loupe.zoom
                width: implicitWidth * loupe.zoom
                height: implicitHeight * loupe.zoom
            }

            // The chosen pixel
            Rectangle {
                anchors.centerIn: parent
                width: loupe.zoom + 2
                height: loupe.zoom + 2
                color: "transparent"
                border.width: 1
                border.color: Capture.hoverColor && Qt.color(Capture.hoverColor).hslLightness > 0.5 ? "black" : "white"
            }
        }
        // Outline on top (the lens clips the content to a rectangle)
        Rectangle {
            width: loupe.size
            height: loupe.size
            radius: Theme.radius
            color: "transparent"
            border.width: 2
            border.color: Theme.surface
        }

        Rectangle {
            y: loupe.size + 8
            anchors.horizontalCenter: lens.horizontalCenter
            width: Math.max(loupe.size, valueRow.implicitWidth + 20)
            height: 30
            radius: 15
            color: Theme.surface
            border.width: 1
            border.color: Theme.surfaceBorder

            Row {
                id: valueRow
                anchors.centerIn: parent
                spacing: 8

                Rectangle {
                    anchors.verticalCenter: parent.verticalCenter
                    width: 14
                    height: 14
                    radius: 7
                    color: Capture.hoverColor || "transparent"
                    border.width: 1
                    border.color: Theme.surfaceBorder
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: Capture.hoverColor ? Colors.text(Capture.hoverColor) : "…"
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }
            }
        }
    }

    // Pill with the modes (only on the active screen)
    Rectangle {
        visible: root.active && !sel.dragging
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 40
        width: tools.implicitWidth + 12
        height: 48
        radius: 24
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        Row {
            id: tools
            anchors.centerIn: parent
            spacing: 4

            Tool {
                glyph: "crop"
                label: Tr.t("Region")
                selected: !root.picking
                onClicked: Capture.mode = "region"
            }
            Tool {
                visible: !root.picking
                glyph: "fullscreen"
                label: Tr.t("Screen")
                onClicked: Capture.cropScreen(root.modelScreen)
            }
            Tool {
                glyph: "web_asset"
                label: Tr.t("Window")
                visible: !root.picking
                onClicked: {
                    Capture.cancel();
                    Capture.start("window");
                }
            }
            Tool {
                glyph: "colorize"
                label: Tr.t("Color")
                selected: root.picking
                onClicked: Capture.mode = "color"
            }

            // Eyedropper: format and the latest colours (clicking copies again)
            Rectangle {
                visible: root.picking
                width: 1
                height: 24
                anchors.verticalCenter: parent.verticalCenter
                color: Theme.surfaceBorder
            }
            Repeater {
                model: root.picking ? Colors.formats : []
                Tool {
                    required property var modelData
                    label: modelData.label
                    selected: Colors.format === modelData.id
                    onClicked: Colors.setFormat(modelData.id)
                }
            }
            Rectangle {
                visible: root.picking && Colors.history.length > 0
                width: 1
                height: 24
                anchors.verticalCenter: parent.verticalCenter
                color: Theme.surfaceBorder
            }
            Repeater {
                model: root.picking ? Colors.history.slice(0, 6) : []
                Rectangle {
                    id: recent
                    required property string modelData
                    anchors.verticalCenter: parent.verticalCenter
                    width: 24
                    height: 24
                    radius: 12
                    color: modelData
                    border.width: recentMouse.containsMouse ? 2 : 1
                    border.color: recentMouse.containsMouse ? Theme.text : Theme.surfaceBorder
                    MouseArea {
                        id: recentMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            Colors.copy(recent.modelData);
                            Capture.cancel();
                        }
                    }
                }
            }
            Rectangle {
                width: 1
                height: 24
                anchors.verticalCenter: parent.verticalCenter
                color: Theme.surfaceBorder
            }
            Tool { glyph: "close"; onClicked: Capture.cancel() }
        }
    }

    component Tool: Rectangle {
        id: tool
        property string glyph: ""
        property string label: ""
        property bool selected: false
        signal clicked

        anchors.verticalCenter: parent.verticalCenter
        width: toolRow.implicitWidth + (label ? 28 : 20)
        height: 36
        radius: 18
        color: selected ? Theme.accent : toolMouse.containsMouse ? Theme.buttonHover : "transparent"

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        Row {
            id: toolRow
            anchors.centerIn: parent
            spacing: 6
            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                icon: tool.glyph
                size: 18
                color: tool.selected ? Theme.accentText : Theme.text
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                visible: tool.label !== ""
                text: tool.label
                color: tool.selected ? Theme.accentText : Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
            }
        }
        MouseArea {
            id: toolMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tool.clicked()
        }
    }
}
