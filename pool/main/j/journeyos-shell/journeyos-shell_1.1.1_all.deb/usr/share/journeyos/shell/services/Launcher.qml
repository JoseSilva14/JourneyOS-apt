pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Launcher: apps (and the most used, ~/.local/state/shadow-kde/launcher.json), calculator and
// conversions (Convert),
// reminders ("lembrar …" = "remind …"), system commands, files in the home folder (fd) and emojis (starting with ":").
// Each result: { kind, key, title, subtitle, icon (from the theme) | glyph (Material) | emoji, run }
Singleton {
    id: root

    property bool open: false
    property var screen: null
    property string query: ""

    readonly property bool grid: Config.options.launcher.layout === "grid"

    function toggle(screen) {
        if (open) {
            open = false;
            return;
        }
        root.screen = screen ?? Windows.activeScreen;
        query = "";
        open = true;
    }

    function toggleLayout() {
        Config.options.launcher.layout = grid ? "list" : "grid";
    }

    onOpenChanged: {
        if (open) {
            QuickPanel.open = false;
            Notifs.centerOpen = false;
        }
    }

    function launch(item) {
        if (!item)
            return;
        // Just a hint (e.g. a reminder with no time yet): stays open to keep typing
        if (item.keep)
            return;
        if (item.kind === "app") {
            const counts = Object.assign({}, usage.counts);
            counts[item.key] = (counts[item.key] ?? 0) + 1;
            usage.counts = counts;
        }
        open = false;
        item.run();
    }

    function copy(text) {
        Quickshell.execDetached(["wl-copy", "--", text]);
        // Short confirmation in the pill
        Events.push({ icon: "content_copy", title: Tr.t("Copied"), text: text.length > 40 ? text.slice(0, 40) + "…" : text, duration: 1500 });
    }

    // No accents or capitals
    function norm(s) {
        return (s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
    }

    // Query letters in the right order, not necessarily adjacent ("ffx" → Firefox)
    function subsequence(q, s) {
        let i = 0;
        for (let c of s)
            if (c === q[i] && ++i === q.length)
                return true;
        return false;
    }

    function words(s) { return norm(s).split(/[\s\-_.,;/]+/); }

    // --- Apps ---
    readonly property var allApps: DesktopEntries.applications.values.filter(e => !e.noDisplay)
    // Without the hidden ones (those the shell replaces and those the user hid: ShellApps)
    readonly property var apps: allApps.filter(e => !ShellApps.isHidden(e.id))

    function appItem(e) {
        return { kind: "app", key: e.id, title: e.name, subtitle: e.genericName || e.comment, icon: e.icon,
            run: () => Apps.launch(e) };
    }

    function score(e, q) {
        const name = norm(e.name);
        const extra = [e.genericName, ...e.keywords];
        let s = 0;
        if (name === q) s = 1000;
        else if (name.startsWith(q)) s = 800;
        else if (words(e.name).some(w => w.startsWith(q))) s = 600;
        // A word of the generic name/keywords ("Terminal") counts
        // more than a piece in the middle of the name ("uxTERM")
        else if (extra.some(x => words(x).some(w => w.startsWith(q)))) s = 500;
        else if (name.includes(q)) s = 450;
        else if (extra.some(x => norm(x).includes(q))) s = 300;
        else if (norm(e.comment).includes(q) || norm(e.id).includes(q)) s = 150;
        else if (subsequence(q, name)) s = 100;
        else return 0;
        // The most used rise (without overtaking a better name match)
        return s + Math.min(99, (usage.counts[e.id] ?? 0) * 3);
    }

    // --- Calculator: only numbers, operators and a few functions; a leading "=" forces it ---
    function calculate(text) {
        let t = text.trim();
        const forced = t.startsWith("=");
        if (forced)
            t = t.slice(1);
        if (!t || !/^[0-9+\-*/%^().,\s a-z]*$/i.test(t))
            return null;
        const fns = ["sqrt", "sin", "cos", "tan", "log", "ln", "abs", "round", "floor", "ceil", "pi", "e"];
        const letters = t.match(/[a-z]+/gi) ?? [];
        if (letters.some(l => !fns.includes(l.toLowerCase())))
            return null;
        // A real calculation (not just a number)
        if (!forced && !/[+\-*/%^]|[a-z]\(/i.test(t))
            return null;
        const js = t.replace(/,/g, ".").replace(/\^/g, "**")
            .replace(/\bln\(/gi, "Math.log(").replace(/\blog\(/gi, "Math.log10(")
            .replace(/\b(sqrt|sin|cos|tan|abs|round|floor|ceil)\(/gi, (m, f) => "Math." + f.toLowerCase() + "(")
            .replace(/\bpi\b/gi, "Math.PI").replace(/\be\b/g, "Math.E");
        try {
            const v = Function("return (" + js + ")")();
            if (typeof v !== "number" || !isFinite(v))
                return null;
            return Math.round(v * 1e10) / 1e10;
        } catch (e) {
            return null;
        }
    }

    // --- Commands ---
    readonly property var commands: [
        { title: Tr.t("Lock screen"), keys: "bloquear lock", glyph: "lock", run: () => Session.lock() },
        { title: Tr.t("Log out##2"), keys: "sair logout terminar sessão", glyph: "logout", run: () => Session.prompt("logout") },
        { title: Tr.t("Restart"), keys: "reiniciar reboot restart", glyph: "restart_alt", run: () => Session.prompt("reboot") },
        { title: Tr.t("Shut down"), keys: "desligar shutdown poweroff", glyph: "power_settings_new", run: () => Session.prompt("shutdown") },
        { title: Tr.t("Sleep"), keys: "suspender dormir sleep suspend", glyph: "bedtime", run: () => Apps.run(["systemctl", "suspend"]) },
        { title: Theme.light ? Tr.t("Dark mode") : Tr.t("Light mode"), keys: "dark light mode theme modo escuro claro tema", glyph: Theme.light ? "dark_mode" : "light_mode",
            run: () => Config.options.theme.mode = Theme.light ? "dark" : "light" },
        { title: Notifs.dnd ? Tr.t("Turn off Do not disturb") : Tr.t("Do not disturb"), keys: "do not disturb silence dnd notifications nao incomodar silencio notificações", glyph: "notifications_off",
            run: () => Notifs.setDnd(!Notifs.dnd) },
        { title: KeepAwake.enabled ? Tr.t("Stop keeping awake") : Tr.t("Keep awake"), keys: "keep awake caffeine coffee manter acordado cafe", glyph: "coffee",
            run: () => KeepAwake.toggle() },
        { title: Tr.t("Screenshot of a region"), keys: "captura screenshot região print", glyph: "crop", run: () => Capture.start("region") },
        { title: Tr.t("Screenshot of the screen"), keys: "captura screenshot ecrã print", glyph: "fullscreen", run: () => Capture.start("screen") },
        { title: Tr.t("Color picker"), keys: "conta-gotas pipeta cor cores color picker hex rgb copiar", glyph: "colorize", run: () => Capture.start("color") },
        ...Colors.history.slice(0, 6).map(h => ({ title: Tr.t("Copy ") + Colors.text(h), keys: "cor cores copiar recente " + h,
            glyph: "palette", run: () => Colors.copy(h) })),
        { title: Tr.t("Screenshot of a window"), keys: "captura screenshot janela print", glyph: "web_asset", run: () => Capture.start("window") },
        ...Focus.modes.map(m => ({ title: Focus.active === m.id ? Tr.t("Leave mode ") + Tr.t(m.name) : Tr.t("Mode ") + Tr.t(m.name),
            keys: "foco modo focus mode " + m.name + " " + Tr.t(m.name), glyph: m.icon, run: () => Focus.toggle(m.id) })),
        ...Tiling.layouts.map(l => ({ title: Tr.t("Arrange windows: ") + l.title.toLowerCase(),
            keys: "arrumar janelas mosaico tiling dividir lado a lado " + l.title, glyph: l.icon, run: () => Tiling.apply(l.id) })),
        { title: Tr.t("Welcome"), keys: "welcome setup wizard tutorial boas-vindas assistente", glyph: "waving_hand", run: () => Welcome.show() },
        { title: Tr.t("Notes and tasks"), keys: "notes tasks todo list notas tarefas lista", glyph: "sticky_note_2", run: () => Dashboard.toggle("notes", null) },
        { title: Countdown.active && Countdown.mode === "pomodoro" ? Tr.t("Stop the Pomodoro") : "Pomodoro", keys: "pomodoro focus timer concentration foco temporizador",
            glyph: "av_timer", run: () => Countdown.active && Countdown.mode === "pomodoro" ? Countdown.reset() : Countdown.startPomodoro() },
        { title: Share.active ? Tr.t("Stop sharing ") + Share.name : Tr.t("Share a file on the local network"),
            keys: "share send phone local network qr link file partilhar enviar telemóvel rede ficheiro", glyph: "ios_share",
            run: () => Share.active ? Share.stop() : Share.pick() },
        { title: Tr.t("Reminders"), keys: "reminders remind alarm later lembretes lembrar alarme avisar mais tarde", glyph: "alarm",
            run: () => Qt.callLater(() => { root.toggle(null); root.query = Tr.pt ? "lembretes" : "reminders"; }) },
        { title: Tr.t("Calendar"), keys: "calendar events today agenda calendário eventos hoje", glyph: "event", run: () => Dashboard.toggle("agenda", null) },
        ...(Dev.enabled ? [{ title: Tr.t("Ports and containers"), keys: "dev ports containers docker development portas contentores programação",
            glyph: "terminal", run: () => Dashboard.toggle("dev", null) }] : []),
        { title: Tr.t("Calculator"), keys: "calculator math calculate kcalc calculadora contas calcular", glyph: "calculate", run: () => Calculator.toggle() },
        { title: "Web apps", keys: "web apps sites site navegador browser juntar", glyph: "language", run: () => Dashboard.toggle("web", null) },
        { title: Tr.t("All apps"), keys: "all apps applications programs pin aplicações todas programas fixar", glyph: "apps", run: () => Dashboard.toggle("apps", null) },
        { title: Tr.t("Random wallpaper"), keys: "wallpaper fundo aleatório", glyph: "shuffle", run: () => Wallpapers.random() },
        { title: Tr.t("Edit widgets"), keys: "widgets editar ambiente", glyph: "widgets", run: () => Widgets.editing = true },
        { title: Tr.t("Clipboard"), keys: "área transferência clipboard copiado", glyph: "content_paste", run: () => Clipboard.toggle(null) },
        { title: Tr.t("Empty the trash"), keys: "empty trash bin lixo esvaziar", glyph: "delete", run: () => Storage.emptyTrash() },
        { title: Tr.t("Settings"), keys: "definições settings configurar preferências", glyph: "settings", run: () => SettingsApp.show("home") }
    ]

    function commandScore(c, q) {
        const title = norm(c.title);
        if (title.startsWith(q)) return 900;
        if (words(c.title + " " + c.keys).some(w => w.startsWith(q))) return 550;
        return 0;
    }

    // --- Files (fd in the home folder, from 3 letters) ---
    property var files: []
    property string filesFor: ""

    Timer {
        id: fileSearch
        interval: 250
        onTriggered: {
            const q = root.query.trim();
            if (q.length < 3 || q.startsWith(":") || root.calculate(q) !== null || Convert.looksLike(q)
                || /^(lembr|nota\s|tarefa\s|todo\s)/i.test(q)) {
                root.files = [];
                return;
            }
            Run.cmd(["sh", "-c", 'command -v fd >/dev/null && exec fd "$@" || exec fdfind "$@"', "fd", "-i", "--max-depth", "6",
                "--max-results", "12", "--", q, Quickshell.env("HOME")], (code, out) => {
                if (root.query.trim() !== q)
                    return;
                const home = Quickshell.env("HOME");
                root.files = out.trim().split("\n").filter(p => p).map(p => {
                    const isDir = p.endsWith("/");
                    const clean = isDir ? p.slice(0, -1) : p;
                    const name = clean.split("/").pop();
                    return { kind: "file", key: clean, title: name,
                        subtitle: clean.slice(0, -name.length - 1).replace(home, "~") || "~",
                        glyph: isDir ? "folder" : "description", run: () => Apps.run(["xdg-open", clean]) };
                });
            });
        }
    }
    onQueryChanged: fileSearch.restart()

    // --- Emojis (":coração", ":smile"), from the list generated by scripts/emoji.py ---
    property var emojis: []
    readonly property string emojiCache: Quickshell.env("HOME") + "/.cache/shadow-kde/emoji.json"

    FileView {
        id: emojiFile
        path: root.emojiCache
        printErrors: false
        blockLoading: false
        onLoaded: {
            try {
                root.emojis = JSON.parse(text());
            } catch (e) {
            }
        }
        // Does not exist yet: generate it
        onLoadFailed: Run.sh("mkdir -p \"$(dirname '" + root.emojiCache + "')\" && " + Quickshell.shellPath("scripts/emoji.py")
            + " > '" + root.emojiCache + ".tmp' && mv '" + root.emojiCache + ".tmp' '" + root.emojiCache + "'", () => emojiFile.reload())
    }

    // --- Results ---
    readonly property var results: {
        const raw = query.trim();
        const q = norm(raw);
        if (!q) {
            // No query: the apps, most used first, then alphabetically
            return apps.slice().sort((a, b) =>
                ((usage.counts[b.id] ?? 0) - (usage.counts[a.id] ?? 0)) || a.name.localeCompare(b.name)).map(appItem);
        }

        if (q.startsWith(":")) {
            const terms = q.slice(1).split(/\s+/).filter(t => t);
            return emojis.filter(x => terms.every(t => x.n.includes(t))).slice(0, 40)
                .map(x => ({ kind: "emoji", key: x.e, title: x.n, subtitle: Tr.t("Enter copies"), emoji: x.e, run: () => root.copy(x.e) }));
        }

        const out = [];
        // "nota …" / "tarefa …" (Portuguese: "note …" / "task …"): jots it down without opening anything
        const quick = /^(nota|tarefa|todo|note|task)\s+(.+)$/i.exec(raw);
        if (quick) {
            const text = quick[2].trim();
            const isNote = ["nota", "note"].includes(quick[1].toLowerCase());
            out.push({ kind: "command", key: "quick-" + quick[1], glyph: isNote ? "sticky_note_2" : "task_alt",
                title: (isNote ? Tr.t("New note: ") : Tr.t("New task: ")) + text, subtitle: Tr.t("Enter saves"),
                run: () => {
                    if (isNote)
                        Notes.add(text);
                    else
                        Tasks.add(text);
                    Events.push({ icon: isNote ? "sticky_note_2" : "task_alt", title: isNote ? Tr.t("Note saved") : Tr.t("Task added"),
                        text: Tasks.parse(text).text, duration: 1500 });
                } });
        }
        // "lembrar 20 min tirar o café" (Portuguese: "remind 20 min …") / "lembretes" ("reminders"): the scheduled ones (Enter cancels)
        const remind = /^(?:lembrar|lembra-me|lembra me|lembrete|remind(?:\s+me)?|reminder)\s+(.+)$/i.exec(raw);
        if (remind) {
            const p = Reminders.parse(remind[1]);
            out.push(p ? { kind: "command", key: "remind", glyph: "alarm", title: Tr.t("Remind: ") + p.text,
                subtitle: Reminders.whenText(p.at).replace(/^./, c => c.toUpperCase()) + " · Enter marca",
                run: () => {
                    Reminders.add(p.text, p.at);
                    Events.push({ icon: "alarm", title: Tr.t("Reminder set"), text: Reminders.whenText(p.at) + " · " + p.text, duration: 2000 });
                } }
                : { kind: "command", key: "remind", glyph: "alarm", keep: true, title: Tr.t("Remind: ") + remind[1].trim(),
                    subtitle: Tr.t("Say when: 20 min, in 2h, 6pm, tomorrow at 9, friday at 10…"), run: () => {} });
        } else if (/^(?:lembretes?|reminders?)$/.test(q)) {
            if (!Reminders.pending.length)
                out.push({ kind: "command", key: "reminders-none", glyph: "alarm", keep: true, title: Tr.t("No reminders set"),
                    subtitle: Tr.t("Type, for example, \"remind 20 min take the coffee\""), run: () => {} });
            for (const r of Reminders.pending)
                out.push({ kind: "command", key: "reminder-" + r.id, glyph: "alarm", title: r.text,
                    subtitle: Reminders.whenText(r.at).replace(/^./, c => c.toUpperCase()) + " · Enter cancela",
                    run: () => {
                        Reminders.remove(r.id);
                        Events.push({ icon: "alarm_off", title: Tr.t("Reminder cancelled"), text: r.text, duration: 1500 });
                    } });
        }

        const value = calculate(raw);
        if (value !== null) {
            const shown = value.toLocaleString(Tr.locale, "f", 10).replace(/[.,]?0+$/, "");
            out.push({ kind: "calc", key: "calc", title: "= " + shown, subtitle: Tr.t("Enter copies the result"), glyph: "calculate",
                run: () => root.copy(String(value)) });
        }
        // Percentages, units, currencies and times in other places
        for (const c of Convert.results(raw))
            out.push({ kind: "calc", key: "conv-" + c.glyph, title: c.title, glyph: c.glyph, keep: !!c.keep,
                subtitle: c.subtitle + (c.copy ? Tr.t(" · Enter copies") : ""), run: () => root.copy(c.copy) });

        const scored = [
            ...commands.map(c => ({ item: { kind: "command", key: c.title, title: c.title, subtitle: Tr.t("Command"), glyph: c.glyph, run: c.run },
                s: commandScore(c, q) })),
            ...apps.map(e => ({ item: appItem(e), s: score(e, q) }))
        ].filter(x => x.s > 0).sort((a, b) => b.s - a.s || a.item.title.localeCompare(b.item.title));

        return [...out, ...scored.map(x => x.item), ...files];
    }

    FileView {
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/launcher.json"
        atomicWrites: true
        watchChanges: true
        onFileChanged: reload()
        onAdapterUpdated: writeAdapter()
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                writeAdapter();
        }

        JsonAdapter {
            id: usage
            property var counts: ({})
        }
    }

    IpcHandler {
        target: "launcher"
        function toggle(): void { root.toggle(null); }
        function query(text: string): void {
            if (!root.open)
                root.toggle(null);
            root.query = text;
        }
    }
}
