pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Services.Pipewire

// What is using the microphone, camera and screen, via PipeWire nodes; and the
// privacy settings: recent files history (kactivitymanagerd), trash (ktrashrc).
Singleton {
    id: root

    readonly property var nodes: Pipewire.nodes.values

    function cls(n) { return n.properties?.["media.class"] ?? ""; }
    function appName(n) {
        const p = n.properties ?? {};
        return p["application.name"] || p["node.description"] || p["node.name"] || "";
    }
    function names(list) { return [...new Set(list.map(appName).filter(s => s))]; }

    // Microphone: whoever records sound from an input (not those that only listen to the output, like cava)
    readonly property var micStreams: nodes.filter(n => cls(n) === "Stream/Input/Audio"
        && n.properties?.["stream.capture.sink"] !== "true"
        && !/cava/i.test(appName(n)))
    // Screen: KWin's video sources (screen sharing and recordings)
    readonly property var screenSources: nodes.filter(n => cls(n) === "Video/Source"
        && !n.properties?.["device.api"])
    // Camera: whoever reads video when there is no screen sharing (whoever views it is also a Stream/Input/Video)
    readonly property var videoStreams: nodes.filter(n => cls(n) === "Stream/Input/Video")

    readonly property bool mic: micStreams.length > 0
    readonly property bool screen: screenSources.length > 0
    readonly property bool camera: videoStreams.length > 0 && !screen
    readonly property bool any: mic || camera || screen

    readonly property var micApps: names(micStreams)
    readonly property var cameraApps: names(videoStreams)

    // Node properties only arrive when they are "bound"
    PwObjectTracker {
        objects: root.nodes
    }

    // --- Privacy settings ---
    readonly property string scoring: "Plugin-org.kde.ActivityManager.Resources.Scoring"
    readonly property string trashGroup: Quickshell.env("HOME") + "/.local/share/Trash"

    property bool rememberFiles: true   // what-to-remember: 0 = everything, 2 = nothing
    property int historyMonths: 0       // 0 = forever
    property bool trashAutoEmpty: false
    property int trashDays: 30

    function refresh() {
        Kcfg.readMany("kactivitymanagerd-pluginsrc", [
            { group: scoring, key: "what-to-remember", fallback: "0" },
            { group: scoring, key: "keep-history-for", fallback: "0" }
        ], v => {
            root.rememberFiles = v[scoring + "/what-to-remember"] !== "2";
            root.historyMonths = Number(v[scoring + "/keep-history-for"]) || 0;
        });
        Kcfg.readMany("ktrashrc", [
            { group: trashGroup, key: "UseTimeLimit", fallback: "false" },
            { group: trashGroup, key: "Days", fallback: "30" }
        ], v => {
            root.trashAutoEmpty = v[trashGroup + "/UseTimeLimit"] === "true";
            root.trashDays = Number(v[trashGroup + "/Days"]) || 30;
        });
    }

    function setRemember(on) { Kcfg.write("kactivitymanagerd-pluginsrc", scoring, "what-to-remember", on ? "0" : "2", () => refresh()); }
    function setHistory(months) { Kcfg.write("kactivitymanagerd-pluginsrc", scoring, "keep-history-for", String(months), () => refresh()); }

    function clearHistory() {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.ActivityManager", "--object-path",
            "/ActivityManager/Resources/Scoring", "--method", "org.kde.ActivityManager.ResourcesScoring.DeleteRecentStats",
            "", "0", "everything"]);
    }

    function setTrashAuto(on) { Kcfg.write("ktrashrc", trashGroup, "UseTimeLimit", on, () => refresh()); }
    function setTrashDays(days) { Kcfg.write("ktrashrc", trashGroup, "Days", String(days), () => refresh()); }
}
