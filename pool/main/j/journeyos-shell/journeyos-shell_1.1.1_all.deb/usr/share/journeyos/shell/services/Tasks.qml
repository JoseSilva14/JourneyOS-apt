pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Tasks (the dashboard's Notes tab, and the next one in the pill's Pomodoro):
// ~/.local/state/shadow-kde/tasks.json { tasks: [{ id, text, done, important,
// created, doneAt }] }. "!" at the start of the text = important. To do:
// important first, then in the order they were added; done: most recent first.
Singleton {
    id: root

    property var tasks: []
    property bool loaded: false
    property bool broken: false

    readonly property var pending: tasks.filter(t => !t.done)
        .sort((a, b) => (b.important - a.important) || (a.created - b.created))
    readonly property var done: tasks.filter(t => t.done).sort((a, b) => b.doneAt - a.doneAt)
    // The one the Pomodoro shows
    readonly property var next: pending[0] ?? null

    // "!text" → { text: "text", important: true }
    function parse(text) {
        const t = text.trim();
        return t.startsWith("!") ? { text: t.slice(1).trim(), important: true } : { text: t, important: false };
    }

    function add(text) {
        const p = parse(text);
        if (!p.text)
            return "";
        const now = Date.now();
        const task = { id: now.toString(36) + Math.random().toString(36).slice(2, 6), text: p.text,
            important: p.important, done: false, created: now, doneAt: 0 };
        tasks = [...tasks, task];
        save();
        return task.id;
    }

    function update(id, changes) {
        tasks = tasks.map(t => t.id === id ? Object.assign({}, t, changes) : t);
        save();
    }

    function toggle(id) {
        const t = tasks.find(x => x.id === id);
        if (t)
            update(id, { done: !t.done, doneAt: t.done ? 0 : Date.now() });
    }

    function toggleImportant(id) {
        const t = tasks.find(x => x.id === id);
        if (t)
            update(id, { important: !t.important });
    }

    // Empty text deletes
    function setText(id, text) {
        const p = parse(text);
        if (!p.text)
            remove(id);
        else
            update(id, { text: p.text, important: p.important || (tasks.find(x => x.id === id)?.important ?? false) });
    }

    function remove(id) {
        tasks = tasks.filter(t => t.id !== id);
        save();
    }

    function clearDone() {
        tasks = tasks.filter(t => !t.done);
        save();
    }

    function save() {
        if (!loaded || broken)
            return;
        file.setText(JSON.stringify({ tasks }, null, 1) + "\n");
    }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/tasks.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const list = JSON.parse(text()).tasks;
                root.tasks = Array.isArray(list) ? list.filter(t => t && typeof t.text === "string") : [];
                root.broken = false;
            } catch (e) {
                root.broken = true;
                console.warn("tasks.json is corrupt: not overwriting it", e);
            }
            root.loaded = true;
        }
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                root.loaded = true;
        }
    }

    IpcHandler {
        target: "tasks"
        function add(text: string): string { return root.add(text); }
        function list(): string { return root.pending.map(t => (t.important ? "! " : "") + t.text).join("\n"); }
        function toggle(id: string): void { root.toggle(id); }
        function remove(id: string): void { root.remove(id); }
    }
}
