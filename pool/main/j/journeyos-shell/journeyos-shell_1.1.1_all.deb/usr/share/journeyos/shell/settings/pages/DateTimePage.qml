import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Date and time: automatic sync, time zone (both ask for authorization) and the clock format.
Page {
    id: root

    Component.onCompleted: DateTime.refresh()

    SystemClock {
        id: clock
        precision: SystemClock.Seconds
    }

    // Current time, large
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: 96
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        Column {
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: 20
            spacing: 2

            Text {
                text: Qt.formatTime(clock.date, DateTime.use24h ? "HH:mm:ss" : "h:mm:ss AP")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 34
                font.weight: Font.Bold
            }
            Text {
                text: {
                    const s = Tr.locale.toString(clock.date, Tr.t("dddd, d MMMM yyyy"));
                    return s.charAt(0).toUpperCase() + s.slice(1) + " · " + DateTime.timezone;
                }
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }

    SettingRow {
        title: Tr.t("Set time automatically")
        description: DateTime.ntp ? (DateTime.synced ? Tr.t("Synced from the internet.") : Tr.t("Waiting to sync…")) : Tr.t("The time is not synced from the internet.")
        icon: "sync"
        Toggle {
            checked: DateTime.ntp
            onToggled: on => DateTime.setNtp(on)
        }
    }

    SettingRow {
        title: Tr.t("Time zone")
        description: Tr.t("Asks for the administrator password.")
        icon: "public"
        Select {
            implicitWidth: 260
            options: DateTime.timezones.map(t => ({ id: t, label: t.replace(/_/g, " ") }))
            current: DateTime.timezone
            searchable: true
            onSelected: id => DateTime.setTimezone(id)
        }
    }

    SettingRow {
        title: Tr.t("24-hour clock")
        description: Tr.t("In the bar, the pill, the desktop clock and the lock screen.")
        icon: "schedule"
        Toggle {
            checked: Config.options.clock.use24h
            onToggled: on => Config.options.clock.use24h = on
        }
    }
}
