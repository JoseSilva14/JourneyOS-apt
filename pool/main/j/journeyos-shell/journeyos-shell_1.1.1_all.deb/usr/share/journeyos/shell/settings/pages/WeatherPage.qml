import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Weather: the city (searched by name, or automatic from the IP address) and current conditions.
Page {
    id: page

    property var results: []
    property bool searching: false
    property string lastQuery: ""

    function search() {
        const q = cityField.text.trim();
        lastQuery = q;
        if (q.length < 2) {
            results = [];
            searching = false;
            return;
        }
        searching = true;
        Weather.search(q, list => {
            if (q !== page.lastQuery)
                return;             // an older answer: the user kept typing
            page.results = list;
            page.searching = false;
        });
    }

    // Search while typing (after a short pause)
    Timer {
        id: typing
        interval: 400
        onTriggered: page.search()
    }

    SettingRow {
        title: Tr.t("City")
        description: Weather.automatic
            ? Tr.t("Automatic, by IP address. Search for your city for exact weather.")
            : Config.options.weather.place || Config.options.weather.location
        icon: Weather.automatic ? "my_location" : "location_on"

        Rectangle {
            visible: !Weather.automatic
            implicitWidth: autoText.implicitWidth + 28
            implicitHeight: 32
            radius: height / 2
            color: autoMouse.containsMouse ? Theme.buttonHover : Theme.button

            Text {
                id: autoText
                anchors.centerIn: parent
                text: Tr.t("Automatic")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }
            MouseArea {
                id: autoMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Weather.useAutomatic()
            }
        }
    }

    // Search: type and pick from the suggestions (Enter picks the first)
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: searchColumn.implicitHeight + 24
        radius: Theme.radius
        color: Theme.surfaceCard

        ColumnLayout {
            id: searchColumn
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 12
            spacing: 6

            TextField {
                id: cityField
                Layout.fillWidth: true
                placeholder: Tr.t("Search city (e.g. Braga, Porto, Madrid)…")
                acceptOnBlur: false
                onTextChanged: typing.restart()
                onAccepted: {
                    if (page.results.length) {
                        Weather.choose(page.results[0]);
                        cityField.text = "";
                        page.results = [];
                    }
                }
            }

            Text {
                visible: cityField.text.trim().length >= 2 && !page.searching && page.results.length === 0
                Layout.fillWidth: true
                Layout.leftMargin: 4
                text: Tr.t("No city found (or no network).")
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            Repeater {
                model: page.results

                Rectangle {
                    id: result
                    required property var modelData
                    Layout.fillWidth: true
                    implicitHeight: 44
                    radius: Theme.radiusSmall + 2
                    color: resultMouse.containsMouse ? Theme.buttonHover : "transparent"

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        spacing: 10

                        MIcon {
                            icon: "location_on"
                            size: 18
                            color: Theme.subtext
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 0
                            Text {
                                Layout.fillWidth: true
                                text: result.modelData.name
                                elide: Text.ElideRight
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontNormal
                                font.weight: Font.DemiBold
                            }
                            Text {
                                Layout.fillWidth: true
                                text: [result.modelData.region, result.modelData.country].filter(x => x).join(", ")
                                elide: Text.ElideRight
                                color: Theme.dim
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                        }
                    }
                    MouseArea {
                        id: resultMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            Weather.choose(result.modelData);
                            cityField.text = "";
                            page.results = [];
                        }
                    }
                }
            }
        }
    }

    SettingRow {
        title: Weather.ready ? Weather.area + " · " + Weather.temp + "° · " + Weather.desc : Tr.t("No weather data")
        description: Weather.ready ? Tr.t("Feels like ") + Weather.feels + Tr.t("° · Humidity ") + Weather.humidity + Tr.t("% · Wind ") + Weather.wind + Tr.t(" km/h") : Tr.t("No network or the service didn't respond.")
        icon: Weather.ready ? Weather.icon : "cloud_off"

        Rectangle {
            implicitWidth: refreshText.implicitWidth + 28
            implicitHeight: 32
            radius: height / 2
            color: refreshMouse.containsMouse ? Theme.buttonHover : Theme.button

            Behavior on color {
                ColorAnimation { duration: Theme.animFast }
            }

            Text {
                id: refreshText
                anchors.centerIn: parent
                text: Tr.t("Update")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }

            MouseArea {
                id: refreshMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Weather.refresh()
            }
        }
    }
}
