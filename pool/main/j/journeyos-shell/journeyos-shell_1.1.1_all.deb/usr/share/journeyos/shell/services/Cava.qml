pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Bars for the sound that is playing, via cava (only runs with a visualizer
// on screen, or with music playing and the pill on). Without cava
// installed, available stays false and the widget says how to install it.
Singleton {
    id: root

    readonly property int bars: 24
    property var values: []          // 0–1, one per bar
    property bool available: false

    readonly property bool wanted: Widgets.items.some(i => i.type === "visualizer")
        || (Media.playing && Config.options.notch.enabled)

    // cava config: text output (0–100 separated by ;), 30 frames/s
    readonly property string script: `
conf="\${XDG_RUNTIME_DIR:-/tmp}/shadow-kde-cava.conf"
cat > "$conf" <<EOF
[general]
bars = ${bars}
framerate = 30
[input]
method = pulse
[output]
method = raw
raw_target = /dev/stdout
data_format = ascii
ascii_max_range = 100
bar_delimiter = 59
[smoothing]
noise_reduction = 77
EOF
exec cava -p "$conf"
`

    Process {
        running: true
        command: ["sh", "-c", "command -v cava"]
        onExited: code => root.available = code === 0
    }

    Process {
        id: cava
        running: root.available && root.wanted
        command: ["sh", "-c", root.script]
        stdout: SplitParser {
            onRead: line => {
                const v = line.split(";").filter(s => s !== "").map(s => Number(s) / 100);
                if (v.length)
                    root.values = v;
            }
        }
        onRunningChanged: if (!running) root.values = []
    }
}
