#!/usr/bin/env python3
"""Share a file (or a folder, as a .zip) on the local network, to open it on a phone.

share.py <path> [minutes=15]

Serves only that file, at an address with a random part (http://<ip>:<port>/<code>), and
stops by itself after the given minutes (or on SIGTERM). Writes one JSON line per event:
  {"event": "ready", "url", "name", "size", "qr", "ends"}   qr = PNG of the code (needs qrencode)
  {"event": "download", "ip"}                                 a completed download
  {"event": "error", "message"}
"""
import html
import json
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, unquote


# The page the phone opens: English by default, Portuguese with SHADOW_LANG=pt
WORDS = ({"lang": "pt", "shared_by": "partilhado por", "download": "Descarregar"}
         if os.environ.get("SHADOW_LANG") == "pt" else {"lang": "en", "shared_by": "shared by", "download": "Download"})


def say(**event):
    print(json.dumps(event, ensure_ascii=False), flush=True)


def lan_ip():
    # Sends nothing: only asks the system which interface it would go out through
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1000 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}".replace(".", ",")
        n /= 1000
    return f"{n} B"


PAGE = """<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{name}</title>
<style>
body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0b0c;color:#f2f2f2;
font-family:system-ui,sans-serif}}
main{{width:min(88vw,380px);padding:28px;border:1px solid #2a2a2e;border-radius:20px;background:#141416;text-align:center}}
h1{{font-size:18px;margin:6px 0 4px;word-break:break-all}} p{{color:#9a9aa2;margin:0 0 22px;font-size:14px}}
a{{display:block;padding:14px;border-radius:999px;background:#f2f2f2;color:#0b0b0c;text-decoration:none;font-weight:600}}
</style></head><body><main>
<div style="font-size:34px">📄</div><h1>{name}</h1><p>{size} · {shared_by} {host}</p>
<a href="{link}" download>{download}</a>
</main></body></html>"""


def main():
    if len(sys.argv) < 2:
        print(__doc__, file=sys.stderr)
        return 2
    path = os.path.abspath(os.path.expanduser(sys.argv[1]))
    minutes = float(sys.argv[2]) if len(sys.argv) > 2 else 15
    if not os.path.exists(path):
        say(event="error", message="The file no longer exists.")
        return 1

    tmpdir = tempfile.mkdtemp(prefix="shadow-kde-share-", dir=os.environ.get("XDG_RUNTIME_DIR"))
    try:
        if os.path.isdir(path):
            # Folders go in a .zip (made now, deleted at the end)
            base = os.path.basename(path.rstrip("/")) or "folder"
            path = shutil.make_archive(os.path.join(tmpdir, base), "zip", path)
        name = os.path.basename(path)
        size = os.path.getsize(path)
        token = secrets.token_urlsafe(6)
        link = f"/{token}/{quote(name)}"

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                route = unquote(self.path.split("?")[0])
                if route in (f"/{token}", f"/{token}/"):
                    body = PAGE.format(name=html.escape(name), size=human(size), host=html.escape(socket.gethostname()),
                                       link=link, **WORDS).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                elif route == f"/{token}/{name}":
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Length", str(size))
                    self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(name)}")
                    self.end_headers()
                    try:
                        with open(path, "rb") as f:
                            shutil.copyfileobj(f, self.wfile, 1 << 16)
                        say(event="download", ip=self.client_address[0])
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                else:
                    self.send_error(404)

        server = None
        for port in range(8800, 8900):
            try:
                server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
                break
            except OSError:
                continue
        if not server:
            say(event="error", message="No free port.")
            return 1
        server.daemon_threads = True

        url = f"http://{lan_ip()}:{server.server_port}/{token}"
        qr = ""
        if shutil.which("qrencode"):
            qr = os.path.join(tmpdir, "qr.png")
            if subprocess.run(["qrencode", "-o", qr, "-s", "8", "-m", "1", url]).returncode != 0:
                qr = ""
        ends = int((time.time() + minutes * 60) * 1000)
        say(event="ready", url=url, name=name, size=human(size), qr=qr, ends=ends)

        stop = lambda *_: threading.Thread(target=server.shutdown, daemon=True).start()
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        timer = threading.Timer(minutes * 60, stop)
        timer.daemon = True
        timer.start()
        server.serve_forever()
        server.server_close()
        return 0
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
