pragma Singleton

import QtQuick
import Quickshell

// Reading and writing KDE config (kreadconfig6/kwriteconfig6).
// group can be a list for nested groups: ["AC", "Display"].
Singleton {
    function groupArgs(group) {
        // (Qt's JavaScript has no flatMap)
        const out = [];
        for (const g of Array.isArray(group) ? group : [group])
            out.push("--group", g);
        return out;
    }

    function read(file, group, key, fallback, callback) {
        Run.cmd(["kreadconfig6", "--file", file, ...groupArgs(group), "--key", key, "--default", String(fallback)],
            (code, out) => callback(out.trim()));
    }

    function path(group, key) { return (Array.isArray(group) ? group.join("/") : group) + "/" + key; }

    // Several keys at once: keys = [{ group, key, fallback }] → callback({ "group/key": value })
    function readMany(file, keys, callback) {
        const script = keys.map(k => "kreadconfig6 --file " + shq(file) + " "
            + groupArgs(k.group).map(shq).join(" ") + " --key " + shq(k.key)
            + " --default " + shq(String(k.fallback ?? ""))).join("; echo '\u0001'; ");
        Run.sh(script, (code, out) => {
            const values = out.split("\u0001\n");
            const result = {};
            keys.forEach((k, i) => result[path(k.group, k.key)] = (values[i] ?? "").trim());
            callback(result);
        });
    }

    function write(file, group, key, value, callback) {
        // --notify: notifies whoever watches the file (KWin only applies night light this way)
        const args = ["kwriteconfig6", "--notify", "--file", file, ...groupArgs(group), "--key", key];
        if (typeof value === "boolean")
            args.push("--type", "bool");
        args.push("--", String(value));
        Run.cmd(args, () => { if (callback) callback(); });
    }

    function shq(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }
}
