import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Pipewire
import qs
import qs.components
import qs.services

// Sound menu: output (volume and which to use), input (microphone volume and which to use)
// and the volume of each app that is playing.
ColumnLayout {
    id: root

    spacing: 6

    // Inside the settings page: no title or "Settings…", lists always visible
    property bool embedded: false

    readonly property var nodes: Pipewire.nodes.values
    readonly property PwNode sink: Pipewire.defaultAudioSink
    readonly property PwNode source: Pipewire.defaultAudioSource

    // By media.class (Quickshell's isSink is also true for app streams)
    function cls(n) { return n.properties?.["media.class"] ?? ""; }
    readonly property var sinks: nodes.filter(n => cls(n) === "Audio/Sink")
    readonly property var sources: nodes.filter(n => cls(n).startsWith("Audio/Source"))
    // Apps playing (the speech-dispatcher stream is always open, silent)
    readonly property var apps: nodes.filter(n => cls(n) === "Stream/Output/Audio"
        && !/speech-dispatcher/.test(n.name))

    // Properties and volume only arrive with "bound" nodes: all of them are bound
    // (the filters above depend on them)
    PwObjectTracker {
        objects: root.nodes
    }

    function label(n) {
        return n.description || n.nickname || n.name || Tr.t("Unnamed");
    }

    function deviceIcon(n, input) {
        const t = (label(n) + " " + (n.properties?.["device.form-factor"] ?? "")).toLowerCase();
        if (input)
            return /headset/.test(t) ? "headset_mic" : "mic";
        if (/headphone|headset|auscult/.test(t)) return "headphones";
        if (/hdmi|displayport|tv/.test(t)) return "tv";
        return "speaker";
    }

    function appName(n) {
        const p = n.properties ?? {};
        return p["application.name"] || p["media.name"] || label(n);
    }

    function appIcon(n) {
        const p = n.properties ?? {};
        const name = p["application.icon-name"] || p["application.process.binary"] || "";
        return name ? Quickshell.iconPath(name, true) : "";
    }

    Text {
        visible: !root.embedded
        Layout.fillWidth: true
        Layout.bottomMargin: 4
        text: Tr.t("Sound")
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: Theme.fontLarge
        font.weight: Font.Bold
    }

    // --- Output ---
    Label { text: Tr.t("Output") }

    VolumeRow {
        node: root.sink
        icon: root.sink?.audio?.muted ? "volume_off" : "volume_up"
    }

    Repeater {
        // With a single output, the list says nothing
        model: root.sinks.length > 1 || root.embedded ? root.sinks : []

        MenuRow {
            required property var modelData
            icon: root.deviceIcon(modelData, false)
            title: root.label(modelData)
            active: modelData === root.sink
            implicitHeight: 42
            onClicked: Pipewire.preferredDefaultAudioSink = modelData
        }
    }

    // --- Input ---
    Label { text: Tr.t("Input") }

    Text {
        visible: root.sources.length === 0
        Layout.fillWidth: true
        Layout.leftMargin: 4
        text: Tr.t("No microphone.")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    VolumeRow {
        visible: root.sources.length > 0
        node: root.source
        icon: root.source?.audio?.muted ? "mic_off" : "mic"
    }

    Repeater {
        model: root.sources.length > 1 || root.embedded ? root.sources : []

        MenuRow {
            required property var modelData
            icon: root.deviceIcon(modelData, true)
            title: root.label(modelData)
            active: modelData === root.source
            implicitHeight: 42
            onClicked: Pipewire.preferredDefaultAudioSource = modelData
        }
    }

    // --- Apps ---
    Label {
        visible: root.apps.length > 0
        text: "Apps"
    }

    Repeater {
        model: root.apps.slice(0, 5)

        VolumeRow {
            required property var modelData
            node: modelData
            title: root.appName(modelData)
            appIcon: root.appIcon(modelData)
            icon: "graphic_eq"
        }
    }

    Rectangle {
        visible: !root.embedded
        Layout.fillWidth: true
        Layout.topMargin: 4
        implicitHeight: 1
        color: Theme.surfaceBorder
    }

    MenuRow {
        visible: !root.embedded
        icon: "settings"
        title: Tr.t("Sound settings…")
        onClicked: {
            BarMenu.open = "";
            SettingsApp.show("sound");
        }
    }

    component Label: Text {
        Layout.fillWidth: true
        Layout.topMargin: 6
        Layout.leftMargin: 4
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
        font.weight: Font.Bold
    }

    // Volume of a node: mute button (or the app icon), bar and percentage
    component VolumeRow: ColumnLayout {
        id: vrow

        property PwNode node: null
        property string icon: "volume_up"
        property string title: ""
        property string appIcon: ""
        readonly property bool muted: node?.audio?.muted ?? false
        readonly property real volume: node?.audio?.volume ?? 0

        Layout.fillWidth: true
        spacing: 0

        Text {
            visible: vrow.title !== ""
            Layout.fillWidth: true
            Layout.leftMargin: 46
            text: vrow.title
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Rectangle {
                implicitWidth: 36
                implicitHeight: 36
                radius: 18
                color: muteMouse.containsMouse ? Theme.buttonHover : Theme.button

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                IconImage {
                    id: appImage
                    anchors.centerIn: parent
                    implicitSize: 20
                    source: vrow.appIcon
                    visible: vrow.appIcon !== "" && status === Image.Ready
                    opacity: vrow.muted ? 0.4 : 1
                }
                MIcon {
                    anchors.centerIn: parent
                    visible: !appImage.visible
                    icon: vrow.icon
                    size: 18
                    color: vrow.muted ? Theme.dim : Theme.text
                }

                MouseArea {
                    id: muteMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: if (vrow.node?.audio) vrow.node.audio.muted = !vrow.muted
                }
            }

            Slider {
                Layout.fillWidth: true
                value: vrow.volume
                opacity: vrow.muted ? 0.45 : 1
                onMoved: v => {
                    if (!vrow.node?.audio)
                        return;
                    vrow.node.audio.volume = v;
                    if (vrow.muted && v > 0)
                        vrow.node.audio.muted = false;
                }
            }

            Text {
                Layout.preferredWidth: 38
                horizontalAlignment: Text.AlignRight
                text: Math.round(vrow.volume * 100) + "%"
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }
        }
    }
}
