pragma Singleton

import QtQuick
import Quickshell

// Window behaviour (kwinrc + reconfigure): focus, dragging to the edges,
// double-click on the title bar, the Overview corner and the number of virtual desktops.
Singleton {
    id: root

    property string focusPolicy: "ClickToFocus"     // ClickToFocus | FocusFollowsMouse
    property bool snapMaximize: true                // dragging up maximizes
    property bool snapTile: true                    // dragging to the sides: half the screen
    property string doubleClick: "Maximize"         // Maximize | Minimize | Shade | Close
    property bool overviewCorner: true              // top-left corner opens the Overview
    property int desktops: 1

    function refresh() {
        Kcfg.readMany("kwinrc", [
            { group: "Windows", key: "FocusPolicy", fallback: "ClickToFocus" },
            { group: "Windows", key: "ElectricBorderMaximize", fallback: "true" },
            { group: "Windows", key: "ElectricBorderTiling", fallback: "true" },
            { group: "Windows", key: "TitlebarDoubleClickCommand", fallback: "Maximize" },
            { group: "Effect-overview", key: "BorderActivate", fallback: "7" }
        ], v => {
            root.focusPolicy = v["Windows/FocusPolicy"];
            root.snapMaximize = v["Windows/ElectricBorderMaximize"] === "true";
            root.snapTile = v["Windows/ElectricBorderTiling"] === "true";
            root.doubleClick = v["Windows/TitlebarDoubleClickCommand"];
            // 9 = no corner (7 = top left)
            root.overviewCorner = v["Effect-overview/BorderActivate"] !== "9";
        });
        Run.cmd(["busctl", "--user", "get-property", "org.kde.KWin", "/VirtualDesktopManager",
            "org.kde.KWin.VirtualDesktopManager", "count"], (code, out) => root.desktops = Number(out.trim().split(" ")[1]) || 1);
    }

    function reconfigure() {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/KWin",
            "--method", "org.kde.KWin.reconfigure"], () => refresh());
    }

    function set(group, key, value) {
        Kcfg.write("kwinrc", group, key, value, () => reconfigure());
    }

    function setOverviewCorner(on) { set("Effect-overview", "BorderActivate", on ? "7" : "9"); }

    // Add or remove virtual desktops until there are n (removing one with windows moves them to another)
    function setDesktops(n) {
        Run.cmd(["busctl", "--user", "-j", "get-property", "org.kde.KWin", "/VirtualDesktopManager",
            "org.kde.KWin.VirtualDesktopManager", "desktops"], (code, out) => {
            let list = [];
            try {
                list = JSON.parse(out).data;
            } catch (e) {
                return;
            }
            const cmds = [];
            for (let i = list.length; i < n; i++)
                cmds.push("busctl --user call org.kde.KWin /VirtualDesktopManager org.kde.KWin.VirtualDesktopManager createDesktop us " + i + " '" + Tr.t("Desktop ") + (i + 1) + "'");
            for (let i = list.length - 1; i >= n; i--)
                cmds.push("busctl --user call org.kde.KWin /VirtualDesktopManager org.kde.KWin.VirtualDesktopManager removeDesktop s " + list[i][1]);
            if (cmds.length)
                Run.sh(cmds.join("; "), () => refresh());
        });
    }
}
