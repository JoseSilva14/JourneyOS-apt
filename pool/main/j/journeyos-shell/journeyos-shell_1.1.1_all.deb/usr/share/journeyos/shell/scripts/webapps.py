#!/usr/bin/env python3
"""Dashboard web apps (Web tab).

webapps.py icon <url> <out.png>       looks up the site's icon and saves it as a 128×128 PNG; writes
                                       JSON { "icon": path|"", "title": page title|"", "url" }
webapps.py import <image> <out.png>    converts a chosen image to a 128×128 PNG
webapps.py desktop <id> <name> <url> <icon>   creates/updates the .desktop entry (launcher, dock, Apps)
webapps.py remove <id>                 deletes the .desktop entry
webapps.py open <url>                  opens: in a Chromium browser in app mode (its own window, no
                                       bars) if there is one; otherwise in a new Firefox window; otherwise xdg-open

Icon order: manifest (the largest) > apple-touch-icon > <link rel=icon> (the largest) > /favicon.ico.
"""
import json
import re
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import urllib.request
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
APPS = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")), "applications")
SELF = os.path.realpath(__file__)
CHROMIUMS = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser",
             "microsoft-edge", "vivaldi"]


def normalize(url):
    url = url.strip()
    if not urlparse(url).scheme:
        url = "https://" + url
    return url


def fetch(url, limit=4 << 20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.geturl(), r.read(limit), r.headers.get_content_charset() or "utf-8"


def size_of(sizes):
    best = 0
    for s in (sizes or "").lower().split():
        if s == "any":
            return 512
        if "x" in s:
            try:
                best = max(best, int(s.split("x")[0]))
            except ValueError:
                pass
    return best


class Head(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.title = ""
        self.in_title = False
        self.title_done = False   # only the first <title> (the page's <svg> elements have one too)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "link" and a.get("href"):
            self.links.append(a)
        elif tag == "title" and not self.title_done:
            self.in_title = True

    def handle_endtag(self, tag):
        if tag == "title" and self.in_title:
            self.in_title = False
            self.title_done = True

    def handle_data(self, data):
        if self.in_title and len(self.title) < 200:
            self.title += data


def candidates(page_url, html):
    head = Head()
    try:
        head.feed(html)
    except Exception:
        pass
    found = []  # (priority, size, url)
    for a in head.links:
        rel = (a.get("rel") or "").lower().split()
        href = urljoin(page_url, a["href"])
        if "manifest" in rel:
            try:
                murl, data, _ = fetch(href, 1 << 20)
                for icon in json.loads(data).get("icons", []):
                    # "monochrome" ones are single-colour silhouettes (for notifications)
                    if icon.get("src") and "monochrome" not in (icon.get("purpose") or "any").split():
                        found.append((3, size_of(icon.get("sizes")), urljoin(murl, icon["src"])))
            except Exception:
                pass
        elif "apple-touch-icon" in rel or "apple-touch-icon-precomposed" in rel:
            found.append((2, size_of(a.get("sizes")) or 180, href))
        elif "icon" in rel and "mask-icon" not in rel:
            found.append((1, size_of(a.get("sizes")) or (64 if href.endswith(".svg") else 16), href))
    found.append((0, 16, urljoin(page_url, "/favicon.ico")))
    # Largest first; with the same size, the highest priority
    found.sort(key=lambda x: (min(x[1], 256), x[0]), reverse=True)
    # To suggest the name: only the first part ("GitHub · Change is constant…" → "GitHub")
    title = re.split(r"\s+[·|—–-]\s+|:\s", " ".join(head.title.split()))[0].strip()
    return title[:40], found


def largest_ico_frame(data):
    """Index of the largest image in an .ico (so ImageMagick does not pick the 16 px one)."""
    try:
        if data[:4] != b"\x00\x00\x01\x00":
            return None
        count = struct.unpack("<H", data[4:6])[0]
        best, index = -1, 0
        for i in range(count):
            w = data[6 + i * 16] or 256
            if w > best:
                best, index = w, i
        return index
    except Exception:
        return None


def to_png(src_path, out, data=None):
    """Converts to a 128×128 PNG (centred, transparent background). True on success."""
    source = src_path
    if data is not None:
        frame = largest_ico_frame(data)
        if frame is not None:
            source = f"{src_path}[{frame}]"
    tmp = out + ".tmp.png"
    r = subprocess.run(["magick", "-background", "none", source, "-thumbnail", "128x128", "-gravity", "center",
                        "-extent", "128x128", "PNG32:" + tmp], capture_output=True)
    if r.returncode != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) == 0:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False
    os.replace(tmp, out)
    return True


def cmd_icon(url, out):
    url = normalize(url)
    title, icon = "", ""
    try:
        page_url, html, charset = fetch(url)
        title, found = candidates(page_url, html.decode(charset, "replace"))
    except Exception:
        found = [(0, 16, urljoin(url, "/favicon.ico"))]
    os.makedirs(os.path.dirname(out), exist_ok=True)
    seen = set()
    with tempfile.TemporaryDirectory() as tmpdir:
        for _, _, href in found:
            if href in seen:
                continue
            seen.add(href)
            try:
                _, data, _ = fetch(href)
            except Exception:
                continue
            if len(data) < 64:
                continue
            ext = os.path.splitext(urlparse(href).path)[1].lower()[:5] or ".img"
            src = os.path.join(tmpdir, "icon" + ext)
            with open(src, "wb") as f:
                f.write(data)
            if to_png(src, out, data):
                icon = out
                break
    print(json.dumps({"icon": icon, "title": title, "url": url}, ensure_ascii=False))
    return 0


def quote_exec(arg):
    # Exec rules for .desktop entries: quoted, with \ " ` $ escaped, and % doubled
    arg = arg.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$")
    return '"' + arg.replace("%", "%%") + '"'


def desktop_path(app_id):
    return os.path.join(APPS, f"shadow-kde-web-{app_id}.desktop")


def cmd_desktop(app_id, name, url, icon):
    url = normalize(url)
    os.makedirs(APPS, exist_ok=True)
    clean = lambda s: s.replace("\n", " ").strip()
    text = "\n".join([
        "[Desktop Entry]",
        "Type=Application",
        f"Name={clean(name)}",
        f"Comment=Web app · {urlparse(url).hostname or url}",
        f"Exec={quote_exec(SELF)} open {quote_exec(url)}",
        f"Icon={clean(icon) or 'internet-web-browser'}",
        "Categories=Network;",
        "Keywords=web;site;",
        "StartupNotify=true",
        f"X-Shadow-Webapp={app_id}",
        "",
    ])
    path = desktop_path(app_id)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)
    return 0


def cmd_open(url):
    url = normalize(url)
    for b in CHROMIUMS:
        if shutil.which(b):
            os.execvp(b, [b, f"--app={url}"])
    for b in ("firefox", "firefox-esr"):
        if shutil.which(b):
            os.execvp(b, [b, "--new-window", url])
    os.execvp("xdg-open", ["xdg-open", url])


def main():
    a = sys.argv[1:]
    if a[:1] == ["icon"] and len(a) == 3:
        return cmd_icon(a[1], a[2])
    if a[:1] == ["import"] and len(a) == 3:
        return 0 if to_png(a[1], a[2], open(a[1], "rb").read() if a[1].lower().endswith(".ico") else None) else 1
    if a[:1] == ["desktop"] and len(a) == 5:
        return cmd_desktop(*a[1:])
    if a[:1] == ["remove"] and len(a) == 2:
        try:
            os.remove(desktop_path(a[1]))
        except FileNotFoundError:
            pass
        return 0
    if a[:1] == ["open"] and len(a) == 2:
        return cmd_open(a[1])
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
