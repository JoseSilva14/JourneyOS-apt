pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Displays (kscreen-doctor) and night light (kwinrc [NightColor] + KWin's D-Bus). Changing
// resolution/scale/rotation asks for confirmation: with no answer in 15 s, it reverts.
Singleton {
    id: root

    property var outputs: []            // from kscreen-doctor -j
    property var pending: null          // { previous: [arguments to restore] } awaiting confirmation
    property int countdown: 0

    // Night light
    property bool nightEnabled: false
    property string nightMode: "Constant"    // Constant | Times (Automatic needs the location)
    property int nightTemperature: 4500
    property string eveningBegin: "1800"
    property string morningBegin: "0600"

    readonly property var rotations: [
        { id: "normal", label: Tr.t("Normal"), value: 1 },
        { id: "left", label: Tr.t("90° left"), value: 2 },
        { id: "inverted", label: "180°", value: 4 },
        { id: "right", label: Tr.t("90° right"), value: 8 }
    ]

    function refresh() {
        Run.cmd(["kscreen-doctor", "-j"], (code, out) => {
            try {
                root.outputs = JSON.parse(out).outputs.filter(o => o.connected);
            } catch (e) {
                console.warn("display: invalid reply from kscreen-doctor");
            }
        });
        Kcfg.readMany("kwinrc", [
            { group: "NightColor", key: "Active", fallback: "false" },
            { group: "NightColor", key: "Mode", fallback: "Constant" },
            { group: "NightColor", key: "NightTemperature", fallback: "4500" },
            { group: "NightColor", key: "EveningBeginFixed", fallback: "1800" },
            { group: "NightColor", key: "MorningBeginFixed", fallback: "0600" }
        ], v => {
            root.nightEnabled = v["NightColor/Active"] === "true";
            root.nightMode = v["NightColor/Mode"];
            root.nightTemperature = Number(v["NightColor/NightTemperature"]) || 4500;
            root.eveningBegin = v["NightColor/EveningBeginFixed"];
            root.morningBegin = v["NightColor/MorningBeginFixed"];
        });
    }

    function rotationId(value) { return rotations.find(r => r.value === value)?.id ?? "normal"; }

    // kscreen-doctor arguments that restore a display's current state
    function stateArgs(o) {
        const out = ["output." + o.name + ".mode." + o.currentModeId,
            "output." + o.name + ".scale." + o.scale,
            "output." + o.name + ".rotation." + rotationId(o.rotation)];
        return out;
    }

    // changes: { mode, scale, rotation, enabled, primary } (only those that change)
    function apply(o, changes) {
        const args = [];
        if (changes.mode !== undefined) args.push("output." + o.name + ".mode." + changes.mode);
        if (changes.scale !== undefined) args.push("output." + o.name + ".scale." + changes.scale);
        if (changes.rotation !== undefined) args.push("output." + o.name + ".rotation." + changes.rotation);
        if (changes.enabled !== undefined) args.push("output." + o.name + "." + (changes.enabled ? "enable" : "disable"));
        if (changes.primary) args.push("output." + o.name + ".priority.1");
        if (!args.length)
            return;
        const previous = stateArgs(o);
        Run.cmd(["kscreen-doctor", ...args], () => {
            refresh();
            // Becoming primary needs no confirmation; everything else does
            if (changes.mode !== undefined || changes.scale !== undefined || changes.rotation !== undefined || changes.enabled === false) {
                root.pending = { previous };
                root.countdown = 15;
                confirmTimer.restart();
            }
        });
    }

    function keep() {
        confirmTimer.stop();
        pending = null;
    }

    function revert() {
        confirmTimer.stop();
        if (pending)
            Run.cmd(["kscreen-doctor", ...pending.previous], () => refresh());
        pending = null;
    }

    Timer {
        id: confirmTimer
        interval: 1000
        repeat: true
        onTriggered: {
            root.countdown--;
            if (root.countdown <= 0)
                root.revert();
        }
    }

    // --- Night light ---
    // Turning it on in automatic mode (KWin's default) does nothing without a location:
    // switch to "Always"
    function setNightEnabled(on) {
        if (on && nightMode !== "Constant" && nightMode !== "Times")
            Kcfg.write("kwinrc", "NightColor", "Mode", "Constant", () => setNight("Active", true));
        else
            setNight("Active", on);
    }

    function setNight(key, value) {
        Kcfg.write("kwinrc", "NightColor", key, value, () => {
            Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/KWin",
                "--method", "org.kde.KWin.reconfigure"], () => refresh());
        });
    }

    // Shows the temperature while choosing (KWin reverts on its own after a few seconds)
    function preview(kelvin) {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/org/kde/KWin/NightLight",
            "--method", "org.kde.KWin.NightLight.preview", String(kelvin)]);
    }

    function stopPreview() {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/org/kde/KWin/NightLight",
            "--method", "org.kde.KWin.NightLight.stopPreview"]);
    }
}
