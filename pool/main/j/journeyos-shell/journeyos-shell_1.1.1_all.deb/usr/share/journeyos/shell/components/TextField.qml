import QtQuick
import qs

// Text field in the shell's style: dark pill, placeholder text in grey.
Rectangle {
    id: root

    property alias text: input.text
    property alias echoMode: input.echoMode
    property string placeholder: ""
    // Losing focus counts as Enter (in settings fields); not in password fields
    property bool acceptOnBlur: true
    signal accepted(string text)

    // Keyboard focus to the field (forms open with the first field ready to type)
    function grab() { input.forceActiveFocus(); }

    implicitWidth: 260
    implicitHeight: 36
    radius: Theme.radiusSmall + 2
    color: Theme.button
    border.width: 1
    border.color: input.activeFocus ? Theme.accent : "transparent"

    Behavior on border.color {
        ColorAnimation { duration: Theme.animFast }
    }

    TextInput {
        id: input
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        verticalAlignment: TextInput.AlignVCenter
        color: Theme.text
        selectionColor: Theme.accent
        selectedTextColor: Theme.accentText
        font.family: Theme.font
        font.pixelSize: Theme.fontNormal
        clip: true
        onAccepted: root.accepted(text)
        onActiveFocusChanged: if (!activeFocus && root.acceptOnBlur) root.accepted(text)

        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: !input.text
            text: root.placeholder
            color: Theme.dim
            font: input.font
        }
    }
}
