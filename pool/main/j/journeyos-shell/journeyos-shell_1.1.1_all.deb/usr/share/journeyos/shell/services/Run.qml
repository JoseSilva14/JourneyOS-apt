pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Run a command and get the result: Run.cmd(argv, (code, out, err) => …). Waits for
// both the process and its output to finish (exited may arrive before the text).
Singleton {
    id: root

    function cmd(argv, callback, env) {
        const p = proc.createObject(root, { command: argv, callback: callback ?? null, environment: env ?? ({}) });
        p.running = true;
        return p;
    }

    // Only the exit code, without reading anything
    function sh(script, callback) {
        return cmd(["sh", "-c", script], callback);
    }

    Component {
        id: proc

        Process {
            id: p

            property var callback: null
            property int code: -1
            property bool exited: false
            property int streams: 0

            function finish() {
                if (!exited || streams < 2)
                    return;
                if (callback)
                    callback(code, out.text, err.text);
                p.destroy();
            }

            stdout: StdioCollector {
                id: out
                onStreamFinished: { p.streams++; p.finish(); }
            }
            stderr: StdioCollector {
                id: err
                onStreamFinished: { p.streams++; p.finish(); }
            }
            onExited: code => {
                p.code = code;
                p.exited = true;
                p.finish();
            }
        }
    }
}
