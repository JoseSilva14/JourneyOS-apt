import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Windows: focus, dragging to screen edges, title bar double-click, the Overview corner,
// virtual desktops and tiling (services/Tiling).
Page {
    id: root

    Component.onCompleted: WindowBehavior.refresh()

    SettingRow {
        title: Tr.t("Activate a window")
        description: WindowBehavior.focusPolicy === "ClickToFocus" ? Tr.t("On click.") : Tr.t("On hover.")
        icon: "ads_click"
        Segmented {
            model: [
                { id: "ClickToFocus", label: Tr.t("Click") },
                { id: "FocusFollowsMouse", label: Tr.t("Hover") }
            ]
            current: WindowBehavior.focusPolicy === "ClickToFocus" ? "ClickToFocus" : "FocusFollowsMouse"
            onSelected: id => WindowBehavior.set("Windows", "FocusPolicy", id)
        }
    }

    SettingRow {
        title: Tr.t("Double-click on title bar")
        icon: "web_asset"
        Select {
            options: [
                { id: "Maximize", label: Tr.t("Maximize") },
                { id: "Minimize", label: Tr.t("Minimize") },
                { id: "Shade", label: Tr.t("Shade") },
                { id: "Close", label: Tr.t("Close") },
                { id: "Nothing", label: Tr.t("Nothing") }
            ]
            current: WindowBehavior.doubleClick
            onSelected: id => WindowBehavior.set("Windows", "TitlebarDoubleClickCommand", id)
        }
    }

    SectionLabel { text: Tr.t("Drag to edges") }

    SettingRow {
        title: Tr.t("Up: maximize")
        icon: "fullscreen"
        Toggle {
            checked: WindowBehavior.snapMaximize
            onToggled: on => WindowBehavior.set("Windows", "ElectricBorderMaximize", on)
        }
    }

    SettingRow {
        title: Tr.t("Sides: half screen")
        description: Tr.t("Two windows side by side. Also with Meta+arrows.")
        icon: "vertical_split"
        Toggle {
            checked: WindowBehavior.snapTile
            onToggled: on => WindowBehavior.set("Windows", "ElectricBorderTiling", on)
        }
    }

    SectionLabel { text: Tr.t("Overview and virtual desktops") }

    SettingRow {
        title: Tr.t("Top-left corner opens Overview")
        description: Tr.t("All windows and desktops at once (also with Meta+W).")
        icon: "grid_view"
        Toggle {
            checked: WindowBehavior.overviewCorner
            onToggled: on => WindowBehavior.setOverviewCorner(on)
        }
    }

    SettingRow {
        title: Tr.t("Virtual desktops · ") + WindowBehavior.desktops
        description: Tr.t("Separate workspaces (Meta+Ctrl+arrows to switch). Removing one moves its windows to another.")
        icon: "view_carousel"
        Segmented {
            model: [1, 2, 3, 4, 6].map(n => ({ id: String(n), label: String(n) }))
            current: String(WindowBehavior.desktops)
            onSelected: id => WindowBehavior.setDesktops(Number(id))
        }
    }

    SectionLabel { text: Tr.t("Tile windows") }

    // Each layout immediately arranges the current screen's windows (active one first)
    Repeater {
        model: Tiling.layouts

        SettingRow {
            id: tileRow
            required property var modelData
            title: modelData.title + " · " + (Config.options.shortcuts[modelData.shortcut] || Tr.t("no shortcut"))
            description: modelData.description
            icon: modelData.icon
            PillButton {
                text: Tr.t("Arrange")
                onClicked: Tiling.apply(tileRow.modelData.id)
            }
        }
    }

    SettingRow {
        title: Tr.t("Gap between windows")
        description: Tr.t("Also around, up to the bar and the dock.")
        icon: "padding"
        Segmented {
            model: [0, 4, 8, 16].map(n => ({ id: String(n), label: n + Tr.t(" px") }))
            current: String(Config.options.tiling.gap)
            onSelected: id => Config.options.tiling.gap = Number(id)
        }
    }
}
