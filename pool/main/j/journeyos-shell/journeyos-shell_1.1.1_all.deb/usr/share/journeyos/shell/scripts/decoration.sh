#!/bin/sh
# shadow-kde window decoration in KWin.
#   install  copies the package to ~/.local/share/kwin/decorations/shadowkde
#            (KWin does not follow symlinks for decorations)
#   apply    installs it and selects it in kwinrc
#   refresh  recreates it (KWin only reads the colours when creating the decoration), if selected
#   breeze   goes back to KDE's
set -e
dir=$(dirname "$(readlink -f "$0")")/..
dest="$HOME/.local/share/kwin/decorations/shadowkde"
group=org.kde.kdecoration2

set_deco() {
    kwriteconfig6 --file kwinrc --group "$group" --key library "$1"
    kwriteconfig6 --file kwinrc --group "$group" --key theme "$2"
    gdbus call --session --dest org.kde.KWin --object-path /KWin --method org.kde.KWin.reconfigure >/dev/null
}

install() {
    tmp="$dest.tmp"
    rm -rf "$tmp"
    mkdir -p "$(dirname "$dest")"
    cp -r "$dir/decoration" "$tmp"
    rm -rf "$dest"
    mv "$tmp" "$dest"
}

case "$1" in
    install)
        install
        ;;
    apply)
        install
        set_deco org.kde.kwin.aurorae shadowkde
        ;;
    refresh)
        [ "$(kreadconfig6 --file kwinrc --group "$group" --key theme)" = shadowkde ] || exit 0
        # Switch to Breeze and back: reapplying the same name recreates nothing
        set_deco org.kde.breeze Breeze
        sleep 0.3
        set_deco org.kde.kwin.aurorae shadowkde
        ;;
    breeze)
        set_deco org.kde.breeze Breeze
        ;;
    *)
        echo "usage: $0 install|apply|refresh|breeze" >&2
        exit 1
        ;;
esac
