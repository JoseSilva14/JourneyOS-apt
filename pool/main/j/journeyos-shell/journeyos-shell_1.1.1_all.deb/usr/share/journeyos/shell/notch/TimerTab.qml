import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Time tab: ring with the time left and, on the right, Timer (usual durations) or
// Pomodoro (focus and break durations, cycles, the next task from the dashboard and skip phase).
// Pomodoro durations are changed here; the long break, auto-start and the linked focus mode
// are in Settings → Focus modes.
Item {
    id: root

    // What shows on the right: the running mode, or the chosen one when everything is stopped
    property string view: Countdown.active ? Countdown.mode : "timer"
    readonly property bool pomodoro: view === "pomodoro"
    readonly property bool pomodoroRunning: Countdown.active && Countdown.mode === "pomodoro"

    Connections {
        target: Countdown
        function onActiveChanged() { if (Countdown.active) root.view = Countdown.mode; }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 18

        // Ring with the time
        Item {
            implicitWidth: 112
            implicitHeight: 112

            Ring {
                anchors.fill: parent
                thickness: 5
                value: Countdown.active ? Countdown.progress : 0
            }

            Column {
                anchors.centerIn: parent
                spacing: 0

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Countdown.active ? Countdown.format(Countdown.left)
                        : root.pomodoro ? Countdown.format(Countdown.focusMin * 60) : "0:00"
                    color: Countdown.phase === "paused" || !Countdown.active ? Theme.subtext : Theme.text
                    font.family: Theme.font
                    font.pixelSize: Countdown.left >= 3600 ? 17 : 22
                    font.weight: Font.Bold
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: !Countdown.active ? (root.pomodoro ? "Pomodoro" : Tr.t("Stopped"))
                        : Countdown.waiting ? Tr.t(Countdown.label) + Tr.t(" next")
                        : Countdown.phase === "paused" ? Tr.t("Paused")
                        : Tr.t(Countdown.label)
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 8

            // With everything stopped the mode is chosen; while running, the mode stays
            Segmented {
                visible: !Countdown.active
                model: [
                    { id: "timer", label: Tr.t("Timer"), icon: "timer" },
                    { id: "pomodoro", label: "Pomodoro", icon: "av_timer" }
                ]
                current: root.view
                onSelected: id => root.view = id
            }

            // --- Timer ---
            Flow {
                visible: !root.pomodoro
                Layout.fillWidth: true
                spacing: 6

                Repeater {
                    model: [1, 5, 10, 15, 25, 45]

                    Chip {
                        required property int modelData
                        text: modelData + Tr.t(" min")
                        onClicked: Countdown.start(modelData, "")
                    }
                }
            }

            // --- Pomodoro stopped: durations and start ---
            RowLayout {
                visible: root.pomodoro && !Countdown.active
                spacing: 14

                Stepper {
                    label: Tr.t("Focus")
                    value: Countdown.cfg.focus
                    step: 5
                    min: 5
                    max: 120
                    onChanged: v => Config.options.pomodoro.focus = v
                }
                Stepper {
                    label: Tr.t("Break")
                    value: Countdown.cfg.shortBreak
                    step: 1
                    min: 1
                    max: 30
                    onChanged: v => Config.options.pomodoro.shortBreak = v
                }
            }
            RowLayout {
                visible: root.pomodoro && !Countdown.active
                spacing: 10

                Chip {
                    text: Tr.t("Start")
                    active: true
                    onClicked: Countdown.startPomodoro()
                }
                Text {
                    Layout.fillWidth: true
                    text: Tr.t("Long break of ") + Countdown.longBreakMin + Tr.t(" min every ") + Countdown.every
                        + (Focus.mode(Countdown.cfg.focusMode) ? Tr.t(" · mode ") + Tr.t(Focus.mode(Countdown.cfg.focusMode).name) : "")
                    elide: Text.ElideRight
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
            }

            // --- Pomodoro running: cycles and the next task ---
            Row {
                visible: root.pomodoroRunning
                spacing: 6

                Repeater {
                    model: Countdown.every

                    Rectangle {
                        required property int index
                        readonly property int inRound: Countdown.cycle % Countdown.every
                        // Done in this round filled; the current one (in focus) outlined with the accent
                        readonly property bool doneDot: index < inRound
                        readonly property bool currentDot: index === inRound && Countdown.label === "Focus"
                        anchors.verticalCenter: parent.verticalCenter
                        width: 10
                        height: 10
                        radius: 5
                        color: doneDot ? Theme.accent : "transparent"
                        border.width: 1.5
                        border.color: doneDot || currentDot ? Theme.accent : Theme.faint
                    }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    leftPadding: 4
                    text: Countdown.cycle + (Countdown.cycle === 1 ? Tr.t(" focus done") : Tr.t(" focus sessions done"))
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
            }

            // The next task (dashboard → Notes → Tasks): clicking the circle marks it as done
            Rectangle {
                visible: root.pomodoroRunning && Countdown.cfg.showTask
                Layout.fillWidth: true
                implicitHeight: 30
                radius: 15
                color: Theme.button

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 6
                    anchors.rightMargin: 12
                    spacing: 8

                    Rectangle {
                        visible: !!Tasks.next
                        implicitWidth: 20
                        implicitHeight: 20
                        radius: 10
                        color: checkMouse.containsMouse ? Theme.buttonHover : "transparent"
                        border.width: 1.5
                        border.color: Tasks.next?.important ? Theme.accent : Theme.subtext

                        MIcon {
                            anchors.centerIn: parent
                            visible: checkMouse.containsMouse
                            icon: "check"
                            size: 13
                        }
                        MouseArea {
                            id: checkMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: if (Tasks.next) Tasks.toggle(Tasks.next.id)
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        leftPadding: Tasks.next ? 0 : 6
                        text: Tasks.next ? Tasks.next.text
                            : Tasks.tasks.length ? Tr.t("All done.") : Tr.t("No tasks: add them in the dashboard.")
                        elide: Text.ElideRight
                        color: Tasks.next ? Theme.text : Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                    Text {
                        visible: Tasks.pending.length > 1
                        text: "+" + (Tasks.pending.length - 1)
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall - 1
                    }
                }
            }

            Item { Layout.fillHeight: true }

            // Controls
            RowLayout {
                spacing: 8
                visible: Countdown.active

                Control {
                    icon: Countdown.phase === "running" ? "pause" : "play_arrow"
                    big: true
                    onClicked: Countdown.toggle()
                }
                Control {
                    visible: Countdown.mode === "timer"
                    icon: "add"
                    onClicked: Countdown.addMinute()
                }
                Control {
                    visible: Countdown.mode === "pomodoro"
                    icon: "skip_next"
                    onClicked: Countdown.skip()
                }
                Text {
                    text: Countdown.mode === "timer" ? Tr.t("+1 min")
                        : Countdown.label === "Focus" ? Tr.t("Skip to break") : Tr.t("Skip to focus")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }
                Item { Layout.fillWidth: true }
                Control {
                    icon: "stop"
                    onClicked: Countdown.reset()
                }
            }
        }
    }

    // − value + (minutes)
    component Stepper: RowLayout {
        id: stepper

        property string label: ""
        property int value: 0
        property int step: 1
        property int min: 1
        property int max: 60
        signal changed(int value)

        spacing: 4

        Text {
            text: stepper.label
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            rightPadding: 2
        }
        Chip {
            text: "−"
            enabled: stepper.value > stepper.min
            onClicked: stepper.changed(Math.max(stepper.min, stepper.value - stepper.step))
        }
        Text {
            Layout.minimumWidth: 40
            horizontalAlignment: Text.AlignHCenter
            text: stepper.value + Tr.t(" min")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.Bold
        }
        Chip {
            text: "+"
            enabled: stepper.value < stepper.max
            onClicked: stepper.changed(Math.min(stepper.max, stepper.value + stepper.step))
        }
    }

    component Chip: Rectangle {
        id: chip

        property string text: ""
        property bool active: false
        signal clicked

        implicitWidth: Math.max(28, chipText.implicitWidth + 20)
        implicitHeight: 28
        radius: height / 2
        opacity: enabled ? 1 : 0.4
        color: active ? Theme.accent : chipMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: chipMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Text {
            id: chipText
            anchors.centerIn: parent
            text: chip.text
            color: chip.active ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }

        MouseArea {
            id: chipMouse
            anchors.fill: parent
            enabled: chip.enabled
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: chip.clicked()
        }
    }
}
