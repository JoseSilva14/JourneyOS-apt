import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Home: greeting and shortcuts to the other pages.
Page {
    id: root

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    readonly property int hour: clock.date.getHours()

    RowLayout {
        Layout.fillWidth: true
        Layout.bottomMargin: Theme.gap
        spacing: 16

        RoundImage {
            id: avatar
            implicitWidth: 72
            implicitHeight: 72
            radius: 36
            source: User.face

            Text {
                anchors.centerIn: parent
                visible: !avatar.ready
                text: User.name.charAt(0).toUpperCase()
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 28
                font.weight: Font.Bold
            }
        }

        ColumnLayout {
            spacing: 4
            Text {
                text: (root.hour >= 6 && root.hour < 12 ? Tr.t("Good morning")
                    : root.hour >= 12 && root.hour < 20 ? Tr.t("Good afternoon") : Tr.t("Good evening")) + ", " + User.name
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge + 2
                font.weight: Font.Bold
            }
            Text {
                text: SystemInfo.os + " · " + SystemInfo.desktop + Tr.t(" · up for ") + Stats.duration(Stats.uptime)
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        Item {
            Layout.fillWidth: true
        }

        // Reopens the first-run wizard
        PillButton {
            text: Tr.t("Welcome")
            onClicked: Welcome.show()
        }
    }

    GridLayout {
        Layout.fillWidth: true
        columns: 3
        rowSpacing: 10
        columnSpacing: 10

        Repeater {
            model: SettingsApp.pages.filter(p => p.id !== "home")

            Rectangle {
                id: tile
                required property var modelData

                Layout.fillWidth: true
                implicitHeight: 72
                radius: Theme.radius
                color: tileMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
                border.width: 1
                border.color: Theme.surfaceBorder
                scale: tileMouse.pressed ? 0.98 : 1

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }
                Behavior on scale {
                    NumberAnimation { duration: Theme.animFast }
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 12

                    Rectangle {
                        implicitWidth: 38
                        implicitHeight: 38
                        radius: Theme.radiusSmall + 2
                        color: Theme.button

                        MIcon {
                            anchors.centerIn: parent
                            icon: tile.modelData.icon
                            size: 19
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        text: tile.modelData.label
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.DemiBold
                    }
                }

                MouseArea {
                    id: tileMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: SettingsApp.page = tile.modelData.id
                }
            }
        }
    }
}
