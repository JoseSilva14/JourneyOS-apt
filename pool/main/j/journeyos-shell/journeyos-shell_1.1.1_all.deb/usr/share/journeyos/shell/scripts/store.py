#!/usr/bin/env python3
"""App store backend (services/Store): Flatpak apps from Flathub, installed for the user (no password).

  store.py status             {"flatpak", "ready", "installed": [...], "updates": [...], "nvidia": {...}}
  store.py setup              adds Flathub (user) + downloads its catalogue + Breeze GTK theme; then index
  store.py index              the catalogue → ~/.cache/journeyos/store.json [{id, name, summary, icon, kw}]
  store.py install <id>       \\
  store.py remove <id>         > print progress lines {"progress": n, "text"} and finally {"done", "ok", "error"}
  store.py update             /
Catalogue icons come from Flathub's appstream download (icons/128x128/<id>.png).
"""

import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

HOME = os.path.expanduser("~")
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.join(HOME, ".cache")), "journeyos")
INDEX = os.path.join(CACHE, "store.json")
APPSTREAM = os.path.join(HOME, ".local/share/flatpak/appstream/flathub")
LANG = (os.environ.get("SHADOW_LANG") or "en").split("_")[0]


def out(obj):
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def run(*cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def arch_dir():
    if not os.path.isdir(APPSTREAM):
        return None
    for a in os.listdir(APPSTREAM):
        d = os.path.join(APPSTREAM, a, "active")
        if os.path.isdir(d):
            return d
    return None


def has_remote():
    code, so, _ = run("flatpak", "remotes", "--user", "--columns=name")
    return code == 0 and "flathub" in so.split()


def installed():
    code, so, _ = run("flatpak", "list", "--user", "--app", "--columns=application,name,version")
    apps = []
    if code == 0:
        for line in so.splitlines():
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0]:
                apps.append({"id": parts[0], "name": parts[1], "version": parts[2] if len(parts) > 2 else ""})
    return apps


def updates():
    code, so, _ = run("flatpak", "remote-ls", "--user", "--updates", "--app", "--columns=application")
    return [l.strip() for l in so.splitlines() if l.strip()] if code == 0 else []


def nvidia():
    """An NVIDIA card without NVIDIA's driver in use (nouveau or nothing)."""
    code, so, _ = run("lspci", "-nn")
    gpus = [l for l in so.splitlines() if re.search(r"VGA|3D|Display", l) and re.search(r"NVIDIA|\[10de:", l)]
    if not gpus:
        return {"present": False}
    loaded = os.path.exists("/proc/driver/nvidia/version")
    name = re.sub(r".*: ", "", gpus[0]).split(" [")[0] if gpus else ""
    name = re.sub(r"\s*\(rev .*\)", "", name)
    return {"present": True, "driver": loaded, "name": name}


def localized(el, tag):
    """The element's text in the shell language, else the untranslated one."""
    plain = None
    for c in el.findall(tag):
        lang = c.get("{http://www.w3.org/XML/1998/namespace}lang")
        if lang and lang.split("_")[0] == LANG:
            return (c.text or "").strip()
        if lang is None and plain is None:
            plain = (c.text or "").strip()
    return plain or ""


def index():
    d = arch_dir()
    if not d:
        out({"done": True, "ok": False, "error": "no catalogue"})
        return 1
    src = os.path.join(d, "appstream.xml.gz")
    if not os.path.exists(src):
        src = os.path.join(d, "appstream.xml")
    icons = os.path.join(d, "icons", "128x128")
    opener = gzip.open if src.endswith(".gz") else open
    apps = []
    with opener(src, "rb") as fh:
        for _, el in ET.iterparse(fh, events=("end",)):
            if el.tag != "component":
                continue
            if el.get("type") not in ("desktop", "desktop-application"):
                el.clear()
                continue
            cid = (el.findtext("id") or "").strip()
            if cid.endswith(".desktop"):
                cid = cid[:-8]
            name = localized(el, "name")
            if not cid or not name:
                el.clear()
                continue
            icon = os.path.join(icons, cid + ".png")
            kw = " ".join((k.text or "") for k in el.iter("keyword"))
            apps.append({"id": cid, "name": name, "summary": localized(el, "summary"),
                         "icon": icon if os.path.exists(icon) else "", "kw": kw.lower()})
            el.clear()
    apps.sort(key=lambda a: a["name"].lower())
    os.makedirs(CACHE, exist_ok=True)
    tmp = INDEX + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(apps, fh, ensure_ascii=False)
    os.replace(tmp, INDEX)
    out({"done": True, "ok": True, "count": len(apps)})
    return 0


def stream(cmd):
    """Runs a flatpak command, turning its output into progress lines."""
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    last = ""
    for raw in p.stdout:
        for line in re.split(r"[\r\n]", raw):
            line = line.strip()
            if not line:
                continue
            last = line
            m = re.search(r"(\d+)%", line)
            out({"progress": int(m.group(1)) if m else -1, "text": line[:120]})
    code = p.wait()
    return code, last


def setup():
    if not shutil.which("flatpak"):
        out({"done": True, "ok": False, "error": "flatpak is not installed"})
        return 1
    out({"progress": -1, "text": "Flathub"})
    code, _, err = run("flatpak", "remote-add", "--user", "--if-not-exists", "flathub",
                       "https://dl.flathub.org/repo/flathub.flatpakrepo")
    if code != 0:
        out({"done": True, "ok": False, "error": err.strip()[:200]})
        return 1
    code, last = stream(["flatpak", "update", "--user", "--appstream", "flathub"])
    if code != 0:
        out({"done": True, "ok": False, "error": last})
        return 1
    # Flatpak apps read the shell's GTK colours (colors.css) and KDE settings; Breeze for GTK apps
    run("flatpak", "override", "--user", "--filesystem=xdg-config/gtk-3.0:ro",
        "--filesystem=xdg-config/gtk-4.0:ro", "--filesystem=xdg-config/kdeglobals:ro")
    stream(["flatpak", "install", "--user", "-y", "--noninteractive", "flathub",
            "org.gtk.Gtk3theme.Breeze", "org.gtk.Gtk3theme.Breeze-Dark"])
    return index()


def action(kind, app):
    if kind == "install":
        cmd = ["flatpak", "install", "--user", "-y", "--noninteractive", "flathub", app]
    elif kind == "remove":
        cmd = ["flatpak", "uninstall", "--user", "-y", "--noninteractive", app]
    else:
        cmd = ["flatpak", "update", "--user", "-y", "--noninteractive"]
    code, last = stream(cmd)
    if code == 0 and kind == "remove":
        # Runtimes nothing uses any more (a removed app's GNOME/KDE platform: hundreds of MB)
        run("flatpak", "uninstall", "--user", "--unused", "-y", "--noninteractive")
    out({"done": True, "ok": code == 0, "error": "" if code == 0 else last})
    return code


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "status":
        ok = bool(shutil.which("flatpak"))
        ready = ok and has_remote() and os.path.exists(INDEX)
        out({"flatpak": ok, "ready": ready, "installed": installed() if ok else [],
             "updates": updates() if ready else [], "nvidia": nvidia()})
        return 0
    if cmd == "setup":
        return setup()
    if cmd == "index":
        return index()
    if cmd in ("install", "remove") and len(sys.argv) > 2:
        return action(cmd, sys.argv[2])
    if cmd == "update":
        return action("update", "")
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
