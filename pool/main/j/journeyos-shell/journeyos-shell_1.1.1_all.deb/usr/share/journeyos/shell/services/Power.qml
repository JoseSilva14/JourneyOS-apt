pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Services.UPower

// Power: profile (powerprofilesctl), dimming/turning off the screen and suspending (powerdevilrc, per
// "AC" = plugged in and "Battery") and automatic locking (kscreenlockerrc, from kscreenlocker).
Singleton {
    id: root

    readonly property bool hasBattery: UPower.displayDevice?.isLaptopBattery ?? false

    property string profile: ""
    property var profiles: []           // ["power-saver", "balanced", "performance"]

    // Per powerdevil profile: { dim, off, suspend } in seconds (-1 = never), suspendAction
    property var settings: ({ AC: {}, Battery: {} })

    property bool autolock: false
    property int lockMinutes: 5
    property bool lockOnResume: true

    readonly property var profileNames: ({
        "power-saver": Tr.t("Power saver"), "balanced": Tr.t("Balanced"), "performance": Tr.t("Performance")
    })

    function refresh() {
        Run.cmd(["powerprofilesctl", "list"], (code, out) => {
            const list = [];
            let current = "";
            for (const line of out.split("\n")) {
                const m = line.match(/^(\*)?\s*([a-z-]+):$/);
                if (m) {
                    list.push(m[2]);
                    if (m[1])
                        current = m[2];
                }
            }
            root.profiles = list;
            root.profile = current;
        });
        const keys = [];
        for (const p of ["AC", "Battery"]) {
            keys.push({ group: [p, "Display"], key: "DimDisplayWhenIdle", fallback: "true" });
            keys.push({ group: [p, "Display"], key: "DimDisplayIdleTimeoutSec", fallback: "300" });
            keys.push({ group: [p, "Display"], key: "TurnOffDisplayWhenIdle", fallback: "true" });
            keys.push({ group: [p, "Display"], key: "TurnOffDisplayIdleTimeoutSec", fallback: "600" });
            keys.push({ group: [p, "SuspendAndShutdown"], key: "AutoSuspendAction", fallback: "1" });
            keys.push({ group: [p, "SuspendAndShutdown"], key: "AutoSuspendIdleTimeoutSec", fallback: "900" });
        }
        Kcfg.readMany("powerdevilrc", keys, v => {
            const s = {};
            for (const p of ["AC", "Battery"]) {
                const g = k => v[p + "/" + k];
                s[p] = {
                    dim: g("Display/DimDisplayWhenIdle") === "true" ? Number(g("Display/DimDisplayIdleTimeoutSec")) : -1,
                    off: g("Display/TurnOffDisplayWhenIdle") === "true" ? Number(g("Display/TurnOffDisplayIdleTimeoutSec")) : -1,
                    suspend: g("SuspendAndShutdown/AutoSuspendAction") !== "0" ? Number(g("SuspendAndShutdown/AutoSuspendIdleTimeoutSec")) : -1
                };
            }
            root.settings = s;
        });
        Kcfg.readMany("kscreenlockerrc", [
            { group: "Daemon", key: "Autolock", fallback: "true" },
            { group: "Daemon", key: "Timeout", fallback: "5" },
            { group: "Daemon", key: "LockOnResume", fallback: "true" }
        ], v => {
            root.autolock = v["Daemon/Autolock"] === "true";
            root.lockMinutes = Number(v["Daemon/Timeout"]) || 5;
            root.lockOnResume = v["Daemon/LockOnResume"] === "true";
        });
    }

    function setProfile(name) {
        Run.cmd(["powerprofilesctl", "set", name], () => refresh());
    }

    // what: dim | off | suspend; seconds: -1 = never
    function setIdle(p, what, seconds) {
        const never = seconds < 0;
        const done = () => Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.Solid.PowerManagement",
            "--object-path", "/org/kde/Solid/PowerManagement", "--method",
            "org.kde.Solid.PowerManagement.reparseConfiguration"], () => refresh());
        if (what === "suspend") {
            Kcfg.write("powerdevilrc", [p, "SuspendAndShutdown"], "AutoSuspendAction", never ? "0" : "1", () => {
                if (never)
                    done();
                else
                    Kcfg.write("powerdevilrc", [p, "SuspendAndShutdown"], "AutoSuspendIdleTimeoutSec", String(seconds), done);
            });
            return;
        }
        const prefix = what === "dim" ? "DimDisplay" : "TurnOffDisplay";
        Kcfg.write("powerdevilrc", [p, "Display"], prefix + "WhenIdle", !never, () => {
            if (never)
                done();
            else
                Kcfg.write("powerdevilrc", [p, "Display"], prefix + "IdleTimeoutSec", String(seconds), done);
        });
    }

    function setLock(key, value) {
        Kcfg.write("kscreenlockerrc", "Daemon", key, value, () => {
            Run.cmd(["gdbus", "call", "--session", "--dest", "org.freedesktop.ScreenSaver", "--object-path",
                "/ScreenSaver", "--method", "org.kde.screensaver.configure"], () => refresh());
        });
    }

}
