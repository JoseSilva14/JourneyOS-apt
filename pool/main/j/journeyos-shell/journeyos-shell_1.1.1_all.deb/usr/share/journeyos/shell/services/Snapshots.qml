pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// System snapshots (snapper on btrfs, set up on the first boot by journeyos-snapper-setup).
// Admins (sudo group, snapper's ALLOW_GROUPS) list, create and delete them through snapperd,
// without root; undoing an update (snapper undochange of an apt pre/post pair) asks for authorization.
Singleton {
    id: root

    // unknown | ok | missing (snapper not installed) | noconfig (not btrfs / not set up) | denied
    property string state: "unknown"
    property var snapshots: []          // [{ number, type, pre, date, description, cleanup, user, important }]
    property bool busy: false
    property string message: ""
    // snapper config ("root" = the system; IPC useConfig changes it for tests)
    property string config: "root"

    // apt pairs as one entry: { pre, post, date, description } + the single ones
    readonly property var entries: {
        const byNumber = {};
        for (const s of snapshots)
            byNumber[s.number] = s;
        const out = [];
        for (const s of snapshots) {
            if (s.number === 0 || s.type === "pre")
                continue;
            if (s.type === "post") {
                const pre = byNumber[s.pre];
                out.push({ kind: "pair", pre: s.pre, post: s.number, date: s.date,
                           description: (pre?.description || s.description || "apt"), cleanup: s.cleanup });
            } else {
                out.push({ kind: "single", number: s.number, date: s.date, description: s.description,
                           cleanup: s.cleanup, important: s.important });
            }
        }
        return out.reverse();       // newest first
    }

    function refresh() {
        if (!lister.running)
            lister.running = true;
    }

    function create(description) {
        busy = true;
        Run.cmd(["snapper", "-c", root.config, "create", "--cleanup-algorithm", "number",
                 "--description", description || Tr.t("Manual snapshot")], (code, out, err) => {
            busy = false;
            message = code === 0 ? Tr.t("Snapshot created") : err.trim();
            refresh();
        });
    }

    function remove(numbers) {
        busy = true;
        Run.cmd(["snapper", "-c", root.config, "delete", ...numbers.map(String)], (code, out, err) => {
            busy = false;
            message = code === 0 ? Tr.t("Snapshot deleted") : err.trim();
            refresh();
        });
    }

    // Undo what an update changed (files go back to how they were before it). Needs root.
    function undo(pre, post) {
        busy = true;
        message = Tr.t("Undoing the update…");
        Run.cmd(["pkexec", "snapper", "-c", root.config, "undochange", pre + ".." + post], (code, out, err) => {
            busy = false;
            message = code === 0 ? Tr.t("Update undone. Restart the computer to be sure everything uses the old versions.")
                : code === 126 || code === 127 ? Tr.t("Not authorized") : err.trim();
            refresh();
        });
    }

    Process {
        id: lister
        command: ["sh", "-c", "command -v snapper >/dev/null || { echo MISSING; exit 0; }; snapper --jsonout -c \"$1\" list 2>&1", "sh", root.config]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim();
                if (t === "MISSING") {
                    root.state = "missing";
                    root.snapshots = [];
                    return;
                }
                try {
                    const d = JSON.parse(t);
                    root.snapshots = (d[root.config] ?? []).map(s => ({
                        number: s.number, type: s.type, pre: s["pre-number"] ?? 0, date: s.date ?? "",
                        description: s.description ?? "", cleanup: s.cleanup ?? "", user: s.user ?? "",
                        important: (s.userdata?.important ?? "") === "yes"
                    }));
                    root.state = "ok";
                } catch (e) {
                    root.snapshots = [];
                    root.state = /denied|permission|No permissions/i.test(t) ? "denied" : "noconfig";
                }
            }
        }
    }

    IpcHandler {
        target: "snapshots"
        function status(): string { return JSON.stringify({ state: root.state, count: root.snapshots.length, message: root.message }); }
        function refresh(): void { root.refresh(); }
        function create(description: string): void { root.create(description); }
        function useConfig(name: string): void { root.config = name || "root"; root.refresh(); }
    }
}
