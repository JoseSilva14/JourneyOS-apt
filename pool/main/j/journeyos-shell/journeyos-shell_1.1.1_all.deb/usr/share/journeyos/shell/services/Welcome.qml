pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// First-run wizard (welcome/WelcomeWindow): theme, wallpaper, dock, network and the
// main shortcuts. Opens on its own while config.json "welcome.done" is false; can be
// reopened from Settings (Home) or the launcher ("Boas-vindas" = "Welcome").
Singleton {
    id: root

    property bool open: false
    property int step: 0

    readonly property var steps: [
        { id: "hello", title: Tr.t("Hello"), icon: "waving_hand" },
        { id: "look", title: Tr.t("Look"), icon: "palette" },
        { id: "wallpaper", title: "Wallpaper", icon: "wallpaper" },
        { id: "dock", title: "Dock", icon: "dock" },
        { id: "network", title: Tr.t("Network"), icon: "wifi" },
        { id: "keys", title: Tr.t("Shortcuts"), icon: "keyboard_command_key" }
    ]
    readonly property bool last: step === steps.length - 1

    function show() {
        step = 0;
        open = true;
        SettingsApp.open = false;
        Dashboard.open = false;
        Launcher.open = false;
        QuickPanel.open = false;
    }

    function next() {
        if (last)
            finish();
        else
            step += 1;
    }

    function back() { step = Math.max(0, step - 1); }

    // Finish or skip: does not open on its own again
    function finish() {
        Config.options.welcome.done = true;
        open = false;
    }

    // First time: waits for the config and the rest of the shell before opening. Only once per session
    // (marker in $XDG_RUNTIME_DIR): reloading the shell does not reopen it on top of everything.
    Timer {
        running: Config.ready && !Config.options.welcome.done
        interval: 2500
        onTriggered: Run.sh('m="${XDG_RUNTIME_DIR:-/tmp}/shadow-kde-welcome"; [ ! -e "$m" ] && touch "$m"',
            code => { if (code === 0 && !Config.options.welcome.done) root.show(); })
    }

    IpcHandler {
        target: "welcome"
        function open(): void { root.show(); }
        function close(): void { root.open = false; }
        function go(step: int): void { root.show(); root.step = Math.max(0, Math.min(root.steps.length - 1, step)); }
    }
}
