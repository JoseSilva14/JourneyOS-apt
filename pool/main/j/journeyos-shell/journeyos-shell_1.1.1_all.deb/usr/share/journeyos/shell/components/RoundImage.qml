import QtQuick
import qs

// Image with rounded corners. Drawn on a Canvas because ClippingRectangle
// uses a shader and does not show up in the software renderer.
Canvas {
    id: root

    property string source: ""
    property real radius: Theme.radius
    property color fallback: Theme.button
    property bool ready: false

    onSourceChanged: load()
    Component.onCompleted: load()

    function load() {
        ready = false;
        if (source !== "") {
            loadImage(source);
            // Already loaded before: imageLoaded will not fire again
            ready = isImageLoaded(source);
        }
        requestPaint();
    }
    onImageLoaded: {
        ready = isImageLoaded(source);
        requestPaint();
    }
    onRadiusChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        const ctx = getContext("2d");
        const w = width, h = height, r = Math.min(radius, w / 2, h / 2);
        ctx.reset();
        ctx.beginPath();
        ctx.moveTo(r, 0);
        ctx.arcTo(w, 0, w, h, r);
        ctx.arcTo(w, h, 0, h, r);
        ctx.arcTo(0, h, 0, 0, r);
        ctx.arcTo(0, 0, w, 0, r);
        ctx.closePath();
        ctx.fillStyle = fallback;
        ctx.fill();
        if (ready) {
            ctx.clip();
            ctx.drawImage(source, 0, 0, w, h);
        }
    }
}
