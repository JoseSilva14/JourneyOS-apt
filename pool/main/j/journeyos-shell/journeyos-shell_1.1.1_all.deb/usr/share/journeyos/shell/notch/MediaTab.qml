import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Music tab: cover, title, artist and controls; without music, the time, date and weather.
Item {
    id: root

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    RowLayout {
        anchors.fill: parent
        spacing: 14
        visible: Media.player !== null

        RoundImage {
            id: art
            implicitWidth: 104
            implicitHeight: 104
            radius: Theme.radius
            source: Media.art

            MIcon {
                anchors.centerIn: parent
                visible: !art.ready
                icon: "music_note"
                size: 36
                color: Theme.subtext
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 2

            RowLayout {
                Layout.fillWidth: true
                Text {
                    Layout.fillWidth: true
                    text: Media.title
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontMedium
                    font.weight: Font.Bold
                }
                Bars {
                    running: Media.playing
                }
            }
            Text {
                Layout.fillWidth: true
                text: Media.artist || (Media.player?.identity ?? "")
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            Item { Layout.fillHeight: true }

            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 10

                Control {
                    icon: "skip_previous"
                    enabled: Media.player?.canGoPrevious ?? false
                    onClicked: Media.previous()
                }
                Control {
                    icon: Media.playing ? "pause" : "play_arrow"
                    big: true
                    onClicked: Media.toggle()
                }
                Control {
                    icon: "skip_next"
                    enabled: Media.player?.canGoNext ?? false
                    onClicked: Media.next()
                }
            }
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 16
        visible: Media.player === null

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 2

            Text {
                text: DateTime.time(clock.date)
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 44
                font.weight: Font.Bold
            }
            Text {
                text: {
                    const s = Tr.locale.toString(clock.date, Tr.t("dddd, d MMMM"));
                    return s.charAt(0).toUpperCase() + s.slice(1);
                }
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Text {
                text: Tr.t("Nothing playing")
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        ColumnLayout {
            visible: Weather.ready
            spacing: 0

            MIcon {
                Layout.alignment: Qt.AlignHCenter
                icon: Weather.icon
                size: 38
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: Weather.temp + "°"
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge
                font.weight: Font.Bold
            }
        }
    }
}
