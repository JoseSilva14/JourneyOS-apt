import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// App appearance: fonts, icons, cursor and animations (the colour theme is under Theme).
Page {
    id: root

    Component.onCompleted: SystemLook.refresh()

    SectionLabel { text: Tr.t("Fonts") }

    SettingRow {
        title: Tr.t("Apps")
        icon: "text_fields"
        Select {
            options: SystemLook.families
            current: SystemLook.font
            searchable: true
            onSelected: id => SystemLook.setFont(id)
        }
    }

    SettingRow {
        title: Tr.t("Size · ") + SystemLook.fontSize + Tr.t(" pt")
        icon: "format_size"
        Segmented {
            model: [9, 10, 11, 12, 13].map(s => ({ id: String(s), label: String(s) }))
            current: String(SystemLook.fontSize)
            onSelected: id => SystemLook.setFontSize(Number(id))
        }
    }

    SettingRow {
        title: Tr.t("Monospace")
        description: Tr.t("In the terminal and code editors.")
        icon: "code"
        Select {
            options: SystemLook.families
            current: SystemLook.fixedFont
            searchable: true
            onSelected: id => SystemLook.setFixedFont(id)
        }
    }

    SectionLabel { text: Tr.t("Icons and cursor") }

    SettingRow {
        title: Tr.t("Icons")
        icon: "interests"
        Select {
            options: SystemLook.iconThemes
            current: SystemLook.iconTheme
            onSelected: id => SystemLook.setIconTheme(id)
        }
    }

    SettingRow {
        title: Tr.t("Cursor")
        icon: "mouse"
        Select {
            options: SystemLook.cursorThemes
            current: SystemLook.cursorTheme
            onSelected: id => SystemLook.setCursor(id, SystemLook.cursorSize)
        }
    }

    SettingRow {
        title: Tr.t("Cursor size")
        icon: "open_in_full"
        Segmented {
            model: [24, 32, 48].map(s => ({ id: String(s), label: s === 24 ? Tr.t("Normal") : s === 32 ? Tr.t("Large") : Tr.t("Huge") }))
            current: String(SystemLook.cursorSize)
            onSelected: id => SystemLook.setCursor(SystemLook.cursorTheme, Number(id))
        }
    }

    SectionLabel { text: Tr.t("Motion") }

    SettingRow {
        title: Tr.t("Window animations")
        description: Tr.t("Opening, closing and minimizing windows.")
        icon: "animation"
        Segmented {
            model: [
                { id: "0", label: Tr.t("None##sem") },
                { id: "0.5", label: Tr.t("Fast") },
                { id: "1", label: Tr.t("Normal##pl") },
                { id: "2", label: Tr.t("Slow") }
            ]
            current: String(SystemLook.animationFactor)
            onSelected: id => SystemLook.setAnimationFactor(Number(id))
        }
    }
}
