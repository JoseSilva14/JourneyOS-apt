import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Apps tab: all installed apps in a grid, with search and the pinned filter.
// Clicking opens (and closes the dashboard); the pin (or right click) pins/unpins from the dock; the eye hides
// (Settings → Apps in the launcher shows it again).
// Enter opens the first; Esc closes.
// With pinMode (in the welcome wizard) clicking pins/unpins instead of opening.
ColumnLayout {
    id: root

    signal closeRequested

    property string query: ""
    property string filter: "all"      // all | pinned | store (Flathub, StoreView)
    property bool pinMode: false

    readonly property var pinned: Config.options.dock.pinned
    readonly property var shown: {
        const q = Launcher.norm(query.trim());
        let list = Launcher.apps.filter(e => e.id !== Dashboard.desktopId);
        if (filter === "pinned")
            list = list.filter(e => pinned.includes(e.id));
        if (!q)
            return list.slice().sort((a, b) => a.name.localeCompare(b.name));
        return list.map(e => ({ e, s: Launcher.score(e, q) }))
            .filter(x => x.s > 0)
            .sort((a, b) => b.s - a.s)
            .map(x => x.e);
    }

    function open(entry) {
        Launcher.launch(Launcher.appItem(entry));
        root.closeRequested();
    }

    function activate(entry) {
        if (pinMode)
            togglePin(entry);
        else
            open(entry);
    }

    function togglePin(entry) {
        DockApps.setPinned(entry.id, !pinned.includes(entry.id));
    }

    spacing: Theme.gap

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 38
            radius: height / 2
            color: Theme.button

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 14
                anchors.rightMargin: 14
                spacing: 8

                MIcon {
                    icon: "search"
                    size: 18
                    color: Theme.subtext
                }

                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    clip: true
                    focus: !root.pinMode
                    onTextChanged: {
                        root.query = text;
                        grid.positionViewAtBeginning();
                    }
                    onAccepted: if (root.filter !== "store" && root.shown.length > 0) root.activate(root.shown[0])
                    Keys.onEscapePressed: root.closeRequested()

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !search.text
                        text: root.filter === "store" ? Tr.t("Search Flathub") : Tr.t("Search apps")
                        color: Theme.dim
                        font: search.font
                    }
                }

                Text {
                    visible: root.filter !== "store"
                    text: root.shown.length
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        Segmented {
            model: [
                { id: "all", label: Tr.t("All"), icon: "apps" },
                { id: "pinned", label: Tr.t("Pinned"), icon: "push_pin" },
                // The store, except in the welcome wizard (pin mode)
                ...(root.pinMode ? [] : [{ id: "store", label: Tr.t("Store"), icon: "storefront" }])
            ]
            current: root.filter
            onSelected: id => root.filter = id
        }
    }

    StoreView {
        visible: root.filter === "store"
        Layout.fillWidth: true
        Layout.fillHeight: true
        query: root.query
        onCloseRequested: root.closeRequested()
    }

    GridView {
        id: grid
        visible: root.filter !== "store"
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        readonly property int columns: Math.max(4, Math.floor(width / 116))
        cellWidth: width / columns
        cellHeight: 112
        model: root.shown

        delegate: Item {
            id: cell
            required property var modelData
            required property int index
            readonly property bool isPinned: root.pinned.includes(modelData.id)
            // With a search, the first one is what Enter opens
            readonly property bool first: index === 0 && root.query.trim() !== ""
            readonly property string iconSource: {
                const name = modelData.icon ?? "";
                return !name ? "" : name.startsWith("/") ? "file://" + name : Quickshell.iconPath(name, true);
            }

            width: grid.cellWidth
            height: grid.cellHeight

            Rectangle {
                id: tile
                anchors.fill: parent
                anchors.margins: 4
                radius: Theme.radius
                // No transition, like the launcher rows
                color: cellMouse.containsMouse || cell.first ? Theme.buttonHover : "transparent"
                border.width: cell.first ? 1 : 0
                border.color: Theme.surfaceBorder
                scale: cellMouse.pressed ? 0.95 : 1

                Behavior on scale {
                    NumberAnimation { duration: Theme.animFast }
                }

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 8
                    anchors.topMargin: 12
                    spacing: 6

                    IconImage {
                        id: image
                        Layout.alignment: Qt.AlignHCenter
                        implicitSize: 44
                        source: cell.iconSource
                        visible: cell.iconSource !== "" && status === Image.Ready
                    }
                    // No icon in the theme: the initial
                    Rectangle {
                        Layout.alignment: Qt.AlignHCenter
                        visible: !image.visible
                        implicitWidth: 44
                        implicitHeight: 44
                        radius: 12
                        color: Theme.button

                        Text {
                            anchors.centerIn: parent
                            text: cell.modelData.name.charAt(0).toUpperCase()
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: 20
                            font.weight: Font.Bold
                        }
                    }

                    Text {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        text: cell.modelData.name
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        maximumLineCount: 2
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }

                MouseArea {
                    id: cellMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    onClicked: m => {
                        if (m.button === Qt.RightButton)
                            root.togglePin(cell.modelData);
                        else
                            root.activate(cell.modelData);
                    }
                }

                // Pin: always visible on pinned ones, on the others only on hover
                Rectangle {
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 4
                    width: 26
                    height: 26
                    radius: 13
                    visible: cell.isPinned || cellMouse.containsMouse || pinMouse.containsMouse || hideMouse.containsMouse
                    color: cell.isPinned ? Theme.accent : pinMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
                    border.width: cell.isPinned ? 0 : 1
                    border.color: Theme.surfaceBorder

                    Behavior on color {
                        ColorAnimation { duration: Theme.animFast }
                    }

                    MIcon {
                        anchors.centerIn: parent
                        icon: "push_pin"
                        size: 14
                        color: cell.isPinned ? Theme.accentText : Theme.subtext
                        rotation: cell.isPinned ? 0 : 45
                        Behavior on rotation {
                            NumberAnimation { duration: Theme.animFast }
                        }
                    }

                    MouseArea {
                        id: pinMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.togglePin(cell.modelData)
                    }
                }

                // Hide (from the launcher and here; comes back in Settings → Apps in the launcher)
                Rectangle {
                    anchors.left: parent.left
                    anchors.top: parent.top
                    anchors.margins: 4
                    width: 26
                    height: 26
                    radius: 13
                    visible: !root.pinMode && (cellMouse.containsMouse || pinMouse.containsMouse || hideMouse.containsMouse)
                    color: hideMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
                    border.width: 1
                    border.color: Theme.surfaceBorder

                    MIcon {
                        anchors.centerIn: parent
                        icon: "visibility_off"
                        size: 14
                        color: Theme.subtext
                    }
                    MouseArea {
                        id: hideMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            ShellApps.setHidden(cell.modelData.id, true);
                            Events.push({ icon: "visibility_off", title: Tr.t("App hidden"), text: cell.modelData.name + Tr.t(" · bring it back in Settings → Launcher apps"), duration: 2500 });
                        }
                    }
                }
            }
        }

        Text {
            anchors.centerIn: parent
            visible: grid.count === 0
            text: root.filter === "pinned" && !root.query.trim() ? Tr.t("You haven't pinned any apps yet.") : Tr.t("No apps found.")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
