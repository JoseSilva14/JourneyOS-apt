import QtQuick
import qs
import qs.services

// CPU, RAM and GPU, one card above the other.
Column {
    id: root

    property bool plain: false

    spacing: Theme.gap

    ResourceCard {
        plain: root.plain
        label: "CPU"
        icon: "memory"
        value: Stats.cpu
    }
    ResourceCard {
        plain: root.plain
        label: "RAM"
        icon: "developer_board"
        value: Stats.ram
    }
    ResourceCard {
        plain: root.plain
        label: "GPU"
        icon: "monitor"
        value: Stats.gpu
        available: Stats.hasGpu
    }
}
