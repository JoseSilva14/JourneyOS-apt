#!/usr/bin/env python3
"""Lists the wallpapers in the given folders, as JSON: [{"path", "name"}].

A KDE theme folder (/usr/share/wallpapers: <theme>/contents/images/<res>.<ext>)
gives one image per theme (1920x1080 if present, otherwise the largest) with the name from
metadata.json; other folders give the images they contain, sorted by name.
"""

import json
import os
import re
import sys

EXTS = (".png", ".jpg", ".jpeg", ".webp", ".svg")


def kde_theme(theme_dir):
    images = os.path.join(theme_dir, "contents", "images")
    if not os.path.isdir(images):
        return None
    files = [f for f in os.listdir(images) if f.lower().endswith(EXTS)]
    if not files:
        return None

    def area(f):
        m = re.match(r"(\d+)x(\d+)", f)
        return int(m[1]) * int(m[2]) if m else 0

    best = next((f for f in files if f.startswith("1920x1080")), None) or max(files, key=area)
    name = os.path.basename(theme_dir)
    try:
        with open(os.path.join(theme_dir, "metadata.json"), encoding="utf-8") as fh:
            name = json.load(fh)["KPlugin"]["Name"]
    except (OSError, KeyError, ValueError):
        pass
    return {"path": os.path.join(images, best), "name": name}


def scan(folder):
    out = []
    try:
        entries = sorted(os.listdir(folder), key=str.lower)
    except OSError:
        return out
    for e in entries:
        p = os.path.join(folder, e)
        if os.path.isdir(p):
            theme = kde_theme(p)
            if theme:
                out.append(theme)
            else:
                out.extend(scan(p))
        elif e.lower().endswith(EXTS):
            out.append({"path": p, "name": os.path.splitext(e)[0]})
    return out


def main():
    result, seen = [], set()
    for folder in sys.argv[1:]:
        for w in scan(os.path.expanduser(folder)):
            # Some themes are links to others: only one per real file
            real = os.path.realpath(w["path"])
            if real not in seen:
                seen.add(real)
                result.append(w)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
