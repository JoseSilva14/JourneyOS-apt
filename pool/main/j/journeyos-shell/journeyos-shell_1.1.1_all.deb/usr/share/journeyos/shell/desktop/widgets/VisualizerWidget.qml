import QtQuick
import qs
import qs.components
import qs.services

// Sound visualizer: bars that rise and fall with the music (via cava).
Card {
    id: root

    width: 340
    height: 110

    Row {
        id: bars
        anchors.fill: parent
        anchors.margins: 14
        visible: Cava.available
        spacing: 4

        readonly property real barWidth: (width - spacing * (Cava.bars - 1)) / Cava.bars

        Repeater {
            model: Cava.bars

            Rectangle {
                required property int index
                readonly property real level: Cava.values[index] ?? 0

                anchors.bottom: parent.bottom
                width: bars.barWidth
                height: Math.max(3, bars.height * level)
                radius: Math.min(width / 2, 3)
                color: Theme.accent
                opacity: 0.35 + 0.65 * level
            }
        }
    }

    Column {
        anchors.centerIn: parent
        visible: !Cava.available
        spacing: 4

        MIcon {
            anchors.horizontalCenter: parent.horizontalCenter
            icon: "graphic_eq"
            size: 26
            color: Theme.dim
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Tr.t("Needs cava: sudo apt install cava")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
