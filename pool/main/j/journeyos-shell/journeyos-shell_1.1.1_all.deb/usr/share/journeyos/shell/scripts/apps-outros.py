#!/usr/bin/env python3
""".desktop entries that are not meant for KDE (NotShowIn=KDE, or OnlyShowIn without KDE):
Quickshell's DesktopEntries does not read these fields and the launcher showed them (e.g. "KDE
System Settings", made for other desktops). Writes the ids, one per line."""
import configparser
import os

DIRS = [os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")), "applications")]
DIRS += [os.path.join(d, "applications") for d in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":") if d]

seen = set()
for base in DIRS:
    if not os.path.isdir(base):
        continue
    for root, _, files in os.walk(base):
        for f in files:
            if not f.endswith(".desktop"):
                continue
            did = os.path.relpath(os.path.join(root, f), base)[:-8].replace("/", "-")
            if did in seen:
                continue
            seen.add(did)
            c = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                c.read(os.path.join(root, f), encoding="utf-8")
                e = c["Desktop Entry"]
            except Exception:
                continue
            only = [x for x in e.get("OnlyShowIn", "").split(";") if x]
            nots = [x for x in e.get("NotShowIn", "").split(";") if x]
            if "KDE" in nots or (only and "KDE" not in only):
                print(did)
