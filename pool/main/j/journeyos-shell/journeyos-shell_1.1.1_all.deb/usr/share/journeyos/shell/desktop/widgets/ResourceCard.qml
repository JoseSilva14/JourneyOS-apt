import QtQuick
import qs
import qs.components

// Resource card: big percentage, name and ring with an icon.
Card {
    id: root

    property string label: ""
    property string icon: ""
    property real value: 0
    property bool available: true

    width: 160
    height: 118

    Ring {
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.margins: 14
        width: 48
        height: 48
        icon: root.icon
        value: root.available ? root.value : 0
    }

    Column {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.leftMargin: Theme.cardPadding
        anchors.bottomMargin: 14
        spacing: 2

        Text {
            text: root.available ? Math.round(root.value * 100) + "%" : "—"
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontStat
            font.weight: Font.Bold
        }

        Text {
            text: root.label
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
