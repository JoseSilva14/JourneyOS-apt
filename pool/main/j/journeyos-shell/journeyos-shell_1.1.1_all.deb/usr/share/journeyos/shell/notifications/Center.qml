import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Notification centre: panel on the right, below the bar.
// Clicking outside or Esc closes.
PanelWindow {
    id: root

    // This instance's screen (the window's "screen" changes with "visible": binding loop)
    required property var modelScreen
    readonly property bool open: Notifs.centerOpen && Notifs.centerScreen === modelScreen

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    color: "transparent"
    // Stays open until the closing animation finishes
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-center"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: if (!open) closing.restart()

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    MouseArea {
        anchors.fill: parent
        onClicked: Notifs.centerOpen = false
    }

    Rectangle {
        id: panel

        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.margins: Theme.gap
        width: Theme.centerWidth
        x: parent.width - width - Theme.gap + (root.open ? 0 : Theme.gap * 3)
        opacity: root.open ? 1 : 0
        radius: Theme.radiusCard + 4
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder

        Behavior on x {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }

        focus: root.open
        Keys.onEscapePressed: Notifs.centerOpen = false

        // Clicks on the panel do not close it
        MouseArea {
            anchors.fill: parent
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Theme.cardPadding
            spacing: Theme.gap

            RowLayout {
                Layout.fillWidth: true

                Text {
                    text: Tr.t("Notifications")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge
                    font.weight: Font.Bold
                }

                Text {
                    Layout.fillWidth: true
                    Layout.leftMargin: 4
                    visible: Notifs.list.length > 0
                    text: Notifs.list.length
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                }

                Rectangle {
                    visible: Notifs.list.length > 0
                    implicitWidth: clearRow.implicitWidth + 20
                    implicitHeight: 28
                    radius: height / 2
                    color: clearMouse.containsMouse ? Theme.buttonHover : Theme.button

                    Behavior on color {
                        ColorAnimation { duration: Theme.animFast }
                    }

                    Row {
                        id: clearRow
                        anchors.centerIn: parent
                        spacing: 4

                        MIcon {
                            anchors.verticalCenter: parent.verticalCenter
                            icon: "clear_all"
                            size: 16
                            color: Theme.subtext
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: Tr.t("Clear")
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            font.weight: Font.DemiBold
                        }
                    }

                    MouseArea {
                        id: clearMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Notifs.clearAll()
                    }
                }
            }

            // Do not disturb
            Card {
                Layout.fillWidth: true
                implicitHeight: 60
                color: Theme.surfaceCard
                border.color: Theme.surfaceBorder

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 14
                    spacing: 12

                    Rectangle {
                        implicitWidth: 34
                        implicitHeight: 34
                        radius: Theme.radiusSmall + 2
                        color: Notifs.dnd ? Theme.accent : Theme.button

                        Behavior on color {
                            ColorAnimation { duration: Theme.animFast }
                        }

                        MIcon {
                            anchors.centerIn: parent
                            icon: Notifs.dnd ? "notifications_off" : "notifications"
                            size: 18
                            color: Notifs.dnd ? Theme.accentText : Theme.text
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1

                        Text {
                            text: Tr.t("Do not disturb")
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: Font.Bold
                        }
                        Text {
                            text: Notifs.dnd ? Tr.t("Only urgent ones show") : Tr.t("Alerts show on screen")
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                    }

                    Toggle {
                        checked: Notifs.dnd
                        onToggled: on => Notifs.setDnd(on)
                    }
                }
            }

            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: Theme.gap / 1.5
                boundsBehavior: Flickable.StopAtBounds
                model: ScriptModel {
                    values: Notifs.list
                }

                delegate: NotificationCard {
                    required property var modelData
                    width: list.width
                    entry: modelData
                }

                add: Transition {
                    NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.animNormal }
                }
                remove: Transition {
                    NumberAnimation { property: "x"; to: Theme.centerWidth; duration: Theme.animNormal; easing.type: Easing.InCubic }
                    NumberAnimation { property: "opacity"; to: 0; duration: Theme.animNormal }
                }
                displaced: Transition {
                    NumberAnimation { property: "y"; duration: Theme.animNormal; easing.type: Easing.OutCubic }
                }

                // Empty
                Column {
                    anchors.centerIn: parent
                    visible: list.count === 0
                    spacing: 8

                    MIcon {
                        anchors.horizontalCenter: parent.horizontalCenter
                        icon: "notifications_none"
                        size: 40
                        color: Theme.faint
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: Tr.t("No notifications")
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                    }
                }
            }
        }
    }
}
