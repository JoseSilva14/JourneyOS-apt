import QtQuick
import QtQuick.Layouts
import qs
import qs.components

// Dashboard card, with an optional title in the top corner.
Rectangle {
    id: root

    property string title: ""
    property string icon: ""
    default property alias content: body.data

    color: Theme.surfaceCard
    radius: Theme.radiusCard
    border.width: 1
    border.color: Theme.surfaceBorder

    RowLayout {
        id: header
        visible: root.title !== ""
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 14
        spacing: 6

        MIcon {
            visible: root.icon !== ""
            icon: root.icon
            size: 15
            color: Theme.subtext
        }
        Text {
            Layout.fillWidth: true
            text: root.title
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
    }

    Item {
        id: body
        anchors.fill: parent
        anchors.margins: 14
        anchors.topMargin: root.title !== "" ? 14 + header.height + 8 : 14
    }
}
