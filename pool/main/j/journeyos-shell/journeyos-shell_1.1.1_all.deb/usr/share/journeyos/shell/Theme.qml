pragma Singleton

import QtQuick
import Quickshell
import qs.services

// All visual tokens: colours, fonts, radii, sizes and durations.
// Dark or light theme (theme.mode: dark | light | auto, light from 7h to 19h); backgrounds
// take the scheme's tint (services/Scheme.qml) and the accent comes from it.
Singleton {
    id: root

    SystemClock {
        id: clock
        precision: SystemClock.Hours
    }

    readonly property string mode: Config.options.theme.mode
    readonly property bool light: mode === "light"
        || (mode === "auto" && clock.date.getHours() >= 7 && clock.date.getHours() < 19)

    // Picks between the dark theme colour and the light one
    function pick(dark, lightColor) { return light ? lightColor : dark; }

    // Mixes the scheme's tint into a background colour (alpha is kept)
    function tinted(base, alpha) {
        const t = Scheme.tint, k = Scheme.strength * (light ? 0.7 : 1);
        return Qt.rgba(base.r + (t.r - base.r) * k, base.g + (t.g - base.g) * k,
            base.b + (t.b - base.b) * k, alpha ?? base.a);
    }

    function luminance(c) { return 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b; }

    // Dark or light text depending on the accent's lightness
    function onColor(c) { return luminance(c) > 0.55 ? "#111112" : "#f5f5f5"; }

    // Colours: almost black (or almost white), with the scheme's tint
    readonly property color bg: tinted(Qt.color(pick("#111112", "#ececee")))
    readonly property color barBg: tinted(pick(Qt.rgba(0.07, 0.07, 0.075, 1), Qt.rgba(0.97, 0.97, 0.975, 1)), pick(0.82, 0.88))
    readonly property color card: tinted(pick(Qt.rgba(0.13, 0.13, 0.14, 1), Qt.rgba(1, 1, 1, 1)), pick(0.88, 0.86))
    readonly property color cardHover: tinted(pick(Qt.rgba(0.17, 0.17, 0.18, 1), Qt.rgba(0.97, 0.97, 0.98, 1)), 0.92)
    readonly property color cardBorder: pick(Qt.rgba(1, 1, 1, 0.05), Qt.rgba(0, 0, 0, 0.07))
    // Above the windows (no blur, must be opaque)
    readonly property color surface: tinted(Qt.color(pick("#18181a", "#f6f6f7")))
    readonly property color surfaceCard: tinted(Qt.color(pick("#222224", "#ffffff")))
    readonly property color surfaceCardHover: tinted(Qt.color(pick("#2a2a2d", "#efeff1")))
    readonly property color surfaceBorder: pick(Qt.rgba(1, 1, 1, 0.08), Qt.rgba(0, 0, 0, 0.10))
    readonly property color scrim: pick(Qt.rgba(0, 0, 0, 0.35), Qt.rgba(0, 0, 0, 0.22))
    // The collapsed pill is almost black in dark (white in light), with the scheme's tint;
    // open it switches to the dashboard surface (surface), with the content in a card (surfaceCard)
    readonly property color notch: tinted(Qt.color(pick("#0c0c0d", "#ffffff")))
    readonly property color button: pick(Qt.rgba(1, 1, 1, 0.06), Qt.rgba(0, 0, 0, 0.06))
    readonly property color buttonHover: pick(Qt.rgba(1, 1, 1, 0.12), Qt.rgba(0, 0, 0, 0.11))
    readonly property color text: pick("#ececec", "#18181b")
    readonly property color subtext: pick("#9a9a9c", "#52525b")
    readonly property color dim: pick("#5c5c60", "#8e8e96")
    readonly property color faint: pick("#3a3a3e", "#c8c8cf")
    // In light: monochrome ones have a dark accent and very light colours get darker
    readonly property color accent: !light ? Scheme.accent
        : Scheme.accentLight ?? (luminance(Scheme.accent) > 0.5 ? Qt.darker(Scheme.accent, 1.3) : Scheme.accent)
    readonly property color accentText: onColor(accent)
    readonly property color ringTrack: pick(Qt.rgba(1, 1, 1, 0.10), Qt.rgba(0, 0, 0, 0.10))
    readonly property color ringFill: Scheme.scheme.group === "color" || Scheme.current === "auto" ? accent : pick("#d8d8d8", "#3f3f46")
    // Pill privacy dots (fixed colours: orange = microphone, green = camera, blue = screen)
    readonly property color privacyMic: "#ff9f43"
    readonly property color privacyCamera: "#2ecc71"
    readonly property color privacyScreen: "#4dabf7"
    readonly property color graphFill: pick(Qt.rgba(1, 1, 1, 0.06), Qt.rgba(0, 0, 0, 0.06))
    // JourneyOS logo (white in dark, dark in light)
    readonly property string logo: "file://" + Quickshell.shellPath(light ? "assets/logos/journeyos-dark.png" : "assets/logos/journeyos.png")
    // Background without a wallpaper: soft light at the top
    readonly property color wallTop: tinted(Qt.color(pick("#161618", "#f4f4f6")))
    readonly property color wallBottom: tinted(Qt.color(pick("#0b0b0c", "#dcdce0")))

    // Fonts
    readonly property string font: "JetBrains Mono"
    readonly property string iconFont: iconLoader.name
    readonly property int fontSmall: 11
    readonly property int fontNormal: 13
    readonly property int fontMedium: 15
    readonly property int fontLarge: 18
    readonly property int fontStat: 24

    // Radii
    readonly property int radiusSmall: 8
    readonly property int radius: 14
    readonly property int radiusCard: 18

    // Sizes
    readonly property int barHeight: 32
    // Bar style and its zone height (the floating ones have a margin around them)
    readonly property string barStyle: Config.options.bar.style
    readonly property int barMargin: barStyle === "flat" ? 0 : 6
    readonly property int barZone: barHeight + barMargin
    readonly property int barPadding: 14
    readonly property int barIcon: 17
    readonly property int gap: 12
    readonly property int edge: 40          // widget margin to the screen edge
    readonly property int cardPadding: 18
    readonly property int popupWidth: 380
    readonly property int centerWidth: 400
    readonly property int notifIcon: 40
    readonly property int panelWidth: 380
    readonly property int menuWidth: 360
    readonly property int menuListHeight: 300
    readonly property int dashboardWidth: 1000
    readonly property int dashboardHeight: 480
    readonly property int notchHeight: 26
    readonly property int notchIdleWidth: 120
    readonly property int notchMediaWidth: 300
    readonly property int notchOsdWidth: 240
    readonly property int notchPeekWidth: 380
    readonly property int notchPeekHeight: 50
    readonly property int notchTimerWidth: 170
    readonly property int notchEventWidth: 260
    readonly property int notchExpandedWidth: 500
    readonly property int notchExpandedHeight: 240
    readonly property int notchHoverOpen: 250       // mouse resting on it until it opens
    readonly property int notchHoverClose: 500      // after leaving, until it closes
    readonly property int dockHeight: 56
    readonly property int dockCell: 46
    readonly property int dockIcon: 34
    readonly property int dockPadding: 6
    readonly property int dockSeparator: 13       // space for the separator between pinned and open
    readonly property int dockHoverLift: 4        // the icon rises on hover
    readonly property int dockOverlay: 240        // above the dock: name and menu
    readonly property int dockMenuWidth: 230
    readonly property int settingsWidth: 980
    readonly property int settingsHeight: 640
    readonly property int calcHistoryWidth: 230      // calculator history
    readonly property int windowTitleHeight: 34   // window decoration title bar
    readonly property int settingsSidebar: 250
    readonly property int launcherWidth: 600
    readonly property int launcherRow: 52
    readonly property int launcherCell: 104

    // Durations
    // With "reduce motion" (accessibility), everything is instant
    readonly property bool reduceMotion: Config.options.a11y.reduceMotion
    readonly property int animFast: reduceMotion ? 0 : 120
    readonly property int animNormal: reduceMotion ? 0 : 220
    readonly property int animSlow: reduceMotion ? 0 : 420

    FontLoader {
        id: iconLoader
        source: Qt.resolvedUrl("assets/fonts/MaterialIconsRound-Regular.otf")
    }
}
