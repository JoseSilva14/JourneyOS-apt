import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Notes tab: notes on the left (searchable list + the open note, which saves itself) and
// tasks on the right (Enter adds, "!" at the start = important, clicking the text edits). The first
// pending task shows up in the pill's Pomodoro.
RowLayout {
    id: root

    signal closeRequested

    spacing: Theme.gap

    // ---------------- Notes ----------------
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.preferredWidth: 6
        title: Tr.t("Notes · ") + Notes.notes.length
        icon: "sticky_note_2"

        RowLayout {
            id: notesBody
            anchors.fill: parent
            spacing: Theme.gap

            property string current: ""
            property string query: ""
            readonly property var note: Notes.find(current)
            readonly property var shown: Notes.search(query)

            // When leaving an empty note, it is not kept
            onCurrentChanged: {
                if (previous && previous !== current)
                    Notes.dropIfEmpty(previous);
                previous = current;
                editor.load();
            }
            property string previous: ""

            function newNote() {
                query = "";
                current = Notes.add("");
                editor.forceActiveFocus();
            }

            Component.onCompleted: current = Notes.sorted[0]?.id ?? ""
            Component.onDestruction: Notes.dropIfEmpty(current)

            // List
            // Fixed width: without it, the empty-list message stretched the column and pushed the editor
            ColumnLayout {
                Layout.preferredWidth: 220
                Layout.minimumWidth: 220
                Layout.maximumWidth: 220
                Layout.fillHeight: true
                spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Pill {
                        Layout.fillWidth: true
                        TextInput {
                            id: noteSearch
                            anchors.fill: parent
                            anchors.leftMargin: 12
                            anchors.rightMargin: 12
                            verticalAlignment: TextInput.AlignVCenter
                            color: Theme.text
                            selectionColor: Theme.accent
                            selectedTextColor: Theme.accentText
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            clip: true
                            onTextChanged: notesBody.query = text
                            Keys.onEscapePressed: text ? text = "" : root.closeRequested()

                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !noteSearch.text
                                text: Tr.t("Search")
                                color: Theme.dim
                                font: noteSearch.font
                            }
                        }
                    }
                    RoundButton {
                        glyph: "add"
                        accent: true
                        onClicked: notesBody.newNote()
                    }
                }

                ListView {
                    id: noteList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    spacing: 4
                    boundsBehavior: Flickable.StopAtBounds
                    model: notesBody.shown

                    delegate: Rectangle {
                        id: noteRow
                        required property var modelData
                        readonly property bool selected: modelData.id === notesBody.current

                        width: noteList.width
                        height: 50
                        radius: Theme.radiusSmall + 2
                        color: selected ? Theme.buttonHover : noteMouse.containsMouse ? Theme.button : "transparent"

                        ColumnLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 10
                            anchors.rightMargin: 10
                            spacing: 1

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 4
                                MIcon {
                                    visible: noteRow.modelData.pinned
                                    icon: "push_pin"
                                    size: 12
                                    color: Theme.subtext
                                }
                                Text {
                                    Layout.fillWidth: true
                                    text: Notes.title(noteRow.modelData)
                                    elide: Text.ElideRight
                                    color: noteRow.modelData.text.trim() ? Theme.text : Theme.dim
                                    font.family: Theme.font
                                    font.pixelSize: Theme.fontSmall + 1
                                    font.weight: Font.DemiBold
                                }
                            }
                            Text {
                                Layout.fillWidth: true
                                text: Notes.preview(noteRow.modelData) || root.when(noteRow.modelData.updated)
                                elide: Text.ElideRight
                                color: Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall - 1
                            }
                        }

                        MouseArea {
                            id: noteMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: notesBody.current = noteRow.modelData.id
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        width: parent.width - 20
                        // With no notes at all, the invitation goes on the editor side
                        visible: noteList.count === 0 && Notes.notes.length > 0
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        text: Tr.t("No notes match.")
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            Rectangle {
                Layout.fillHeight: true
                implicitWidth: 1
                color: Theme.surfaceBorder
            }

            // Open note
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 6

                RowLayout {
                    Layout.fillWidth: true
                    visible: !!notesBody.note
                    spacing: 6

                    Text {
                        Layout.fillWidth: true
                        text: notesBody.note ? Tr.t("Edited ") + root.when(notesBody.note.updated) : ""
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall - 1
                    }
                    RoundButton {
                        glyph: "push_pin"
                        active: notesBody.note?.pinned ?? false
                        onClicked: Notes.togglePin(notesBody.current)
                    }
                    RoundButton {
                        glyph: "content_copy"
                        onClicked: {
                            Quickshell.execDetached(["wl-copy", "--", notesBody.note.text]);
                            Events.push({ icon: "content_copy", title: Tr.t("Note copied"), text: Notes.title(notesBody.note), duration: 1500 });
                        }
                    }
                    RoundButton {
                        glyph: "delete"
                        onClicked: {
                            const id = notesBody.current;
                            const list = notesBody.shown.filter(n => n.id !== id);
                            Notes.remove(id);
                            notesBody.previous = "";
                            notesBody.current = list[0]?.id ?? "";
                        }
                    }
                }

                Flickable {
                    id: editorFlick
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: !!notesBody.note
                    clip: true
                    contentHeight: editor.implicitHeight
                    boundsBehavior: Flickable.StopAtBounds

                    TextEdit {
                        id: editor
                        width: editorFlick.width
                        wrapMode: TextEdit.Wrap
                        color: Theme.text
                        selectionColor: Theme.accent
                        selectedTextColor: Theme.accentText
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        selectByMouse: true

                        property bool loading: false

                        function load() {
                            loading = true;
                            // By id (the "note" may not have changed yet at this point)
                            text = Notes.find(notesBody.current)?.text ?? "";
                            loading = false;
                            saveLater.stop();
                        }

                        onTextChanged: if (!loading) saveLater.restart()
                        // Keeps the cursor in view while typing
                        onCursorRectangleChanged: {
                            const r = cursorRectangle;
                            if (r.y < editorFlick.contentY)
                                editorFlick.contentY = r.y;
                            else if (r.y + r.height > editorFlick.contentY + editorFlick.height)
                                editorFlick.contentY = r.y + r.height - editorFlick.height;
                        }
                        Keys.onEscapePressed: root.closeRequested()

                        Text {
                            visible: !editor.text
                            text: Tr.t("The first line is the title…")
                            color: Theme.dim
                            font: editor.font
                        }
                    }
                }

                // Saves half a second after typing stops (and on leaving)
                Timer {
                    id: saveLater
                    interval: 500
                    onTriggered: Notes.setText(notesBody.current, editor.text)
                }
                Connections {
                    target: root
                    function onVisibleChanged() { if (saveLater.running) saveLater.triggered(); }
                }
                Component.onDestruction: if (saveLater.running) Notes.setText(notesBody.current, editor.text)

                // Only with notes in the list (with none, the list's message is enough)
                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: !notesBody.note

                    Text {
                        anchors.centerIn: parent
                        width: parent.width - 20
                        visible: Notes.notes.length > 0
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        text: Tr.t("Pick a note or create a new one.")
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }

                    // No notes yet: invitation with the button
                    ColumnLayout {
                        anchors.centerIn: parent
                        width: parent.width - 20
                        visible: Notes.notes.length === 0
                        spacing: 10

                        MIcon {
                            Layout.alignment: Qt.AlignHCenter
                            icon: "sticky_note_2"
                            size: 36
                            color: Theme.faint
                        }
                        Text {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.Wrap
                            text: Tr.t("No notes yet")
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: Font.DemiBold
                        }
                        Text {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.Wrap
                            text: Tr.t("Jot down ideas, lists and things you don't want to forget. Also works with \"note …\" in the launcher.")
                            color: Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                        Rectangle {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.topMargin: 4
                            implicitWidth: newLabel.implicitWidth + 28
                            implicitHeight: 32
                            radius: 16
                            color: Theme.accent
                            scale: newMouse.pressed ? 0.95 : 1

                            Behavior on scale {
                                NumberAnimation { duration: Theme.animFast }
                            }

                            Text {
                                id: newLabel
                                anchors.centerIn: parent
                                text: Tr.t("New note")
                                color: Theme.accentText
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall + 1
                                font.weight: Font.Bold
                            }
                            MouseArea {
                                id: newMouse
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: notesBody.newNote()
                            }
                        }
                    }
                }
            }
        }
    }

    // ---------------- Tasks ----------------
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.preferredWidth: 4
        title: Tr.t("Tasks · ") + Tasks.pending.length + Tr.t(" to do")
        icon: "task_alt"

        ColumnLayout {
            id: tasksBody
            anchors.fill: parent
            spacing: 8

            property bool showDone: false
            property string editing: ""

            Pill {
                Layout.fillWidth: true

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 6
                    spacing: 6

                    TextInput {
                        id: taskInput
                        Layout.fillWidth: true
                        color: Theme.text
                        selectionColor: Theme.accent
                        selectedTextColor: Theme.accentText
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        clip: true
                        onAccepted: {
                            if (Tasks.add(text))
                                text = "";
                        }
                        Keys.onEscapePressed: text ? text = "" : root.closeRequested()

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !taskInput.text
                            text: Tr.t("New task (! at the start = important)")
                            color: Theme.dim
                            font: taskInput.font
                        }
                    }
                    RoundButton {
                        glyph: "add"
                        small: true
                        accent: taskInput.text.trim() !== ""
                        onClicked: if (Tasks.add(taskInput.text)) taskInput.text = ""
                    }
                }
            }

            ListView {
                id: taskList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 2
                boundsBehavior: Flickable.StopAtBounds
                model: tasksBody.showDone ? [...Tasks.pending, ...Tasks.done] : Tasks.pending

                delegate: Rectangle {
                    id: taskRow
                    required property var modelData
                    readonly property bool editingThis: tasksBody.editing === modelData.id

                    width: taskList.width
                    height: 34
                    radius: Theme.radiusSmall
                    color: rowHover.hovered ? Theme.button : "transparent"

                    HoverHandler {
                        id: rowHover
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 6
                        anchors.rightMargin: 4
                        spacing: 8

                        // Done / to do
                        Rectangle {
                            implicitWidth: 18
                            implicitHeight: 18
                            radius: 9
                            color: taskRow.modelData.done ? Theme.accent : checkMouse.containsMouse ? Theme.buttonHover : "transparent"
                            border.width: taskRow.modelData.done ? 0 : 1.5
                            border.color: taskRow.modelData.important ? Theme.accent : Theme.subtext

                            Behavior on color {
                                ColorAnimation { duration: Theme.animFast }
                            }

                            MIcon {
                                anchors.centerIn: parent
                                visible: taskRow.modelData.done || checkMouse.containsMouse
                                icon: "check"
                                size: 12
                                color: taskRow.modelData.done ? Theme.accentText : Theme.subtext
                            }
                            MouseArea {
                                id: checkMouse
                                anchors.fill: parent
                                anchors.margins: -4
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: Tasks.toggle(taskRow.modelData.id)
                            }
                        }

                        // Text (click edits; Enter saves, Esc gives up, empty deletes)
                        Item {
                            Layout.fillWidth: true
                            Layout.fillHeight: true

                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                width: parent.width
                                visible: !taskRow.editingThis
                                text: taskRow.modelData.text
                                elide: Text.ElideRight
                                color: taskRow.modelData.done ? Theme.dim : Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall + 1
                                font.strikeout: taskRow.modelData.done
                                font.weight: taskRow.modelData.important && !taskRow.modelData.done ? Font.Bold : Font.Normal

                                MouseArea {
                                    anchors.fill: parent
                                    enabled: !taskRow.modelData.done
                                    cursorShape: Qt.IBeamCursor
                                    onClicked: tasksBody.editing = taskRow.modelData.id
                                }
                            }
                            TextInput {
                                id: taskEdit
                                anchors.verticalCenter: parent.verticalCenter
                                width: parent.width
                                visible: taskRow.editingThis
                                text: taskRow.modelData.text
                                color: Theme.text
                                selectionColor: Theme.accent
                                selectedTextColor: Theme.accentText
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall + 1
                                clip: true
                                onVisibleChanged: if (visible) { forceActiveFocus(); selectAll(); }
                                onAccepted: {
                                    Tasks.setText(taskRow.modelData.id, text);
                                    tasksBody.editing = "";
                                }
                                onActiveFocusChanged: if (!activeFocus && taskRow.editingThis) {
                                    Tasks.setText(taskRow.modelData.id, text);
                                    tasksBody.editing = "";
                                }
                                Keys.onEscapePressed: {
                                    text = taskRow.modelData.text;
                                    tasksBody.editing = "";
                                }
                            }
                        }

                        // Important and delete (on hover, or always the star on important ones)
                        RoundButton {
                            visible: !taskRow.modelData.done && (rowHover.hovered || taskRow.modelData.important)
                            glyph: taskRow.modelData.important ? "star" : "star_outline"
                            small: true
                            active: taskRow.modelData.important
                            onClicked: Tasks.toggleImportant(taskRow.modelData.id)
                        }
                        RoundButton {
                            visible: rowHover.hovered
                            glyph: "close"
                            small: true
                            onClicked: Tasks.remove(taskRow.modelData.id)
                        }
                    }
                }

                Text {
                    anchors.centerIn: parent
                    width: parent.width - 20
                    visible: taskList.count === 0
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    text: Tasks.done.length ? Tr.t("All done.") : Tr.t("No tasks. Type one above and press Enter.")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }

            // Done: show/hide and clear
            RowLayout {
                Layout.fillWidth: true
                visible: Tasks.done.length > 0
                spacing: 6

                Text {
                    Layout.fillWidth: true
                    text: (tasksBody.showDone ? Tr.t("Hide") : Tr.t("Show")) + Tr.t(" completed (") + Tasks.done.length + ")"
                    color: doneMouse.containsMouse ? Theme.text : Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall

                    MouseArea {
                        id: doneMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: tasksBody.showDone = !tasksBody.showDone
                    }
                }
                Text {
                    text: Tr.t("Clear")
                    color: clearMouse.containsMouse ? Theme.text : Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall

                    MouseArea {
                        id: clearMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Tasks.clearDone()
                    }
                }
            }
        }
    }

    // "5 min ago", "today at 14:03", "3 Nov"
    function when(ms) {
        const d = new Date(ms), now = new Date();
        const min = Math.floor((now - d) / 60000);
        if (min < 1)
            return Tr.t("now");
        if (min < 60)
            return Tr.t("") + min + Tr.t(" min");
        if (d.toDateString() === now.toDateString())
            return Tr.t("today at ") + Qt.formatTime(d, "HH:mm");
        return Tr.locale.toString(d, "d MMM");
    }

    component Pill: Rectangle {
        implicitHeight: 34
        radius: height / 2
        color: Theme.button
    }

    component RoundButton: Rectangle {
        id: button

        property string glyph: ""
        property bool accent: false
        property bool active: false
        property bool small: false
        signal clicked

        implicitWidth: small ? 26 : 32
        implicitHeight: implicitWidth
        radius: width / 2
        color: accent ? Theme.accent : buttonMouse.containsMouse ? Theme.buttonHover : active ? Theme.button : "transparent"
        scale: buttonMouse.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: button.glyph
            size: button.small ? 15 : 17
            color: button.accent ? Theme.accentText : button.active ? Theme.text : Theme.subtext
        }
        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }
}
