import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Session: lock, log out, restart, shut down; what opens on login and confirmation on logout.
Page {
    id: root

    Component.onCompleted: Session.refresh()

    GridLayout {
        Layout.fillWidth: true
        columns: 4
        columnSpacing: 8
        rowSpacing: 8

        Action { icon: "lock"; label: Tr.t("Lock"); onClicked: Session.lock() }
        Action { icon: "logout"; label: Tr.t("Log out"); onClicked: Session.prompt("logout") }
        Action { icon: "restart_alt"; label: Tr.t("Restart"); onClicked: Session.prompt("reboot") }
        Action { icon: "power_settings_new"; label: Tr.t("Shut down"); onClicked: Session.prompt("shutdown") }
    }

    SectionLabel { text: Tr.t("On login") }

    SettingRow {
        title: Tr.t("Reopen last session's apps")
        description: Tr.t("Windows open when you log out reopen when you log in.")
        icon: "restore"
        Toggle {
            checked: Session.loginMode === "restorePreviousLogout"
            onToggled: on => Session.set("loginMode", on ? "restorePreviousLogout" : "emptySession")
        }
    }

    SettingRow {
        title: Tr.t("Shell authorization dialog")
        description: Tr.t("Administrator password prompt in the shell's style. When off, KDE's appears.")
        icon: "admin_panel_settings"
        Toggle {
            checked: Config.options.polkit.own
            onToggled: on => Config.options.polkit.own = on
        }
    }

    SettingRow {
        title: Tr.t("Confirm on logout")
        description: Tr.t("Asks before logging out, restarting or shutting down.")
        icon: "help"
        Toggle {
            checked: Session.confirmLogout
            onToggled: on => Session.set("confirmLogout", on)
        }
    }

    component Action: Rectangle {
        id: action
        property string icon: ""
        property string label: ""
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 76
        radius: Theme.radius
        color: actionMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder
        scale: actionMouse.pressed ? 0.97 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Column {
            anchors.centerIn: parent
            spacing: 6
            MIcon {
                anchors.horizontalCenter: parent.horizontalCenter
                icon: action.icon
                size: 22
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: action.label
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
            }
        }
        MouseArea {
            id: actionMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: action.clicked()
        }
    }
}
