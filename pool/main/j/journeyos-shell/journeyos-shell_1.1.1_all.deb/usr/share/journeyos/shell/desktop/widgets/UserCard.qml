import QtQuick
import Quickshell
import qs
import qs.components
import qs.services

// User card: photo, "Hello, name!", greeting and date.
Card {
    id: root

    width: 340
    height: 118

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    readonly property int hour: clock.date.getHours()
    readonly property string greeting: hour >= 6 && hour < 12 ? Tr.t("Good morning")
        : hour >= 12 && hour < 20 ? Tr.t("Good afternoon")
        : Tr.t("Good evening")

    RoundImage {
        id: avatar
        anchors.left: parent.left
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: Theme.cardPadding
        width: 78
        height: 78
        radius: Theme.radius
        source: User.face

        // No photo: the initial
        Text {
            anchors.centerIn: parent
            visible: !avatar.ready
            text: User.name.charAt(0).toUpperCase()
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: 34
            font.weight: Font.Bold
        }
    }

    Column {
        anchors.left: avatar.right
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 16
        anchors.rightMargin: Theme.cardPadding
        spacing: 4

        Text {
            width: parent.width
            text: Tr.t("Hello, ") + User.name + "!"
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontLarge
            font.weight: Font.Bold
        }

        Text {
            text: root.greeting
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }

        Text {
            text: Tr.t("Today · ") + Tr.locale.toString(clock.date, "dddd, d MMM")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
