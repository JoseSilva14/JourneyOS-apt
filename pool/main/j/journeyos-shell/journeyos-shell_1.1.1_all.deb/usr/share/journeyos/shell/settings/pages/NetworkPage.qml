import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs
import qs.components
import qs.services
import qs.menus

// Network: Wi-Fi and wired (same as the bar menu), details of the active connection,
// saved connections (forget) and VPNs (connect/disconnect), via nmcli.
Page {
    id: root

    property var details: ({})          // { connection, type, ip4, gateway, dns, ip6, mac }
    property var saved: []              // [{ name, uuid, type, active }]
    property string confirmDelete: ""   // uuid awaiting the second click

    // nmcli escapes ":" inside values as "\:"
    function fields(line) {
        return line.replace(/\\:/g, "\u0001").split(":").map(f => f.replace(/\u0001/g, ":"));
    }

    readonly property string script: `
dev=$(nmcli -t -f DEVICE,STATE device | awk -F: '$2=="connected"{print $1; exit}')
[ -n "$dev" ] && nmcli -t -f GENERAL.CONNECTION,GENERAL.TYPE,IP4.ADDRESS,IP4.GATEWAY,IP4.DNS,IP6.ADDRESS,GENERAL.HWADDR device show "$dev"
echo "--"
nmcli -t -f NAME,UUID,TYPE,ACTIVE connection show
`

    function refresh() {
        if (!reader.running)
            reader.running = true;
    }

    function nm(args) {
        Quickshell.execDetached(["nmcli", ...args]);
        later.restart();
    }

    Process {
        id: reader
        command: ["sh", "-c", root.script]
        stdout: StdioCollector {
            onStreamFinished: {
                const [head, tail] = text.split("\n--\n");
                const d = { dns: [] };
                for (const line of (head ?? "").split("\n")) {
                    const i = line.indexOf(":");
                    if (i < 0)
                        continue;
                    const key = line.slice(0, i), value = line.slice(i + 1).replace(/\\:/g, ":");
                    if (key === "GENERAL.CONNECTION") d.connection = value;
                    else if (key === "GENERAL.TYPE") d.type = value;
                    else if (key.startsWith("IP4.ADDRESS") && !d.ip4) d.ip4 = value;
                    else if (key === "IP4.GATEWAY") d.gateway = value;
                    else if (key.startsWith("IP4.DNS")) d.dns.push(value);
                    else if (key.startsWith("IP6.ADDRESS") && !d.ip6) d.ip6 = value;
                    else if (key === "GENERAL.HWADDR") d.mac = value;
                }
                root.details = d;
                // Only those relevant to the user (no lo, docker…)
                root.saved = (tail ?? "").trim().split("\n").filter(l => l).map(l => {
                    const f = root.fields(l);
                    return { name: f[0], uuid: f[1], type: f[2], active: f[3] === "yes" };
                }).filter(c => /wireless|ethernet|vpn|wireguard/.test(c.type));
            }
        }
    }

    Timer {
        running: true
        interval: 5000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // Re-read after a command
    Timer {
        id: later
        interval: 1500
        onTriggered: root.refresh()
    }

    function typeIcon(t) {
        return /wireless/.test(t) ? "wifi" : /ethernet/.test(t) ? "lan" : "vpn_key";
    }
    function typeName(t) {
        return /wireless/.test(t) ? "Wi-Fi" : /ethernet/.test(t) ? "Cabo" : "VPN";
    }

    MenuCard {
        NetworkMenu {
            width: parent.width
            embedded: true
            listHeight: 380
        }
    }

    // --- Active connection details ---
    SectionLabel {
        visible: !!root.details.connection
        text: Tr.t("Active connection: ") + (root.details.connection ?? "")
    }

    GridLayout {
        visible: !!root.details.connection
        Layout.fillWidth: true
        columns: 2
        rowSpacing: 8
        columnSpacing: 8

        Detail { label: Tr.t("IPv4 address"); value: root.details.ip4 ?? "—" }
        Detail { label: "Gateway"; value: root.details.gateway || "—" }
        Detail { label: "DNS"; value: (root.details.dns ?? []).join(", ") || "—" }
        Detail { label: Tr.t("Hardware address (MAC)"); value: root.details.mac ?? "—" }
        Detail { label: Tr.t("IPv6 address"); value: root.details.ip6 ?? "—"; Layout.columnSpan: 2 }
    }

    // --- VPN ---
    SectionLabel {
        visible: root.saved.some(c => /vpn|wireguard/.test(c.type))
        text: "VPN"
    }

    Repeater {
        model: root.saved.filter(c => /vpn|wireguard/.test(c.type))

        SettingRow {
            required property var modelData
            title: modelData.name
            description: modelData.active ? Tr.t("Connected") : Tr.t("Off##f")
            icon: "vpn_key"

            Toggle {
                checked: modelData.active
                onToggled: on => root.nm(["connection", on ? "up" : "down", "uuid", modelData.uuid])
            }
        }
    }

    // --- Saved connections ---
    SectionLabel {
        visible: root.saved.length > 0
        text: Tr.t("Saved connections")
    }

    Repeater {
        model: root.saved.filter(c => !/vpn|wireguard/.test(c.type))

        SettingRow {
            id: savedRow
            required property var modelData
            readonly property bool confirming: root.confirmDelete === modelData.uuid

            title: modelData.name
            description: root.typeName(modelData.type) + (modelData.active ? Tr.t(" · in use") : "")
            icon: root.typeIcon(modelData.type)

            // Forgetting needs a second click
            Rectangle {
                implicitWidth: forgetText.implicitWidth + 28
                implicitHeight: 32
                radius: height / 2
                color: savedRow.confirming ? Theme.privacyMic
                    : forgetMouse.containsMouse ? Theme.buttonHover : Theme.button

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                Text {
                    id: forgetText
                    anchors.centerIn: parent
                    text: savedRow.confirming ? Tr.t("Confirm") : Tr.t("Forget")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }

                MouseArea {
                    id: forgetMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        const uuid = modelData.uuid;
                        if (root.confirmDelete === uuid) {
                            root.confirmDelete = "";
                            root.nm(["connection", "delete", "uuid", uuid]);
                        } else {
                            root.confirmDelete = uuid;
                            confirmTimeout.restart();
                        }
                    }
                }
            }
        }
    }

    Timer {
        id: confirmTimeout
        interval: 4000
        onTriggered: root.confirmDelete = ""
    }

    component Detail: Rectangle {
        id: detail

        property string label: ""
        property string value: ""

        Layout.fillWidth: true
        implicitHeight: 56
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        Column {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: 14
            anchors.rightMargin: 14
            spacing: 2

            Text {
                text: detail.label
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Text {
                width: parent.width
                text: detail.value
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
        }
    }
}
