import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Development: the Dev UI (the dashboard's Dev tab, with ports in use and Docker containers).
Page {
    id: root

    SectionLabel { text: "UI Dev" }

    SettingRow {
        title: "UI Dev"
        description: Tr.t("Adds the Dev tab to the dashboard: ports in use (which program is on each) and Docker containers, with start, stop, logs and terminal.")
        icon: "terminal"
        Toggle {
            checked: Config.options.dev.enabled
            onToggled: on => Config.options.dev.enabled = on
        }
    }

    SettingRow {
        visible: Config.options.dev.enabled
        title: Tr.t("Open the Dev tab")
        description: Tr.t("Also with \"portas\" or \"contentores\" in the launcher.")
        icon: "space_dashboard"
        PillButton {
            text: Tr.t("Open")
            onClicked: Dashboard.toggle("dev", null)
        }
    }
}
