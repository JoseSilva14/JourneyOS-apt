pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// User name and photo.
Singleton {
    id: root

    readonly property string login: Quickshell.env("USER") || ""
    property string realName: ""
    readonly property string name: Config.options.displayName || realName || login
    property string face: ""          // Photo URL; empty = no photo
    readonly property bool hasFace: face !== ""

    // The full name is the 1st GECOS field
    Process {
        running: root.login !== ""
        command: ["getent", "passwd", root.login]
        stdout: StdioCollector {
            onStreamFinished: root.realName = (text.split(":")[4] || "").split(",")[0].trim()
        }
    }

    // The JourneyOS logo avatar has a dark version for the light theme
    readonly property string logoAvatar: Quickshell.shellPath("assets/logos/journeyos-avatar.png")
    readonly property string avatarFile: Config.options.avatar === logoAvatar && Theme.light
        ? Quickshell.shellPath("assets/logos/journeyos-avatar-dark.png")
        : Config.options.avatar

    // The photo (avatar option, or ~/.face) may have no extension, and Qt does not
    // recognise an SVG like that: give it a link with the right extension in the cache
    Process {
        id: faceLink
        running: Config.ready
        command: ["sh", "-c", `
f="\${1:-$HOME/.face}"
[ -s "$f" ] || exit 0
case "$(file -b -L --mime-type "$f")" in
  image/svg+xml) ext=svg ;;
  image/png) ext=png ;;
  image/jpeg) ext=jpg ;;
  *) exit 0 ;;
esac
d="\${XDG_CACHE_HOME:-$HOME/.cache}/shadow-kde"
# One name per file: Canvas caches images by address
name="face-$(printf %s "$f" | md5sum | cut -c1-8).$ext"
mkdir -p "$d" && ln -sfn "$f" "$d/$name" && echo "$d/$name"
`, "sh", root.avatarFile]
        stdout: StdioCollector {
            onStreamFinished: root.face = text.trim() ? "file://" + text.trim() : ""
        }
    }

    Connections {
        target: Config.options
        function onAvatarChanged() { Qt.callLater(() => faceLink.running = true); }
    }

    // On the next cycle: here the process command still has the previous file
    onAvatarFileChanged: Qt.callLater(() => faceLink.running = true)
}
