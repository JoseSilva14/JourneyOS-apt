pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Keyboard layout in use (D-Bus org.kde.keyboard /Layouts): for the bar indicator.
// Follows the layoutChanged signal (also when switching with the KDE shortcut).
Singleton {
    id: root

    property var layouts: []            // [{ short, variant, name }]
    property int current: 0
    readonly property var layout: layouts[current] ?? null
    readonly property bool multiple: layouts.length > 1

    function refresh() {
        Run.cmd(["busctl", "--user", "-j", "call", "org.kde.keyboard", "/Layouts", "org.kde.KeyboardLayouts", "getLayoutsList"], (code, out) => {
            try {
                root.layouts = JSON.parse(out).data[0].map(l => ({ short: l[0], variant: l[1], name: l[2] }));
            } catch (e) {
                root.layouts = [];
            }
        });
        Run.cmd(["busctl", "--user", "call", "org.kde.keyboard", "/Layouts", "org.kde.KeyboardLayouts", "getLayout"],
            (code, out) => root.current = Number(out.trim().split(" ")[1]) || 0);
    }

    function next() {
        Run.cmd(["busctl", "--user", "call", "org.kde.keyboard", "/Layouts", "org.kde.KeyboardLayouts", "switchToNextLayout"], () => refresh());
    }

    // The layoutChanged/layoutListChanged signals via gdbus monitor
    Process {
        running: true
        command: ["gdbus", "monitor", "--session", "--dest", "org.kde.keyboard", "--object-path", "/Layouts"]
        stdout: SplitParser {
            onRead: line => {
                if (/layoutChanged|layoutListChanged/.test(line))
                    root.refresh();
            }
        }
    }

    Component.onCompleted: refresh()
}
