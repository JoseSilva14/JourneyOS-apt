#!/bin/sh
# Removes shadow-kde and goes back to KDE Plasma (no sudo).
#   uninstall.sh             uninstalls
#   uninstall.sh --simular   only shows what it would do (dry run)
#   uninstall.sh --tudo      (all) also deletes the shell's settings and data
#                            (~/.config/shadow-kde, ~/.local/state/shadow-kde, ~/.local/share/shadow-kde)
#
# Restores what scripts/install.sh saved in ~/.local/state/shadow-kde/antes.conf (without that
# file, goes back to KDE's defaults). The files in this folder stay.
# The login screen (SDDM) needs root: the command is shown at the end.
set -e
dir=$(readlink -f "$(dirname "$(readlink -f "$0")")/..")
state="$HOME/.local/state/shadow-kde"
units="$HOME/.config/systemd/user"
before="$state/antes.conf"
sim=""
all=""
for a in "$@"; do
    case "$a" in
        --simular) sim=1 ;;
        --tudo) all=1 ;;
        *) echo "usage: $0 [--simular] [--tudo]" >&2; exit 1 ;;
    esac
done

say() { printf '\033[1m›\033[0m %s\n' "$*"; }
run() {
    if [ -n "$sim" ]; then
        printf '    %s\n' "$*"
    else
        "$@" || true
    fi
}
# Value saved before the install (empty if there was none)
was() { [ -f "$before" ] && sed -n "s/^$1=//p" "$before" | head -n1; return 0; }
# Restores a key: the old value, or deletes it if there was none
restore() {  # file group key value
    if [ -n "$4" ]; then
        run kwriteconfig6 --file "$1" --group "$2" --key "$3" "$4"
    else
        run kwriteconfig6 --file "$1" --group "$2" --key "$3" --delete
    fi
}
reconfigure() {
    run gdbus call --session --dest org.kde.KWin --object-path /KWin --method org.kde.KWin.reconfigure
}

[ -f "$before" ] || echo "No $before: going back to the KDE defaults."

say "Stopping the shell"
run systemctl --user disable --now shadow-kde-watchdog.timer shadow-kde.service
run rm -f "$units/shadow-kde.service" "$units/shadow-kde-watchdog.service" "$units/shadow-kde-watchdog.timer"
run systemctl --user daemon-reload

say "Keyboard shortcuts (gives Meta+V and the Print keys back to KDE)"
run python3 "$dir/scripts/shortcuts.py" repor

say "Lock screen"
restore plasmashellrc Shell ShellPackage "$(was shell_package)"
run rm -f "$HOME/.local/share/plasma/shells/org.shadowkde.desktop"

say "Window decoration and Alt+Tab"
lib=$(was decoration_library)
theme=$(was decoration_theme)
# Only restores the saved engine+theme pair; with no saved theme, KDE's (Breeze) is used
if [ -z "$theme" ]; then
    lib=org.kde.breeze
    theme=Breeze
fi
restore kwinrc org.kde.kdecoration2 library "${lib:-org.kde.breeze}"
restore kwinrc org.kde.kdecoration2 theme "$theme"
restore kwinrc TabBox LayoutName "$(was tabbox)"
restore kwinrc TabBoxAlternative LayoutName "$(was tabbox_alt)"
reconfigure
run rm -rf "$HOME/.local/share/kwin/decorations/shadowkde" "$HOME/.local/share/kwin/tabbox/shadowkde"

say "Session splash screen"
restore ksplashrc KSplash Engine "$(was splash_engine)"
restore ksplashrc KSplash Theme "$(was splash_theme)"
run rm -rf "$HOME/.local/share/plasma/look-and-feel/org.shadowkde.splash"

say "App colours"
scheme=$(was color_scheme)
case "$scheme" in
    ShadowKDE*|"") run python3 "$dir/scripts/kde-colors.py" reset ;;
    *) run plasma-apply-colorscheme "$scheme" ;;
esac
restore konsolerc "Desktop Entry" DefaultProfile "$(was konsole_profile)"
run rm -f "$HOME/.local/share/color-schemes/ShadowKDEA.colors" "$HOME/.local/share/color-schemes/ShadowKDEB.colors"

say "Re-enabling plasmashell"
# It only stays disabled if it already was before the shell
if [ "$(was plasmashell)" = masked ]; then
    echo "    (it was already disabled before the install: leaving it so)"
else
    run systemctl --user unmask plasma-plasmashell.service
    run systemctl --user start plasma-plasmashell.service
fi

# KDE notices (donations, Welcome Center) come back
run "$dir/scripts/kde-quiet.sh" reset

# "Share on the local network" in Dolphin
run "$dir/scripts/servicemenu.sh" remove

# The entries the shell writes for the dock and the launcher: Dashboard, Settings, the tools
# (Calculator, Monitor, Capture…) and the web apps (the data stays, unless --tudo)
for f in "$HOME"/.local/share/applications/shadow-kde-*.desktop; do
    [ -e "$f" ] && run rm -f "$f"
done

if [ -n "$all" ]; then
    say "Deleting the shell's settings and data"
    run rm -rf "$HOME/.config/shadow-kde" "$state" "$HOME/.local/share/shadow-kde" "$HOME/.cache/shadow-kde"
else
    run rm -f "$before"
    echo "    Your settings stay (for a reinstall). To delete them: $0 --tudo"
fi

echo
if [ -d /usr/share/sddm/themes/shadowkde ]; then
    echo "The login screen is left (asks for the administrator password):"
    echo "    sudo $dir/scripts/sddm.sh repor"
fi
echo "Done. Some changes (colours and decoration of apps already open) only show after logging in again."
