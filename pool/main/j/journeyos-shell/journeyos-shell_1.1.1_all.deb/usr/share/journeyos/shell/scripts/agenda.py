#!/usr/bin/env python3
"""Shell calendar: reads ICS calendars (http/https/webcal addresses or files) and the
local events, and writes the events of a time range to stdout as JSON.

Usage:
  agenda.py eventos <days back> <days ahead> <source>...   (events; source = name|colour|address)
  agenda.py juntar <title> <ISO start> <ISO end> <all day 0|1>   (add)
  agenda.py tirar <id>                                           (remove)

Output of "eventos": [{ id, title, start, end (ms), allDay, location, source, color }]
sorted by start. Each remote source is cached (~/.cache/shadow-kde/calendar/):
without a network, the last copy is used. Local events are in
~/.local/state/shadow-kde/calendar.json ({ events: [{ id, title, start, end, allDay }] }).

Recurrence (RRULE): FREQ daily/weekly/monthly/yearly, INTERVAL, COUNT, UNTIL, BYDAY (with
an ordinal when monthly: 1MO, -1FR), BYMONTHDAY and BYMONTH; EXDATE and RECURRENCE-ID (changes to
a single occurrence). Enough for Google, Nextcloud and Outlook calendars.
"""
import fcntl
import hashlib
import json
import os
import sys
import time
import urllib.request
import uuid
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

HOME = os.path.expanduser("~")
CACHE = os.path.join(HOME, ".cache/shadow-kde/calendar")
LOCAL = os.path.join(HOME, ".local/state/shadow-kde/calendar.json")
LOCAL_TZ = datetime.now().astimezone().tzinfo
MAX_AGE = 10 * 60          # seconds before downloading a source again
DAYS = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]


# --- Sources ---

def fetch(url):
    """Calendar text; cached, and the cache is used when there is no network."""
    if url.startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    if not url.startswith(("http://", "https://")):
        path = os.path.expanduser(url.removeprefix("file://"))
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    os.makedirs(CACHE, exist_ok=True)
    cached = os.path.join(CACHE, hashlib.sha1(url.encode()).hexdigest() + ".ics")
    if os.path.exists(cached) and time.time() - os.path.getmtime(cached) < MAX_AGE:
        with open(cached, encoding="utf-8", errors="replace") as f:
            return f.read()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "shadow-kde"})
        with urllib.request.urlopen(req, timeout=15) as r:
            text = r.read().decode("utf-8", errors="replace")
        tmp = cached + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, cached)
        return text
    except Exception as e:  # no network: the last copy
        print(f"calendar {url}: {e}", file=sys.stderr)
        if os.path.exists(cached):
            with open(cached, encoding="utf-8", errors="replace") as f:
                return f.read()
        return ""


# --- ICS ---

def unfold(text):
    lines = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw[:1] in (" ", "\t") and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw)
    return lines


def parse_line(line):
    name, _, value = line.partition(":")
    parts = name.split(";")
    params = {}
    for p in parts[1:]:
        k, _, v = p.partition("=")
        params[k.upper()] = v.strip('"')
    return parts[0].upper(), params, value


def unescape(s):
    return s.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def parse_dt(value, params):
    """(timezone-aware datetime, all day?)"""
    value = value.strip()
    if params.get("VALUE") == "DATE" or (len(value) == 8 and value.isdigit()):
        d = datetime.strptime(value[:8], "%Y%m%d")
        return d.replace(tzinfo=LOCAL_TZ), True
    utc = value.endswith("Z")
    d = datetime.strptime(value.rstrip("Z")[:15], "%Y%m%dT%H%M%S")
    if utc:
        return d.replace(tzinfo=timezone.utc), False
    tzid = params.get("TZID")
    if tzid:
        try:
            return d.replace(tzinfo=ZoneInfo(tzid)), False
        except Exception:
            pass  # Windows time zones ("GMT Standard Time"): local time
    return d.replace(tzinfo=LOCAL_TZ), False


def parse_events(text):
    events, cur = [], None
    for line in unfold(text):
        if line == "BEGIN:VEVENT":
            cur = {"exdates": set()}
        elif line == "END:VEVENT":
            if cur and "start" in cur:
                events.append(cur)
            cur = None
        elif cur is not None and ":" in line:
            name, params, value = parse_line(line)
            if name == "DTSTART":
                cur["start"], cur["allDay"] = parse_dt(value, params)
            elif name == "DTEND":
                cur["end"], _ = parse_dt(value, params)
            elif name == "DURATION":
                cur["duration"] = parse_duration(value)
            elif name == "SUMMARY":
                cur["title"] = unescape(value)
            elif name == "LOCATION":
                cur["location"] = unescape(value)
            elif name == "UID":
                cur["uid"] = value
            elif name == "RRULE":
                cur["rrule"] = dict(p.split("=", 1) for p in value.split(";") if "=" in p)
            elif name == "EXDATE":
                for v in value.split(","):
                    cur["exdates"].add(parse_dt(v, params)[0].timestamp())
            elif name == "RECURRENCE-ID":
                cur["recurrenceId"] = parse_dt(value, params)[0].timestamp()
            elif name == "STATUS":
                cur["status"] = value.upper()
    return events


def parse_duration(v):
    sign = -1 if v.startswith("-") else 1
    v = v.lstrip("+-").lstrip("P")
    days = secs = 0
    num = ""
    in_time = False
    for ch in v:
        if ch == "T":
            in_time = True
        elif ch.isdigit():
            num += ch
        else:
            n = int(num or 0)
            num = ""
            if ch == "W":
                days += 7 * n
            elif ch == "D":
                days += n
            elif ch == "H":
                secs += 3600 * n
            elif ch == "M" and in_time:
                secs += 60 * n
            elif ch == "S":
                secs += n
    return sign * timedelta(days=days, seconds=secs)


# --- Recurrence ---

def add_months(d, n):
    m = d.month - 1 + n
    y = d.year + m // 12
    m = m % 12 + 1
    return y, m


def month_days(y, m):
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return (nxt - date(y, m, 1)).days


def nth_weekdays(y, m, rule):
    """Days of the month for BYDAY (e.g. 'MO', '1MO', '-1FR')."""
    out = []
    last = month_days(y, m)
    for item in rule:
        wd = DAYS.index(item[-2:])
        n = int(item[:-2]) if item[:-2] not in ("", "+") else 0
        days = [d for d in range(1, last + 1) if date(y, m, d).weekday() == wd]
        if n == 0:
            out += days
        elif -len(days) <= n <= len(days) and n != 0:
            out.append(days[n - 1] if n > 0 else days[n])
    return sorted(set(out))


def occurrences(ev, lo, hi):
    """Start times (datetime) of the recurrence between lo and hi."""
    start = ev["start"]
    rule = ev.get("rrule")
    if not rule:
        return [start]
    freq = rule.get("FREQ", "DAILY")
    interval = int(rule.get("INTERVAL", 1))
    count = int(rule["COUNT"]) if "COUNT" in rule else None
    until = parse_dt(rule["UNTIL"], {})[0] if "UNTIL" in rule else None
    byday = rule["BYDAY"].split(",") if "BYDAY" in rule else None
    bymonthday = [int(x) for x in rule["BYMONTHDAY"].split(",")] if "BYMONTHDAY" in rule else None
    bymonth = [int(x) for x in rule["BYMONTH"].split(",")] if "BYMONTH" in rule else None
    tz = start.tzinfo
    naive = start.replace(tzinfo=None)
    t = naive.time()

    def make(d):
        return datetime.combine(d, t).replace(tzinfo=tz)

    out, n, step = [], 0, 0
    # Without COUNT, jump straight to near the range (a daily series from 2010 would never get there)
    if count is None and lo.replace(tzinfo=None) > naive:
        gap = lo.replace(tzinfo=None).date() - naive.date()
        units = {"DAILY": gap.days, "WEEKLY": gap.days // 7,
                 "MONTHLY": gap.days // 31, "YEARLY": gap.days // 366}.get(freq, 0)
        step = max(0, units // interval - 1)
    limit = step + 5000
    while step < limit:
        # Candidate days in this period
        if freq == "DAILY":
            cands = [naive.date() + timedelta(days=step * interval)]
        elif freq == "WEEKLY":
            week0 = naive.date() - timedelta(days=naive.weekday())
            week = week0 + timedelta(weeks=step * interval)
            wds = [DAYS.index(x[-2:]) for x in byday] if byday else [naive.weekday()]
            cands = [week + timedelta(days=w) for w in sorted(wds)]
        elif freq == "MONTHLY":
            y, m = add_months(naive.date(), step * interval)
            if byday:
                days = nth_weekdays(y, m, byday)
            elif bymonthday:
                days = [d if d > 0 else month_days(y, m) + d + 1 for d in bymonthday]
            else:
                days = [naive.day]
            cands = [date(y, m, d) for d in days if 1 <= d <= month_days(y, m)]
        elif freq == "YEARLY":
            y = naive.year + step * interval
            months = bymonth or [naive.month]
            cands = []
            for m in months:
                if byday:
                    cands += [date(y, m, d) for d in nth_weekdays(y, m, byday)]
                elif naive.day <= month_days(y, m):
                    cands.append(date(y, m, naive.day))
        else:
            return [start]
        step += 1
        for d in cands:
            if d < naive.date():
                continue
            occ = make(d)
            if until and occ > until:
                return out
            n += 1
            if count is not None and n > count:
                return out
            if occ > hi:
                return out
            out.append(occ)
        if cands and make(cands[0]) > hi:
            break
    return out


def expand(events, lo, hi, source, color):
    # Changes to one occurrence (RECURRENCE-ID) replace that occurrence of the series
    overrides = {}
    for ev in events:
        if "recurrenceId" in ev:
            overrides.setdefault(ev.get("uid"), set()).add(ev["recurrenceId"])
    out = []
    for ev in events:
        if ev.get("status") == "CANCELLED":
            continue
        length = (ev["end"] - ev["start"]) if "end" in ev else ev.get("duration") or \
            (timedelta(days=1) if ev["allDay"] else timedelta(0))
        skip = ev["exdates"] | (overrides.get(ev.get("uid"), set()) if "recurrenceId" not in ev else set())
        for occ in occurrences(ev, lo, hi):
            if occ.timestamp() in skip:
                continue
            end = occ + length
            if end < lo or occ > hi:
                continue
            key = f"{ev.get('uid', '')}|{int(occ.timestamp())}"
            out.append({
                "id": hashlib.sha1((source + key).encode()).hexdigest()[:16],
                "title": ev.get("title") or ("(sem título)" if os.environ.get("SHADOW_LANG") == "pt" else "(untitled)"),
                "start": int(occ.timestamp() * 1000),
                "end": int(end.timestamp() * 1000),
                "allDay": ev["allDay"],
                "location": ev.get("location", ""),
                "source": source,
                "color": color,
            })
    return out


# --- Local events ---

def load_local():
    try:
        with open(LOCAL, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"events": []}


def save_local(data):
    os.makedirs(os.path.dirname(LOCAL), exist_ok=True)
    tmp = LOCAL + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, LOCAL)


def locked(fn):
    os.makedirs(os.path.dirname(LOCAL), exist_ok=True)
    with open(LOCAL + ".lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return fn()


def local_events(lo, hi):
    out = []
    for e in load_local().get("events", []):
        s, en = e["start"], e["end"]
        if en < lo.timestamp() * 1000 or s > hi.timestamp() * 1000:
            continue
        out.append({"id": e["id"], "title": e["title"], "start": s, "end": en, "allDay": e.get("allDay", False),
                    "location": "", "source": "", "color": "", "local": True})
    return out


def iso_ms(s):
    d = datetime.fromisoformat(s)
    if d.tzinfo is None:
        d = d.replace(tzinfo=LOCAL_TZ)
    return int(d.timestamp() * 1000)


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "eventos":
        back, ahead = int(sys.argv[2]), int(sys.argv[3])
        today = datetime.now(LOCAL_TZ).replace(hour=0, minute=0, second=0, microsecond=0)
        lo, hi = today - timedelta(days=back), today + timedelta(days=ahead)
        out = local_events(lo, hi)
        for spec in sys.argv[4:]:
            name, color, url = (spec.split("|", 2) + ["", ""])[:3]
            try:
                out += expand(parse_events(fetch(url)), lo, hi, name, color)
            except Exception as e:
                print(f"calendar {name}: {e}", file=sys.stderr)
        out.sort(key=lambda e: (e["start"], not e["allDay"]))
        print(json.dumps(out, ensure_ascii=False))
    elif cmd == "juntar":
        title, start, end, all_day = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5] == "1"

        def add():
            data = load_local()
            data.setdefault("events", []).append({"id": uuid.uuid4().hex[:12], "title": title,
                                                  "start": iso_ms(start), "end": iso_ms(end), "allDay": all_day})
            save_local(data)
        locked(add)
    elif cmd == "tirar":
        def rm():
            data = load_local()
            data["events"] = [e for e in data.get("events", []) if e["id"] != sys.argv[2]]
            save_local(data)
        locked(rm)
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
