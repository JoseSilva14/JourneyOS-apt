import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Display: resolution, refresh rate, scale, rotation and primary for each screen (asks for
// confirmation) and night light.
Page {
    id: root

    Component.onCompleted: Display.refresh()

    // Confirmation after a change (reverts if there is no answer)
    Rectangle {
        Layout.fillWidth: true
        visible: Display.pending !== null
        implicitHeight: 60
        radius: Theme.radius
        color: Theme.accent

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 16
            anchors.rightMargin: 10
            spacing: 8

            Text {
                Layout.fillWidth: true
                text: Tr.t("Keep these settings? Reverting in ") + Display.countdown + Tr.t(" s.")
                wrapMode: Text.Wrap
                color: Theme.accentText
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Pill { text: Tr.t("Revert"); onClicked: Display.revert() }
            Pill { text: Tr.t("Keep"); strong: true; onClicked: Display.keep() }
        }
    }

    Repeater {
        model: Display.outputs

        ColumnLayout {
            id: out
            required property var modelData
            readonly property var o: modelData
            readonly property var mode: o.modes.find(m => m.id === o.currentModeId)
            // Resolutions without duplicates (refresh rate is picked separately), largest first
            readonly property var sizes: [...new Set(o.modes.map(m => m.size.width + "x" + m.size.height))]
                .sort((a, b) => b.split("x")[0] * b.split("x")[1] - a.split("x")[0] * a.split("x")[1])
            readonly property string size: mode ? mode.size.width + "x" + mode.size.height : ""
            readonly property var rates: o.modes.filter(m => m.size.width + "x" + m.size.height === size)
                .sort((a, b) => b.refreshRate - a.refreshRate)

            Layout.fillWidth: true
            spacing: 8

            SectionLabel {
                text: (out.o.name + (Display.outputs.length > 1 && out.o.priority === 1 ? Tr.t(" · primary") : ""))
            }

            SettingRow {
                visible: Display.outputs.length > 1
                title: Tr.t("On")
                icon: "desktop_windows"
                Toggle {
                    checked: out.o.enabled
                    onToggled: on => Display.apply(out.o, { enabled: on })
                }
            }

            SettingRow {
                title: Tr.t("Resolution")
                icon: "aspect_ratio"
                Select {
                    options: out.sizes.map(s => ({ id: s, label: s.replace("x", " × ") }))
                    current: out.size
                    onSelected: id => {
                        // The highest refresh rate for the chosen resolution
                        const best = out.o.modes.filter(m => m.size.width + "x" + m.size.height === id)
                            .sort((a, b) => b.refreshRate - a.refreshRate)[0];
                        if (best)
                            Display.apply(out.o, { mode: best.id });
                    }
                }
            }

            SettingRow {
                visible: out.rates.length > 1
                title: Tr.t("Refresh rate")
                icon: "speed"
                Select {
                    options: out.rates.map(m => ({ id: m.id, label: Math.round(m.refreshRate) + Tr.t(" Hz") }))
                    current: out.o.currentModeId
                    onSelected: id => Display.apply(out.o, { mode: id })
                }
            }

            SettingRow {
                title: Tr.t("Scale")
                description: Tr.t("The size of everything on screen.")
                icon: "zoom_in"
                Segmented {
                    model: [1, 1.25, 1.5, 1.75, 2].map(s => ({ id: String(s), label: Math.round(s * 100) + "%" }))
                    current: String(out.o.scale)
                    onSelected: id => Display.apply(out.o, { scale: Number(id) })
                }
            }

            SettingRow {
                title: Tr.t("Rotation")
                icon: "screen_rotation"
                Select {
                    options: Display.rotations.map(r => ({ id: r.id, label: r.label }))
                    current: Display.rotationId(out.o.rotation)
                    onSelected: id => Display.apply(out.o, { rotation: id })
                }
            }

            SettingRow {
                visible: Display.outputs.length > 1 && out.o.priority !== 1
                title: Tr.t("Make primary")
                description: Tr.t("The bar and alerts show on this screen.")
                icon: "star"
                Pill {
                    text: Tr.t("Main")
                    onClicked: Display.apply(out.o, { primary: true })
                }
            }
        }
    }

    // --- Night light ---
    SectionLabel { text: Tr.t("Night light") }

    SettingRow {
        title: Tr.t("Night light")
        description: Tr.t("Warmer colors, easier on the eyes at night.")
        icon: "nightlight"
        Toggle {
            checked: Display.nightEnabled
            onToggled: on => Display.setNightEnabled(on)
        }
    }

    SettingRow {
        visible: Display.nightEnabled
        title: Tr.t("When")
        description: Display.nightMode === "Times" ? Tr.t("From 18:00 to 6:00.") : Tr.t("Always on.")
        icon: "schedule"
        Segmented {
            model: [
                { id: "Constant", label: Tr.t("Always") },
                { id: "Times", label: Tr.t("At night") }
            ]
            current: Display.nightMode === "Times" ? "Times" : "Constant"
            onSelected: id => Display.setNight("Mode", id)
        }
    }

    SettingRow {
        visible: Display.nightEnabled
        title: Tr.t("Temperature · ") + temperature.shown + Tr.t(" K")
        description: Tr.t("Further left is warmer.")
        icon: "thermostat"

        Slider {
            id: temperature
            implicitWidth: 240
            readonly property int minK: 2500
            readonly property int maxK: 6000
            property int shown: Display.nightTemperature
            value: (shown - minK) / (maxK - minK)
            onMoved: v => {
                shown = Math.round((minK + v * (maxK - minK)) / 100) * 100;
                Display.preview(shown);
                commit.restart();
            }
            // Saves once the user stops dragging
            Timer {
                id: commit
                interval: 800
                onTriggered: {
                    Display.stopPreview();
                    Display.setNight("NightTemperature", String(temperature.shown));
                }
            }
        }
    }

    component Pill: Rectangle {
        id: pill
        property string text: ""
        property bool strong: false
        signal clicked

        implicitWidth: pillText.implicitWidth + 28
        implicitHeight: 32
        radius: height / 2
        color: strong ? Theme.accentText : pillMouse.containsMouse ? Theme.buttonHover : Theme.button

        Text {
            id: pillText
            anchors.centerIn: parent
            text: pill.text
            color: pill.strong ? Theme.accent : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall + 1
            font.weight: Font.Bold
        }
        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
