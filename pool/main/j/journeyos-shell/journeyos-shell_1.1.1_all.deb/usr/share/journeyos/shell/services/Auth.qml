pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Polkit

// The shell's authorization agent (polkit): the administrator password dialog in the
// shell's style. There can only be one agent per session: at startup it kills KDE's
// and registers this one; if registration fails (or the polkit.own option is off),
// it relaunches KDE's. When the shell stops, the service relaunches KDE's
// (ExecStopPost). (Not called "Polkit": that is the Quickshell module's name.)
Singleton {
    id: root

    readonly property string kdeAgent: "/usr/lib/x86_64-linux-gnu/libexec/polkit-kde-authentication-agent-1"

    readonly property bool wanted: Config.options.polkit.own
    property bool ready: false          // KDE's has already been killed
    readonly property var agent: loader.item
    readonly property var flow: agent?.flow ?? null
    readonly property bool active: agent?.isActive ?? false
    readonly property bool registered: agent?.isRegistered ?? false

    LazyLoader {
        id: loader
        active: root.wanted && root.ready
        PolkitAgent {}
    }

    function startKdeAgent() {
        Run.cmd(["pgrep", "-x", "polkit-kde-auth"], code => {
            if (code !== 0)
                Quickshell.execDetached(["systemd-run", "--user", "--quiet", "--collect", root.kdeAgent]);
        });
    }

    function takeOver() {
        // -x with the process name (truncated to 15 chars): never a command-line pattern
        Run.sh("pkill -x polkit-kde-auth; sleep 0.5", () => {
            root.ready = true;
            check.restart();
        });
    }

    // Did it register? If not, KDE's comes back
    Timer {
        id: check
        interval: 3000
        onTriggered: {
            if (root.wanted && !root.registered) {
                console.warn("authorization: the shell agent didn't register; falling back to KDE");
                root.ready = false;
                root.startKdeAgent();
            }
        }
    }

    onWantedChanged: {
        if (wanted) {
            takeOver();
        } else {
            ready = false;
            startKdeAgent();
        }
    }

    Component.onCompleted: {
        if (wanted)
            takeOver();
    }

    IpcHandler {
        target: "auth"
        function cancel(): void { root.flow?.cancelAuthenticationRequest(); }
        function status(): string { return root.registered ? "registado" : Tr.t("not registered"); }
    }
}
