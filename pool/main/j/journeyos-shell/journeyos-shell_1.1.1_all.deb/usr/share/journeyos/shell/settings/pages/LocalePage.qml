import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Region and language: the apps' language and formats (numbers, dates, currency).
Page {
    id: root

    Component.onCompleted: Locales.refresh()

    readonly property var options: Locales.supported.map(c => ({ id: c, label: Locales.name(c) + (Locales.isGenerated(c) ? "" : Tr.t(" ·  installing")) }))

    // The shell language changes immediately (independent of the system one)
    SettingRow {
        title: Tr.t("Shell language")
        description: Tr.t("The bar, the pill, the dashboard, the launcher and these settings. Changes right away, no need to log out.")
        icon: "language"
        Segmented {
            model: [
                { id: "auto", label: Tr.t("System##do") },
                { id: "pt", label: "Português" },
                { id: "en", label: "English" }
            ]
            current: Config.options.language
            onSelected: id => Config.options.language = id
        }
    }

    Rectangle {
        Layout.fillWidth: true
        implicitHeight: note.implicitHeight + 24
        radius: Theme.radius
        color: Theme.button

        Text {
            id: note
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.margins: 14
            text: Locales.busy ? Tr.t("Installing the language… (may ask for the administrator password)")
                : Tr.t("Changes apply the next time you log in. A language that isn't installed yet gets installed when you choose it (asks for the administrator password).")
            wrapMode: Text.Wrap
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    SettingRow {
        title: Tr.t("Apps language")
        description: Tr.t("For apps and system menus.")
        icon: "translate"
        Select {
            implicitWidth: 280
            options: root.options
            current: Locales.supported.find(c => c.startsWith(Locales.language + ".")) ?? ""
            searchable: true
            onSelected: id => Locales.setLanguage(id)
        }
    }

    SettingRow {
        title: Tr.t("Formats")
        description: Tr.t("Numbers, dates, times and currency.")
        icon: "123"
        Select {
            implicitWidth: 280
            options: root.options
            current: Locales.formats
            searchable: true
            onSelected: id => Locales.setFormats(id)
        }
    }
}
