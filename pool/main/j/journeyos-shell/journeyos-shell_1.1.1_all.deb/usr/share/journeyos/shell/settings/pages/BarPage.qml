import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Bar and pill.
Page {
    SectionLabel { text: Tr.t("Bar") }

    SettingRow {
        title: Tr.t("Style")
        description: Tr.t("Flat against the top, floating with a margin, islands on each side or everything in one island in the center.")
        icon: "view_day"

        Segmented {
            model: [
                { id: "flat", label: Tr.t("Flat") },
                { id: "floating", label: Tr.t("Floating") },
                { id: "islands", label: Tr.t("Islands") },
                { id: "island", label: Tr.t("Single island") }
            ]
            current: Theme.barStyle
            onSelected: id => Config.options.bar.style = id
        }
    }

    SectionLabel { text: Tr.t("Pill") }

    SettingRow {
        title: Tr.t("Show the pill")
        description: Theme.barStyle === "island"
            ? Tr.t("Hidden when the bar is “Single island”, which takes the same spot.")
            : Tr.t("Music, volume and, when open, music controls or date and weather.")
        icon: "crop_16_9"

        Toggle {
            checked: Config.options.notch.enabled
            onToggled: on => Config.options.notch.enabled = on
        }
    }

    SettingRow {
        title: Tr.t("Open on hover")
        description: Tr.t("Opens when the pointer rests on it and closes when it leaves. Without this, it only opens on click.")
        icon: "ads_click"

        Toggle {
            checked: Config.options.notch.hover
            onToggled: on => Config.options.notch.hover = on
        }
    }
}
