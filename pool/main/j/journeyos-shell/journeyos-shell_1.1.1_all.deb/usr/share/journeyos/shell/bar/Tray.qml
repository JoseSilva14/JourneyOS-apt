import QtQuick
import Quickshell
// Prefixed: the tray's Status clashed with bar/Status.qml
import Quickshell.Services.SystemTray as Tray
import Quickshell.Widgets
import qs
import qs.components

// System tray: the apps' icons (Discord, Steam, KDE Connect…).
// Click: the app's action (or the menu, if it only has a menu); right click: the menu; wheel: the app's.
Row {
    id: root

    spacing: 2

    // "Passive" ones (nothing to show) stay hidden
    readonly property var items: Tray.SystemTray.items.values.filter(i => i.status !== Tray.Status.Passive)

    Repeater {
        model: root.items

        BarButton {
            id: button

            required property var modelData
            readonly property var item: modelData

            anchors.verticalCenter: parent.verticalCenter
            implicitWidth: implicitHeight + 2

            IconImage {
                anchors.centerIn: parent
                implicitSize: Theme.barIcon
                source: button.item.icon
            }

            // Dot when the app asks for attention
            Rectangle {
                visible: button.item.status === Tray.Status.NeedsAttention
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: 3
                width: 6
                height: 6
                radius: 3
                color: Theme.accent
            }

            onClicked: m => {
                const win = QsWindow.window;
                const p = button.mapToItem(win.contentItem, 0, button.height + 4);
                if (m.button === Qt.RightButton || button.item.onlyMenu) {
                    if (button.item.hasMenu)
                        button.item.display(win, p.x, p.y);
                } else if (m.button === Qt.MiddleButton) {
                    button.item.secondaryActivate();
                } else {
                    button.item.activate();
                }
            }
            onWheel: w => button.item.scroll(w.angleDelta.y, false)
        }
    }

    // Separator between the tray and the rest, when there are icons
    Rectangle {
        visible: root.items.length > 0
        anchors.verticalCenter: parent.verticalCenter
        width: 1
        height: Theme.barHeight - 16
        color: Theme.faint
    }
}
