pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Open windows (scripts/windows.py, via a KWin script) and commands on them.
Singleton {
    id: root

    property var list: []            // [{ id, appId, cls, title, active, minimized, output }]
    readonly property var active: list.find(w => w.active) ?? null
    // Screen of the active window (where popups appear); without a window, the first
    readonly property var activeScreen: Quickshell.screens.find(s => s.name === active?.output) ?? Quickshell.screens[0]

    function activate(id) { send("activate " + id); }
    function minimize(id) { send("minimize " + id); }
    function close(id) { send("close " + id); }
    // Activates; if it is already active, minimizes
    function toggle(id) { send("toggle " + id); }

    function send(cmd) {
        if (helper.running)
            helper.write(cmd + "\n");
    }

    Process {
        id: helper
        running: true
        stdinEnabled: true
        command: [Quickshell.shellPath("scripts/windows.py")]
        stdout: SplitParser {
            onRead: line => {
                try {
                    root.list = JSON.parse(line);
                } catch (e) {
                    console.warn("windows: invalid line");
                }
            }
        }
        // Crashed (KWin restarted, for example): relaunch
        onExited: restart.start()
    }

    Timer {
        id: restart
        interval: 2000
        onTriggered: helper.running = true
    }
}
