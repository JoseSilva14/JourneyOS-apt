import QtQuick
import qs.dashboard

// Theme: same as the dashboard's Theme tab (colour schemes and bar style).
ThemeTab {}
