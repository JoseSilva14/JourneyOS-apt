pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Quick panel state (button in the bar). Opening the
// panel closes the notification centre and vice versa.
Singleton {
    id: root

    property bool open: false
    property var screen: null

    function toggle(screen) {
        if (open && (!screen || screen === root.screen)) {
            open = false;
            return;
        }
        root.screen = screen ?? Windows.activeScreen;
        open = true;
    }

    onOpenChanged: if (open) Notifs.centerOpen = false

    Connections {
        target: Notifs
        function onCenterOpenChanged() {
            if (Notifs.centerOpen)
                root.open = false;
        }
    }

    IpcHandler {
        target: "panel"
        function toggle(): void { root.toggle(null); }
    }
}
