import QtQuick
import qs

// Choice between side-by-side options, with a light pill that slides to the chosen one.
// model: [{ id, label, icon }]; compact: only the chosen one shows its name (the others, the icon)
Rectangle {
    id: root

    property var model: []
    property string current: ""
    property bool compact: false
    signal selected(string id)

    readonly property int index: Math.max(0, model.findIndex(m => m.id === current))

    implicitHeight: 38
    implicitWidth: row.implicitWidth + 8
    radius: height / 2
    color: Theme.button

    Rectangle {
        id: pill
        y: 4
        height: parent.height - 8
        radius: height / 2
        color: Theme.accent
        readonly property Item target: repeater.count > 0 ? repeater.itemAt(root.index) : null
        x: (target?.x ?? 0) + 4
        width: target?.width ?? 0

        Behavior on x {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on width {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
    }

    Row {
        id: row
        x: 4
        height: parent.height

        Repeater {
            id: repeater
            model: root.model

            Item {
                id: item
                required property var modelData
                required property int index
                readonly property bool active: index === root.index

                width: content.implicitWidth + 28
                height: row.height

                Row {
                    id: content
                    anchors.centerIn: parent
                    spacing: 6

                    MIcon {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !!item.modelData.icon
                        icon: item.modelData.icon ?? ""
                        size: 17
                        color: item.active ? Theme.accentText : Theme.subtext
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !root.compact || item.active || !item.modelData.icon
                        text: item.modelData.label
                        color: item.active ? Theme.accentText : mouse.containsMouse ? Theme.text : Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.DemiBold

                        Behavior on color {
                            ColorAnimation { duration: Theme.animFast }
                        }
                    }
                }

                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.selected(item.modelData.id)
                }
            }
        }
    }
}
