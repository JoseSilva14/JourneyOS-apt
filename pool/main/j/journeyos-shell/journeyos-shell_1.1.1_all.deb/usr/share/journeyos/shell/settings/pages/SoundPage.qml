import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services
import qs.menus

// Sound: output, input and apps (same as the bar menu, with the lists always visible)
// and the notification sound.
Page {
    MenuCard {
        SoundMenu {
            width: parent.width
            embedded: true
        }
    }

    SectionLabel { text: Tr.t("Alerts") }

    SettingRow {
        title: Tr.t("Notification sound")
        description: Tr.t("A short sound when an alert arrives. Silent in Do not disturb.")
        icon: "notifications_active"

        Toggle {
            checked: Config.options.notifications.sound
            onToggled: on => Config.options.notifications.sound = on
        }
    }
}
