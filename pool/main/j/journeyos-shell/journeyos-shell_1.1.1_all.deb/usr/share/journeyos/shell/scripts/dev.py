#!/usr/bin/env python3
"""Ports in use and Docker containers, for the dashboard's Dev tab.

dev.py estado                 (status) JSON { ports: [...], docker: { state, containers: [...] } }
  ports:      { proto, port, address, scope ("local"|"rede" = network), service, process, pid, container }
              (the process is only known for the user's own; ports published by Docker
              carry the container name)
  docker:     state = ok | missing (no docker) | permission (no access to the socket) | down (service stopped)
  containers: { id, name, image, state, status, ports, project, url }
dev.py docker start|stop|restart <id>
dev.py kill <pid>             terminates (SIGTERM) a user process
"""
import json
import os
import re
import shutil
import grp
import pwd
import signal
import socket
import subprocess
import sys


def run(cmd, timeout=6):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, "", str(e)


# Shell language: English by default, Portuguese with SHADOW_LANG=pt
EN = os.environ.get("SHADOW_LANG") != "pt"

UNITS = [
    (r"less than a second", "menos de 1 s"), (r"about a minute", "1 min"), (r"about an hour", "1 h"),
    (r"(\d+) seconds?", r"\1 s"), (r"(\d+) minutes?", r"\1 min"), (r"(\d+) hours?", r"\1 h"),
    (r"(\d+) days?", r"\1 dias"), (r"(\d+) weeks?", r"\1 semanas"), (r"(\d+) months?", r"\1 meses"),
    (r"(\d+) years?", r"\1 anos"), (r"an hour", "1 h"), (r"a minute", "1 min"), (r"a day", "1 dia"),
]


def ago(text):
    t = text.strip().lower()
    if EN:
        return t.replace("about ", "").replace("less than a second", "<1 s")
    for a, b in UNITS:
        t = re.sub(a, b, t)
    return t


def status_pt(state, status):
    """Docker status text; with SHADOW_LANG=pt in Portuguese: "Up 3 hours (healthy)" → "ligado há 3 h · saudável";
    "Exited (0) 2 days ago" → "parado há 2 dias (0)"."""
    s = status.strip()
    if EN:
        return s.replace("Up ", "up ").replace("Exited", "exited")
    health = ""
    m = re.search(r"\((healthy|unhealthy|health: starting)\)", s)
    if m:
        health = {"healthy": " · saudável", "unhealthy": " · com problemas", "health: starting": " · a verificar"}[m.group(1)]
        s = s.replace(m.group(0), "").strip()
    if s.startswith("Up"):
        paused = " (em pausa)" if "Paused" in s else ""
        return "ligado há " + ago(s[2:].replace("(Paused)", "")) + paused + health
    m = re.match(r"Exited \((-?\d+)\) (.+) ago", s)
    if m:
        return f"parado há {ago(m.group(2))}" + ("" if m.group(1) == "0" else f" · código {m.group(1)}")
    if s.startswith("Restarting"):
        return "a reiniciar"
    if s.startswith("Created"):
        return "criado, nunca arrancou"
    return {"dead": "morto", "removing": "a apagar"}.get(state, s)


def in_docker_group():
    """In the docker group but the session does not have it yet (needs to log in again)."""
    try:
        user = pwd.getpwuid(os.getuid()).pw_name
        g = grp.getgrnam("docker")
        return user in g.gr_mem and g.gr_gid not in os.getgroups()
    except KeyError:
        return False


def docker_cmd(args):
    if in_docker_group() and shutil.which("sg"):
        return ["sg", "docker", "-c", " ".join(["docker", *(f"'{x}'" for x in args)])]
    return ["docker", *args]


def docker():
    if not shutil.which("docker"):
        return {"state": "missing", "containers": []}
    code, out, err = run(docker_cmd(["ps", "-a", "--no-trunc", "--format", "{{json .}}"]))
    if code != 0:
        e = err.lower()
        state = "permission" if "permission denied" in e else "down"
        return {"state": state, "containers": []}
    containers = []
    for line in out.splitlines():
        try:
            c = json.loads(line)
        except ValueError:
            continue
        labels = dict(kv.split("=", 1) for kv in (c.get("Labels") or "").split(",") if "=" in kv)
        ports = c.get("Ports") or ""
        # The first port published over http, for "open in browser"
        m = re.search(r"(?:0\.0\.0\.0|\[::\]|127\.0\.0\.1):(\d+)->\d+/tcp", ports)
        published = sorted({int(p) for p in re.findall(r":(\d+)->", ports)})
        containers.append({
            "id": c.get("ID", "")[:12],
            "name": c.get("Names", ""),
            "image": c.get("Image", ""),
            "state": c.get("State", ""),
            "status": status_pt(c.get("State", ""), c.get("Status", "")),
            "ports": published,
            "project": labels.get("com.docker.compose.project", ""),
            "url": f"http://localhost:{m.group(1)}" if m else "",
        })
    order = {"running": 0, "restarting": 1, "paused": 2}
    containers.sort(key=lambda c: (order.get(c["state"], 3), c["project"], c["name"]))
    return {"state": "ok", "containers": containers}


def ports(containers):
    by_port = {}
    for c in containers:
        for p in c["ports"]:
            by_port.setdefault(p, c["name"])
    seen = {}
    for proto, flag in (("tcp", "-tlnpH"), ("udp", "-ulnpH")):
        code, out, _ = run(["ss", flag])
        if code != 0:
            continue
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 5:
                continue
            local = parts[3] if proto == "tcp" else parts[3]
            addr, _, port = local.rpartition(":")
            if not port.isdigit():
                continue
            port = int(port)
            addr = addr.strip("[]").split("%")[0]
            m = re.search(r'users:\(\("([^"]+)",pid=(\d+)', line)
            process, pid = (m.group(1), int(m.group(2))) if m else ("", 0)
            loopback = addr in ("127.0.0.1", "::1") or addr.startswith("127.")
            key = (proto, port)
            item = seen.get(key)
            if item:
                # The same port on IPv4 and IPv6: keep one, "rede" (network) wins over "local"
                if not loopback:
                    item["scope"] = "rede"
                if pid and not item["pid"]:
                    item["process"], item["pid"] = process, pid
                continue
            try:
                service = socket.getservbyport(port, proto)
            except OSError:
                service = ""
            seen[key] = {
                "proto": proto, "port": port, "address": addr or "*", "service": service,
                "scope": "local" if loopback else "rede",
                "process": process, "pid": pid,
                "container": by_port.get(port, "") if proto == "tcp" else "",
            }
    # UDP only with a known process (the rest is system noise: mDNS, DHCP…)
    # and not the ephemeral ports (>= 32768: replies, not services)
    out = [p for p in seen.values() if p["proto"] == "tcp" or (p["pid"] and p["port"] < 32768)]
    out.sort(key=lambda p: (p["proto"] != "tcp", p["port"]))
    return out


def main():
    a = sys.argv[1:]
    if a == ["estado"]:
        d = docker()
        print(json.dumps({"ports": ports(d["containers"]), "docker": d}, ensure_ascii=False))
        return 0
    if len(a) == 3 and a[0] == "docker" and a[1] in ("start", "stop", "restart"):
        code, _, err = run(docker_cmd([a[1], a[2]]), timeout=60)
        if code != 0:
            print(err.strip(), file=sys.stderr)
        return code
    if len(a) == 2 and a[0] == "kill" and a[1].isdigit():
        try:
            os.kill(int(a[1]), signal.SIGTERM)
            return 0
        except OSError as e:
            print(e, file=sys.stderr)
            return 1
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
