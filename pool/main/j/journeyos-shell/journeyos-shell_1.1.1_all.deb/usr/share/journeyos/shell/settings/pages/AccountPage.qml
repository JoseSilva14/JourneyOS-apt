import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Account: photo, name and password.
Page {
    id: root

    Component.onCompleted: Account.refresh()

    // Photo and name
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: 128
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        RowLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 18

            Item {
                implicitWidth: 92
                implicitHeight: 92

                RoundImage {
                    id: photo
                    anchors.fill: parent
                    radius: 46
                    source: User.face

                    Text {
                        anchors.centerIn: parent
                        visible: !photo.ready
                        text: User.name.charAt(0).toUpperCase()
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 36
                        font.weight: Font.Bold
                    }
                }

                // Change the photo
                Rectangle {
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    width: 32
                    height: 32
                    radius: 16
                    color: Theme.accent
                    border.width: 3
                    border.color: Theme.surfaceCard

                    MIcon {
                        anchors.centerIn: parent
                        icon: "photo_camera"
                        size: 16
                        color: Theme.accentText
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Account.choosePhoto()
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4

                Text {
                    text: Account.realName || Account.login
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 22
                    font.weight: Font.Bold
                }
                Text {
                    text: Account.login + " · " + (Account.admin ? Tr.t("Administrator") : Tr.t("Standard user"))
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }
    }

    SettingRow {
        title: Tr.t("Name")
        description: Tr.t("Full name, on the login screen and the user card.")
        icon: "badge"
        TextField {
            implicitWidth: 240
            text: Account.realName
            placeholder: Account.login
            onAccepted: t => { if (t.trim() && t.trim() !== Account.realName) Account.setName(t); }
        }
    }

    SettingRow {
        title: Tr.t("Password")
        description: Tr.t("Opens a terminal to change it (asks for the current one).")
        icon: "password"
        Rectangle {
            implicitWidth: pwText.implicitWidth + 28
            implicitHeight: 32
            radius: height / 2
            color: pwMouse.containsMouse ? Theme.buttonHover : Theme.button
            Text {
                id: pwText
                anchors.centerIn: parent
                text: Tr.t("Change")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }
            MouseArea {
                id: pwMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Account.changePassword()
            }
        }
    }

    SettingRow {
        title: Tr.t("Name on the desktop card")
        description: Tr.t("Empty = the account name. Only changes the shell.")
        icon: "person"
        TextField {
            implicitWidth: 240
            text: Config.options.displayName
            placeholder: Account.realName || Account.login
            onAccepted: t => Config.options.displayName = t.trim()
        }
    }
}
