import QtQuick
import Quickshell
import Quickshell.Wayland
import qs
import qs.services

// Notification popups, in the top-right corner, below the bar.
// The window is always open and transparent; the mask only catches the cards.
PanelWindow {
    id: root

    anchors {
        top: true
        right: true
    }
    margins {
        top: Theme.gap
        right: Theme.gap
    }
    implicitWidth: Theme.popupWidth
    implicitHeight: screen ? screen.height / 2 : 600
    color: "transparent"
    WlrLayershell.namespace: "shadow-notifications"
    WlrLayershell.layer: WlrLayer.Overlay

    mask: Region {
        item: list.contentItem
    }

    ListView {
        id: list
        anchors.fill: parent
        spacing: Theme.gap / 1.5
        interactive: false
        model: ScriptModel {
            values: Notifs.popups
        }

        delegate: NotificationCard {
            required property var modelData
            width: list.width
            entry: modelData
            popup: true
        }

        add: Transition {
            NumberAnimation { property: "x"; from: Theme.popupWidth; to: 0; duration: Theme.animNormal; easing.type: Easing.OutCubic }
            NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.animNormal }
        }
        remove: Transition {
            NumberAnimation { property: "x"; to: Theme.popupWidth; duration: Theme.animNormal; easing.type: Easing.InCubic }
            NumberAnimation { property: "opacity"; to: 0; duration: Theme.animNormal }
        }
        displaced: Transition {
            NumberAnimation { property: "y"; duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
    }
}
