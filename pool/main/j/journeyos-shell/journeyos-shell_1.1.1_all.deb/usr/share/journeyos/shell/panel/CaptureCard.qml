import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Captures: region and screen via the shell's (services/Capture); recording via Spectacle.
// The panel closes first, so it does not appear in the image.
Section {
    id: root

    implicitHeight: column.implicitHeight + 28

    function capture(args) {
        QuickPanel.open = false;
        Apps.runLater(["spectacle", ...args], Theme.animNormal + 200);
    }

    ColumnLayout {
        id: column
        anchors.fill: parent
        anchors.margins: 14
        spacing: 10

        Text {
            text: Tr.t("Screenshots")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Action {
                icon: "crop"
                label: Tr.t("Region")
                onClicked: Capture.start("region")
            }
            Action {
                icon: "fullscreen"
                label: Tr.t("Screen")
                onClicked: Capture.start("screen")
            }
            Action {
                icon: "colorize"
                label: Tr.t("Color")
                onClicked: Capture.start("color")
            }
            Action {
                icon: "radio_button_checked"
                label: Tr.t("Record")
                onClicked: root.capture(["-R", "r"])
            }
        }
    }

    component Action: Rectangle {
        id: action

        property string icon: ""
        property string label: ""
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 44
        radius: Theme.radius
        color: actionMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: actionMouse.pressed ? 0.96 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        // Icon and name side by side (shorter than one above the other)
        Row {
            anchors.centerIn: parent
            spacing: 6

            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                icon: action.icon
                size: 18
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: action.label
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }

        MouseArea {
            id: actionMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: action.clicked()
        }
    }
}
