pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Web apps (the dashboard's Web tab): sites with a name and icon that open in their own window.
// ~/.local/state/shadow-kde/webapps.json { apps: [{ id, name, url, icon, created }] }
// icon: "" (none: the initial) | path to a PNG (from the site or a chosen image, in
// ~/.local/share/shadow-kde/webapps/) | name of a theme icon.
// Each also has a .desktop entry (shadow-kde-web-<id>), so it appears in the launcher,
// the Apps tab and can be pinned to the dock. scripts/webapps.py does the rest (icon, .desktop, opening).
Singleton {
    id: root

    property var apps: []
    property bool loaded: false
    property bool broken: false

    readonly property string script: Quickshell.shellPath("scripts/webapps.py")
    readonly property string iconDir: Quickshell.env("HOME") + "/.local/share/shadow-kde/webapps"

    readonly property var sorted: apps.slice().sort((a, b) => a.name.localeCompare(b.name))

    function newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

    // "github.com" → "https://github.com"
    function normalize(url) {
        const u = url.trim();
        return !u ? "" : /^[a-z][a-z0-9+.-]*:/i.test(u) ? u : "https://" + u;
    }
    function host(url) {
        const m = /^[a-z][a-z0-9+.-]*:\/\/([^/?#]+)/i.exec(normalize(url));
        return m ? m[1].replace(/^www\./, "") : url;
    }
    // Name from the address, when the site has no title: "web.whatsapp.com" → "Whatsapp"
    function guessName(url) {
        const parts = host(url).split(".").filter(p => !["www", "web", "app", "m"].includes(p));
        const word = parts.length > 1 ? parts[parts.length - 2] : parts[0] ?? "";
        return word.charAt(0).toUpperCase() + word.slice(1);
    }
    function valid(url) { return /^https?:\/\/[^\s/]+\.[^\s/]+/i.test(normalize(url)) || /^https?:\/\/localhost/i.test(normalize(url)); }

    // Source for an Image/IconImage
    function iconSource(icon) {
        return !icon ? "" : icon.startsWith("/") ? "file://" + icon : Quickshell.iconPath(icon, true);
    }

    // Fetches a site's icon into a new file (unique name:
    // images are cached by address). done({ icon, title })
    function findIcon(url, done) {
        const out = iconDir + "/" + newId() + ".png";
        Run.cmd([script, "icon", normalize(url), out], (code, stdout) => {
            let r = { icon: "", title: "" };
            try {
                r = JSON.parse(stdout);
            } catch (e) {
            }
            done(r);
        });
    }

    // A chosen image (kdialog) → PNG in the web apps folder. done(path | "")
    function pickImage(done) {
        Run.cmd(["kdialog", "--title", Tr.t("Web app icon"), "--getopenfilename", Quickshell.env("HOME"),
            "Imagens (*.png *.jpg *.jpeg *.svg *.ico *.webp)"], (code, out) => {
            const src = out.trim();
            if (code !== 0 || !src)
                return;
            const dest = iconDir + "/" + newId() + ".png";
            Run.cmd(["sh", "-c", 'mkdir -p "$(dirname "$2")" && exec "$0" import "$1" "$2"', script, src, dest],
                c => done(c === 0 ? dest : ""));
        });
    }

    // A theme icon (KDE's icon picker). done(name)
    function pickThemeIcon(done) {
        Run.cmd(["kdialog", "--title", Tr.t("Web app icon"), "--geticon", "Applications"], (code, out) => {
            if (code === 0 && out.trim())
                done(out.trim());
        });
    }

    // Deletes a PNG of ours that is no longer used
    function dropIcon(icon) {
        if (icon && icon.startsWith(iconDir + "/") && !apps.some(a => a.icon === icon))
            Quickshell.execDetached(["rm", "-f", icon]);
    }

    function save(app) {
        const clean = { id: app.id || newId(), name: app.name.trim() || guessName(app.url), url: normalize(app.url),
            icon: app.icon ?? "", created: app.created ?? Date.now() };
        const old = apps.find(a => a.id === clean.id);
        apps = old ? apps.map(a => a.id === clean.id ? clean : a) : [...apps, clean];
        write();
        if (old && old.icon !== clean.icon)
            dropIcon(old.icon);
        Quickshell.execDetached([script, "desktop", clean.id, clean.name, clean.url, clean.icon]);
        return clean.id;
    }

    function remove(id) {
        const old = apps.find(a => a.id === id);
        apps = apps.filter(a => a.id !== id);
        write();
        if (old)
            dropIcon(old.icon);
        Quickshell.execDetached([script, "remove", id]);
    }

    function open(app) {
        Apps.run([script, "open", app.url]);
    }

    function write() {
        if (!loaded || broken)
            return;
        file.setText(JSON.stringify({ apps }, null, 1) + "\n");
    }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/webapps.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const list = JSON.parse(text()).apps;
                root.apps = Array.isArray(list) ? list.filter(a => a && a.id && a.url) : [];
                root.broken = false;
            } catch (e) {
                root.broken = true;
                console.warn("webapps.json is corrupt: not overwriting it", e);
            }
            root.loaded = true;
        }
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                root.loaded = true;
        }
    }

    IpcHandler {
        target: "webapps"
        // Adds with the site's icon (if it has one)
        function add(name: string, url: string): void {
            root.findIcon(url, r => root.save({ name: name || r.title, url, icon: r.icon }));
        }
        function list(): string { return root.sorted.map(a => a.id + " " + a.name + " " + a.url + " " + (a.icon || "-")).join("\n"); }
        function remove(id: string): void { root.remove(id); }
        function open(id: string): void {
            const a = root.apps.find(x => x.id === id);
            if (a)
                root.open(a);
        }
    }
}
