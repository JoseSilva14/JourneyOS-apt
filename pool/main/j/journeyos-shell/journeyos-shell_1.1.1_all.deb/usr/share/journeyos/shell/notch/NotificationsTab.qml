import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Notifications tab: the three most recent, Do not disturb and open the centre.
Item {
    id: root

    signal openCenter

    ColumnLayout {
        anchors.fill: parent
        spacing: 6

        Repeater {
            model: Notifs.list.slice(0, 3)

            Rectangle {
                id: row
                required property var modelData
                readonly property var n: modelData.n

                Layout.fillWidth: true
                implicitHeight: 34
                radius: Theme.radiusSmall + 2
                color: rowMouse.containsMouse ? Theme.buttonHover : Theme.button

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 10
                    anchors.rightMargin: 6
                    spacing: 8

                    IconImage {
                        implicitSize: 18
                        source: row.n?.appIcon ? (row.n.appIcon.startsWith("/") ? "file://" + row.n.appIcon : Quickshell.iconPath(row.n.appIcon, true)) : ""
                    }
                    Text {
                        Layout.fillWidth: true
                        text: (row.n?.summary || row.n?.appName || "") + (row.n?.body ? "  ·  " + row.n.body.replace(/<[^>]*>/g, "") : "")
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                    MIcon {
                        icon: "close"
                        size: 14
                        color: Theme.subtext

                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -6
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Notifs.dismiss(row.modelData)
                        }
                    }
                }

                MouseArea {
                    id: rowMouse
                    anchors.fill: parent
                    anchors.rightMargin: 28
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: Notifs.activate(row.modelData)
                }
            }
        }

        Text {
            Layout.fillWidth: true
            Layout.fillHeight: Notifs.list.length === 0
            visible: Notifs.list.length === 0
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            text: Tr.t("No notifications")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }

        Item {
            Layout.fillHeight: Notifs.list.length > 0
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Control {
                icon: Notifs.dnd ? "notifications_off" : "notifications"
                active: Notifs.dnd
                onClicked: Notifs.setDnd(!Notifs.dnd)
            }
            Text {
                Layout.fillWidth: true
                text: Notifs.dnd ? Tr.t("Do not disturb is on") : (Notifs.list.length > 3 ? "+" + (Notifs.list.length - 3) + Tr.t(" in the center") : "")
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Control {
                icon: "clear_all"
                enabled: Notifs.list.length > 0
                onClicked: Notifs.clearAll()
            }
            Control {
                icon: "open_in_new"
                onClicked: root.openCenter()
            }
        }
    }
}
