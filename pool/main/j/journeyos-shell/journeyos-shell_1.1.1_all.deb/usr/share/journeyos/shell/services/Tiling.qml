pragma Singleton

import QtQuick
import Quickshell

// Tiling: arranges the windows of the current screen and desktop
// (scripts/tile.py, which runs a short KWin script). The active window
// goes first. Shortcuts Meta+Alt+1…4, launcher and Settings → Windows.
Singleton {
    id: root

    readonly property var layouts: [
        { id: "metades", shortcut: "tileHalves", title: Tr.t("Halves"), icon: "vertical_split",
            description: Tr.t("Two columns; other windows stack on the right") },
        { id: "colunas", shortcut: "tileColumns", title: Tr.t("Columns"), icon: "view_column",
            description: Tr.t("Up to three columns side by side") },
        { id: "principal", shortcut: "tileMain", title: Tr.t("Main"), icon: "view_quilt",
            description: Tr.t("Active window large on the left, the others on the right") },
        { id: "grelha", shortcut: "tileGrid", title: Tr.t("Grid"), icon: "grid_view",
            description: Tr.t("Equal rows and columns") }
    ]

    function apply(layout) {
        Quickshell.execDetached([Quickshell.shellPath("scripts/tile.py"), layout,
            String(Config.options.tiling.gap)]);
    }
}
