import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Wallpapers tab: search, random and a grid of images; clicking applies.
ColumnLayout {
    id: root

    signal closeRequested

    property string query: ""
    readonly property var shown: {
        const q = query.trim().toLowerCase();
        return q ? Wallpapers.list.filter(w => w.name.toLowerCase().includes(q)) : Wallpapers.list;
    }

    spacing: Theme.gap

    Component.onCompleted: Wallpapers.refresh()

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 38
            radius: height / 2
            color: Theme.button

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 14
                anchors.rightMargin: 14
                spacing: 8

                MIcon {
                    icon: "search"
                    size: 18
                    color: Theme.subtext
                }

                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    clip: true
                    focus: true
                    onTextChanged: root.query = text
                    Keys.onEscapePressed: root.closeRequested()

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !search.text
                        text: Tr.t("Search wallpapers")
                        color: Theme.dim
                        font: search.font
                    }
                }

                Text {
                    text: root.shown.length
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        PillAction {
            icon: "folder_open"
            label: Tr.t("Folder")
            onClicked: {
                Wallpapers.openFolder();
                root.closeRequested();
            }
        }

        PillAction {
            icon: "shuffle"
            label: Tr.t("Random")
            onClicked: Wallpapers.random()
        }
    }

    GridView {
        id: grid
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        readonly property int columns: Math.max(2, Math.floor(width / 220))
        cellWidth: width / columns
        cellHeight: cellWidth * 9 / 16 + 30
        model: root.shown

        delegate: Item {
            id: cell
            required property var modelData
            readonly property bool current: modelData.path === Wallpapers.current

            width: grid.cellWidth
            height: grid.cellHeight

            Rectangle {
                id: frame
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: 6
                height: width * 9 / 16
                radius: Theme.radius
                color: Theme.button
                scale: cellMouse.pressed ? 0.97 : 1

                Behavior on scale {
                    NumberAnimation { duration: Theme.animFast }
                }

                Thumbnail {
                    anchors.fill: parent
                    radius: Theme.radius
                    source: "file://" + cell.modelData.path
                    opacity: cellMouse.containsMouse || cell.current ? 1 : 0.85
                }

                // Outline of the current one, outside the image
                Rectangle {
                    visible: cell.current
                    anchors.fill: parent
                    anchors.margins: -4
                    radius: Theme.radius + 4
                    color: "transparent"
                    border.width: 2
                    border.color: Theme.accent
                }

                // Current
                Rectangle {
                    visible: cell.current
                    anchors.top: parent.top
                    anchors.right: parent.right
                    anchors.margins: 8
                    width: 22
                    height: 22
                    radius: 11
                    color: Theme.accent

                    MIcon {
                        anchors.centerIn: parent
                        icon: "check"
                        size: 15
                        color: Theme.accentText
                    }
                }
            }

            Text {
                anchors.top: frame.bottom
                anchors.topMargin: 5
                anchors.left: frame.left
                anchors.right: frame.right
                text: cell.modelData.name
                elide: Text.ElideRight
                color: cell.current ? Theme.text : Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            MouseArea {
                id: cellMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Wallpapers.set(cell.modelData.path)
            }
        }

        Text {
            anchors.centerIn: parent
            visible: grid.count === 0
            horizontalAlignment: Text.AlignHCenter
            text: Wallpapers.list.length === 0
                ? Tr.t("No wallpapers yet. Add images to the Wallpapers folder (Folder button).")
                : Tr.t("No wallpaper for “") + root.query + "”"
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }
    }

    // Round button with an icon and a label (Folder, Random)
    component PillAction: Rectangle {
        id: pill
        property string icon: ""
        property string label: ""
        signal clicked

        implicitWidth: pillRow.implicitWidth + 28
        implicitHeight: 38
        radius: height / 2
        color: pillMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: pillMouse.pressed ? 0.96 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Row {
            id: pillRow
            anchors.centerIn: parent
            spacing: 6

            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                icon: pill.icon
                size: 17
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: pill.label
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
        }

        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
