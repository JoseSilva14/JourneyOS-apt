pragma Singleton

import QtQuick
import Quickshell

// Region and language (plasma-localerc): app language ([Translations] LANGUAGE)
// and number, date and currency formats ([Formats] LANG). Those not generated yet
// are generated with locale-gen (asks for authorization). Takes effect on the next
// login. (Not called "Region": that is the name of a Quickshell type.)
Singleton {
    id: root

    property string language: ""        // "pt_PT"
    property string formats: ""         // "pt_PT.UTF-8"
    property var generated: []          // ["en_US.UTF-8", …]
    property var supported: []          // ["pt_PT.UTF-8", …]
    property bool busy: false

    // Readable names of the most common ones (the others show the code)
    readonly property var names: ({
        "pt_PT": "Português (Portugal)", "pt_BR": "Português (Brasil)", "en_US": "English (US)",
        "en_GB": "English (UK)", "es_ES": "Español", "fr_FR": "Français", "de_DE": "Deutsch",
        "it_IT": "Italiano", "nl_NL": "Nederlands", "pl_PL": "Polski", "ru_RU": "Русский",
        "ja_JP": "日本語", "zh_CN": "中文 (简体)", "uk_UA": "Українська", "sv_SE": "Svenska",
        "C": Tr.t("C (no language)")
    })

    function name(code) {
        const base = code.replace(/\..*$/, "");
        return names[base] ? names[base] + " · " + base : base;
    }

    function refresh() {
        Kcfg.readMany("plasma-localerc", [
            { group: "Translations", key: "LANGUAGE", fallback: "" },
            { group: "Formats", key: "LANG", fallback: "" }
        ], v => {
            root.language = (v["Translations/LANGUAGE"] || Quickshell.env("LANG") || "").split(":")[0].replace(/\..*$/, "");
            root.formats = v["Formats/LANG"] || Quickshell.env("LANG") || "";
        });
        Run.cmd(["locale", "-a"], (code, out) => {
            // locale -a prints "pt_PT.utf8": normalise to "pt_PT.UTF-8"
            root.generated = out.trim().split("\n").filter(l => /utf8/i.test(l)).map(l => l.replace(/\.utf8$/i, ".UTF-8"));
        });
        if (!supported.length)
            Run.sh("grep ' UTF-8$' /usr/share/i18n/SUPPORTED | cut -d' ' -f1 | grep -v '@'", (code, out) => {
                root.supported = out.trim().split("\n");
            });
    }

    function isGenerated(code) { return generated.includes(code); }

    // Generates (if needed) and selects; the callback runs at the end
    function ensure(code, callback) {
        if (isGenerated(code)) {
            callback();
            return;
        }
        busy = true;
        const pattern = code.replace(/\./g, "\\.");
        Run.cmd(["pkexec", "sh", "-c", "sed -i -E 's/^# ?(" + pattern + " UTF-8)$/\\1/' /etc/locale.gen && "
            + "grep -q '^" + pattern + " UTF-8' /etc/locale.gen || echo '" + code + " UTF-8' >> /etc/locale.gen; locale-gen"], exit => {
            busy = false;
            refresh();
            if (exit === 0)
                callback();
        });
    }

    function setLanguage(code) {
        ensure(code, () => {
            const base = code.replace(/\..*$/, "");
            Kcfg.write("plasma-localerc", "Translations", "LANGUAGE", base + ":en_US", () => refresh());
        });
    }

    function setFormats(code) {
        ensure(code, () => Kcfg.write("plasma-localerc", "Formats", "LANG", code, () => refresh()));
    }
}
