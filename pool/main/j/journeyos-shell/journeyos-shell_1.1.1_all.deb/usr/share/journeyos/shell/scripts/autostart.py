#!/usr/bin/env python3
"""Apps that start on login (~/.config/autostart and /etc/xdg/autostart).

  autostart.py list            → JSON [{ id, name, icon, enabled, system }]
  autostart.py enable <id>     → starts again
  autostart.py disable <id>    → stops starting (for system ones: a copy in ~/.config with Hidden=true)
  autostart.py add <id>        → adds an app (from the applications' .desktop)
  autostart.py remove <id>     → removes one the user added

The essential session parts (authentication agent, keyring, power…) are not listed:
disabling them would break the session.
"""

import configparser
import json
import os
import shutil
import sys

USER = os.path.expanduser("~/.config/autostart")
SYSTEM = "/etc/xdg/autostart"
APPS = [os.path.expanduser("~/.local/share/applications"), "/usr/local/share/applications", "/usr/share/applications"]

ESSENTIAL = {
    "at-spi-dbus-bus.desktop", "gmenudbusmenuproxy.desktop", "gnome-keyring-pkcs11.desktop",
    "gnome-keyring-secrets.desktop", "gnome-keyring-ssh.desktop", "kglobalacceld.desktop",
    "org.kde.plasma-fallback-session-restore.desktop", "org.kde.plasmashell.desktop",
    "pam_kwallet_init.desktop", "polkit-kde-authentication-agent-1.desktop", "powerdevil.desktop",
    "spice-vdagent.desktop", "xapp-sn-watcher.desktop", "xdg-user-dirs.desktop",
    "xdg-user-dirs-kde.desktop", "xembedsniproxy.desktop", "kaccess.desktop",
}


def read(path):
    p = configparser.ConfigParser(interpolation=None, strict=False)
    p.optionxform = str
    p.read(path, encoding="utf-8")
    return p


def write(p, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        p.write(fh, space_around_delimiters=False)
    os.replace(tmp, path)


def info(path):
    try:
        e = read(path)["Desktop Entry"]
    except (configparser.Error, KeyError):
        return None
    return {
        "name": e.get("Name[pt_PT]") or e.get("Name[pt]") or e.get("Name", os.path.basename(path)),
        "icon": e.get("Icon", ""),
        "hidden": e.get("Hidden", "false") == "true",
        "kde": "KDE" not in e.get("NotShowIn", "") and (not e.get("OnlyShowIn") or "KDE" in e.get("OnlyShowIn", "")),
    }


def listing():
    out = {}
    for base, system in ((SYSTEM, True), (USER, False)):
        try:
            files = sorted(os.listdir(base))
        except OSError:
            continue
        for f in files:
            if not f.endswith(".desktop") or f in ESSENTIAL:
                continue
            i = info(os.path.join(base, f))
            if not i or not i["kde"]:
                continue
            # The user's copy wins (that is how a system one is disabled)
            out[f] = {"id": f, "name": i["name"], "icon": i["icon"], "enabled": not i["hidden"],
                      "system": system or out.get(f, {}).get("system", False)}
    return sorted(out.values(), key=lambda x: x["name"].lower())


def set_hidden(desktop_id, hidden):
    user = os.path.join(USER, desktop_id)
    system = os.path.join(SYSTEM, desktop_id)
    # Re-enabling a system one: just remove the copy that disabled it
    if not hidden and os.path.exists(system) and os.path.exists(user):
        os.remove(user)
        return 0
    if not os.path.exists(user):
        src = os.path.join(SYSTEM, desktop_id)
        if not os.path.exists(src):
            return 1
        os.makedirs(USER, exist_ok=True)
        shutil.copy(src, user)
    p = read(user)
    p["Desktop Entry"]["Hidden"] = "true" if hidden else "false"
    write(p, user)
    return 0


def add(desktop_id):
    for d in APPS:
        src = os.path.join(d, desktop_id)
        if os.path.exists(src):
            os.makedirs(USER, exist_ok=True)
            shutil.copy(src, os.path.join(USER, desktop_id))
            return 0
    return 1


def remove(desktop_id):
    user = os.path.join(USER, desktop_id)
    if os.path.exists(user) and not os.path.exists(os.path.join(SYSTEM, desktop_id)):
        os.remove(user)
        return 0
    return 1


if __name__ == "__main__":
    cmd = sys.argv[1:2]
    arg = sys.argv[2] if len(sys.argv) > 2 else ""
    if cmd == ["list"]:
        print(json.dumps(listing()))
    elif cmd == ["enable"] and arg:
        sys.exit(set_hidden(arg, False))
    elif cmd == ["disable"] and arg:
        sys.exit(set_hidden(arg, True))
    elif cmd == ["add"] and arg:
        sys.exit(add(arg))
    elif cmd == ["remove"] and arg:
        sys.exit(remove(arg))
    else:
        print(__doc__, file=sys.stderr)
        sys.exit(1)
