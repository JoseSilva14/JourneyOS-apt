pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Timer and Pomodoro (durations in config.json "pomodoro": focus, short break, long break every N). Saves
// the end time in ~/.local/state/shadow-kde/timer.json: a shell restart does not lose the time. At the end
// it sends a notification (goes through the centre, with sound) and, in Pomodoro, moves on to the next
// phase: on its own (autoStart) or waiting for a click ("waiting"). It can turn on a focus mode during the
// session and turn it off when stopping (only if it was the one that turned it on).
Singleton {
    id: root

    readonly property var cfg: Config.options.pomodoro
    readonly property int focusMin: Math.max(1, cfg.focus)
    readonly property int shortBreakMin: Math.max(1, cfg.shortBreak)
    readonly property int longBreakMin: Math.max(1, cfg.longBreak)
    readonly property int every: Math.max(2, cfg.every)
    property bool waiting: false        // Pomodoro: next phase ready, waiting to start
    property bool focusOwned: false     // the focus mode was turned on by the Pomodoro

    property string phase: "idle"       // idle | running | paused
    property string mode: "timer"       // timer | pomodoro
    property string label: ""           // "Timer", "Focus", "Break" (shown with Tr.t)
    property int total: 0               // phase length in seconds
    property real endsAt: 0             // ms (while running)
    property int pausedLeft: 0          // seconds left when paused
    property int cycle: 0               // focus sessions completed in the Pomodoro

    property real now: Date.now()
    readonly property bool active: phase !== "idle"
    readonly property int left: phase === "running" ? Math.max(0, Math.ceil((endsAt - now) / 1000))
        : phase === "paused" ? pausedLeft : 0
    readonly property real progress: total > 0 ? 1 - left / total : 0

    // "24:59" or "1:05:00"
    function format(s) {
        const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
        const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
        return (h > 0 ? h + ":" : "") + mm + ":" + String(sec).padStart(2, "0");
    }

    function start(minutes, label) {
        mode = "timer";
        run(Math.round(minutes * 60), label || "Timer");
    }

    function startPomodoro() {
        mode = "pomodoro";
        cycle = 0;
        const fm = cfg.focusMode;
        if (fm && Focus.mode(fm) && !Focus.active) {
            Focus.activate(fm, false);
            focusOwned = true;
        }
        run(focusMin * 60, "Focus");
    }

    function run(seconds, name) {
        waiting = false;
        label = name;
        total = seconds;
        endsAt = Date.now() + seconds * 1000;
        now = Date.now();
        phase = "running";
        save();
    }

    function pause() {
        if (phase !== "running")
            return;
        pausedLeft = left;
        phase = "paused";
        save();
    }

    function resume() {
        if (phase !== "paused")
            return;
        waiting = false;
        endsAt = Date.now() + pausedLeft * 1000;
        now = Date.now();
        phase = "running";
        save();
    }

    function toggle() {
        if (phase === "running")
            pause();
        else if (phase === "paused")
            resume();
    }

    function reset() {
        if (focusOwned && Focus.active === cfg.focusMode)
            Focus.deactivate();
        focusOwned = false;
        waiting = false;
        phase = "idle";
        total = 0;
        cycle = 0;
        save();
    }

    // Pomodoro: skip to the next phase now (no notification)
    function skip() {
        if (mode === "pomodoro" && active)
            nextPhase(false);
    }

    // Prepares the next phase; with autoStart it starts right away, otherwise it waits
    function nextPhase(announce) {
        let seconds, name, title, body;
        if (label === "Focus") {
            cycle++;
            const longBreak = cycle % every === 0;
            seconds = (longBreak ? longBreakMin : shortBreakMin) * 60;
            name = "Break";
            title = longBreak ? Tr.t("Focus done: long break") : Tr.t("Focus done: break");
            body = (longBreak ? longBreakMin : shortBreakMin) + Tr.t(" minutes of break.");
        } else {
            seconds = focusMin * 60;
            name = "Focus";
            title = Tr.t("Break over");
            body = Tr.t("Back to focus: ") + focusMin + Tr.t(" minutes.") + (Tasks.next ? Tr.t(" Next: ") + Tasks.next.text : "");
        }
        if (announce)
            notify(title, cfg.autoStart ? body : body + Tr.t(" Start it from the pill."));
        if (cfg.autoStart) {
            run(seconds, name);
        } else {
            label = name;
            total = seconds;
            pausedLeft = seconds;
            phase = "paused";
            waiting = true;
            save();
        }
    }

    function addMinute() {
        if (phase === "running")
            endsAt += 60000;
        else if (phase === "paused")
            pausedLeft += 60;
        else
            return;
        total += 60;
        save();
    }

    function finish() {
        const done = label;
        if (mode === "pomodoro") {
            nextPhase(true);
        } else {
            notify(done + Tr.t(" finished"), Tr.t("Time's up."));
            phase = "idle";
            save();
        }
    }

    // Through the shell's own notification server (goes to the centre, with sound)
    function notify(summary, body) {
        Quickshell.execDetached(["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
            "--object-path", "/org/freedesktop/Notifications", "--method", "org.freedesktop.Notifications.Notify",
            "--", "Timer", "0", "ktimer", summary, body, "[]", "{}", "8000"]);
    }

    Timer {
        running: root.phase === "running"
        interval: 250
        repeat: true
        onTriggered: {
            root.now = Date.now();
            if (root.left <= 0)
                root.finish();
        }
    }

    // --- Saved state ---
    function save() {
        file.setText(JSON.stringify({ phase, mode, label, total, endsAt, pausedLeft, cycle, waiting, focusOwned }));
    }

    FileView {
        id: file
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/timer.json"
        atomicWrites: true
        printErrors: false
        onLoaded: {
            try {
                const s = JSON.parse(text());
                root.mode = s.mode ?? "timer";
                // Old saves had the labels in Portuguese
                root.label = ({ "Foco": "Focus", "Pausa": "Break", "Temporizador": "Timer" })[s.label] ?? s.label ?? "";
                root.total = s.total ?? 0;
                root.endsAt = s.endsAt ?? 0;
                root.pausedLeft = s.pausedLeft ?? 0;
                root.cycle = s.cycle ?? 0;
                root.waiting = s.waiting ?? false;
                root.focusOwned = s.focusOwned ?? false;
                root.now = Date.now();
                root.phase = s.phase ?? "idle";
                // Finished while the shell was stopped: handle it now
                if (root.phase === "running" && root.endsAt <= Date.now())
                    root.finish();
            } catch (e) {
            }
        }
    }

    IpcHandler {
        target: "timer"
        function start(minutes: real): void { root.start(minutes, ""); }
        function pomodoro(): void { root.startPomodoro(); }
        function skip(): void { root.skip(); }
        function toggle(): void { root.toggle(); }
        function reset(): void { root.reset(); }
        function status(): string { return root.phase + " " + root.label + " " + root.format(root.left); }
    }
}
