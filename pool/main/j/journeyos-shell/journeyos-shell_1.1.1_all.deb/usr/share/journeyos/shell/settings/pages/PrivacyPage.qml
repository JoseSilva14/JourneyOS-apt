import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Privacy: what is using the microphone/camera/screen right now, recent files
// history, the trash and stored notifications.
Page {
    id: root

    Component.onCompleted: Privacy.refresh()

    property bool cleared: false

    SectionLabel { text: Tr.t("Now") }

    SettingRow {
        title: Privacy.any ? Tr.t("In use") : Tr.t("Nothing is using the microphone, camera or screen")
        description: [
            Privacy.mic ? Tr.t("Microphone: ") + (Privacy.micApps.join(", ") || Tr.t("in use")) : "",
            Privacy.camera ? Tr.t("Camera: ") + (Privacy.cameraApps.join(", ") || Tr.t("in use")) : "",
            Privacy.screen ? Tr.t("Screen shared") : ""
        ].filter(s => s).join(" · ")
        icon: Privacy.any ? "privacy_tip" : "verified_user"
    }

    SectionLabel { text: Tr.t("History") }

    SettingRow {
        title: Tr.t("Remember opened files")
        description: Tr.t("To show them as recent in apps.")
        icon: "history"
        Toggle {
            checked: Privacy.rememberFiles
            onToggled: on => Privacy.setRemember(on)
        }
    }

    SettingRow {
        visible: Privacy.rememberFiles
        title: Tr.t("Keep for")
        icon: "event"
        Select {
            options: [
                { id: "1", label: Tr.t("1 month") }, { id: "3", label: Tr.t("3 months") }, { id: "6", label: Tr.t("6 months") },
                { id: "12", label: Tr.t("1 year") }, { id: "0", label: Tr.t("Forever") }
            ]
            current: String(Privacy.historyMonths)
            onSelected: id => Privacy.setHistory(Number(id))
        }
    }

    SettingRow {
        title: root.cleared ? Tr.t("History cleared") : Tr.t("Clear history")
        icon: "delete_sweep"
        PillButton {
            text: Tr.t("Delete")
            enabled: !root.cleared
            onClicked: {
                Privacy.clearHistory();
                root.cleared = true;
            }
        }
    }

    SectionLabel { text: Tr.t("Trash and alerts") }

    SettingRow {
        title: Tr.t("Empty trash automatically")
        description: Tr.t("Permanently deletes what has been in the trash for more than ") + Privacy.trashDays + Tr.t(" days.")
        icon: "auto_delete"
        Toggle {
            checked: Privacy.trashAutoEmpty
            onToggled: on => Privacy.setTrashAuto(on)
        }
    }

    SettingRow {
        visible: Privacy.trashAutoEmpty
        title: Tr.t("After")
        icon: "timer"
        Select {
            options: [7, 14, 30, 60, 90].map(d => ({ id: String(d), label: d + Tr.t(" days") }))
            current: String(Privacy.trashDays)
            onSelected: id => Privacy.setTrashDays(Number(id))
        }
    }

    SettingRow {
        title: Notifs.list.length ? Notifs.list.length + Tr.t(" saved notifications") : Tr.t("No saved notifications")
        icon: "notifications"
        PillButton {
            visible: Notifs.list.length > 0
            text: Tr.t("Delete")
            onClicked: Notifs.clearAll()
        }
    }
}
