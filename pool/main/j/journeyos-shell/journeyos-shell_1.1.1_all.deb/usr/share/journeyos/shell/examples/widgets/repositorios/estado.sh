#!/bin/sh
# estado.sh <folder>: one line per repository: path|branch|changes|ahead|behind
# (no network: "behind" is what was already fetched last time)
base=$(eval echo "$1")
find "$base" -maxdepth 3 -name .git -type d 2>/dev/null | sort | while read -r g; do
    d=$(dirname "$g")
    branch=$(git -C "$d" symbolic-ref --short -q HEAD || git -C "$d" rev-parse --short HEAD 2>/dev/null)
    changes=$(git -C "$d" status --porcelain 2>/dev/null | wc -l)
    counts=$(git -C "$d" rev-list --left-right --count '@{u}...HEAD' 2>/dev/null)
    behind=$(echo "$counts" | awk '{print $1+0}')
    ahead=$(echo "$counts" | awk '{print $2+0}')
    echo "$d|$branch|$changes|$ahead|$behind"
done
