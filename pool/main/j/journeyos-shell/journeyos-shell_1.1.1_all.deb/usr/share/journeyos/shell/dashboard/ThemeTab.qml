import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Theme tab: mode, colour scheme (Auto, monochrome and colours) and bar style.
SmoothFlickable {
    id: root

    contentHeight: column.implicitHeight + 8

    readonly property var monoSchemes: Scheme.names.filter(n => Scheme.schemes[n].group === "mono")
    readonly property var colorSchemes: Scheme.names.filter(n => Scheme.schemes[n].group === "color")

    ColumnLayout {
        id: column
        width: root.width - 14
        spacing: Theme.gap

        Tile {
            Layout.fillWidth: true
            implicitHeight: 100
            title: Tr.t("Mode")
            icon: "contrast"

            Segmented {
                anchors.left: parent.left
                model: [
                    { id: "dark", label: Tr.t("Dark"), icon: "dark_mode" },
                    { id: "light", label: Tr.t("Light"), icon: "light_mode" },
                    { id: "auto", label: Tr.t("Automatic"), icon: "brightness_auto" }
                ]
                current: Theme.mode
                onSelected: id => Config.options.theme.mode = id
            }
        }

        Tile {
            Layout.fillWidth: true
            implicitHeight: schemeColumn.implicitHeight + 28 + 30
            title: Tr.t("Color scheme")
            icon: "palette"

            ColumnLayout {
                id: schemeColumn
                anchors.left: parent.left
                anchors.right: parent.right
                spacing: 10

                Flow {
                    Layout.fillWidth: true
                    spacing: 8

                    Swatch { name: "auto" }
                    Repeater {
                        model: root.monoSchemes
                        Swatch {
                            required property string modelData
                            name: modelData
                        }
                    }
                }

                Flow {
                    Layout.fillWidth: true
                    spacing: 8

                    Repeater {
                        model: root.colorSchemes
                        Swatch {
                            required property string modelData
                            name: modelData
                        }
                    }
                }

                // The wallpaper colours: choosing one makes it the accent (Auto scheme)
                RowLayout {
                    Layout.fillWidth: true
                    visible: Scheme.wallColors.length > 0
                    spacing: 8

                    Text {
                        text: Tr.t("From wallpaper")
                        color: Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        Layout.rightMargin: 4
                    }

                    WallDot {
                        color: Theme.button
                        glyph: "auto_awesome"
                        selected: Scheme.current === "auto" && !Scheme.wallColors.includes(Scheme.wallChoice)
                        onClicked: Scheme.setWallColor("")
                    }
                    Repeater {
                        model: Scheme.wallColors
                        WallDot {
                            required property string modelData
                            color: modelData
                            selected: Scheme.current === "auto" && Scheme.wallChoice === modelData
                            onClicked: Scheme.setWallColor(modelData)
                        }
                    }
                    Item { Layout.fillWidth: true }
                }

                Text {
                    Layout.fillWidth: true
                    visible: Scheme.current === "auto"
                    text: Config.options.wallpaper
                        ? Tr.t("Colors come from the current wallpaper.")
                        : Tr.t("No wallpaper chosen: Mono stays until you pick one.")
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        Tile {
            Layout.fillWidth: true
            implicitHeight: 82
            title: "Apps"
            icon: "apps"

            RowLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                spacing: 12

                Text {
                    Layout.fillWidth: true
                    text: Tr.t("Apps (KDE, GTK and Konsole) use the same colors, light or dark.")
                    wrapMode: Text.Wrap
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Toggle {
                    checked: Config.options.theme.apps
                    onToggled: on => Config.options.theme.apps = on
                }
            }
        }

        Tile {
            Layout.fillWidth: true
            implicitHeight: 100
            title: Tr.t("Bar")
            icon: "view_day"

            Segmented {
                anchors.left: parent.left
                model: [
                    { id: "flat", label: Tr.t("Flat") },
                    { id: "floating", label: Tr.t("Floating") },
                    { id: "islands", label: Tr.t("Islands") },
                    { id: "island", label: Tr.t("Single island") }
                ]
                current: Theme.barStyle
                onSelected: id => Config.options.bar.style = id
            }
        }
    }

    // A wallpaper colour (circle; the chosen one with a ring)
    component WallDot: Rectangle {
        id: dot
        property bool selected: false
        property string glyph: ""
        signal clicked

        implicitWidth: 30
        implicitHeight: 30
        radius: 15
        border.width: selected ? 2 : 0
        border.color: Theme.text
        scale: dotMouse.pressed ? 0.9 : dotMouse.containsMouse ? 1.08 : 1

        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            visible: dot.glyph !== ""
            icon: dot.glyph
            size: 15
            color: Theme.text
        }
        MouseArea {
            id: dotMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: dot.clicked()
        }
    }

    // Scheme swatch: the background with the tint and a circle with the accent
    component Swatch: Rectangle {
        id: swatch

        required property string name
        readonly property var info: Scheme.schemes[name]
        readonly property bool selected: Scheme.current === name
        readonly property color accent: name === "auto" ? Scheme.autoAccent
            : Theme.light ? (info.accentLight ?? (Theme.luminance(info.accent) > 0.5 ? Qt.darker(info.accent, 1.3) : info.accent))
            : info.accent
        readonly property color tint: name === "auto" ? Scheme.autoTint
            : info.group === "color" ? info.accent : info.tint
        readonly property real strength: name === "auto" ? 0.3 : info.group === "color" ? 0.25 : Math.max(0.15, info.strength * 2.5)

        width: 96
        height: 64
        radius: Theme.radius
        readonly property color base: Theme.surfaceCard
        color: Qt.rgba(base.r + (tint.r - base.r) * strength, base.g + (tint.g - base.g) * strength, base.b + (tint.b - base.b) * strength, 1)
        border.width: selected ? 2 : 1
        border.color: selected ? Theme.accent : Theme.surfaceBorder
        scale: swatchMouse.pressed ? 0.96 : 1

        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Rectangle {
            x: 10
            y: 10
            width: 18
            height: 18
            radius: 9
            color: swatch.accent

            MIcon {
                anchors.centerIn: parent
                visible: swatch.name === "auto"
                icon: "auto_awesome"
                size: 12
                color: Theme.onColor(swatch.accent)
            }
        }

        MIcon {
            visible: swatch.selected
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 8
            icon: "check_circle"
            size: 16
            color: Theme.accent
        }

        Text {
            anchors.left: parent.left
            anchors.bottom: parent.bottom
            anchors.margins: 10
            text: swatch.info.name
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: swatch.selected ? Font.Bold : Font.Normal
        }

        MouseArea {
            id: swatchMouse
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: Scheme.set(swatch.name)
        }
    }
}
