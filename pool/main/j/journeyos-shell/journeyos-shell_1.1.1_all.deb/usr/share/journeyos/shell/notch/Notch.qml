import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import Quickshell.Wayland
import Quickshell.Services.Pipewire
import qs
import qs.components
import qs.services

// Pill at the top centre. Collapsed, it shows the most important thing, in this order:
// volume/brightness (1.5 s) > alert (notification or event, a few seconds) > agenda event
// (a few minutes before, with the time left; hovering shows the time and location) >
// timer > music > idle (status icons); the privacy dots (microphone, camera, screen)
// stay on the right. Dropping a file on it shares it on the local network (Share tab). Expanded (mouse resting on it or click), it has the Music,
// Timer, Notifications and Actions tabs.
// The window covers the whole screen but the mask only catches the pill; expanded it catches everything,
// so a click outside closes it.
PanelWindow {
    id: root

    // There is one per screen; IPC stays with the primary one's
    property bool primary: false
    property bool expanded: false
    property bool byHover: false       // opened by the mouse: closes on leave
    property string tab: "media"

    // --- Volume and brightness OSD ---
    property bool osdShown: false
    property string osdKind: "volume"
    readonly property PwNode sink: Pipewire.defaultAudioSink
    readonly property real volume: sink?.audio?.volume ?? 0
    readonly property bool muted: sink?.audio?.muted ?? false
    readonly property bool osdBrightness: osdKind === "brightness"
    readonly property real osdValue: osdBrightness ? Brightness.value : volume
    readonly property bool osdOff: !osdBrightness && muted
    readonly property string osdIcon: osdBrightness
        ? (osdValue < 0.34 ? "brightness_low" : osdValue < 0.67 ? "brightness_medium" : "brightness_high")
        : (muted || volume === 0 ? "volume_off" : volume < 0.5 ? "volume_down" : "volume_up")

    readonly property var peek: Events.current

    readonly property string mode: expanded ? "expanded"
        : dropping ? "drop"
        : osdShown ? "osd"
        : peek ? "peek"
        : Agenda.soon ? "event"
        : Countdown.active ? "timer"
        : Media.playing ? "media"
        : "idle"

    // A file dragged over it: dropping shares it on the local network
    readonly property bool dropping: dropArea.containsDrag

    // Event on hover: grows with the time, location and buttons
    readonly property bool eventOpen: mode === "event" && hover.hovered
    readonly property var soon: Agenda.soon
    readonly property color soonColor: soon?.color || Theme.accent

    readonly property var statusIcons: [
        Share.active ? "ios_share" : "",
        Reminders.reminders.length ? "alarm" : "",
        KeepAwake.enabled ? "coffee" : "",
        Notifs.dnd ? "notifications_off" : ""
    ].filter(i => i !== "")

    // Privacy dots (fixed colours, as on phones: orange = microphone, green = camera)
    readonly property var privacyDots: [
        Privacy.mic ? Theme.privacyMic : null,
        Privacy.camera ? Theme.privacyCamera : null,
        Privacy.screen ? Theme.privacyScreen : null
    ].filter(c => c !== null)
    readonly property real dotsWidth: privacyDots.length ? privacyDots.length * 10 + 8 : 0

    readonly property real pillWidth: (mode === "expanded" ? Theme.notchExpandedWidth
        : mode === "osd" ? Theme.notchOsdWidth
        : mode === "peek" || mode === "drop" || eventOpen ? Theme.notchPeekWidth
        : mode === "event" ? Theme.notchEventWidth
        : mode === "timer" ? Theme.notchTimerWidth
        : mode === "media" ? Theme.notchMediaWidth
        : Theme.notchIdleWidth + Math.max(0, statusIcons.length - 1) * 22)
        + (mode === "expanded" || mode === "osd" ? 0 : dotsWidth)
    readonly property real pillHeight: mode === "expanded" ? Theme.notchExpandedHeight
        : mode === "peek" || mode === "drop" || eventOpen ? Theme.notchPeekHeight
        : Theme.notchHeight

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: Config.options.notch.enabled && Theme.barStyle !== "island"
    WlrLayershell.namespace: "shadow-notch"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: expanded ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    mask: Region {
        item: root.expanded ? catcher : pill
    }

    // On opening: the tab for what is happening
    onExpandedChanged: {
        if (!expanded) {
            byHover = false;
            return;
        }
        if (Share.active || Share.starting)
            tab = "share";
        else if (Countdown.active)
            tab = "timer";
        else if (Media.player)
            tab = "media";
    }

    // Volume/brightness changed: shows the OSD (not at startup, when the value arrives for the first time)
    property bool armed: false
    Timer {
        running: true
        interval: 2000
        onTriggered: root.armed = true
    }
    onVolumeChanged: showOsd("volume")
    onMutedChanged: showOsd("volume")
    Connections {
        target: Brightness
        function onChanged() { root.showOsd("brightness"); }
    }
    function showOsd(kind) {
        if (!armed)
            return;
        osdKind = kind;
        osdShown = true;
        osdTimer.restart();
    }
    Timer {
        id: osdTimer
        interval: 1500
        onTriggered: root.osdShown = false
    }

    // Share ready: opens on the Share tab (stays open until clicking outside)
    Connections {
        target: Share
        enabled: root.primary
        function onReady() {
            root.tab = "share";
            root.byHover = false;
            root.expanded = true;
        }
        function onActiveChanged() {
            if (!Share.active && !Share.starting && root.tab === "share")
                root.tab = Media.player ? "media" : "timer";
        }
    }

    PwObjectTracker {
        objects: [root.sink]
    }

    // Mouse resting on it: opens; on leaving (if it opened that way): closes
    Timer {
        running: Config.options.notch.hover && hover.hovered && !root.expanded && root.mode !== "peek" && root.mode !== "event"
        interval: Theme.notchHoverOpen
        onTriggered: {
            root.byHover = true;
            root.expanded = true;
        }
    }
    Timer {
        running: root.expanded && root.byHover && !hover.hovered
        interval: Theme.notchHoverClose
        onTriggered: root.expanded = false
    }

    // Close on clicking outside (only exists for the mask when expanded)
    MouseArea {
        id: catcher
        anchors.fill: parent
        onClicked: root.expanded = false
    }

    Rectangle {
        id: pill

        anchors.horizontalCenter: parent.horizontalCenter
        y: Theme.barMargin + (Theme.barHeight - Theme.notchHeight) / 2
        width: root.pillWidth
        height: root.pillHeight
        radius: root.mode === "expanded" ? Theme.radiusCard + 6 : root.mode === "peek" || root.mode === "drop" || root.eventOpen ? Theme.radiusCard : Theme.notchHeight / 2
        color: root.mode === "expanded" ? Theme.surface : Theme.notch
        border.width: 1
        border.color: Theme.surfaceBorder
        clip: true

        Behavior on color {
            ColorAnimation { duration: Theme.animNormal }
        }

        Behavior on width {
            NumberAnimation { duration: Theme.animSlow; easing.type: Easing.OutBack; easing.overshoot: 1.2 }
        }
        Behavior on height {
            NumberAnimation { duration: Theme.animSlow; easing.type: Easing.OutBack; easing.overshoot: 1.1 }
        }
        Behavior on radius {
            NumberAnimation { duration: Theme.animNormal }
        }

        focus: root.expanded
        Keys.onEscapePressed: root.expanded = false

        HoverHandler {
            id: hover
        }

        DropArea {
            id: dropArea
            anchors.fill: parent
            onEntered: drag => {
                if (drag.hasUrls)
                    drag.accept(Qt.CopyAction);
                else
                    drag.accepted = false;
            }
            onDropped: drop => {
                if (!drop.hasUrls)
                    return;
                drop.accept(Qt.CopyAction);
                Share.share(drop.urls[0].toString());
            }
        }

        // Click: an alert opens the notification; otherwise opens (and stays open) or closes
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (root.mode === "peek") {
                    if (root.peek.entry)
                        Notifs.activate(root.peek.entry);
                    Events.dismiss();
                } else if (root.expanded && !root.byHover) {
                    root.expanded = false;
                } else {
                    root.byHover = false;
                    root.expanded = true;
                }
            }
        }

        // --- Idle ---
        Row {
            anchors.centerIn: parent
            anchors.horizontalCenterOffset: -root.dotsWidth / 2
            spacing: 8
            opacity: root.mode === "idle" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            Repeater {
                model: root.statusIcons
                MIcon {
                    required property string modelData
                    icon: modelData
                    size: 14
                    color: Theme.subtext
                }
            }
        }

        // --- Music ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 5
            anchors.rightMargin: 12 + root.dotsWidth
            spacing: 8
            opacity: root.mode === "media" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            RoundImage {
                id: smallArt
                implicitWidth: Theme.notchHeight - 8
                implicitHeight: Theme.notchHeight - 8
                radius: width / 2
                source: Media.art

                MIcon {
                    anchors.centerIn: parent
                    visible: !smallArt.ready
                    icon: "music_note"
                    size: 12
                    color: Theme.subtext
                }
            }
            Text {
                Layout.fillWidth: true
                text: Media.title + (Media.artist ? " · " + Media.artist : "")
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }
            Bars {
                running: root.mode === "media"
            }
        }

        // --- Timer ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 12 + root.dotsWidth
            spacing: 8
            opacity: root.mode === "timer" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            MIcon {
                icon: Countdown.label === "Break" ? "coffee" : "timer"
                size: 15
                color: Countdown.phase === "paused" ? Theme.dim : Theme.accent
            }
            Text {
                Layout.fillWidth: true
                text: Countdown.format(Countdown.left)
                color: Countdown.phase === "paused" ? Theme.subtext : Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall + 1
                font.weight: Font.Bold
            }
            // Phase progress
            Rectangle {
                implicitWidth: 36
                implicitHeight: 4
                radius: 2
                color: Theme.buttonHover

                Rectangle {
                    width: parent.width * Countdown.progress
                    height: parent.height
                    radius: 2
                    color: Theme.accent
                }
            }
        }

        // --- Agenda event: collapsed, "Title · in 8 min"; on hover, the time, location and buttons ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: root.eventOpen ? 14 : 11
            anchors.rightMargin: (root.eventOpen ? 10 : 12) + root.dotsWidth
            spacing: root.eventOpen ? 12 : 8
            opacity: root.mode === "event" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            // The calendar colour
            Rectangle {
                implicitWidth: root.eventOpen ? 4 : 8
                implicitHeight: root.eventOpen ? 30 : 8
                radius: root.eventOpen ? 2 : 4
                color: root.soonColor
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Text {
                        Layout.fillWidth: true
                        text: root.soon?.title ?? ""
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: root.eventOpen ? Theme.fontSmall + 1 : Theme.fontSmall
                        font.weight: root.eventOpen ? Font.Bold : Font.DemiBold
                    }
                    // Collapsed, the time sits to the right of the title
                    Text {
                        visible: !root.eventOpen
                        text: Agenda.soonText
                        color: Agenda.soonMinutesLeft <= 2 ? root.soonColor : Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                        font.weight: Font.Bold
                    }
                }
                Text {
                    Layout.fillWidth: true
                    visible: root.eventOpen
                    text: root.soon ? [Agenda.soonText.charAt(0).toUpperCase() + Agenda.soonText.slice(1),
                        Agenda.timeText(root.soon), root.soon.location ?? ""].filter(t => t).join(" · ") : ""
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }

            Control {
                visible: root.eventOpen
                implicitWidth: 30
                icon: "calendar_month"
                onClicked: Agenda.openDay(new Date(root.soon.start))
            }
            Control {
                visible: root.eventOpen
                implicitWidth: 30
                icon: "close"
                onClicked: Agenda.hideSoon()
            }
        }

        // --- Dropping a file ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 14
            anchors.rightMargin: 14
            spacing: 12
            opacity: root.mode === "drop" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            MIcon {
                icon: "ios_share"
                size: 22
                color: Theme.accent
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0

                Text {
                    text: Tr.t("Drop to share")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    text: Tr.t("A link and a QR code for your phone, on the same network")
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        // --- Alert: notification or event ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 14 + root.dotsWidth
            spacing: 10
            opacity: root.mode === "peek" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            Item {
                implicitWidth: 30
                implicitHeight: 30

                IconImage {
                    id: peekIcon
                    anchors.fill: parent
                    readonly property string name: root.peek?.appIcon ?? ""
                    source: name ? (name.startsWith("/") ? "file://" + name : Quickshell.iconPath(name, true)) : ""
                    visible: name !== "" && status === Image.Ready
                }
                MIcon {
                    anchors.centerIn: parent
                    visible: !peekIcon.visible && !root.peek?.swatch
                    icon: root.peek?.icon ?? "notifications"
                    size: 20
                }
                // Alerts with a colour (the eyedropper): a circle of that colour
                Rectangle {
                    anchors.centerIn: parent
                    visible: !!root.peek?.swatch
                    width: 24
                    height: 24
                    radius: 12
                    color: root.peek?.swatch ?? "transparent"
                    border.width: 1
                    border.color: Theme.surfaceBorder
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0

                Text {
                    Layout.fillWidth: true
                    text: root.peek?.title ?? ""
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    visible: text !== ""
                    text: root.peek?.text ?? ""
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        // --- Volume / brightness ---
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 14
            spacing: 10
            opacity: root.mode === "osd" ? 1 : 0
            visible: opacity > 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animFast }
            }

            MIcon {
                icon: root.osdIcon
                size: 16
                color: root.osdOff ? Theme.dim : Theme.text
            }
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 4
                radius: 2
                color: Theme.buttonHover

                Rectangle {
                    width: parent.width * Math.min(1, root.osdValue)
                    height: parent.height
                    radius: 2
                    color: root.osdOff ? Theme.dim : Theme.accent

                    Behavior on width {
                        NumberAnimation { duration: Theme.animFast }
                    }
                }
            }
            Text {
                Layout.preferredWidth: 32
                horizontalAlignment: Text.AlignRight
                text: Math.round(root.osdValue * 100) + "%"
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
                font.weight: Font.DemiBold
            }
        }

        // --- Privacy dots (on the right, except when expanded and in the OSD) ---
        Row {
            anchors.right: parent.right
            anchors.rightMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            visible: root.privacyDots.length > 0 && root.mode !== "expanded" && root.mode !== "osd"

            Repeater {
                model: root.privacyDots

                Rectangle {
                    required property color modelData
                    width: 6
                    height: 6
                    radius: 3
                    color: modelData
                }
            }
        }

        // --- Expanded: tabs ---
        Loader {
            anchors.fill: parent
            anchors.margins: 14
            active: root.mode === "expanded"
            opacity: active ? 1 : 0

            Behavior on opacity {
                NumberAnimation { duration: Theme.animNormal }
            }

            sourceComponent: ColumnLayout {
                spacing: 12

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    Segmented {
                        implicitHeight: 32
                        // With the Share tab not all names fit
                        compact: model.length > 4
                        model: [
                            { id: "media", label: Tr.t("Music"), icon: "music_note" },
                            { id: "timer", label: Tr.t("Time"), icon: "timer" },
                            { id: "notifications", label: Tr.t("Alerts"), icon: "notifications" },
                            { id: "actions", label: Tr.t("Actions"), icon: "bolt" },
                            // The extension tabs (Settings → Tabs)
                            ...Widgets.notchTabs,
                            ...(Share.active || Share.starting ? [{ id: "share", label: Tr.t("Share"), icon: "ios_share" }] : [])
                        ]
                        current: root.tab
                        onSelected: id => root.tab = id
                    }

                    Item { Layout.fillWidth: true }

                    // Microphone, camera and screen in use (the app names appear below, in the tab)
                    Row {
                        spacing: 6
                        MIcon { visible: Privacy.mic; icon: "mic"; size: 17; color: Theme.privacyMic }
                        MIcon { visible: Privacy.camera; icon: "videocam"; size: 17; color: Theme.privacyCamera }
                        MIcon { visible: Privacy.screen; icon: "screen_share"; size: 17; color: Theme.privacyScreen }
                    }
                }

                // Which apps are using the microphone/camera/screen
                Text {
                    Layout.fillWidth: true
                    Layout.topMargin: -6
                    visible: Privacy.any
                    text: [
                        Privacy.mic ? Tr.t("Microphone: ") + (Privacy.micApps.join(", ") || Tr.t("in use")) : "",
                        Privacy.camera ? Tr.t("Camera: ") + (Privacy.cameraApps.join(", ") || Tr.t("in use")) : "",
                        Privacy.screen ? Tr.t("Screen shared") : ""
                    ].filter(s => s).join("  ·  ")
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall - 1
                }

                // The tab content in a card, like the dashboard ones
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: Theme.radiusCard - 4
                    color: Theme.surfaceCard
                    border.width: 1
                    border.color: Theme.surfaceBorder

                Loader {
                    anchors.fill: parent
                    anchors.margins: 12
                    sourceComponent: root.tab.startsWith("user/") ? (Widgets.notchTabs.some(t => t.id === root.tab) ? extensionTab : mediaTab)
                        : root.tab === "share" && (Share.active || Share.starting) ? shareTab
                        : root.tab === "timer" ? timerTab
                        : root.tab === "notifications" ? notificationsTab
                        : root.tab === "actions" ? actionsTab
                        : mediaTab
                }
                }
            }
        }
    }

    Component {
        id: mediaTab
        MediaTab {}
    }
    Component {
        id: timerTab
        TimerTab {}
    }
    Component {
        id: extensionTab
        ExtensionTab {
            type: root.tab
            place: "notch"
            onCloseRequested: root.expanded = false
        }
    }
    Component {
        id: shareTab
        ShareTab {}
    }
    Component {
        id: notificationsTab
        NotificationsTab {
            onOpenCenter: {
                root.expanded = false;
                Notifs.toggleCenter(root.screen);
            }
        }
    }
    Component {
        id: actionsTab
        ActionsTab {
            onDone: root.expanded = false
        }
    }

    IpcHandler {
        target: "notch"
        enabled: root.primary
        function toggle(): void { root.expanded = !root.expanded; }
        function tab(name: string): void { root.tab = name; root.byHover = false; root.expanded = true; }
        function osd(): void { root.armed = true; root.showOsd("volume"); }
    }
}
