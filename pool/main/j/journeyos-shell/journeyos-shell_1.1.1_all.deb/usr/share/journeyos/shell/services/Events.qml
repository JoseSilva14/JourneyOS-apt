pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import Quickshell.Services.UPower
import Quickshell.Services.Notifications

// Quick notices the pill shows for a few seconds, one at a time: notifications, Bluetooth
// connected/disconnected, Caps Lock, charger, network and screen sharing/recording. Each notice: {
// icon, title, text, duration, entry? (notification), image?, swatch? (a colour instead of the icon) }
Singleton {
    id: root

    property var queue: []
    property var current: null

    // Only after startup: the first values also look like "changes"
    property bool armed: false
    Timer {
        running: true
        interval: 3000
        onTriggered: root.armed = true
    }

    function push(item) {
        if (!armed)
            return;
        queue = [...queue, item];
        if (!current)
            next();
    }

    function next() {
        current = queue[0] ?? null;
        queue = queue.slice(1);
        if (current)
            shown.restart();
    }

    function dismiss() {
        shown.stop();
        next();
    }

    Timer {
        id: shown
        interval: root.current?.duration ?? 2500
        onTriggered: root.next()
    }

    // --- Notifications ---
    Connections {
        target: Notifs
        function onArrived(entry, critical) {
            const n = entry.n;
            root.push({
                icon: critical ? "priority_high" : "notifications",
                title: n.summary || n.appName || Tr.t("Notification"),
                text: n.body.replace(/<[^>]*>/g, ""),
                appName: n.appName,
                appIcon: n.appIcon || (DesktopEntries.byId(n.desktopEntry)?.icon ?? ""),
                image: n.image,
                duration: n.expireTimeout > 0 ? Math.min(n.expireTimeout, 8000) : 4500,
                entry
            });
        }
    }

    // --- Bluetooth: connected devices (compared every 2 s) ---
    property var connectedBt: []
    Timer {
        running: true
        interval: 2000
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            const devs = Bluetooth.devices?.values ?? [];
            const now = devs.filter(d => d.connected);
            const names = now.map(d => d.name);
            for (const d of now) {
                if (!root.connectedBt.includes(d.name))
                    root.push({
                        icon: /head|phone|bud|audio/i.test(d.icon ?? "") ? "headphones" : "bluetooth_connected",
                        title: d.name,
                        text: d.batteryAvailable ? Tr.t("Connected · battery ") + Math.round(d.battery * 100) + "%" : Tr.t("On"),
                        duration: 2500
                    });
            }
            for (const name of root.connectedBt) {
                if (!names.includes(name))
                    root.push({ icon: "bluetooth_disabled", title: name, text: Tr.t("Off"), duration: 2000 });
            }
            root.connectedBt = names;
        }
    }

    // --- Caps Lock: the keyboard LED (Wayland does not tell the state to clients without focus) ---
    property string capsPath: ""
    property bool caps: false
    Process {
        running: true
        command: ["sh", "-c", "ls /sys/class/leds/*::capslock/brightness 2>/dev/null | head -n1"]
        stdout: StdioCollector {
            onStreamFinished: root.capsPath = text.trim()
        }
    }
    FileView {
        id: capsFile
        path: root.capsPath
        printErrors: false
        onLoaded: {
            const on = text().trim() !== "0";
            if (on !== root.caps) {
                root.caps = on;
                root.push({ icon: "keyboard_capslock", title: on ? Tr.t("Caps Lock on") : Tr.t("Caps Lock off"), text: "", duration: 1500 });
            }
        }
    }
    Timer {
        running: root.capsPath !== ""
        interval: 400
        repeat: true
        onTriggered: capsFile.reload()
    }

    // --- Charger (only with a battery) ---
    readonly property bool hasBattery: UPower.displayDevice?.isLaptopBattery ?? false
    readonly property bool onBattery: UPower.onBattery
    onOnBatteryChanged: {
        if (!hasBattery)
            return;
        const p = UPower.displayDevice.percentage;
        const pct = Math.round((p > 1 ? p / 100 : p) * 100);
        push({ icon: onBattery ? "battery_std" : "battery_charging_full",
            title: onBattery ? Tr.t("On battery") : Tr.t("Charging"), text: pct + "%", duration: 2000 });
    }

    // --- Network ---
    readonly property string netKey: Net.kind + ":" + Net.name
    onNetKeyChanged: {
        if (Net.kind === "none")
            push({ icon: "wifi_off", title: Tr.t("No network"), text: "", duration: 2000 });
        else
            push({ icon: Net.icon, title: Net.name || (Net.kind === "ethernet" ? Tr.t("Wired") : "Wi-Fi"), text: Tr.t("On"), duration: 2000 });
    }

    // --- Screen shared or being recorded ---
    readonly property bool screen: Privacy.screen
    onScreenChanged: push({ icon: screen ? "screen_share" : "stop_screen_share",
        title: screen ? Tr.t("The screen is being shared") : Tr.t("Screen sharing ended"), text: "", duration: 2500 })
}
