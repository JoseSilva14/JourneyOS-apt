import QtQuick
import QtQuick.Shapes
import qs

// Progress ring (0–1) with an icon in the middle.
Item {
    id: root

    property real value: 0
    property string icon: ""
    property real thickness: 3

    implicitWidth: 48
    implicitHeight: 48

    property real shown: value
    Behavior on shown {
        NumberAnimation { duration: Theme.animSlow; easing.type: Easing.OutCubic }
    }

    Shape {
        anchors.fill: parent
        antialiasing: true

        ShapePath {
            fillColor: "transparent"
            strokeColor: Theme.ringTrack
            strokeWidth: root.thickness
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: root.width / 2
                centerY: root.height / 2
                radiusX: root.width / 2 - root.thickness
                radiusY: radiusX
                startAngle: 0
                sweepAngle: 360
            }
        }

        // With no value it draws nothing (the round cap left a dot)
        ShapePath {
            fillColor: "transparent"
            strokeColor: root.shown > 0.005 ? Theme.ringFill : "transparent"
            strokeWidth: root.thickness
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: root.width / 2
                centerY: root.height / 2
                radiusX: root.width / 2 - root.thickness
                radiusY: radiusX
                startAngle: -90
                sweepAngle: 360 * Math.min(1, root.shown)
            }
        }
    }

    MIcon {
        anchors.centerIn: parent
        icon: root.icon
        size: root.width * 0.38
        color: Theme.subtext
    }
}
