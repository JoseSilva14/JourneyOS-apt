import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// App launcher: centred search box, as a list or grid.
// Arrows select, Enter opens, Tab switches layout, Esc or clicking outside closes.
PanelWindow {
    id: root

    // This instance's screen (the window's "screen" changes with "visible": binding loop)
    required property var modelScreen
    readonly property bool open: Launcher.open && Launcher.screen === modelScreen

    readonly property var view: Launcher.grid ? grid : list
    readonly property int columns: 5

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-launcher"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open) {
            search.text = "";
            search.forceActiveFocus();
        } else {
            closing.restart();
        }
    }

    // Search coming from outside (IPC): shows it in the field
    Connections {
        target: Launcher
        function onQueryChanged() {
            if (search.text !== Launcher.query)
                search.text = Launcher.query;
        }
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    // Dims the rest of the screen
    Rectangle {
        anchors.fill: parent
        color: Theme.scrim
        opacity: root.open ? 1 : 0

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
    }

    MouseArea {
        anchors.fill: parent
        onClicked: Launcher.open = false
    }

    Rectangle {
        id: box

        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(parent.height * 0.18) + (root.open ? 0 : Theme.gap * 2)
        width: Math.min(Theme.launcherWidth, parent.width - Theme.gap * 4)
        height: Math.min(content.implicitHeight, parent.height - y - Theme.gap * 2)
        opacity: root.open ? 1 : 0
        scale: root.open ? 1 : 0.97
        radius: Theme.radiusCard + 4
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        clip: true

        Behavior on y {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        // Clicks on the box do not close it
        MouseArea {
            anchors.fill: parent
        }

        ColumnLayout {
            id: content
            anchors.left: parent.left
            anchors.right: parent.right
            spacing: 0

            // Search
            RowLayout {
                Layout.fillWidth: true
                Layout.margins: Theme.cardPadding
                Layout.bottomMargin: Theme.gap
                spacing: 12

                MIcon {
                    icon: "search"
                    size: 22
                    color: Theme.subtext
                }

                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text
                    selectionColor: Theme.accent
                    selectedTextColor: Theme.accentText
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge
                    clip: true
                    focus: root.open
                    onTextChanged: {
                        Launcher.query = text;
                        root.view.currentIndex = 0;
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !search.text
                        text: Tr.t("Search apps, files, commands, math, :emojis")
                        color: Theme.dim
                        font: search.font
                    }

                    Keys.onEscapePressed: Launcher.open = false
                    Keys.onReturnPressed: Launcher.launch(Launcher.results[root.view.currentIndex])
                    Keys.onEnterPressed: Launcher.launch(Launcher.results[root.view.currentIndex])
                    Keys.onTabPressed: Launcher.toggleLayout()
                    Keys.onDownPressed: root.move(Launcher.grid ? root.columns : 1)
                    Keys.onUpPressed: root.move(Launcher.grid ? -root.columns : -1)
                    Keys.onPressed: event => {
                        // Left/right only change app in the grid (in the list they move within the text)
                        if (Launcher.grid && event.key === Qt.Key_Right) {
                            root.move(1);
                            event.accepted = true;
                        } else if (Launcher.grid && event.key === Qt.Key_Left) {
                            root.move(-1);
                            event.accepted = true;
                        } else if (event.key === Qt.Key_PageDown) {
                            root.move(Launcher.grid ? root.columns * 3 : 7);
                            event.accepted = true;
                        } else if (event.key === Qt.Key_PageUp) {
                            root.move(Launcher.grid ? -root.columns * 3 : -7);
                            event.accepted = true;
                        }
                    }
                }

                // List/grid
                Rectangle {
                    implicitWidth: 30
                    implicitHeight: 30
                    radius: Theme.radiusSmall
                    color: layoutMouse.containsMouse ? Theme.buttonHover : Theme.button

                    Behavior on color {
                        ColorAnimation { duration: Theme.animFast }
                    }

                    MIcon {
                        anchors.centerIn: parent
                        icon: Launcher.grid ? "view_list" : "grid_view"
                        size: 17
                        color: Theme.subtext
                    }

                    MouseArea {
                        id: layoutMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Launcher.toggleLayout()
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 1
                color: Theme.surfaceBorder
            }

            // List
            ListView {
                id: list
                Layout.fillWidth: true
                Layout.margins: Theme.gap / 2
                implicitHeight: Math.min(count, 7) * Theme.launcherRow
                visible: !Launcher.grid && count > 0
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                highlightMoveDuration: 0
                model: ScriptModel {
                    values: Launcher.results
                }

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool current: ListView.isCurrentItem

                    width: list.width
                    height: Theme.launcherRow
                    radius: Theme.radius
                    // No transition, as in menus
                    color: current ? Theme.buttonHover : rowMouse.containsMouse ? Theme.button : "transparent"

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 14
                        spacing: 12

                        AppIcon {
                            item: row.modelData
                            size: 32
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1

                            Text {
                                Layout.fillWidth: true
                                text: row.modelData.title
                                elide: Text.ElideRight
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontNormal
                                font.weight: Font.DemiBold
                            }
                            Text {
                                Layout.fillWidth: true
                                visible: text !== ""
                                text: row.modelData.subtitle ?? ""
                                elide: Text.ElideRight
                                color: Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                        }

                        Text {
                            visible: row.current
                            text: "↵"
                            color: Theme.dim
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                        }
                    }

                    MouseArea {
                        id: rowMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Launcher.launch(row.modelData)
                    }
                }
            }

            // Grid
            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.margins: Theme.gap / 2
                implicitHeight: Math.min(Math.ceil(count / root.columns), 3) * cellHeight
                visible: Launcher.grid && count > 0
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                highlightMoveDuration: 0
                cellWidth: width / root.columns
                cellHeight: Theme.launcherCell
                model: ScriptModel {
                    values: Launcher.results
                }

                delegate: Item {
                    id: cell
                    required property var modelData
                    required property int index
                    readonly property bool current: GridView.isCurrentItem

                    width: grid.cellWidth
                    height: grid.cellHeight

                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 4
                        radius: Theme.radius
                        color: cell.current ? Theme.buttonHover : cellMouse.containsMouse ? Theme.button : "transparent"
                    }

                    Column {
                        anchors.centerIn: parent
                        width: parent.width - 16
                        spacing: 8

                        AppIcon {
                            anchors.horizontalCenter: parent.horizontalCenter
                            item: cell.modelData
                            size: 44
                        }

                        Text {
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            text: cell.modelData.title
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                        }
                    }

                    MouseArea {
                        id: cellMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Launcher.launch(cell.modelData)
                    }
                }
            }

            // No results
            Text {
                Layout.fillWidth: true
                Layout.margins: Theme.cardPadding + 4
                visible: Launcher.results.length === 0
                horizontalAlignment: Text.AlignHCenter
                text: Tr.t("Nothing for “") + Launcher.query + "”"
                elide: Text.ElideMiddle
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
        }
    }

    function move(delta) {
        const v = root.view;
        if (v.count === 0)
            return;
        v.currentIndex = Math.max(0, Math.min(v.count - 1, v.currentIndex + delta));
        v.positionViewAtIndex(v.currentIndex, ListView.Contain);
    }

    // Result icon: the theme one (apps), a Material one (commands, files, accounts)
    // or the emoji; with none, the initial
    component AppIcon: Item {
        id: appIcon

        required property var item
        property int size: 32
        readonly property string source: !item.icon ? "" : item.icon.startsWith("/") ? "file://" + item.icon : Quickshell.iconPath(item.icon, true)

        implicitWidth: size
        implicitHeight: size

        IconImage {
            id: image
            anchors.fill: parent
            source: appIcon.source
            visible: appIcon.source !== "" && status === Image.Ready
        }

        Text {
            anchors.centerIn: parent
            visible: !!appIcon.item.emoji
            text: appIcon.item.emoji ?? ""
            // The colour one (without this Qt picked Symbola, in black and white)
            font.family: "Noto Color Emoji"
            font.pixelSize: appIcon.size * 0.8
        }

        Rectangle {
            anchors.fill: parent
            visible: !image.visible && !appIcon.item.emoji
            radius: Theme.radiusSmall
            color: Theme.button

            MIcon {
                anchors.centerIn: parent
                visible: !!appIcon.item.glyph
                icon: appIcon.item.glyph ?? ""
                size: appIcon.size * 0.55
                color: Theme.subtext
            }
            Text {
                anchors.centerIn: parent
                visible: !appIcon.item.glyph
                text: (appIcon.item.title ?? "?").charAt(0).toUpperCase()
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: appIcon.size * 0.45
                font.weight: Font.Bold
            }
        }
    }
}
