#!/bin/sh
# Develop a widget with the shell running: widget-dev.sh <widget folder>
#  - if the folder is not in ~/.local/share/shadow-kde/widgets, links it there (symlink);
#  - adds the widget to the desktop, if it is not there yet (and enables the pill and
#    dashboard tabs, if the manifest has "places");
#  - every time a file in the folder is saved, reloads the user's widgets;
#  - shows the shell log in the terminal (console.log/warn/error and QML errors).
# Ctrl+C exits (the widget stays installed and on the desktop).
set -e
[ -n "$1" ] || { echo "usage: widget-dev.sh <widget folder>"; exit 1; }
src=$(readlink -f "$1")
[ -f "$src/manifest.json" ] || { echo "no manifest.json in $src"; exit 1; }
here=$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)
dir="$HOME/.local/share/shadow-kde/widgets"
id=$(basename "$src")
ipc() { qs -p "$here" ipc call widgets "$@"; }

mkdir -p "$dir"
if [ "$(readlink -f "$dir/$id")" != "$src" ]; then
    [ -e "$dir/$id" ] && { echo "another $dir/$id already exists: rename the folder"; exit 1; }
    ln -s "$src" "$dir/$id"
    echo "linked: $dir/$id → $src"
fi
ipc rescan
sleep 1
# Where it shows (manifest "places"): on the desktop it adds it; in the pill/dashboard it enables the tab
places=$("$here/scripts/widgets.py" listar | python3 -c "import json,sys; print(' '.join(next((w.get('places') or {}) for w in json.load(sys.stdin) if w['id']=='$id')))")
for place in $places; do
    case "$place" in
    desktop) ipc list | grep -q "\"user/$id\"" || ipc add "user/$id" ;;
    notch|dashboard) ipc tab "$place" "user/$id" true; echo "tab enabled: $place" ;;
    esac
done
echo "watching $src (Ctrl+C to exit)"

# Shell log, only what matters to a widget
log="${XDG_RUNTIME_DIR:-/tmp}/shadow-kde-start.log"
tail -n 0 -F "$log" | grep --line-buffered -E "qml|$id|WARN|ERROR" &
tailpid=$!
trap 'kill $tailpid 2>/dev/null; exit 0' INT TERM

# Reloads when any file changes (compares the timestamps every 1 s)
stamp() { find "$src" -type f -printf '%T@ %p\n' 2>/dev/null | sort | md5sum; }
last=$(stamp)
while sleep 1; do
    now=$(stamp)
    if [ "$now" != "$last" ]; then
        last=$now
        echo "── $(date +%H:%M:%S) reloaded"
        ipc rescan
    fi
done
