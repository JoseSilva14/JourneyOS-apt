# Creating a new tab for the pill and the dashboard

This guide teaches you, step by step, how to make your own tab: it appears in the **pill** (when
open, next to Music, Weather, Alerts and Actions) and/or in the **dashboard** (next to Home,
Calendar, Notes…).

By the end you will have made the **Quick commands** tab: buttons that run your commands and show
the result. The complete code is in `examples/widgets/comandos-rapidos/`. There are three more
example tabs to study: `relogios` (the time in other cities), `processos` (the ones using the
most, with a way to end them) and `repositorios` (the git status of your folders, with its own
script in the tab's folder).

> A tab is the same kind of folder as a desktop widget. This guide only covers what is specific
> to tabs. For everything an extension can use (services, components, connecting to other
> apps), see [`WIDGETS.md`](WIDGETS.md).

> A tab runs with your permissions, like any program. Only install tabs you trust
> (read the QML first).

## Contents

1. [How it works](#1-how-it-works)
2. [Step 1: the folder](#2-step-1-the-folder)
3. [Step 2: the `manifest.json`](#3-step-2-the-manifestjson)
4. [Step 3: the simplest tab](#4-step-3-the-simplest-tab)
5. [Step 4: see the tab and reload automatically](#5-step-4-see-the-tab-and-reload-automatically)
6. [Step 5: options](#6-step-5-options)
7. [Step 6: make it do something](#7-step-6-make-it-do-something)
8. [Pill and dashboard: space and look](#8-pill-and-dashboard-space-and-look)
9. [Recipes](#9-recipes)
10. [When something goes wrong](#10-when-something-goes-wrong)
11. [Sharing](#11-sharing)
12. [Checklist](#12-checklist)
13. [Quick reference](#13-quick-reference)

(The paths assume the shell is in `~/Projetos/shadow-kde`; replace them with wherever you have it.)

---

## 1. How it works

```text
~/.local/share/shadow-kde/widgets/
└── comandos-rapidos/           ← the folder (the name is the id: letters, numbers, - and _)
    ├── manifest.json           ← name, icon, where it appears ("places") and options
    └── Tab.qml                 ← what you see in the tab
```

1. The shell reads the folders and finds those whose `places` include `notch` (pill) or `dashboard`.
2. Those appear in **Settings → Tabs**, each with a switch.
3. When turned on, the tab goes at the end of the tabs, with the manifest's name and icon.
4. When you open the tab, the shell loads your QML filling the whole space and gives it the
   options. When you close it or switch tabs, it destroys it.

---

## 2. Step 1: the folder

```sh
mkdir -p ~/tabs/comandos-rapidos
cd ~/tabs/comandos-rapidos
```

You can work wherever you like: `widget-dev.sh` (step 4) links the folder to the shell. The
folder name is the tab's id and **should not change** once you use it (the shell stores it as
`user/<id>`).

---

## 3. Step 2: the `manifest.json`

```json
{
    "name": "Quick commands",
    "icon": "bolt",
    "description": "Buttons that run your commands, in the pill and in the dashboard.",
    "places": { "notch": "Tab.qml", "dashboard": "Tab.qml" }
}
```

| Field | What |
|---|---|
| `name` | The tab's name (also in Settings). Keep it short: tabs sit side by side |
| `icon` | A [Material Icon](https://fonts.google.com/icons?icon.style=Rounded) (`bolt`, `public`, `dns`, `rocket_launch`…) |
| `description` | One sentence, shown in Settings |
| `places` | Where it appears, and with which QML |

`places` can be written in three ways:

```json
"places": { "notch": "Tab.qml", "dashboard": "Tab.qml" }
"places": { "notch": "Pill.qml", "dashboard": "Panel.qml" }
"places": ["notch", "dashboard", "desktop"]
```

- **Object, same file:** one QML serves both places and adapts (that is what we do here).
- **Object, different files:** one QML per place.
- **List:** all use `main` (by default `Widget.qml`). With `desktop`, it is also a desktop widget.

Without `places`, the folder is only a desktop widget.

---

## 4. Step 3: the simplest tab

Create `Tab.qml`:

```qml
import QtQuick
import qs

Item {
    property string place: "notch"

    Text {
        anchors.centerIn: parent
        text: parent.place === "notch" ? "Hello from the pill" : "Hello from the dashboard"
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: Theme.fontLarge
    }
}
```

Two rules that differ from widgets:

- **Don't set `width` or `height` on the root.** The shell stretches it to the tab's space.
- **Declare only the properties you use** (`place`, `options`…). The shell fills in those that exist.

---

## 5. Step 4: see the tab and reload automatically

```sh
~/Projetos/shadow-kde/scripts/widget-dev.sh ~/tabs/comandos-rapidos
```

The script:

- links the folder into `~/.local/share/shadow-kde/widgets/`;
- turns the tab on in the pill and the dashboard (the places in `places`);
- **reloads on every save** of a file in the folder;
- shows your messages (`console.log`) and QML errors in the terminal.

Open the pill (hover over it, or click) or the dashboard and pick your tab. Ctrl+C exits; the
tab stays installed.

Without the script, copy the folder to `~/.local/share/shadow-kde/widgets/`, go to **Settings →
Tabs → Rescan**, and then turn the switch on.

---

## 6. Step 5: options

Options appear in **Settings → Tabs**, below the switch. The pill and the dashboard have
**separate values**: the same tab can show different things in each place.

Add to the manifest:

```json
"options": [
    {
        "key": "comandos",
        "label": "Commands",
        "description": "Name=command, separated by semicolons.",
        "type": "string",
        "default": "Refresh package list=pkcon refresh; Free space=df -h /; Date=date"
    },
    {
        "key": "terminal",
        "label": "Open in a terminal",
        "type": "bool",
        "default": false
    }
]
```

| `type` | Control | Value in QML | Extra fields |
|---|---|---|---|
| `string` | text field | text | — |
| `number` | numbers-only field | number | `min`, `max` |
| `bool` | switch | `true`/`false` | — |
| `choice` | list | the chosen `id` | `choices`: `[{ "id", "label" }]` |

In QML, you receive them in `options`, already with the defaults:

```qml
property var options: ({})

// Updates by itself when the user changes an option
readonly property var commands: String(options.comandos || "").split(";")
    .map(s => s.trim()).filter(s => s.includes("="))
    .map(s => ({ name: s.slice(0, s.indexOf("=")).trim(), command: s.slice(s.indexOf("=") + 1).trim() }))
```

> Options are stored as plain text in `config.json`. Never ask for passwords or tokens in an
> option: read them from the system keyring (see "Secrets" in `WIDGETS.md`).

---

## 7. Step 6: make it do something

The tab needs three things: state, a function that runs the command, and the buttons.

**State and the function:**

```qml
import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

Item {
    id: root

    property var options: ({})
    property string place: "notch"
    signal done

    readonly property bool compact: place === "notch"
    property string running: ""     // the name of what is running
    property string output: ""

    function run(c) {
        if (root.options.terminal) {
            // Apps.run puts the program outside the shell (it does not die if the shell restarts)
            Apps.run(["konsole", "--hold", "-e", "sh", "-c", c.command]);
            root.done();            // closes the pill / the dashboard
            return;
        }
        root.running = c.name;
        Run.cmd(["sh", "-c", c.command], (code, out, err) => {
            root.running = "";
            root.output = (code === 0 ? out : err || "Exited with code " + code).trim();
        });
    }

    // … the buttons (next)
}
```

- **`Run.cmd(argv, (code, out, err) => …)`** runs a command hidden and returns the result.
- **`Apps.run(argv)`** opens a program (window, terminal).
- **`signal done`**: emitting it **closes the pill or the dashboard**. Use it after opening a
  window, so it doesn't end up underneath.

**The buttons and the result:**

```qml
ColumnLayout {
    anchors.fill: parent
    spacing: root.compact ? 8 : Theme.gap

    Flow {
        Layout.fillWidth: true
        spacing: 8

        Repeater {
            model: root.commands

            Rectangle {
                id: button
                required property var modelData
                readonly property bool busy: root.running === modelData.name
                width: label.implicitWidth + 44
                height: root.compact ? 32 : 40
                radius: height / 2
                color: busy ? Theme.accent : mouse.containsMouse ? Theme.buttonHover : Theme.button

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: button.modelData.name
                    color: button.busy ? Theme.accentText : Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                }
                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    enabled: root.running === ""
                    onClicked: root.run(button.modelData)
                }
            }
        }
    }

    // The result, scrollable if it is long
    Rectangle {
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: root.output !== ""
        radius: Theme.radius
        color: Theme.button

        Flickable {
            anchors.fill: parent
            anchors.margins: 10
            clip: true
            contentHeight: result.implicitHeight

            Text {
                id: result
                width: parent.width
                text: root.output
                wrapMode: Text.WrapAnywhere
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }
}
```

Save: the tab reloads and you already have working buttons. The complete version (with icons on
the buttons and the empty state) is in `examples/widgets/comandos-rapidos/Tab.qml`.

---

## 8. Pill and dashboard: space and look

| Place | Space (approx.) | Background | Ideal for |
|---|---|---|---|
| `notch` | 448 × 144 px | the pill's card (`Theme.surfaceCard`) | a quick glance and one or two clicks |
| `dashboard` | 964 × 392 px | the dashboard background | lists, charts, several cards |

**One QML for both.** Use `place` to change sizes:

```qml
readonly property bool compact: place === "notch"

Text {
    font.pixelSize: root.compact ? Theme.fontLarge : Theme.fontStat * 2
}
```

**To look like part of the shell:**

- **Always use `Theme`, never fixed colours or sizes.** That way it follows the colour schemes,
  the light theme and "Reduce motion".
- **In the pill,** boxes inside the tab use `Theme.button` (the background is already a card).
- **In the dashboard,** group things in cards like the other tabs: `color: Theme.surfaceCard`,
  `border.color: Theme.surfaceBorder`, `radius: Theme.radiusCard`.
- **Text:** `Theme.text` (primary), `Theme.subtext` (secondary), `Theme.dim` (dimmed).
- **Accent:** `Theme.accent`, with `Theme.accentText` on top.
- **Buttons:** `Theme.button` / `Theme.buttonHover`, with `Behavior on color` and
  `Theme.animFast`.
- **The font is always `Theme.font`.** Sizes are `Theme.fontSmall`, `fontNormal`, `fontMedium`,
  `fontLarge` and `fontStat`.
- **Icons:** `MIcon { icon: "bolt"; size: 16; color: Theme.subtext }` (from `qs.components`).

**Lifecycle.** The tab only exists while it is visible:

- `Timer`s stop by themselves when it closes (they cost nothing while hidden);
- state (variables) is lost: to keep something between openings, write a file (recipe below);
- when opening, read the data straight away (`triggeredOnStart: true` on the `Timer`) so it
  isn't empty.

---

## 9. Recipes

**Update every few seconds**

```qml
Timer {
    running: true
    repeat: true
    triggeredOnStart: true
    interval: 5000
    onTriggered: Run.cmd(["uptime", "-p"], (code, out) => root.text = out.trim())
}
```

**Read a web API**

```qml
function fetch() {
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200)
            root.data = JSON.parse(xhr.responseText);
    };
    xhr.open("GET", "https://api.github.com/repos/" + root.options.repo);
    xhr.send();
}
```

**Keep state between openings**

```qml
import Quickshell
import Quickshell.Io

property string widgetId: ""        // the shell gives one id per place (pill/dashboard)

FileView {
    id: store
    path: Quickshell.env("HOME") + "/.local/state/my-tab-" + root.widgetId + ".json"
    onLoaded: root.count = JSON.parse(text()).count ?? 0
}
function save() { store.setText(JSON.stringify({ count: root.count })); }
```

**Receive data from another app or script** (without polling every few seconds):

```sh
~/Projetos/shadow-kde/scripts/widget-send.sh build '{"status":"compiling","progress":0.4}'
```

```qml
import qs.services

property var build: Widgets.lastMessage("build") ?? ({})
Connections {
    target: Widgets
    function onMessage(channel, data) { if (channel === "build") root.build = data; }
}
```

**Open a website or a folder, and close**

```qml
onClicked: {
    Apps.run(["xdg-open", "https://github.com"]);
    root.done();
}
```

**A short notice in the pill**

```qml
Events.push({ icon: "check", title: "Done", text: "The build finished", duration: 2000 });
```

**Images from the tab's folder**

```qml
property string widgetDir: ""
Image { source: "file://" + root.widgetDir + "/logo.png" }
```

More (D-Bus, sockets, secrets, performance): [`WIDGETS.md`](WIDGETS.md), sections 5 to 7.

---

## 10. When something goes wrong

| Symptom | What to do |
|---|---|
| The tab doesn't appear in Settings → Tabs | `manifest.json` has an error: it appears at the end of the page, "(with errors)", with the line. Check `places` |
| "This tab has an error" | The QML didn't load: `widget-dev.sh` shows the line. Also see `journalctl --user -u shadow-kde -f` |
| The tab is empty or small | Did you remove `width`/`height` from the root? Do the children use `anchors.fill: parent` or layouts with `Layout.fill…`? |
| I changed the QML and nothing changed | Settings → Tabs → Rescan (`widget-dev.sh` does this on every save) |
| `options` is empty | Did you declare `property var options: ({})` on the **root**? |
| The window I opened stays underneath | Emit `done()` after opening it |
| The pill gets slow | Too many fast `Timer`s or heavy commands: see "Performance" in `WIDGETS.md` |

`console.log("x =", x)` writes to the `widget-dev.sh` terminal.

---

## 11. Sharing

A tab is just a folder. In **Settings → Tabs**, **Export** (next to it) makes a `.zip` ready to
send. `zip -r comandos-rapidos.zip comandos-rapidos` works too, or a git repository.

Whoever receives it:

1. goes to **Settings → Tabs → Choose .zip…** (or drags the `.zip` there);
2. sees the review: where it appears and what the code can do (commands, internet, files…);
3. presses **Install** and turns the switch on in the pill and/or the dashboard.

The `manifest.json` must be at the root of the `.zip` or in a single folder inside it (**Export**
already does it this way). Details in `WIDGETS.md`, section 9.

Put `author` and `version` in the manifest, and explain in `description` what the tab does. If it
runs commands or talks to the internet, say which.

---

## 12. Checklist

- [ ] The folder name only has letters, numbers, `-` and `_`.
- [ ] `manifest.json` has `name`, `icon` and `places` with `notch` and/or `dashboard`.
- [ ] The QML root has no `width`/`height`, and declares only the properties it uses.
- [ ] Colours, fonts, sizes and animations come from `Theme`.
- [ ] It looks right in both themes (light and dark) and in the places where it appears.
- [ ] It has an empty or error state (no network, no data) instead of staying blank.
- [ ] Programs open with `Apps.run` and the tab emits `done()` afterwards.
- [ ] No secrets in the options.
- [ ] `Timer`s have sensible intervals (seconds, not milliseconds).

---

## 13. Quick reference

```text
Folder:        ~/.local/share/shadow-kde/widgets/<id>/{manifest.json, Tab.qml}
Where:         "places": { "notch": "Tab.qml", "dashboard": "Tab.qml" }   (or ["notch", "dashboard"])
Turn on:       Settings → Tabs   ·   qs -p <shell> ipc call widgets tab notch|dashboard user/<id> true
Develop:       scripts/widget-dev.sh <folder>
Rescan:        qs -p <shell> ipc call widgets rescan
Examples:      examples/widgets/{comandos-rapidos, relogios, processos, repositorios}
Install .zip:  Settings → Tabs → Choose .zip…   ·   scripts/widgets.py ver|instalar <zip>

On the QML root (declare only the ones you use):
  property var options: ({})        the manifest options, per place
  property string place: "notch"    "notch" or "dashboard"
  property string widgetDir: ""     the tab's folder
  property string widgetId: ""      one id per place
  signal done                       emitting it closes the pill / the dashboard

Space:         pill 448 × 144 · dashboard 964 × 392 (no width/height on the root)
Useful:        Run.cmd(argv, (code, out, err) => {}) · Apps.run(argv) · Events.push({ icon, title, text })
               Widgets.lastMessage(channel) · Theme.* · MIcon
```
