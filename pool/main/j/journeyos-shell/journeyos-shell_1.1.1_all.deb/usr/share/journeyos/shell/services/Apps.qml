pragma Singleton

import QtQuick
import Quickshell

// Launching programs. Each one goes into its own scope in app.slice: launched directly
// it stayed in the shadow-kde.service cgroup and died when that was restarted.
Singleton {
    function run(command) {
        Quickshell.execDetached(["systemd-run", "--user", "--scope", "--quiet",
            "--slice=app.slice", "--collect", ...command]);
    }

    // Opens an app by its .desktop entry (terminal ones
    // in Konsole); the shell's settings open directly
    function launch(entry, screen) {
        if (entry.id === SettingsApp.desktopId) {
            SettingsApp.show("home");
            return;
        }
        // The shell's tools (Calculator, Monitor, Capture…): directly
        const tool = ShellApps.toolFor(entry.id);
        if (tool) {
            tool.run();
            return;
        }
        if (entry.id === Dashboard.desktopId) {
            // No tab: close if open, otherwise open on the last one
            Dashboard.toggle("", screen ?? Windows.activeScreen);
            return;
        }
        const cmd = entry.runInTerminal ? ["konsole", "-e", ...entry.command] : entry.command;
        if (entry.workingDirectory)
            run(["sh", "-c", 'cd "$0" && exec "$@"', entry.workingDirectory, ...cmd]);
        else
            run(cmd);
    }

    // Like run, but after a delay (e.g. let the panel close before a capture)
    function runLater(command, ms) {
        run(["sh", "-c", 'sleep "$0" && exec "$@"', String(ms / 1000), ...command]);
    }
}
