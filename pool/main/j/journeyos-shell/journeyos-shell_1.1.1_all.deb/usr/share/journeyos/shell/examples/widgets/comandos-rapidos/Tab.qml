import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// "Quick commands" tab: one button per command (option "comandos": Name=command; …).
// Hidden, it shows the result below; in a terminal, it opens Konsole and closes the pill/dashboard.
Item {
    id: root

    // --- What the shell gives us ---
    property var options: ({})
    property string place: "notch"
    signal done

    // --- Tab state ---
    readonly property bool compact: place === "notch"
    // "Date=date; Space=df -h /" → [{ name: "Date", command: "date" }, …]
    readonly property var commands: String(options.comandos || "").split(";")
        .map(s => s.trim()).filter(s => s.includes("="))
        .map(s => ({ name: s.slice(0, s.indexOf("=")).trim(), command: s.slice(s.indexOf("=") + 1).trim() }))
    property string running: ""      // the name of what is running
    property string output: ""

    function run(c) {
        if (root.options.terminal) {
            // Apps.run puts the program outside the shell (it does not die if the shell restarts)
            Apps.run(["konsole", "--hold", "-e", "sh", "-c", c.command]);
            root.done();                 // closes the pill / the dashboard
            return;
        }
        root.running = c.name;
        Run.cmd(["sh", "-c", c.command], (code, out, err) => {
            root.running = "";
            root.output = (code === 0 ? out : err || "Exited with code " + code).trim();
        });
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: root.compact ? 8 : Theme.gap

        // The buttons
        Flow {
            Layout.fillWidth: true
            spacing: 8

            Repeater {
                model: root.commands

                Rectangle {
                    id: button
                    required property var modelData
                    readonly property bool busy: root.running === modelData.name
                    width: label.implicitWidth + 44
                    height: root.compact ? 32 : 40
                    radius: height / 2
                    color: busy ? Theme.accent : mouse.containsMouse ? Theme.buttonHover : Theme.button

                    Behavior on color {
                        ColorAnimation { duration: Theme.animFast }
                    }

                    Row {
                        anchors.centerIn: parent
                        spacing: 6
                        MIcon {
                            anchors.verticalCenter: parent.verticalCenter
                            icon: button.busy ? "hourglass_top" : "play_arrow"
                            size: 16
                            color: button.busy ? Theme.accentText : Theme.subtext
                        }
                        Text {
                            id: label
                            anchors.verticalCenter: parent.verticalCenter
                            text: button.modelData.name
                            color: button.busy ? Theme.accentText : Theme.text
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall + 1
                            font.weight: Font.DemiBold
                        }
                    }
                    MouseArea {
                        id: mouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        enabled: root.running === ""
                        onClicked: root.run(button.modelData)
                    }
                }
            }
        }

        // The result of the last command
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            visible: root.output !== ""
            radius: Theme.radius
            color: Theme.button

            Flickable {
                anchors.fill: parent
                anchors.margins: 10
                clip: true
                contentHeight: result.implicitHeight
                boundsBehavior: Flickable.StopAtBounds

                Text {
                    id: result
                    width: parent.width
                    text: root.output
                    wrapMode: Text.WrapAnywhere
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
            }
        }

        // No commands
        Text {
            visible: root.commands.length === 0
            text: "Add commands in Settings → Tabs."
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }

        Item {
            Layout.fillHeight: true
            visible: root.output === ""
        }
    }
}
