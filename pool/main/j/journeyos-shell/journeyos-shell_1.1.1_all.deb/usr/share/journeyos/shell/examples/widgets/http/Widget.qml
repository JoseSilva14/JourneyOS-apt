import QtQuick
import QtQuick.Layouts
import qs
import qs.components

// Connects the widget to a web service: XMLHttpRequest (comes with QML, nothing to install),
// JSON.parse and a field chosen in the options. Without a network, the last value stays.
Card {
    id: root

    property var options: ({})

    width: 280
    height: 130

    property string value: ""
    property string error: ""
    property date updated

    function pick(obj, path) {
        return path.split(".").filter(p => p !== "").reduce((o, k) => o?.[k], obj);
    }

    function fetch() {
        const url = root.options.url ?? "";
        if (!url)
            return;
        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = () => {
            if (xhr.readyState !== XMLHttpRequest.DONE)
                return;
            if (xhr.status !== 200) {
                root.error = xhr.status ? "Error " + xhr.status : "No connection";
                return;
            }
            try {
                const v = root.pick(JSON.parse(xhr.responseText), root.options.campo ?? "");
                root.value = v === undefined ? "—" : String(v);
                root.error = "";
                root.updated = new Date();
            } catch (e) {
                root.error = "The response is not JSON";
            }
        };
        xhr.open("GET", url);
        xhr.send();
    }

    Timer {
        running: true
        interval: Math.max(1, root.options.intervalo ?? 10) * 60000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.fetch()
    }

    // The options changed: fetch now
    onOptionsChanged: fetch()

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Theme.cardPadding
        spacing: 2

        Text {
            text: root.options.titulo ?? ""
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
        Text {
            Layout.fillWidth: true
            text: root.value ? root.value + " " + (root.options.unidade ?? "") : "…"
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: 30
            font.weight: Font.Bold
        }
        Item { Layout.fillHeight: true }
        Text {
            text: root.error || (root.value ? "Updated at " + Qt.formatTime(root.updated, "HH:mm") : "")
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }
}
