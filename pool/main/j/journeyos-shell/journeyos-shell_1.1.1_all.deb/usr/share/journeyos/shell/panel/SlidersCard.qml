import QtQuick
import QtQuick.Layouts
import Quickshell.Services.Pipewire
import qs
import qs.components
import qs.services

// Volume and brightness in one card (brightness disappears when the system does not allow changing it).
// Clicking the volume icon mutes; the brightness one does nothing.
Section {
    id: root

    readonly property PwNode sink: Pipewire.defaultAudioSink
    readonly property bool muted: sink?.audio?.muted ?? false
    readonly property real volume: sink?.audio?.volume ?? 0

    implicitHeight: column.implicitHeight + 16

    PwObjectTracker {
        objects: [root.sink]
    }

    ColumnLayout {
        id: column
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 8
        anchors.rightMargin: Theme.cardPadding
        spacing: 2

        SliderRow {
            visible: root.sink !== null
            icon: root.muted || root.volume === 0 ? "volume_off" : root.volume < 0.5 ? "volume_down" : "volume_up"
            value: root.volume
            dimmed: root.muted
            clickable: true
            onIconClicked: if (root.sink?.audio) root.sink.audio.muted = !root.muted
            onMoved: v => {
                if (!root.sink?.audio)
                    return;
                root.sink.audio.volume = v;
                if (root.muted && v > 0)
                    root.sink.audio.muted = false;
            }
        }

        SliderRow {
            visible: Brightness.available
            icon: Brightness.value < 0.34 ? "brightness_low" : Brightness.value < 0.67 ? "brightness_medium" : "brightness_high"
            value: Brightness.value
            onMoved: v => Brightness.set(v)
        }
    }

    component SliderRow: RowLayout {
        id: row

        property string icon: ""
        property real value: 0
        property bool dimmed: false
        property bool clickable: false
        signal moved(real value)
        signal iconClicked

        Layout.fillWidth: true
        implicitHeight: 40
        spacing: 10

        Rectangle {
            implicitWidth: 34
            implicitHeight: 34
            radius: 17
            color: row.clickable && iconMouse.containsMouse ? Theme.buttonHover : "transparent"

            Behavior on color {
                ColorAnimation { duration: Theme.animFast }
            }

            MIcon {
                anchors.centerIn: parent
                icon: row.icon
                size: 19
                color: row.dimmed ? Theme.dim : Theme.text
            }

            MouseArea {
                id: iconMouse
                anchors.fill: parent
                enabled: row.clickable
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: row.iconClicked()
            }
        }

        Slider {
            Layout.fillWidth: true
            value: row.value
            opacity: row.dimmed ? 0.45 : 1
            onMoved: v => row.moved(v)
        }

        Text {
            Layout.preferredWidth: 38
            horizontalAlignment: Text.AlignRight
            text: Math.round(row.value * 100) + "%"
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
    }
}
