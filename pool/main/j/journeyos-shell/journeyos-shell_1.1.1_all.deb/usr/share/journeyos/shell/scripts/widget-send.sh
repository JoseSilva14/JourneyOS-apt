#!/bin/sh
# Sends data to a widget (the widgets' message channel): widget-send.sh <channel> <data>
# The data is parsed as JSON when it is JSON (otherwise text). For other apps and scripts:
#   widget-send.sh status '{"title":"Build","text":"Compiling…","progress":0.4}'
[ $# -ge 2 ] || { echo "usage: widget-send.sh <channel> <data>"; exit 1; }
here=$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)
exec qs -p "$here" ipc call widgets send "$1" "$2"
