import QtQuick
import QtQuick.Layouts
import QtCore

// shadow-kde lock screen, loaded by KDE's kscreenlocker.
// Runs outside the shell: colours, wallpaper and avatar come from the INI the shell exports
// (~/.local/state/shadow-kde/theme.conf, services/LockTheme.qml).
Item {
    id: root

    // Properties and signals kscreenlocker looks for
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false
    signal suspendToDisk()
    signal suspendToRam()
    signal clearPassword()

    implicitWidth: 1280
    implicitHeight: 800

    readonly property url conf: "file://" + StandardPaths.writableLocation(StandardPaths.HomeLocation)
        .toString().replace("file://", "") + "/.local/state/shadow-kde/theme.conf"

    Settings {
        id: theme
        location: root.conf
        category: "Theme"
        property bool light: false
        property string bg: "#111112"
        property string surface: "#18181a"
        property string border: "#14ffffff"
        property string button: "#0fffffff"
        property string buttonHover: "#1fffffff"
        property string text: "#ececec"
        property string subtext: "#9a9a9c"
        property string dim: "#5c5c60"
        property string accent: "#f2f2f2"
        property string accentText: "#111112"
        property string wallTop: "#161618"
        property string wallBottom: "#0b0b0c"
        property string font: "JetBrains Mono"
        property bool clock24: true
        property string iconFont: ""
        property string logo: ""
    }

    Settings {
        id: user
        location: root.conf
        category: "User"
        property string name: kscreenlocker_userName
        property string avatar: ""
    }

    Settings {
        id: desktop
        location: root.conf
        category: "Desktop"
        property string wallpaper: ""
    }

    // Texts in the shell language (exported by services/LockTheme.qml; English by default)
    Settings {
        id: strings
        location: root.conf
        category: "Strings"
        property string locale: "en_GB"
        property string date: "dddd, d MMMM"
        property string wrongPassword: "Wrong password"
        property string suspend: "Sleep"
        property string password: "Password"
        property string checking: "Checking…"
        property string tryAgain: "Didn't get an answer, try again"
    }

    FontLoader {
        id: icons
        source: theme.iconFont ? "file://" + theme.iconFont : ""
    }

    property bool busy: false
    property string message: ""

    // The secret waits here when PAM is not asking for it yet
    property bool pendingSecret: false

    function unlock() {
        if (busy || !password.text)
            return;
        busy = true;
        message = "";
        stuck.restart();
        if (authenticator.promptForSecret) {
            authenticator.respond(password.text);
        } else {
            // No conversation waiting (the greeter stops authenticating e.g. while the screen is
            // off): start one and answer when PAM asks. Responding with none waiting was ignored and
            // the field stayed busy forever.
            pendingSecret = true;
            authenticator.startAuthenticating();
        }
    }

    // Never stay stuck: no answer in 10 s → free the field and start again
    Timer {
        id: stuck
        interval: 10000
        onTriggered: {
            if (!root.busy)
                return;
            root.busy = false;
            root.pendingSecret = false;
            root.message = strings.tryAgain;
            authenticator.startAuthenticating();
            password.forceActiveFocus();
        }
    }

    Connections {
        target: authenticator

        function onSucceeded() {
            stuck.stop();
            Qt.quit();
        }
        function onFailed(kind) {
            // Only password errors (the other authenticators fail silently)
            if (kind !== 0)
                return;
            stuck.stop();
            root.pendingSecret = false;
            root.busy = false;
            root.message = strings.wrongPassword;
            password.text = "";
            shake.restart();
            retry.restart();
        }
        function onErrorMessageChanged() {
            if (authenticator.errorMessage)
                root.message = authenticator.errorMessage;
        }
        function onPromptForSecretChanged() {
            if (authenticator.promptForSecret && root.pendingSecret) {
                root.pendingSecret = false;
                authenticator.respond(password.text);
                return;
            }
            password.forceActiveFocus();
        }
    }

    // After a failure the authenticator has to restart
    Timer {
        id: retry
        interval: 1500
        onTriggered: authenticator.startAuthenticating()
    }

    onClearPassword: password.text = ""

    Component.onCompleted: {
        authenticator.startAuthenticating();
        password.forceActiveFocus();
    }

    // --- Background: the wallpaper (or the gradient) with a veil on top ---
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: theme.wallTop }
            GradientStop { position: 0.55; color: theme.bg }
            GradientStop { position: 1.0; color: theme.wallBottom }
        }
    }

    Image {
        anchors.fill: parent
        source: desktop.wallpaper ? "file://" + desktop.wallpaper : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        sourceSize.width: root.width
        sourceSize.height: root.height
    }

    Rectangle {
        anchors.fill: parent
        color: theme.bg
        opacity: desktop.wallpaper ? 0.55 : 0
    }

    // A click anywhere returns to the password field
    MouseArea {
        anchors.fill: parent
        onClicked: password.forceActiveFocus()
    }

    // Narrow: clock on top, password below
    readonly property bool narrow: width < 900

    GridLayout {
        id: content
        anchors.centerIn: parent
        width: Math.min(parent.width - 80, 1000)
        columns: root.narrow ? 1 : 2
        columnSpacing: 80
        rowSpacing: 40
        opacity: 0

        Component.onCompleted: opacity = 1
        Behavior on opacity {
            NumberAnimation { duration: 400 }
        }

        // Big clock: hours above minutes
        ColumnLayout {
            Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignVCenter | Qt.AlignLeft
            spacing: 0

            Column {
                Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignLeft
                spacing: -40

                Text {
                    id: hours
                    color: theme.text
                    font.family: theme.font
                    font.pixelSize: 180
                    font.weight: Font.ExtraBold
                    font.letterSpacing: -7
                }
                Text {
                    id: minutes
                    color: theme.subtext
                    font.family: theme.font
                    font.pixelSize: 180
                    font.weight: Font.ExtraBold
                    font.letterSpacing: -7
                }
            }

            Text {
                id: date
                Layout.alignment: root.narrow ? Qt.AlignHCenter : Qt.AlignLeft
                Layout.leftMargin: 6
                color: theme.subtext
                font.family: theme.font
                font.pixelSize: 18
            }

            Timer {
                running: true
                repeat: true
                interval: 1000
                triggeredOnStart: true
                onTriggered: {
                    const now = new Date();
                    hours.text = Qt.formatTime(now, theme.clock24 ? "HH" : "h");
                    minutes.text = Qt.formatTime(now, "mm");
                    const d = Qt.locale(strings.locale).toString(now, strings.date);
                    date.text = d.charAt(0).toUpperCase() + d.slice(1);
                }
            }
        }

        // User and password
        ColumnLayout {
            id: login
            Layout.alignment: Qt.AlignCenter
            Layout.preferredWidth: 340
            Layout.maximumWidth: 340
            spacing: 14

            // Round avatar (the image sits under a ring in the background colour)
            Item {
                Layout.alignment: Qt.AlignHCenter
                implicitWidth: 112
                implicitHeight: 112

                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: theme.button
                    border.width: 1
                    border.color: theme.border
                    clip: true

                    Image {
                        id: avatar
                        anchors.fill: parent
                        anchors.margins: 18
                        source: user.avatar ? "file://" + user.avatar
                            : kscreenlocker_userImage ? "file://" + kscreenlocker_userImage : ""
                        fillMode: Image.PreserveAspectFit
                        sourceSize.width: 160
                        sourceSize.height: 160
                    }

                    Text {
                        anchors.centerIn: parent
                        visible: avatar.status !== Image.Ready
                        text: user.name.charAt(0).toUpperCase()
                        color: theme.text
                        font.family: theme.font
                        font.pixelSize: 44
                        font.weight: Font.Bold
                    }
                }
            }

            Text {
                Layout.alignment: Qt.AlignHCenter
                text: user.name
                color: theme.text
                font.family: theme.font
                font.pixelSize: 22
                font.weight: Font.Bold
            }

            // Password field in a pill, with the log-in button inside
            Rectangle {
                id: field
                Layout.fillWidth: true
                Layout.topMargin: 10
                implicitHeight: 50
                radius: height / 2
                color: theme.surface
                border.width: 1
                border.color: password.activeFocus ? theme.accent : theme.border

                Behavior on border.color {
                    ColorAnimation { duration: 150 }
                }

                SequentialAnimation {
                    id: shake
                    loops: 1
                    NumberAnimation { target: fieldShift; property: "x"; to: -12; duration: 50 }
                    NumberAnimation { target: fieldShift; property: "x"; to: 12; duration: 70 }
                    NumberAnimation { target: fieldShift; property: "x"; to: -8; duration: 60 }
                    NumberAnimation { target: fieldShift; property: "x"; to: 6; duration: 50 }
                    NumberAnimation { target: fieldShift; property: "x"; to: 0; duration: 40 }
                }

                transform: Translate {
                    id: fieldShift
                }

                TextInput {
                    id: password
                    anchors.left: parent.left
                    anchors.right: enter.left
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.leftMargin: 22
                    anchors.rightMargin: 10
                    echoMode: TextInput.Password
                    passwordCharacter: "●"
                    color: theme.text
                    selectionColor: theme.accent
                    selectedTextColor: theme.accentText
                    font.family: theme.font
                    font.pixelSize: 16
                    font.letterSpacing: 2
                    enabled: !root.busy
                    focus: true
                    clip: true
                    onAccepted: root.unlock()
                    onTextChanged: if (text) root.message = ""
                    Keys.onEscapePressed: text = ""

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !password.text
                        text: root.busy ? strings.checking : strings.password
                        color: theme.dim
                        font.family: theme.font
                        font.pixelSize: 15
                    }
                }

                Rectangle {
                    id: enter
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.rightMargin: 6
                    width: 38
                    height: 38
                    radius: 19
                    color: theme.accent
                    opacity: password.text ? 1 : 0.4
                    scale: enterMouse.pressed ? 0.92 : 1

                    Behavior on opacity {
                        NumberAnimation { duration: 150 }
                    }
                    Behavior on scale {
                        NumberAnimation { duration: 100 }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "arrow_forward"
                        font.family: icons.name
                        font.pixelSize: 20
                        color: theme.accentText
                    }

                    MouseArea {
                        id: enterMouse
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.unlock()
                    }
                }
            }

            Text {
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredHeight: 20
                text: root.message
                color: "#ff6b6b"
                font.family: theme.font
                font.pixelSize: 13
            }
        }
    }

    // Suspend, at the bottom centre (when the system allows it)
    Rectangle {
        visible: root.suspendToRamSupported
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 40
        width: suspendRow.implicitWidth + 32
        height: 40
        radius: 20
        color: suspendMouse.containsMouse ? theme.buttonHover : theme.button

        Row {
            id: suspendRow
            anchors.centerIn: parent
            spacing: 8

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "bedtime"
                font.family: icons.name
                font.pixelSize: 18
                color: theme.text
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: strings.suspend
                color: theme.text
                font.family: theme.font
                font.pixelSize: 14
            }
        }

        MouseArea {
            id: suspendMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: root.suspendToRam()
        }
    }
}
