import QtQuick
import qs
import qs.components

// Round pill button (big = filled with the accent).
Rectangle {
    id: control

    property string icon: ""
    property bool big: false
    property bool active: false
    signal clicked

    implicitWidth: big ? 40 : 34
    implicitHeight: implicitWidth
    radius: width / 2
    color: big || active ? Theme.accent : controlMouse.containsMouse ? Theme.buttonHover : Theme.button
    opacity: enabled ? 1 : 0.35
    scale: controlMouse.pressed ? 0.92 : 1

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }
    Behavior on scale {
        NumberAnimation { duration: Theme.animFast }
    }

    MIcon {
        anchors.centerIn: parent
        icon: control.icon
        size: control.big ? 22 : 19
        color: control.big || control.active ? Theme.accentText : Theme.text
    }

    MouseArea {
        id: controlMouse
        anchors.fill: parent
        hoverEnabled: true
        enabled: control.enabled
        cursorShape: Qt.PointingHandCursor
        onClicked: control.clicked()
    }
}
