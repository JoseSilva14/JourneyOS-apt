import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Desktop: wallpaper, wallpaper folders and widgets.
Page {
    id: root

    readonly property string wallpaperName: Wallpapers.list.find(w => w.path === Wallpapers.current)?.name
        ?? (Wallpapers.current ? Wallpapers.current.split("/").pop() : "Gradiente escuro")

    SectionLabel { text: "Wallpaper" }

    SettingRow {
        title: root.wallpaperName
        description: Tr.t("Pick one in the dashboard's Wallpapers tab.")
        icon: "wallpaper"

        Row {
            spacing: 6
            PillButton {
                text: Tr.t("Random")
                onClicked: Wallpapers.random()
            }
            PillButton {
                text: Tr.t("Choose")
                accent: true
                onClicked: {
                    SettingsApp.open = false;
                    Dashboard.toggle("wallpapers", null);
                }
            }
        }
    }

    SettingRow {
        title: Tr.t("No wallpaper")
        description: Tr.t("Back to the dark gradient.")
        icon: "gradient"

        PillButton {
            text: Tr.t("Use")
            onClicked: Wallpapers.set("")
        }
    }

    SectionLabel { text: Tr.t("Wallpaper folders") }

    Repeater {
        model: Config.options.wallpaperDirs

        SettingRow {
            required property string modelData
            title: modelData
            icon: "folder"

            PillButton {
                text: Tr.t("Remove##tirar")
                onClicked: {
                    Config.options.wallpaperDirs = Config.options.wallpaperDirs.filter(d => d !== modelData);
                    Wallpapers.refresh();
                }
            }
        }
    }

    TextField {
        id: newDir
        Layout.fillWidth: true
        placeholder: Tr.t("Add a folder (e.g. ~/Pictures/Backgrounds) and press Enter")
        onAccepted: text => {
            const dir = text.trim();
            if (dir && !Config.options.wallpaperDirs.includes(dir)) {
                Config.options.wallpaperDirs = [...Config.options.wallpaperDirs, dir];
                Wallpapers.refresh();
            }
            newDir.text = "";
        }
    }

    SectionLabel { text: "Widgets" }

    SettingRow {
        title: Tr.t("Edit widgets")
        description: Tr.t("Move, resize, change style, add and remove (") + Config.options.shortcuts.widgets + ")."
        icon: "widgets"

        PillButton {
            text: Tr.t("Edit")
            accent: true
            onClicked: {
                SettingsApp.open = false;
                Widgets.editing = true;
            }
        }
    }

    Repeater {
        model: Widgets.items

        ColumnLayout {
            id: widgetRow
            required property var modelData
            readonly property var info: Widgets.types[modelData.type]
            readonly property var values: Widgets.optionsFor(modelData)
            Layout.fillWidth: true
            spacing: 4

            SettingRow {
                title: widgetRow.info?.name ?? widgetRow.modelData.type
                description: widgetRow.info?.error ? Tr.t(widgetRow.info.error)
                    : !widgetRow.info ? Tr.t("No longer installed.")
                    : (widgetRow.modelData.style === "plain" ? Tr.t("Transparent") : Tr.t("Card")) + " · " + Math.round((widgetRow.modelData.scale ?? 1) * 100) + "%"
                icon: widgetRow.info?.icon ?? "extension_off"

                PillButton {
                    text: Tr.t("Remove##tirar")
                    onClicked: Widgets.remove(widgetRow.modelData.id)
                }
            }

            // Manifest options (user widgets), slightly indented
            Repeater {
                model: widgetRow.info?.options ?? []

                SettingRow {
                    id: optionRow
                    required property var modelData
                    readonly property var value: widgetRow.values[modelData.key]
                    Layout.leftMargin: 28
                    title: modelData.label
                    description: modelData.description

                    function set(v) { Widgets.setOption(widgetRow.modelData.id, optionRow.modelData.key, v); }

                    Loader {
                        sourceComponent: optionRow.modelData.type === "bool" ? boolControl
                            : optionRow.modelData.type === "choice" ? choiceControl
                            : textControl
                    }
                    Component {
                        id: boolControl
                        Toggle {
                            checked: optionRow.value === true
                            onToggled: on => optionRow.set(on)
                        }
                    }
                    Component {
                        id: choiceControl
                        Select {
                            options: optionRow.modelData.choices
                            current: String(optionRow.value)
                            onSelected: id => optionRow.set(id)
                        }
                    }
                    Component {
                        id: textControl
                        TextField {
                            implicitWidth: 260
                            text: String(optionRow.value ?? "")
                            placeholder: String(optionRow.modelData.default ?? "")
                            onAccepted: t => {
                                if (optionRow.modelData.type !== "number") {
                                    optionRow.set(t);
                                    return;
                                }
                                let n = Number(t.replace(",", "."));
                                if (isNaN(n))
                                    return;
                                if (optionRow.modelData.min !== undefined)
                                    n = Math.max(optionRow.modelData.min, n);
                                if (optionRow.modelData.max !== undefined)
                                    n = Math.min(optionRow.modelData.max, n);
                                optionRow.set(n);
                            }
                        }
                    }
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Your widgets") }

    SettingRow {
        title: Widgets.userList.length === 0 ? Tr.t("None installed")
            : Widgets.userList.length === 1 ? Tr.t("1 installed") : Widgets.userList.length + Tr.t(" installed")
        description: Tr.t("Each widget is a folder in ~/.local/share/shadow-kde/widgets with a manifest.json and a Widget.qml. After copying or changing one, press \"Rescan\".")
        icon: "extension"

        Row {
            spacing: 6
            PillButton {
                text: Tr.t("Open folder")
                onClicked: Run.cmd(["mkdir", "-p", Widgets.userDir], () => Apps.run(["xdg-open", Widgets.userDir]))
            }
            PillButton {
                text: Tr.t("Rescan")
                onClicked: Widgets.reload()
            }
            PillButton {
                text: Tr.t("Install the examples")
                onClicked: Run.cmd([Quickshell.shellPath("scripts/widgets.py"), "exemplos", Quickshell.shellPath("examples/widgets")], () => Widgets.reload())
            }
        }
    }

    // Install from a .zip, and the installed ones (with Export and Remove; broken ones show why)
    ExtensionManager {}

    SettingRow {
        title: Tr.t("Make a widget")
        description: Tr.t("The guide explains the format, what a widget can use and how to connect it to other apps, with examples.")
        icon: "menu_book"

        PillButton {
            text: Tr.t("Open the guide")
            onClicked: Apps.run(["xdg-open", Quickshell.shellPath("WIDGETS.md")])
        }
    }

    component PillButton: Rectangle {
        id: pill

        property string text: ""
        property bool accent: false
        signal clicked

        implicitWidth: label.implicitWidth + 28
        implicitHeight: 32
        radius: height / 2
        color: accent ? Theme.accent : pillMouse.containsMouse ? Theme.buttonHover : Theme.button
        scale: pillMouse.pressed ? 0.95 : 1

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animFast }
        }

        Text {
            id: label
            anchors.centerIn: parent
            text: pill.text
            color: pill.accent ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall + 1
            font.weight: Font.Bold
        }

        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
