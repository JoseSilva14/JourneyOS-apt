import QtQuick
import qs

// Slider 0–1: drag, click or turn the mouse wheel.
Item {
    id: root

    property real value: 0
    property real step: 0.05
    signal moved(real value)

    implicitWidth: 200
    implicitHeight: 20

    function set(v) { moved(Math.max(0, Math.min(1, v))); }

    Rectangle {
        id: track
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width
        height: 6
        radius: 3
        color: Theme.buttonHover

        Rectangle {
            width: Math.max(height, parent.width * root.value)
            height: parent.height
            radius: parent.radius
            color: Theme.accent

            Behavior on width {
                enabled: !mouse.pressed
                NumberAnimation { duration: Theme.animFast }
            }
        }
    }

    Rectangle {
        anchors.verticalCenter: parent.verticalCenter
        x: Math.max(0, Math.min(parent.width - width, parent.width * root.value - width / 2))
        width: mouse.containsMouse || mouse.pressed ? 16 : 12
        height: width
        radius: width / 2
        color: Theme.accent
        border.width: 2
        border.color: Theme.surfaceCard

        Behavior on width {
            NumberAnimation { duration: Theme.animFast }
        }
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        preventStealing: true
        onPressed: m => root.set(m.x / width)
        onPositionChanged: m => { if (pressed) root.set(m.x / width); }
        onWheel: w => root.set(root.value + (w.angleDelta.y > 0 ? root.step : -root.step))
    }
}
