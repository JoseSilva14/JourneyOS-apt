import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// About tab: the system, the computer and updates.
RowLayout {
    id: root

    spacing: Theme.gap

    function gib(v) { return v.toLocaleString(Tr.locale, "f", 1) + " GiB"; }

    // System
    Tile {
        Layout.fillHeight: true
        Layout.preferredWidth: 300

        ColumnLayout {
            anchors.fill: parent
            spacing: 6

            Item { Layout.fillHeight: true }

            IconImage {
                Layout.alignment: Qt.AlignHCenter
                implicitSize: 84
                source: Theme.logo
            }
            // fillWidth + wrap/elide: a long name must not widen the column (it pushed the
            // updates box out of the card)
            Text {
                Layout.fillWidth: true
                Layout.topMargin: 8
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.Wrap
                maximumLineCount: 2
                elide: Text.ElideRight
                text: SystemInfo.os
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontLarge
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideRight
                text: SystemInfo.desktop
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }

            Item { Layout.fillHeight: true }

            // Updates
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 54
                radius: Theme.radius
                color: Theme.button

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 8
                    spacing: 10

                    MIcon {
                        icon: "system_update"
                        size: 20
                        color: SystemInfo.updates > 0 ? Theme.text : Theme.subtext
                    }
                    Text {
                        Layout.fillWidth: true
                        text: SystemInfo.updates < 0 ? Tr.t("Checking…")
                            : SystemInfo.updates === 0 ? Tr.t("System up to date")
                            : SystemInfo.updates === 1 ? Tr.t("1 update")
                            : SystemInfo.updates + Tr.t(" updates")
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.DemiBold
                    }
                    Rectangle {
                        visible: SystemInfo.updates > 0
                        implicitWidth: upText.implicitWidth + 22
                        implicitHeight: 32
                        radius: height / 2
                        color: Theme.accent
                        scale: upMouse.pressed ? 0.95 : 1

                        Behavior on scale {
                            NumberAnimation { duration: Theme.animFast }
                        }

                        Text {
                            id: upText
                            anchors.centerIn: parent
                            text: Tr.t("Update")
                            color: Theme.accentText
                            font.family: Theme.font
                            font.pixelSize: Theme.fontSmall
                            font.weight: Font.Bold
                        }
                        MouseArea {
                            id: upMouse
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                Dashboard.open = false;
                                SystemInfo.upgrade();
                            }
                        }
                    }
                }
            }
        }
    }

    // Computer
    Tile {
        Layout.fillWidth: true
        Layout.fillHeight: true
        title: Tr.t("This computer")
        icon: "computer"

        GridLayout {
            anchors.fill: parent
            columns: 2
            columnSpacing: 18
            rowSpacing: 0

            Info { label: Tr.t("Name"); value: SystemInfo.hostname }
            Info { label: Tr.t("User"); value: User.login }
            Info { label: Tr.t("Processor"); value: SystemInfo.cpu }
            Info { label: Tr.t("Cores"); value: SystemInfo.cores || "" }
            Info { label: Tr.t("Memory"); value: SystemInfo.memGiB ? root.gib(SystemInfo.memGiB) : "" }
            Info { label: Tr.t("Disk (/)"); value: Stats.diskTotalGiB ? root.gib(Stats.diskTotalGiB) : "" }
            Info { label: Tr.t("Graphics"); value: SystemInfo.gpu || "—" }
            Info { label: Tr.t("Screen"); value: Dashboard.screen ? Dashboard.screen.width + "×" + Dashboard.screen.height : "" }
            Info { label: "Kernel"; value: SystemInfo.kernel }
            Info { label: Tr.t("Packages"); value: SystemInfo.packages || "" }
            Info { label: Tr.t("Uptime"); value: Stats.duration(Stats.uptime) }
            Info { label: "Quickshell"; value: "0.3" }
        }
    }

    component Info: ColumnLayout {
        property string label: ""
        property var value: ""

        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.preferredWidth: 1
        spacing: 1

        Text {
            text: parent.label
            color: Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
        Text {
            Layout.fillWidth: true
            text: String(parent.value)
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.DemiBold
        }
    }
}
