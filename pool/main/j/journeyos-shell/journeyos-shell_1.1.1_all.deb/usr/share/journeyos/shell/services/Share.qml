pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Share on the local network: dropping a file on the pill (or Tr.t("Share on the local
// network") in the Dolphin menu, or the launcher command) serves it via scripts/share.py at an
// address with a random part, with a QR code for the phone, for 15 min. One at a time: sharing
// another replaces the previous one. The pill opens on the Share tab when it is ready.
Singleton {
    id: root

    readonly property int minutes: 15
    property string path: ""
    property bool active: false        // ready to serve
    property bool starting: false
    property string name: ""
    property string size: ""
    property string url: ""
    property string qr: ""
    property real endsAt: 0
    property int downloads: 0
    property bool restart: false       // switching files: launch the new one when the previous one exits

    signal ready

    function share(file) {
        let p = String(file);
        if (p.startsWith("file://"))
            p = decodeURIComponent(p.slice(7));
        if (!p)
            return;
        path = p;
        active = false;
        starting = true;
        downloads = 0;
        if (proc.running) {
            restart = true;
            proc.signal(15);
        } else {
            proc.running = true;
        }
    }

    function stop() {
        restart = false;
        if (proc.running)
            proc.signal(15);
        active = false;
        starting = false;
    }

    function copyUrl() {
        if (!url)
            return;
        Quickshell.execDetached(["wl-copy", "--", url]);
        Events.push({ icon: "link", title: Tr.t("Link copied"), text: url, duration: 1500 });
    }

    // Pick with the KDE dialog (launcher)
    function pick() {
        Run.cmd(["kdialog", "--title", Tr.t("Share on the local network"), "--getopenfilename", Quickshell.env("HOME")], (code, out) => {
            if (code === 0 && out.trim())
                root.share(out.trim());
        });
    }

    Process {
        id: proc
        // Language via env(1), which execs share.py (same PID, so signal(15) still reaches it):
        // binding environment to an object literal fails ("Unable to assign QJSValue to QVariantHash")
        command: ["env", "SHADOW_LANG=" + Tr.lang, Quickshell.shellPath("scripts/share.py"), root.path, String(root.minutes)]
        stdout: SplitParser {
            onRead: line => {
                let e;
                try {
                    e = JSON.parse(line);
                } catch (err) {
                    return;
                }
                if (e.event === "ready") {
                    root.name = e.name;
                    root.size = e.size;
                    root.url = e.url;
                    root.qr = e.qr;
                    root.endsAt = e.ends;
                    root.starting = false;
                    root.active = true;
                    root.ready();
                } else if (e.event === "download") {
                    root.downloads++;
                    Events.push({ icon: "download_done", title: Tr.t("Downloaded"), text: root.name + " · " + e.ip, duration: 2500 });
                } else if (e.event === "error") {
                    root.starting = false;
                    Events.push({ icon: "error", title: Tr.t("Couldn't share"), text: Tr.t(e.message), duration: 3000 });
                }
            }
        }
        onExited: {
            root.active = false;
            if (root.restart) {
                root.restart = false;
                proc.running = true;
            } else {
                root.starting = false;
            }
        }
    }

    IpcHandler {
        target: "share"
        function file(path: string): void { root.share(path); }
        function stop(): void { root.stop(); }
        function status(): string { return root.active ? root.url + " " + root.name + " " + root.downloads : ""; }
    }
}
