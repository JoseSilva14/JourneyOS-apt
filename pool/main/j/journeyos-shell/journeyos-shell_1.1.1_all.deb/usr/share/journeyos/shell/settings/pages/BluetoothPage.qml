import QtQuick
import QtQuick.Layouts
import Quickshell.Bluetooth
import qs
import qs.services
import qs.components
import qs.menus

// Bluetooth: on/off, devices (same as the bar menu), name and visibility.
Page {
    id: root

    readonly property var adapter: Bluetooth.defaultAdapter

    MenuCard {
        BluetoothMenu {
            width: parent.width
            embedded: true
        }
    }

    SectionLabel {
        visible: root.adapter !== null
        text: Tr.t("This computer")
    }

    SettingRow {
        visible: root.adapter !== null
        title: root.adapter?.name ?? ""
        description: Tr.t("Name other devices see.")
        icon: "computer"
    }

    SettingRow {
        visible: root.adapter !== null
        title: Tr.t("Visible to other devices")
        description: Tr.t("To pair from a phone or another computer.")
        icon: "visibility"

        Toggle {
            checked: root.adapter?.discoverable ?? false
            enabled: root.adapter?.enabled ?? false
            opacity: enabled ? 1 : 0.4
            onToggled: on => root.adapter.discoverable = on
        }
    }
}
