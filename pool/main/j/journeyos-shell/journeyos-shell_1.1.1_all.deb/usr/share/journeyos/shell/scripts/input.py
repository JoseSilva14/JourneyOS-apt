#!/usr/bin/env python3
"""Mice, touchpads and keyboards through KWin's D-Bus (/org/kde/KWin/InputDevice/*).

  input.py list                     → JSON [{ sys, name, pointer, touchpad, keyboard, <properties> }]
  input.py set <sys> <prop> <value> → changes a property (KWin applies and saves it)
"""

import json
import sys

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS = "org.kde.KWin"
ROOT = "/org/kde/KWin/InputDevice"
IFACE = "org.kde.KWin.InputDevice"
PROPS = ["name", "sysName", "pointer", "touchpad", "keyboard", "enabled", "pointerAcceleration",
         "pointerAccelerationProfileFlat", "naturalScroll", "leftHanded", "scrollFactor",
         "tapToClick", "disableWhileTyping", "middleEmulation", "supportsNaturalScroll",
         "supportsDisableWhileTyping", "tapFingerCount", "supportsLeftHanded"]


def main():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def call(path, iface, method, args, ret):
        res = conn.call_sync(BUS, path, iface, method, args, GLib.VariantType(ret) if ret else None,
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack() if res else None

    def devices():
        xml = call(ROOT, "org.freedesktop.DBus.Introspectable", "Introspect", None, "(s)")[0]
        node = Gio.DBusNodeInfo.new_for_xml(xml)
        return [n.path for n in node.nodes]

    if sys.argv[1:2] == ["list"]:
        out = []
        for name in devices():
            path = f"{ROOT}/{name}"
            try:
                allp = call(path, "org.freedesktop.DBus.Properties", "GetAll", GLib.Variant("(s)", (IFACE,)), "(a{sv})")[0]
            except GLib.Error:
                continue
            d = {"sys": name}
            d.update({k: allp[k] for k in PROPS if k in allp})
            out.append(d)
        print(json.dumps(out))
        return 0

    if sys.argv[1:2] == ["set"] and len(sys.argv) == 5:
        _, _, name, prop, value = sys.argv
        path = f"{ROOT}/{name}"
        current = call(path, "org.freedesktop.DBus.Properties", "Get", GLib.Variant("(ss)", (IFACE, prop)), "(v)")[0]
        # The type comes from the current value
        if isinstance(current, bool):
            v = GLib.Variant("b", value in ("true", "1"))
        elif isinstance(current, float):
            v = GLib.Variant("d", float(value))
        elif isinstance(current, int):
            v = GLib.Variant("i", int(value))
        else:
            v = GLib.Variant("s", value)
        call(path, "org.freedesktop.DBus.Properties", "Set", GLib.Variant("(ssv)", (IFACE, prop, v)), None)
        return 0

    print(__doc__, file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
