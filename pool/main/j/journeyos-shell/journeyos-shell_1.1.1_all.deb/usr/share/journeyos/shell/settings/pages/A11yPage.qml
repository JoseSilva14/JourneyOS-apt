import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Accessibility: seeing (magnifier, screen reader, larger text and cursor), motion and keyboard.
Page {
    id: root

    Component.onCompleted: {
        A11y.refresh();
        SystemLook.refresh();
    }

    SectionLabel { text: Tr.t("View") }

    SettingRow {
        title: Tr.t("Magnifier")
        description: Tr.t("Zoom in with Meta+= and out with Meta+-.")
        icon: "zoom_in"
        Toggle {
            checked: A11y.zoom
            onToggled: on => A11y.setZoom(on)
        }
    }

    SettingRow {
        title: Tr.t("Screen reader")
        description: Tr.t("Reads the screen aloud (Orca).")
        icon: "record_voice_over"
        Toggle {
            checked: A11y.screenReader
            onToggled: on => A11y.setScreenReader(on)
        }
    }

    SettingRow {
        title: Tr.t("Larger text")
        description: Tr.t("App text size (also in Appearance).")
        icon: "format_size"
        Toggle {
            checked: SystemLook.fontSize >= 12
            onToggled: on => SystemLook.setFontSize(on ? 12 : 10)
        }
    }

    SettingRow {
        title: Tr.t("Larger cursor")
        icon: "mouse"
        Toggle {
            checked: SystemLook.cursorSize >= 32
            onToggled: on => SystemLook.setCursor(SystemLook.cursorTheme, on ? 48 : 24)
        }
    }

    SectionLabel { text: Tr.t("Motion") }

    SettingRow {
        title: Tr.t("Reduce motion")
        description: Tr.t("No animations in the shell and windows.")
        icon: "motion_photos_off"
        Toggle {
            checked: A11y.reduceMotion
            onToggled: on => {
                A11y.setReduceMotion(on);
                SystemLook.setAnimationFactor(on ? 0 : 1);
            }
        }
    }

    SectionLabel { text: Tr.t("Keyboard") }

    SettingRow {
        title: Tr.t("Sticky keys")
        description: Tr.t("Ctrl, Alt, Shift and Meta stay pressed until the next key: shortcuts one key at a time.")
        icon: "keyboard"
        Toggle {
            checked: A11y.stickyKeys
            onToggled: on => A11y.setStickyKeys(on)
        }
    }
}
