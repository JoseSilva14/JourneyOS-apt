import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs
import qs.components
import qs.services

// Dock: on/off and pinned apps (order, remove, add).
Page {
    id: root

    property string query: ""
    readonly property var pinned: Config.options.dock.pinned
    readonly property var candidates: {
        const q = query.trim().toLowerCase();
        if (!q)
            return [];
        return DesktopEntries.applications.values
            .filter(e => !e.noDisplay && !pinned.includes(e.id) && e.id !== Dashboard.desktopId && e.name.toLowerCase().includes(q))
            .slice(0, 6);
    }

    function move(i, d) {
        const list = pinned.slice();
        const j = i + d;
        if (j < 0 || j >= list.length)
            return;
        [list[i], list[j]] = [list[j], list[i]];
        Config.options.dock.pinned = list;
    }

    SettingRow {
        title: Tr.t("Show the dock")
        description: Tr.t("Always visible at the bottom; maximized windows stop above it.")
        icon: "dock"

        Toggle {
            checked: Config.options.dock.enabled
            onToggled: on => Config.options.dock.enabled = on
        }
    }

    SettingRow {
        title: Tr.t("Dashboard button")
        description: Tr.t("At the start of the dock, before the apps.")
        icon: "space_dashboard"

        Toggle {
            checked: Config.options.dock.dashboard
            onToggled: on => Config.options.dock.dashboard = on
        }
    }

    SectionLabel { text: Tr.t("Pinned apps") }

    Repeater {
        model: root.pinned

        AppRow {
            required property string modelData
            required property int index
            entry: DesktopEntries.byId(modelData)
            fallback: modelData

            Row {
                spacing: 4
                SmallButton {
                    icon: "arrow_upward"
                    enabled: index > 0
                    onClicked: root.move(index, -1)
                }
                SmallButton {
                    icon: "arrow_downward"
                    enabled: index < root.pinned.length - 1
                    onClicked: root.move(index, 1)
                }
                SmallButton {
                    icon: "remove_circle_outline"
                    onClicked: DockApps.setPinned(modelData, false)
                }
            }
        }
    }

    SectionLabel { text: Tr.t("Add an app") }

    TextField {
        Layout.fillWidth: true
        placeholder: Tr.t("Search apps to pin")
        onTextChanged: root.query = text
    }

    Repeater {
        model: root.candidates

        AppRow {
            required property var modelData
            entry: modelData

            SmallButton {
                icon: "add"
                onClicked: DockApps.setPinned(modelData.id, true)
            }
        }
    }

    component AppRow: Rectangle {
        id: row

        property var entry: null
        property string fallback: ""
        default property alias actions: slot.data

        Layout.fillWidth: true
        implicitHeight: 52
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 10
            spacing: 12

            IconImage {
                implicitSize: 30
                source: !row.entry?.icon ? "" : row.entry.icon.startsWith("/") ? "file://" + row.entry.icon : Quickshell.iconPath(row.entry.icon, true)
            }
            Text {
                Layout.fillWidth: true
                text: row.entry?.name ?? (row.fallback + Tr.t(" (not installed)"))
                elide: Text.ElideRight
                color: row.entry ? Theme.text : Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
            Item {
                id: slot
                implicitWidth: childrenRect.width
                implicitHeight: childrenRect.height
            }
        }
    }

    component SmallButton: Rectangle {
        id: button

        property string icon: ""
        signal clicked

        width: 32
        height: 32
        radius: 16
        color: buttonMouse.containsMouse ? Theme.buttonHover : Theme.button
        opacity: enabled ? 1 : 0.3

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        MIcon {
            anchors.centerIn: parent
            icon: button.icon
            size: 17
        }

        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            enabled: button.enabled
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }
}
