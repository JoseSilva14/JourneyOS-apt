pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Clipboard history (scripts/clipboard.py): the watcher runs while the shell runs; the
// list is read from the file (which the watcher writes). Meta+V opens the window.
Singleton {
    id: root

    property var items: []              // [{ id, text, pinned, time }]
    property bool open: false
    property var screen: null

    readonly property string script: Quickshell.shellPath("scripts/clipboard.py")

    function toggle(screen) {
        if (open) {
            open = false;
            return;
        }
        root.screen = screen ?? Windows.activeScreen;
        open = true;
    }

    onOpenChanged: {
        if (open) {
            Launcher.open = false;
            QuickPanel.open = false;
        }
    }

    // Copies (it becomes the most recent) and closes
    function copy(item) {
        open = false;
        Quickshell.execDetached(["wl-copy", "--", item.text]);
    }

    function pin(item) { Run.cmd([script, item.pinned ? "unpin" : "pin", item.id]); }
    function remove(item) { Run.cmd([script, "delete", item.id]); }
    function clear() { Run.cmd([script, "clear"]); }

    Process {
        id: watcher
        running: true
        command: [root.script, "watch"]
        onExited: restart.start()
    }

    Timer {
        id: restart
        interval: 3000
        onTriggered: watcher.running = true
    }

    FileView {
        path: Quickshell.env("HOME") + "/.local/state/shadow-kde/clipboard.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                const list = JSON.parse(text()).items ?? [];
                // Pinned first
                root.items = [...list.filter(i => i.pinned), ...list.filter(i => !i.pinned)];
            } catch (e) {
            }
        }
    }

    IpcHandler {
        target: "clipboard"
        function toggle(): void { root.toggle(null); }
        function count(): int { return root.items.length; }
    }
}
