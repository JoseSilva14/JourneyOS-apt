import QtQuick
import Quickshell
import Quickshell.Services.Pipewire
import Quickshell.Bluetooth
import qs
import qs.components
import qs.services

// Right side of the bar: volume, clock, Bluetooth, network, notifications and power.
Row {
    id: root

    spacing: 2

    readonly property PwNode sink: Pipewire.defaultAudioSink
    readonly property bool muted: sink?.audio?.muted ?? false
    readonly property real volume: sink?.audio?.volume ?? 0
    readonly property var adapter: Bluetooth.defaultAdapter

    PwObjectTracker {
        objects: [root.sink]
    }

    Tray {
        anchors.verticalCenter: parent.verticalCenter
    }

    // Focus mode active: clicking opens its settings
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        visible: Focus.current !== null
        icon: Focus.current?.icon ?? ""
        onClicked: SettingsApp.show("focus")
    }

    // Keyboard layout (only with more than one): clicking switches to the next
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        visible: Keyboard.multiple
        label: (Keyboard.layout?.short ?? "").toUpperCase()
        onClicked: Keyboard.next()
    }

    // Docker: containers running, and how many failed (in red); opens the list
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        visible: Dev.showInBar
        icon: "view_in_ar"
        label: Dev.failedList.length ? Dev.running + " · " + Dev.failedList.length + " ✕" : String(Dev.running)
        iconColor: Dev.failedList.length ? Theme.privacyMic : Dev.running ? Theme.text : Theme.dim
        color: BarMenu.open === "docker" || hovered ? Theme.button : "transparent"
        onClicked: BarMenu.toggle("docker", QsWindow.window?.screen ?? null)
    }

    // Claude plan limits (5 hours · week): opens the details; red from 90%
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        visible: ClaudeUsage.showInBar
        icon: "auto_awesome"
        label: "5h " + Math.round(ClaudeUsage.fivePct) + "% · 7d " + Math.round(ClaudeUsage.weekPct) + "%"
        iconColor: Math.max(ClaudeUsage.fivePct, ClaudeUsage.weekPct) >= 90 ? Theme.privacyMic
            : ClaudeUsage.stale ? Theme.dim : Theme.text
        color: BarMenu.open === "claude" || hovered ? Theme.button : "transparent"
        onClicked: BarMenu.toggle("claude", QsWindow.window?.screen ?? null)
    }

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: root.muted || root.volume === 0 ? "volume_off" : root.volume < 0.5 ? "volume_down" : "volume_up"
        label: Math.round(root.volume * 100) + "%"
        iconColor: root.muted ? Theme.dim : Theme.text
        visible: root.sink !== null
        color: BarMenu.open === "sound" || hovered ? Theme.button : "transparent"
        // Click: sound menu; right click: mute; wheel: volume
        onClicked: m => {
            if (m.button === Qt.RightButton) {
                if (root.sink?.audio)
                    root.sink.audio.muted = !root.sink.audio.muted;
            } else {
                BarMenu.toggle("sound", QsWindow.window?.screen ?? null);
            }
        }
        onWheel: w => {
            if (!root.sink?.audio)
                return;
            const step = w.angleDelta.y > 0 ? 0.05 : -0.05;
            root.sink.audio.volume = Math.max(0, Math.min(1, root.sink.audio.volume + step));
        }
    }

    // Clock: opens the dashboard
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        label: DateTime.time(clock.date)
        color: Dashboard.open || hovered ? Theme.button : "transparent"
        onClicked: Dashboard.toggle("home", QsWindow.window?.screen ?? null)
    }

    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: !root.adapter?.enabled ? "bluetooth_disabled"
            : root.adapter.devices.values.some(d => d.connected) ? "bluetooth_connected"
            : "bluetooth"
        iconColor: root.adapter?.enabled ? Theme.text : Theme.dim
        color: BarMenu.open === "bluetooth" || hovered ? Theme.button : "transparent"
        onClicked: BarMenu.toggle("bluetooth", QsWindow.window?.screen ?? null)
    }

    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: Net.icon
        iconColor: Net.kind === "none" ? Theme.dim : Theme.text
        color: BarMenu.open === "network" || hovered ? Theme.button : "transparent"
        onClicked: BarMenu.toggle("network", QsWindow.window?.screen ?? null)
    }

    // Battery (laptops): level and %; charging, or red when low. Opens the quick panel (power mode)
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        visible: Power.hasBattery
        icon: Power.batteryIcon
        label: Power.batteryText
        iconColor: Power.batteryLow ? Theme.privacyMic : Power.charging ? Theme.accent : Theme.text
        color: QuickPanel.open || hovered ? Theme.button : "transparent"
        onClicked: QuickPanel.toggle(QsWindow.window?.screen ?? null)
    }

    // Quick panel (Keep awake, captures, volume, music, quick toggles, power mode)
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: "tune"
        color: QuickPanel.open || hovered ? Theme.button : "transparent"
        onClicked: QuickPanel.toggle(QsWindow.window?.screen ?? null)
    }

    // Notifications: opens the centre; dot = unread
    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: Notifs.dnd ? "notifications_off" : "notifications"
        iconColor: Notifs.dnd ? Theme.dim : Theme.text
        color: Notifs.centerOpen || hovered ? Theme.button : "transparent"
        onClicked: Notifs.toggleCenter(QsWindow.window?.screen ?? null)

        Rectangle {
            x: parent.width / 2 + 3
            y: 3
            width: 7
            height: 7
            radius: 3.5
            color: Theme.accent
            border.width: 1.5
            border.color: Theme.bg
            visible: Notifs.unread > 0 && !Notifs.dnd
        }
    }

    BarButton {
        anchors.verticalCenter: parent.verticalCenter
        icon: "power_settings_new"
        // Shell exit screen (lock, suspend, log out, restart, shut down)
        onClicked: Session.prompt("all")
    }
}
