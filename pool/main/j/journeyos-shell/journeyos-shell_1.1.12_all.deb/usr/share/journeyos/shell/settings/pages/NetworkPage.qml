import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs
import qs.components
import qs.services
import qs.menus

// Network: Wi-Fi and wired (same as the bar menu), details of the active connection,
// saved connections (forget) and VPNs (connect/disconnect), via nmcli.
Page {
    id: root

    property var details: ({})          // { connection, type, ip4, gateway, dns, ip6, mac }
    property var saved: []              // [{ name, uuid, type, active }]
    property string confirmDelete: ""   // uuid awaiting the second click
    property string confirmRule: ""     // firewall rule awaiting the second click

    Component.onCompleted: Firewall.refresh()

    // "5353/udp" → "Port 5353 · UDP", "6000:6010/tcp" → "Ports 6000–6010 · TCP", "80" → "Port 80 · TCP + UDP"
    function ruleTitle(spec) {
        // "from 192.168.0.0/16 port 5353 proto udp": answers from a source port, only from those addresses
        const f = /^from (\S+) port (\d+) proto (tcp|udp)$/.exec(spec);
        if (f)
            return Tr.t("From port ") + f[2] + " · " + f[3].toUpperCase() + " · " + f[1];
        const m = /^(\d+)(?::(\d+))?(?:\/(tcp|udp))?$/.exec(spec);
        if (!m)
            return spec;
        const ports = m[2] ? Tr.t("Ports") + " " + m[1] + "–" + m[2] : Tr.t("Port") + " " + m[1];
        return ports + " · " + (m[3] ? m[3].toUpperCase() : "TCP + UDP");
    }

    // nmcli escapes ":" inside values as "\:"
    function fields(line) {
        return line.replace(/\\:/g, "\u0001").split(":").map(f => f.replace(/\u0001/g, ":"));
    }

    readonly property string script: `
dev=$(nmcli -t -f DEVICE,STATE device | awk -F: '$2=="connected"{print $1; exit}')
[ -n "$dev" ] && nmcli -t -f GENERAL.CONNECTION,GENERAL.TYPE,IP4.ADDRESS,IP4.GATEWAY,IP4.DNS,IP6.ADDRESS,GENERAL.HWADDR device show "$dev"
echo "--"
nmcli -t -f NAME,UUID,TYPE,ACTIVE connection show
`

    function refresh() {
        if (!reader.running)
            reader.running = true;
    }

    function nm(args) {
        Quickshell.execDetached(["nmcli", ...args]);
        later.restart();
    }

    Process {
        id: reader
        command: ["sh", "-c", root.script]
        stdout: StdioCollector {
            onStreamFinished: {
                const [head, tail] = text.split("\n--\n");
                const d = { dns: [] };
                for (const line of (head ?? "").split("\n")) {
                    const i = line.indexOf(":");
                    if (i < 0)
                        continue;
                    const key = line.slice(0, i), value = line.slice(i + 1).replace(/\\:/g, ":");
                    if (key === "GENERAL.CONNECTION") d.connection = value;
                    else if (key === "GENERAL.TYPE") d.type = value;
                    else if (key.startsWith("IP4.ADDRESS") && !d.ip4) d.ip4 = value;
                    else if (key === "IP4.GATEWAY") d.gateway = value;
                    else if (key.startsWith("IP4.DNS")) d.dns.push(value);
                    else if (key.startsWith("IP6.ADDRESS") && !d.ip6) d.ip6 = value;
                    else if (key === "GENERAL.HWADDR") d.mac = value;
                }
                root.details = d;
                // Only those relevant to the user (no lo, docker…)
                root.saved = (tail ?? "").trim().split("\n").filter(l => l).map(l => {
                    const f = root.fields(l);
                    return { name: f[0], uuid: f[1], type: f[2], active: f[3] === "yes" };
                }).filter(c => /wireless|ethernet|vpn|wireguard/.test(c.type));
            }
        }
    }

    Timer {
        running: true
        interval: 5000
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // Re-read after a command
    Timer {
        id: later
        interval: 1500
        onTriggered: root.refresh()
    }

    function typeIcon(t) {
        return /wireless/.test(t) ? "wifi" : /ethernet/.test(t) ? "lan" : "vpn_key";
    }
    function typeName(t) {
        return /wireless/.test(t) ? "Wi-Fi" : /ethernet/.test(t) ? "Cabo" : "VPN";
    }

    MenuCard {
        NetworkMenu {
            width: parent.width
            embedded: true
            listHeight: 380
        }
    }

    // --- Active connection details ---
    SectionLabel {
        visible: !!root.details.connection
        text: Tr.t("Active connection: ") + (root.details.connection ?? "")
    }

    GridLayout {
        visible: !!root.details.connection
        Layout.fillWidth: true
        columns: 2
        rowSpacing: 8
        columnSpacing: 8

        Detail { label: Tr.t("IPv4 address"); value: root.details.ip4 ?? "—" }
        Detail { label: "Gateway"; value: root.details.gateway || "—" }
        Detail { label: "DNS"; value: (root.details.dns ?? []).join(", ") || "—" }
        Detail { label: Tr.t("Hardware address (MAC)"); value: root.details.mac ?? "—" }
        Detail { label: Tr.t("IPv6 address"); value: root.details.ip6 ?? "—"; Layout.columnSpan: 2 }
    }

    // --- VPN ---
    SectionLabel {
        visible: root.saved.some(c => /vpn|wireguard/.test(c.type))
        text: "VPN"
    }

    Repeater {
        model: root.saved.filter(c => /vpn|wireguard/.test(c.type))

        SettingRow {
            required property var modelData
            title: modelData.name
            description: modelData.active ? Tr.t("Connected") : Tr.t("Off##f")
            icon: "vpn_key"

            Toggle {
                checked: modelData.active
                onToggled: on => root.nm(["connection", on ? "up" : "down", "uuid", modelData.uuid])
            }
        }
    }

    // --- Saved connections ---
    SectionLabel {
        visible: root.saved.length > 0
        text: Tr.t("Saved connections")
    }

    Repeater {
        model: root.saved.filter(c => !/vpn|wireguard/.test(c.type))

        SettingRow {
            id: savedRow
            required property var modelData
            readonly property bool confirming: root.confirmDelete === modelData.uuid

            title: modelData.name
            description: root.typeName(modelData.type) + (modelData.active ? Tr.t(" · in use") : "")
            icon: root.typeIcon(modelData.type)

            // Forgetting needs a second click
            Rectangle {
                implicitWidth: forgetText.implicitWidth + 28
                implicitHeight: 32
                radius: height / 2
                color: savedRow.confirming ? Theme.privacyMic
                    : forgetMouse.containsMouse ? Theme.buttonHover : Theme.button

                Behavior on color {
                    ColorAnimation { duration: Theme.animFast }
                }

                Text {
                    id: forgetText
                    anchors.centerIn: parent
                    text: savedRow.confirming ? Tr.t("Confirm") : Tr.t("Forget")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }

                MouseArea {
                    id: forgetMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        const uuid = modelData.uuid;
                        if (root.confirmDelete === uuid) {
                            root.confirmDelete = "";
                            root.nm(["connection", "delete", "uuid", uuid]);
                        } else {
                            root.confirmDelete = uuid;
                            confirmTimeout.restart();
                        }
                    }
                }
            }
        }
    }

    // --- Firewall (ufw) ---
    SectionLabel {
        visible: Firewall.loaded && Firewall.installed
        text: Tr.t("Firewall")
    }

    SettingRow {
        visible: Firewall.loaded && Firewall.installed
        title: Tr.t("Firewall")
        description: Firewall.message || (Firewall.enabled
            ? Tr.t("Blocks connections from other devices that this computer did not ask for")
            : Tr.t("Off: anything listening on this computer can be reached from the network"))
        icon: Firewall.enabled ? "shield" : "remove_moderator"

        Toggle {
            checked: Firewall.enabled
            enabled: !Firewall.busy
            onToggled: on => Firewall.setEnabled(on)
        }
    }

    Repeater {
        model: Firewall.loaded && Firewall.installed ? Firewall.rules : []

        SettingRow {
            id: ruleRow
            required property var modelData
            readonly property string key: modelData.args.join(" ")
            readonly property bool confirming: root.confirmRule === key

            title: root.ruleTitle(modelData.spec)
            description: (modelData.action === "allow" ? Tr.t("Open to the network") : modelData.action)
                + (modelData.comment ? " · " + modelData.comment : "")
            icon: "lan"

            PillButton {
                text: ruleRow.confirming ? Tr.t("Close it? Click again") : Tr.t("Close")
                danger: ruleRow.confirming
                enabled: !Firewall.busy
                onClicked: {
                    if (ruleRow.confirming) {
                        root.confirmRule = "";
                        Firewall.remove(ruleRow.modelData);
                    } else {
                        root.confirmRule = ruleRow.key;
                        confirmTimeout.restart();
                    }
                }
            }
        }
    }

    SettingRow {
        visible: Firewall.loaded && Firewall.installed
        title: Tr.t("Open a port")
        description: Tr.t("For a server on this computer (a game, development, sharing files)")
        icon: "add_circle"

        RowLayout {
            spacing: 8

            TextField {
                id: portField
                implicitWidth: 120
                placeholder: "8000"
                acceptOnBlur: false
                onAccepted: t => openButton.clicked()
            }
            Select {
                id: protoSelect
                implicitWidth: 130
                options: [{ id: "tcp", label: "TCP" }, { id: "udp", label: "UDP" }, { id: "any", label: "TCP + UDP" }]
                current: "tcp"
                onSelected: id => current = id
            }
            PillButton {
                id: openButton
                readonly property bool valid: /^\d{1,5}(:\d{1,5})?$/.test(portField.text.trim())
                    && !(portField.text.includes(":") && protoSelect.current === "any")
                text: Tr.t("Open")
                accent: true
                enabled: valid && !Firewall.busy
                onClicked: {
                    if (!valid)
                        return;
                    Firewall.allow(portField.text.trim(), protoSelect.current, "");
                    portField.text = "";
                }
            }
        }
    }

    Timer {
        id: confirmTimeout
        interval: 4000
        onTriggered: {
            root.confirmDelete = "";
            root.confirmRule = "";
        }
    }

    component Detail: Rectangle {
        id: detail

        property string label: ""
        property string value: ""

        Layout.fillWidth: true
        implicitHeight: 56
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        Column {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: 14
            anchors.rightMargin: 14
            spacing: 2

            Text {
                text: detail.label
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Text {
                width: parent.width
                text: detail.value
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
        }
    }
}
