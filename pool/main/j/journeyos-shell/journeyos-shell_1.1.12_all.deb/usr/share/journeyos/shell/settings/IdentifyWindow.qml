import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.services

// Settings → Screen → "Identify": each screen's name and size in the middle of it, for 3 seconds,
// to tell which box in the arrangement is which screen.
PanelWindow {
    id: root

    required property ShellScreen modelScreen
    readonly property var output: Display.outputs.find(o => o.name === modelScreen.name) ?? null

    visible: Display.identifying
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore
    implicitWidth: 420
    implicitHeight: 190
    WlrLayershell.namespace: "shadow-identify"
    WlrLayershell.layer: WlrLayer.Overlay

    Rectangle {
        anchors.fill: parent
        radius: Theme.radiusCard + 6
        color: Theme.surface
        border.width: 2
        border.color: root.output && root.output.priority === 1 ? Theme.accent : Theme.surfaceBorder

        ColumnLayout {
            anchors.centerIn: parent
            spacing: 6

            Text {
                Layout.alignment: Qt.AlignHCenter
                text: root.modelScreen.name
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 44
                font.weight: Font.Bold
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: root.modelScreen.width + " × " + root.modelScreen.height
                    + (root.output && root.output.priority === 1 ? Tr.t(" · primary") : "")
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
            }
        }
    }
}
