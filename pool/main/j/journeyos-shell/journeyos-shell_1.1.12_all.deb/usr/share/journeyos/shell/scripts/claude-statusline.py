#!/usr/bin/env python3
"""Claude Code status line for JourneyOS: saves the plan's usage limits for the shell's meter and
prints a short status line.

Claude Code runs this after each answer with a JSON on stdin; for Pro/Max plans it has
rate_limits.five_hour / seven_day = {"used_percentage": 0-100, "resets_at": epoch seconds}
(https://code.claude.com/docs/en/statusline). They are saved to ~/.cache/journeyos/claude-usage.json.

If the user already had a status line, its command is kept in ~/.config/journeyos/claude-statusline-next
and gets the same JSON: what it prints is shown instead of ours.
"""
import json
import os
import subprocess
import sys
import time

HOME = os.path.expanduser("~")
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.join(HOME, ".cache")), "journeyos", "claude-usage.json")
NEXT = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.join(HOME, ".config")), "journeyos", "claude-statusline-next")


def save(data):
    limits = data.get("rate_limits") or {}
    windows = {}
    for name in ("five_hour", "seven_day"):
        w = limits.get(name)
        if isinstance(w, dict) and w.get("used_percentage") is not None:
            windows[name] = {"used": float(w["used_percentage"]), "resets_at": int(w.get("resets_at") or 0)}
    if not windows:
        return  # not a Pro/Max plan, or before the first answer: keep what was there
    try:
        with open(CACHE, encoding="utf-8") as f:
            old = json.load(f)
    except (OSError, ValueError):
        old = {}
    out = {**{k: old[k] for k in ("five_hour", "seven_day") if k in old}, **windows,
           "updated": int(time.time()), "model": (data.get("model") or {}).get("display_name", "")}
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    tmp = CACHE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(out, f)
    os.replace(tmp, CACHE)


def line(data):
    parts = []
    model = (data.get("model") or {}).get("display_name")
    if model:
        parts.append(model)
    cwd = (data.get("workspace") or {}).get("current_dir") or data.get("cwd") or ""
    if cwd:
        parts.append(cwd.replace(HOME, "~", 1) if cwd.startswith(HOME) else cwd)
    limits = data.get("rate_limits") or {}
    for name, label in (("five_hour", "5h"), ("seven_day", "7d")):
        w = limits.get(name)
        if isinstance(w, dict) and w.get("used_percentage") is not None:
            parts.append(f"{label} {round(float(w['used_percentage']))}%")
    return " · ".join(parts)


def main():
    raw = sys.stdin.read()
    try:
        data = json.loads(raw)
    except ValueError:
        data = {}
    try:
        save(data)
    except OSError:
        pass
    try:
        with open(NEXT, encoding="utf-8") as f:
            nxt = f.read().strip()
    except OSError:
        nxt = ""
    if nxt:
        try:
            r = subprocess.run(nxt, shell=True, input=raw, capture_output=True, text=True, timeout=5)
            sys.stdout.write(r.stdout)
            return
        except (subprocess.SubprocessError, OSError):
            pass
    print(line(data))


if __name__ == "__main__":
    main()
