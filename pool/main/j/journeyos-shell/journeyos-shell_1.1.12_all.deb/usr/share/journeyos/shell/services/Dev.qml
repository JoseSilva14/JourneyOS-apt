pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Dev UI (Settings → Development, config.json dev.enabled): the dashboard's
// Dev tab with the ports in use and the Docker containers (scripts/dev.py).
// Ports are only read with the tab open (the tab calls refresh() every 3 s).
// The bar's Docker indicator (dev.dockerBar) keeps the containers up to date in the background:
// it listens to "docker events" and reads the list again only when something changes (and every
// minute, in case an event is missed). A container that fails gets a notification.
Singleton {
    id: root

    readonly property bool enabled: Config.options.dev.enabled
    readonly property string script: Quickshell.shellPath("scripts/dev.py")

    property var ports: []
    property var containers: []
    property string dockerState: ""     // ok | missing | permission | down
    property bool loaded: false
    property bool busy: false
    // Actions in progress, by container id (so the button shows it is working)
    property var pending: ({})

    readonly property int running: containers.filter(c => c.state === "running").length
    readonly property var failedList: containers.filter(c => c.failed)
    readonly property bool barEnabled: Config.options.dev.dockerBar
    readonly property bool showInBar: barEnabled && dockerState === "ok" && containers.length > 0
    // When each container was last reported as failed: a notification when one starts failing, and
    // for one that keeps failing (restart loop) at most every 10 minutes
    property var reported: ({})
    property bool containersLoaded: false

    function refresh() {
        if (busy)
            return;
        busy = true;
        Run.cmd([script, "estado"], (code, out) => {
            root.busy = false;
            if (code !== 0)
                return;
            try {
                const d = JSON.parse(out);
                root.ports = d.ports;
                root.setContainers(d.docker);
                root.loaded = true;
            } catch (e) {
                console.warn("dev.py:", e);
            }
        }, { SHADOW_LANG: Tr.lang });
    }

    // Only the containers (bar indicator)
    function refreshContainers() {
        if (lister.running)
            return;
        lister.running = true;
    }

    function setContainers(d) {
        containers = d.containers;
        dockerState = d.state;
        const now = Date.now();
        const seen = {};
        for (const c of containers) {
            if (reported[c.name] !== undefined)
                seen[c.name] = reported[c.name];       // forgotten only when the container is gone
            if (!c.failed || now - (reported[c.name] ?? 0) < 600000)
                continue;
            seen[c.name] = now;
            if (containersLoaded && barEnabled)
                Run.cmd(["notify-send", "--app-name=Docker", "--icon=dialog-warning", Tr.t("Container failed: ") + c.name,
                    c.status + (c.image ? " · " + c.image : "")]);
        }
        reported = seen;
        containersLoaded = true;
        watch();
    }

    // Starts listening to docker events (when the indicator is on and docker answers)
    function watch() {
        if (barEnabled && dockerState === "ok" && !events.running)
            events.running = true;
    }

    Process {
        id: lister
        command: ["env", "SHADOW_LANG=" + Tr.lang, root.script, "containers"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    root.setContainers(JSON.parse(text));
                } catch (e) {
                    console.warn("dev.py containers:", e);
                }
            }
        }
    }

    // docker events: each line is a change (start, die, health_status…); several together read once
    Process {
        id: events
        command: [root.script, "events"]
        stdout: SplitParser {
            onRead: settle.restart()
        }
        // docker stopped (or restarted): read the state again and listen again later
        onExited: {
            root.refreshContainers();
            if (root.barEnabled)
                retry.restart();
        }
    }
    Timer {
        id: settle
        interval: 400
        onTriggered: root.refreshContainers()
    }
    Timer {
        id: retry
        interval: 30000
        onTriggered: root.refreshContainers()
    }
    // Also notices docker being installed or started
    Timer {
        running: root.barEnabled
        interval: 60000
        repeat: true
        onTriggered: root.refreshContainers()
    }
    Component.onCompleted: if (barEnabled) refreshContainers()
    onBarEnabledChanged: {
        if (barEnabled)
            refreshContainers();
        else
            events.running = false;
    }

    function setPending(id, on) {
        const p = Object.assign({}, pending);
        if (on)
            p[id] = true;
        else
            delete p[id];
        pending = p;
    }

    // start | stop | restart
    function container(action, c) {
        setPending(c.id, true);
        Run.cmd([script, "docker", action, c.id], (code, out, err) => {
            root.setPending(c.id, false);
            if (code !== 0)
                Events.push({ icon: "error", title: "Docker: " + c.name, text: (err || "falhou").trim().split("\n").pop(), duration: 4000 });
            root.refresh();
        });
    }

    function logs(c) {
        Apps.run(["konsole", "-e", "sh", "-c", 'docker logs -f --tail 200 "$0" 2>&1 || sg docker -c "docker logs -f --tail 200 $0"', c.name]);
    }

    function shell(c) {
        Apps.run(["konsole", "-e", "sh", "-c", 'docker exec -it "$0" sh 2>/dev/null || sg docker -c "docker exec -it $0 sh"', c.name]);
    }

    function kill(p) {
        Run.cmd([script, "kill", String(p.pid)], (code, out, err) => {
            Events.push(code === 0 ? { icon: "stop_circle", title: Tr.t("Process stopped"), text: p.process + Tr.t(" · port ") + p.port, duration: 2000 }
                : { icon: "error", title: Tr.t("Couldn't stop it"), text: err.trim(), duration: 3000 });
            Qt.callLater(root.refresh);
        });
    }

    function openUrl(url) {
        Apps.run(["xdg-open", url]);
    }

    function copy(text) {
        Quickshell.execDetached(["wl-copy", "--", text]);
        Events.push({ icon: "content_copy", title: Tr.t("Copied"), text, duration: 1500 });
    }

    IpcHandler {
        target: "dev"
        function enable(on: bool): void { Config.options.dev.enabled = on; }
        function refresh(): void { root.refresh(); }
        function status(): string {
            return "docker " + root.dockerState + " · " + root.ports.length + Tr.t(" ports · ") + root.containers.length + Tr.t(" containers");
        }
    }
}
