import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services
import "../settings/pages"

// Phone (KDE Connect) as its own app: a normal window (KWin decoration, shows in the dock as
// "Phone") with the paired phones, pairing requests and the ones nearby. The same page the
// Welcome uses (settings/pages/PhonePage); it is no longer in Settings.
FloatingWindow {
    id: root

    title: Tr.t("Phone")
    visible: Phone.open
    implicitWidth: 620
    implicitHeight: Math.min(680, (Quickshell.screens[0]?.height ?? 800)
        - Theme.barZone - (Config.options.dock.enabled ? Theme.dockHeight + Theme.gap : 0)
        - Theme.windowTitleHeight - Theme.gap * 2)
    color: Theme.bg

    onVisibleChanged: if (!visible) Phone.open = false

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Phone.open = false

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            anchors.rightMargin: 6
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                Layout.rightMargin: 14
                spacing: 12

                Image {
                    source: Quickshell.shellPath("assets/icons/telemovel.svg")
                    sourceSize: Qt.size(40, 40)
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: Tr.t("Phone")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontLarge
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.fillWidth: true
                        text: Phone.phone ? Phone.phone.name + Tr.t(" · connected") : Tr.t("Install KDE Connect on the phone and pair it here.")
                        color: Theme.dim
                        elide: Text.ElideRight
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            PhonePage {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }
}
