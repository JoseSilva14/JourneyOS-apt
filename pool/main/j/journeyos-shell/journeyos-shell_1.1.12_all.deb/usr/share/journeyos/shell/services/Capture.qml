pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Screenshots in the shell's style. Only Spectacle has KWin's permission to read the screen: it
// grabs an image of all screens (no window) and the shell does the rest — the frozen screen for
// picking the region (capture/CaptureOverlay), the crop (ImageMagick), the copy (wl-copy), saving
// to <Pictures>/Capturas and the thumbnail in the corner (capture/CapturePreview). Modes: region |
// screen | window (the active window, also via Spectacle) | color (eyedropper: the frozen screen
// with a magnifier; scripts/color.py reads the pixels and services/Colors copies).
Singleton {
    id: root

    readonly property string tmpDir: Quickshell.env("XDG_RUNTIME_DIR") || "/tmp"
    readonly property string frozen: tmpDir + "/shadow-capture.png"
    property string dir: Quickshell.env("HOME") + "/Pictures/Capturas"

    property bool busy: false
    property bool selecting: false          // the frozen screen is open
    property string mode: "region"          // region | color, with the frozen screen open
    property int frozenStamp: 0             // changes with every new image (the Image reloads)

    // The last capture (the thumbnail in the corner)
    property string last: ""
    property bool previewOpen: false

    // Logical size of all screens together and the scale of Spectacle's image (real pixels)
    readonly property rect desktop: {
        let w = 0, h = 0;
        for (const s of Quickshell.screens) {
            w = Math.max(w, s.x + s.width);
            h = Math.max(h, s.y + s.height);
        }
        return Qt.rect(0, 0, w, h);
    }
    property real scale: 1

    function start(mode) {
        if (busy || selecting)
            return;
        busy = true;
        previewOpen = false;
        // Close whatever is open, so it does not end up in the image
        QuickPanel.open = false;
        Launcher.open = false;
        Dashboard.open = false;
        Notifs.centerOpen = false;
        later.mode = mode;
        later.restart();
    }

    Timer {
        id: later
        property string mode: ""
        interval: Theme.animNormal + 150
        onTriggered: {
            if (mode === "window")
                root.grabWindow();
            else
                root.freeze(mode);
        }
    }

    // Spectacle exits with 0 even when KWin refuses the screenshot: the result only counts
    // if the file was (re)written (otherwise the frozen screen opened black, or with an old image)
    function spectacle(args, out, callback) {
        Run.cmd(["sh", "-c", 'rm -f "$1"; shift; spectacle "$@" && test -s "$0"', out, out].concat(args).concat(["-o", out]),
            code => callback(code === 0));
    }

    function freeze(mode) {
        spectacle(["-b", "-n", "-f"], frozen, ok => {
            if (!ok) {
                fail();
                return;
            }
            // Scale: image width / logical width (screens with fractional scaling)
            Run.cmd(["magick", "identify", "-format", "%w", frozen], (c, out) => {
                const w = Number(out.trim());
                if (c !== 0 || !(w > 0)) {
                    fail();
                    return;
                }
                root.scale = w > 0 && root.desktop.width > 0 ? w / root.desktop.width : 1;
                root.frozenStamp += 1;
                if (mode === "screen") {
                    root.cropScreen(Windows.activeScreen);
                } else {
                    root.mode = mode === "color" ? "color" : "region";
                    root.busy = false;
                    root.selecting = true;
                }
            });
        });
    }

    function grabWindow() {
        const out = tmpDir + "/shadow-capture-window.png";
        spectacle(["-b", "-n", "-a"], out, ok => ok ? finish(out) : fail());
    }

    function cancel() {
        pickPending = false;
        selecting = false;
        busy = false;
    }

    // --- Eyedropper ---
    // Colour under the mouse (real pixels of the frozen image), requested from scripts/color.py
    property string hoverColor: ""
    property bool pickPending: false
    property bool keepPicking: false
    readonly property bool pickerReady: picker.running && picker.ready

    function query(realX, realY) {
        if (picker.running && picker.ready)
            picker.write(Math.round(realX) + " " + Math.round(realY) + "\n");
    }

    // Copies this pixel's colour; "keep" leaves the eyedropper open (Shift+click). The answer is
    // matched by its coordinates (hover answers can still be on the way). A click before color.py is
    // ready waits for it; if it doesn't answer (it failed, or is still loading a huge image), the
    // pixel is read straight from the image after a moment, so a click never goes unanswered.
    property string pickKey: ""
    function pickAt(realX, realY, keep) {
        keepPicking = keep ?? false;
        pickPending = true;
        pickKey = Math.round(realX) + " " + Math.round(realY);
        query(realX, realY);
        pickFallback.restart();
    }

    function picked(hex) {
        pickPending = false;
        pickFallback.stop();
        Colors.copy(hex);
        if (!keepPicking)
            cancel();
    }

    Timer {
        id: pickFallback
        interval: 1500
        onTriggered: {
            if (!root.pickPending)
                return;
            const xy = root.pickKey.split(" ");
            Run.cmd(["magick", root.frozen, "-crop", "1x1+" + Math.max(0, xy[0]) + "+" + Math.max(0, xy[1]) + "!", "+repage",
                "-depth", "8", "-format", "%[hex:p{0,0}]", "info:"], (code, out) => {
                const hex = out.trim().slice(0, 6);
                if (root.pickPending && code === 0 && /^[0-9A-Fa-f]{6}$/.test(hex))
                    root.picked("#" + hex.toLowerCase());
            });
        }
    }

    Process {
        id: picker
        property bool ready: false
        running: root.selecting && root.mode === "color"
        command: [Quickshell.shellPath("scripts/color.py"), root.frozen]
        stdinEnabled: true
        onRunningChanged: {
            ready = false;
            root.hoverColor = "";
        }
        stderr: SplitParser {
            onRead: line => console.warn("color.py:", line)
        }
        stdout: SplitParser {
            onRead: line => {
                const f = line.split(" ");
                if (f[0] === "ready") {
                    picker.ready = true;
                    // A click that came before it was ready
                    if (root.pickPending)
                        picker.write(root.pickKey + "\n");
                    return;
                }
                if (f.length !== 3)
                    return;
                root.hoverColor = f[2];
                if (root.pickPending && f[0] + " " + f[1] === root.pickKey)
                    root.picked(f[2]);
            }
        }
    }

    // Region in logical desktop coordinates (all screens)
    function cropRegion(x, y, w, h) {
        selecting = false;
        if (w < 4 || h < 4) {
            busy = false;
            return;
        }
        busy = true;
        const s = scale;
        const geometry = Math.round(w * s) + "x" + Math.round(h * s) + "+" + Math.round(x * s) + "+" + Math.round(y * s);
        const out = tmpDir + "/shadow-capture-crop.png";
        Run.cmd(["magick", frozen, "-crop", geometry, "+repage", out], code => code === 0 ? finish(out) : fail());
    }

    function cropScreen(screen) {
        if (!screen) {
            fail();
            return;
        }
        cropRegion(screen.x, screen.y, screen.width, screen.height);
    }

    function fileName() {
        return "Captura_" + Qt.formatDateTime(new Date(), "yyyy-MM-dd_HH-mm-ss") + ".png";
    }

    // Saves, copies, plays the shutter sound and shows the thumbnail
    function finish(path) {
        const dest = dir + "/" + fileName();
        Run.cmd(["sh", "-c", 'mkdir -p "$1" && mv "$2" "$3"', "sh", dir, path, dest], code => {
            busy = false;
            if (code !== 0) {
                fail();
                return;
            }
            copy(dest);
            if (Config.options.notifications.sound)
                Quickshell.execDetached(["pw-play", "/usr/share/sounds/freedesktop/stereo/camera-shutter.oga"]);
            root.last = dest;
            root.previewOpen = true;
        });
    }

    function fail() {
        busy = false;
        selecting = false;
        Events.push({ icon: "error", title: Tr.t("Screenshot failed"), text: "", duration: 2500 });
    }

    // wl-copy keeps serving the image in the background (hence execDetached)
    function copy(path) {
        Quickshell.execDetached(["sh", "-c", 'exec wl-copy --type image/png < "$1"', "sh", path]);
    }

    function open(path) { Apps.run(["xdg-open", path]); }
    function showInFolder(path) {
        Apps.run(["dbus-send", "--session", "--dest=org.freedesktop.FileManager1", "--type=method_call",
            "/org/freedesktop/FileManager1", "org.freedesktop.FileManager1.ShowItems",
            "array:string:file://" + path, "string:"]);
    }
    function remove(path) {
        Run.cmd(["gio", "trash", path]);
        if (last === path) {
            previewOpen = false;
            last = "";
        }
    }

    // The user's pictures folder (xdg-user-dirs)
    Component.onCompleted: Run.cmd(["xdg-user-dir", "PICTURES"], (code, out) => {
        if (code === 0 && out.trim())
            root.dir = out.trim() + "/Capturas";
    })

    IpcHandler {
        target: "capture"
        function start(mode: string): void { root.start(mode || "region"); }
        // Eyedropper test without a mouse: the colour of the real pixel (x, y) of the frozen image
        function pick(x: int, y: int): void { root.pickAt(x, y, false); }
        function cancel(): void { root.cancel(); }
    }
}
