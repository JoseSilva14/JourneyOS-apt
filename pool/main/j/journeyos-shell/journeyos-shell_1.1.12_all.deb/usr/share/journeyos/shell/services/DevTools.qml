pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Developer tools in the launcher (same shape as Convert's results: { key, title, subtitle, glyph, copy | run }):
//   a JWT (pasted)              its payload (Enter copies it as formatted JSON), algorithm and expiry
//   1794854400 / 1794854400000  the date (seconds or milliseconds since 1970)
//   2026-11-16 18:00            the Unix timestamp; "now" / "epoch" / "timestamp": the current one
//   uuid                        a random UUID (from the kernel)
//   b64 text / b64d text        base64 encode / decode ("base64", "unbase64" also work)
//   url text / urld text        URL encode / decode
//   0xff / 0b1010 / hex 255     between decimal, hex and binary
//   json / json min             formats / compacts the JSON in the clipboard
Singleton {
    id: root

    // A fresh UUID every time the launcher opens
    FileView {
        id: uuidFile
        path: "/proc/sys/kernel/random/uuid"
        blockLoading: true
        printErrors: false
    }
    Connections {
        target: Launcher
        function onOpenChanged() { if (Launcher.open) uuidFile.reload(); }
    }

    // Qt.btoa already encodes the text as UTF-8
    function utf8ToB64(s) { return Qt.btoa(s); }
    function b64ToUtf8(s) {
        let t = s.replace(/-/g, "+").replace(/_/g, "/").replace(/\s+/g, "");
        while (t.length % 4)
            t += "=";
        const bin = Qt.atob(t);
        try {
            return decodeURIComponent(escape(bin));
        } catch (e) {
            return bin;     // not UTF-8 text
        }
    }

    function dateText(ms) {
        const d = new Date(ms);
        return d.toLocaleString(Qt.locale(Tr.locale), "yyyy-MM-dd HH:mm:ss") + " · " + d.toISOString();
    }

    // Whether the launcher should treat the text as one of these (no file search)
    function looksLike(raw) { return results(raw).length > 0; }

    function results(raw) {
        const t = raw.trim();
        const q = t.toLowerCase();
        const out = [];
        if (!t)
            return out;

        // JWT: header.payload.signature, base64url, the first two are JSON ("eyJ" = '{"')
        if (/^eyJ[\w-]+\.eyJ[\w-]+\.[\w-]*$/.test(t)) {
            try {
                const [h, p] = t.split(".").slice(0, 2).map(x => JSON.parse(b64ToUtf8(x)));
                const who = p.sub ?? p.email ?? p.name ?? p.iss ?? "";
                const parts = ["alg " + (h.alg ?? "?")];
                if (p.exp)
                    parts.push((p.exp * 1000 < Date.now() ? Tr.t("expired ") : Tr.t("expires ")) + dateText(p.exp * 1000).split(" · ")[0]);
                if (p.iat)
                    parts.push(Tr.t("issued ") + dateText(p.iat * 1000).split(" · ")[0]);
                out.push({ key: "jwt", glyph: "key", title: "JWT" + (who ? " · " + who : "") + " · " + Object.keys(p).length + Tr.t(" fields"),
                    subtitle: parts.join(" · "), copy: JSON.stringify(p, null, 2) });
            } catch (e) {
                out.push({ key: "jwt", glyph: "key", title: Tr.t("Not a valid JWT"), subtitle: String(e), keep: true });
            }
            return out;
        }

        // Unix time → date (seconds 2001–2286, or milliseconds)
        if (/^\d{10}$/.test(t) || /^\d{13}$/.test(t)) {
            const ms = t.length === 13 ? Number(t) : Number(t) * 1000;
            const text = dateText(ms);
            out.push({ key: "epoch", glyph: "schedule", title: text.split(" · ")[0], subtitle: (t.length === 13 ? Tr.t("Unix time in ms") : Tr.t("Unix time")) + " · " + text.split(" · ")[1],
                copy: new Date(ms).toISOString() });
            return out;
        }

        // Date → Unix time (local time unless it says Z or an offset)
        const dm = /^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?(Z|[+-]\d{2}:?\d{2})?$/.exec(t);
        if (dm) {
            const ms = Date.parse(dm[1] + "T" + (dm[2] ?? "00:00") + (dm[2] && dm[2].length === 5 ? ":00" : "") + (dm[3] ?? ""));
            if (!isNaN(ms))
                out.push({ key: "toepoch", glyph: "schedule", title: String(Math.floor(ms / 1000)), subtitle: Tr.t("Unix time · in ms ") + ms, copy: String(Math.floor(ms / 1000)) });
            return out;
        }

        if (/^(now|epoch|timestamp|unix|agora)$/.test(q)) {
            const ms = Date.now();
            out.push({ key: "now", glyph: "schedule", title: String(Math.floor(ms / 1000)), subtitle: Tr.t("Unix time now · in ms ") + ms, copy: String(Math.floor(ms / 1000)) });
            return out;
        }

        if (/^(uuid|guid)$/.test(q)) {
            const u = uuidFile.text().trim();
            if (u)
                out.push({ key: "uuid", glyph: "fingerprint", title: u, subtitle: Tr.t("Random UUID (v4)"), copy: u });
            return out;
        }

        // Prefixed: "b64 …", "b64d …", "url …", "urld …"
        const m = /^(b64d|base64d|unbase64|b64|base64|urld|urldecode|url|urlencode)\s+([\s\S]+)$/i.exec(t);
        if (m) {
            const op = m[1].toLowerCase(), arg = m[2];
            try {
                let v, what;
                if (op === "b64" || op === "base64") { v = utf8ToB64(arg); what = Tr.t("Base64"); }
                else if (op.startsWith("b64d") || op.startsWith("base64d") || op === "unbase64") { v = b64ToUtf8(arg); what = Tr.t("Decoded from base64"); }
                else if (op === "url" || op === "urlencode") { v = encodeURIComponent(arg); what = Tr.t("URL-encoded"); }
                else { v = decodeURIComponent(arg.replace(/\+/g, " ")); what = Tr.t("URL-decoded"); }
                out.push({ key: "enc-" + op, glyph: "code", title: v.length > 90 ? v.slice(0, 87) + "…" : v, subtitle: what, copy: v });
            } catch (e) {
                out.push({ key: "enc-" + op, glyph: "code", title: Tr.t("Can't decode that"), subtitle: String(e), keep: true });
            }
            return out;
        }

        // Number bases
        let n = null;
        if (/^0x[0-9a-f]+$/i.test(t)) n = parseInt(t.slice(2), 16);
        else if (/^0b[01]+$/i.test(t)) n = parseInt(t.slice(2), 2);
        else if (/^0o[0-7]+$/i.test(t)) n = parseInt(t.slice(2), 8);
        const hm = /^(hex|bin|oct)\s+(\d+)$/i.exec(t);
        if (hm) {
            const v = Number(hm[2]);
            const base = { hex: 16, bin: 2, oct: 8 }[hm[1].toLowerCase()];
            const text = ({ 16: "0x", 2: "0b", 8: "0o" })[base] + v.toString(base);
            out.push({ key: "base", glyph: "tag", title: text, subtitle: hm[2] + Tr.t(" in base ") + base, copy: text });
            return out;
        }
        if (n !== null && isFinite(n)) {
            out.push({ key: "base", glyph: "tag", title: String(n), subtitle: "0x" + n.toString(16) + " · 0b" + n.toString(2), copy: String(n) });
            return out;
        }

        // JSON in the clipboard
        if (/^json( min)?$/.test(q)) {
            const min = q.endsWith("min");
            out.push({ key: "json", glyph: "data_object", title: min ? Tr.t("Compact the JSON in the clipboard") : Tr.t("Format the JSON in the clipboard"),
                subtitle: Tr.t("Enter replaces the clipboard"), run: () => root.formatClipboard(min) });
        }
        return out;
    }

    readonly property string jsonScript: "import json, subprocess, sys\n"
        + "raw = subprocess.run(['wl-paste', '--no-newline'], capture_output=True, text=True).stdout\n"
        + "data = json.loads(raw)\n"
        + "out = json.dumps(data, ensure_ascii=False, separators=(',', ':')) if sys.argv[1:] == ['min'] "
        + "else json.dumps(data, ensure_ascii=False, indent=2)\n"
        + "subprocess.run(['wl-copy'], input=out, text=True, check=True)\n"

    // --- Suggestions: typing part of a tool's name shows it with an example; Enter writes its command
    // in the search field ("fill") to go on typing. "ferramentas" / "dev tools" lists them all.
    readonly property var tools: [
        { id: "jwt", glyph: "key", title: Tr.t("Decode a JWT"), hint: Tr.t("Paste the token here"), fill: "",
            keys: "jwt token bearer auth decode descodificar" },
        { id: "time", glyph: "schedule", title: Tr.t("Unix time ↔ date"), hint: Tr.t("e.g. 1794860133 or 2026-11-16 18:00 · \"now\" for the current one"), fill: "now",
            keys: "timestamp epoch unix time date data hora tempo now agora" },
        { id: "uuid", glyph: "fingerprint", title: Tr.t("Random UUID"), hint: Tr.t("Type \"uuid\""), fill: "uuid",
            keys: "uuid guid id identifier identificador aleatorio random" },
        { id: "b64", glyph: "code", title: Tr.t("Base64: encode"), hint: Tr.t("b64 <text>"), fill: "b64 ",
            keys: "base64 b64 encode codificar" },
        { id: "b64d", glyph: "code", title: Tr.t("Base64: decode"), hint: Tr.t("b64d <text>"), fill: "b64d ",
            keys: "base64 b64d unbase64 decode descodificar" },
        { id: "url", glyph: "link", title: Tr.t("URL: encode"), hint: Tr.t("url <text>"), fill: "url ",
            keys: "url encode urlencode percent codificar link" },
        { id: "urld", glyph: "link", title: Tr.t("URL: decode"), hint: Tr.t("urld <text>"), fill: "urld ",
            keys: "url urld decode urldecode percent descodificar link" },
        { id: "base", glyph: "tag", title: Tr.t("Number bases"), hint: Tr.t("0xff, 0b1010 or hex 255 / bin 255 / oct 255"), fill: "hex ",
            keys: "hex hexadecimal binary binario octal bases base numero number" },
        { id: "json", glyph: "data_object", title: Tr.t("Format the JSON in the clipboard"), hint: Tr.t("\"json\" · \"json min\" compacts it"), fill: "json",
            keys: "json format formatar pretty bonito clipboard" },
        { id: "jsonmin", glyph: "data_object", title: Tr.t("Compact the JSON in the clipboard"), hint: Tr.t("\"json min\""), fill: "json min",
            keys: "json minify compactar min clipboard" }
    ]

    function fold(s) { return (s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

    // [{ item, s }] for the launcher (scored like its commands)
    function suggestions(raw) {
        const q = fold(raw.trim());
        if (q.length < 2 || results(raw).length)
            return [];
        const all = /^(ferramentas?|tools?|dev ?tools?|devtools|utilitarios?)$/.test(q);
        return tools.map((t, i) => {
            const words = fold(t.title + " " + t.keys).split(/[\s:↔/]+/);
            const s = all ? 900 - i : words.some(w => w === q) ? 700 : words.some(w => w.startsWith(q)) ? 520 : 0;
            return { item: { kind: "command", key: "tool-" + t.id, title: t.title, subtitle: t.hint, glyph: t.glyph, fill: t.fill, run: () => {} }, s };
        }).filter(x => x.s > 0);
    }

    function formatClipboard(min) {
        Run.cmd(["python3", "-c", jsonScript, ...(min ? ["min"] : [])],
            (code, out, err) => Events.push(code === 0
                ? { icon: "data_object", title: min ? Tr.t("JSON compacted") : Tr.t("JSON formatted"), text: Tr.t("In the clipboard"), duration: 1500 }
                : { icon: "error", title: Tr.t("The clipboard isn't JSON"), text: (err.trim().split("\n").pop() ?? "").slice(0, 80), duration: 2500 }));
    }
}
