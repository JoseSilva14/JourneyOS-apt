pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Session (ksmserverrc): what opens at login (last session's apps or nothing), confirm on
// logout, and the lock/suspend/log out/restart/shut down actions with the shell's logout
// screen (session/SessionWindow). scripts/logout-prompt.py owns the name
// org.kde.LogoutPrompt, so Ctrl+Alt+Del and the "Log out" of KDE apps also open the shell's.
Singleton {
    id: root

    property string loginMode: "restorePreviousLogout"   // restorePreviousLogout | emptySession
    property bool confirmLogout: true

    // Logout screen: open, the chosen action and the seconds until it does it on its own (0 = no countdown)
    property bool open: false
    property string selected: "shutdown"
    property int countdown: 0
    readonly property int countdownStart: 30

    property bool canSuspend: false
    property bool canHibernate: false
    // Windows next to JourneyOS (UEFI "Windows Boot Manager" entries): "Restart to Windows". Several
    // with two Windows (one per disk): Settings → Session chooses (config.json session.windows)
    property var windowsEntries: []     // [{ num, uuid, label, disk }]
    readonly property bool canRebootWindows: windowsEntries.length > 0
    function lookForWindows() {
        Run.cmd(["/usr/lib/journeyos/boot-next", "windows-entries"], (code, out) => {
            root.windowsEntries = code !== 0 ? [] : out.split("\n").filter(l => l.trim()).map(l => {
                const f = l.split("\t");
                return { num: f[0], uuid: f[1] ?? "", label: f[2] ?? "", disk: f[3] ?? "" };
            });
        });
    }

    // In screen order
    readonly property var actions: [
        { id: "lock", label: Tr.t("Lock"), icon: "lock" },
        { id: "suspend", label: Tr.t("Sleep"), icon: "bedtime", hidden: !canSuspend },
        { id: "hibernate", label: Tr.t("Hibernate"), icon: "downloading", hidden: !canHibernate },
        { id: "logout", label: Tr.t("Log out"), icon: "logout" },
        { id: "reboot", label: Tr.t("Restart"), icon: "restart_alt" },
        { id: "rebootWindows", label: Tr.t("Restart to Windows"), icon: "desktop_windows", hidden: !canRebootWindows },
        { id: "shutdown", label: Tr.t("Shut down"), icon: "power_settings_new" }
    ].filter(a => !a.hidden)

    function refresh() {
        Kcfg.readMany("ksmserverrc", [
            { group: "General", key: "loginMode", fallback: "restorePreviousLogout" },
            { group: "General", key: "confirmLogout", fallback: "true" }
        ], v => {
            root.loginMode = v["General/loginMode"];
            root.confirmLogout = v["General/confirmLogout"] === "true";
        });
        for (const what of ["Suspend", "Hibernate"]) {
            const name = what;
            Run.cmd(["gdbus", "call", "--system", "--dest", "org.freedesktop.login1", "--object-path", "/org/freedesktop/login1",
                "--method", "org.freedesktop.login1.Manager.Can" + name], (code, out) => {
                root["can" + name] = code === 0 && out.includes("'yes'");
            });
        }
        lookForWindows();
    }

    function set(key, value) { Kcfg.write("ksmserverrc", "General", key, value, () => refresh()); }

    function lock() { Apps.run(["loginctl", "lock-session"]); }

    // kind: logout | reboot | shutdown | all. With "confirm on
    // logout" off it acts right away (except "all", which is a choice)
    function prompt(kind) {
        if (!["logout", "reboot", "shutdown"].includes(kind))
            kind = "all";
        // Windows can appear later (installed after JourneyOS): look again each time
        lookForWindows();
        if (!confirmLogout && kind !== "all") {
            perform(kind);
            return;
        }
        selected = kind === "all" ? "shutdown" : kind;
        // Only a concrete request runs the countdown (as in KDE)
        countdown = kind === "all" ? 0 : countdownStart;
        open = true;
    }

    function cancel() {
        open = false;
        countdown = 0;
    }

    function perform(id) {
        open = false;
        countdown = 0;
        // A moment for the logout screen to disappear first (otherwise it shows up in the lock screen)
        later.action = id;
        later.restart();
    }

    // Without Plasma (no ksmserver, so no org.kde.Shutdown): logind/systemd directly
    readonly property var fallbacks: ({
        logout: ["sh", "-c", "loginctl terminate-session \"${XDG_SESSION_ID:-self}\""],
        logoutAndReboot: ["systemctl", "reboot"],
        logoutAndShutdown: ["systemctl", "poweroff"]
    })

    function run(id) {
        const shutdown = method => Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.Shutdown",
            "--object-path", "/Shutdown", "--method", "org.kde.Shutdown." + method], code => {
            if (code !== 0)
                Run.cmd(root.fallbacks[method]);
        });
        switch (id) {
        case "lock": lock(); break;
        case "suspend": Apps.run(["systemctl", "suspend"]); break;
        case "hibernate": Apps.run(["systemctl", "hibernate"]); break;
        case "logout": shutdown("logout"); break;
        case "reboot": shutdown("logoutAndReboot"); break;
        // Marks Windows for the next start only (UEFI BootNext), then a normal restart
        case "rebootWindows":
            Run.cmd(["pkexec", "/usr/lib/journeyos/boot-next", "windows"].concat(
                Config.options.session.windows ? [Config.options.session.windows] : []), (code, out, err) => {
                if (code === 0)
                    shutdown("logoutAndReboot");
                else
                    Run.cmd(["notify-send", "--app-name=" + Tr.t("Session"), "--icon=dialog-error",
                        Tr.t("Could not restart to Windows"), err.trim() || Tr.t("The computer's firmware did not accept it.")]);
            });
            break;
        case "shutdown": shutdown("logoutAndShutdown"); break;
        }
    }

    Timer {
        id: later
        property string action: ""
        interval: 250
        onTriggered: root.run(action)
    }

    Timer {
        running: root.open && root.countdown > 0
        interval: 1000
        repeat: true
        onTriggered: {
            root.countdown -= 1;
            if (root.countdown === 0)
                root.perform(root.selected);
        }
    }

    // --- KDE requests (org.kde.LogoutPrompt) ---
    Process {
        id: prompts
        running: true
        command: [Quickshell.shellPath("scripts/logout-prompt.py")]
        stdout: SplitParser {
            onRead: line => root.prompt(line.trim())
        }
        // KDE's was open, or it crashed: try again shortly
        onExited: retry.restart()
    }
    Timer {
        id: retry
        interval: 10000
        onTriggered: prompts.running = true
    }

    Component.onCompleted: refresh()

    IpcHandler {
        target: "session"
        function prompt(kind: string): void { root.prompt(kind); }
        function cancel(): void { root.cancel(); }
    }
}
