import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Display: arrangement of the screens (drag them; they snap to each other's edges), resolution,
// refresh rate, scale, rotation and primary for each screen (asks for confirmation), variable
// refresh rate/HDR/wide colour gamut where the screen has them, and night light.
Page {
    id: root

    Component.onCompleted: {
        Display.refresh();
        Store.refresh();
    }

    // Confirmation after a change (reverts if there is no answer)
    Rectangle {
        Layout.fillWidth: true
        visible: Display.pending !== null
        implicitHeight: 60
        radius: Theme.radius
        color: Theme.accent

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 16
            anchors.rightMargin: 10
            spacing: 8

            Text {
                Layout.fillWidth: true
                text: Tr.t("Keep these settings? Reverting in ") + Display.countdown + Tr.t(" s.")
                wrapMode: Text.Wrap
                color: Theme.accentText
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.Bold
            }
            Pill { text: Tr.t("Revert"); onClicked: Display.revert() }
            Pill { text: Tr.t("Keep"); strong: true; onClicked: Display.keep() }
        }
    }

    // --- Arrangement (two screens or more) ---
    readonly property var shown: Display.outputs.filter(o => o.enabled)

    SectionLabel {
        visible: root.shown.length > 1
        text: Tr.t("Arrangement")
    }

    Rectangle {
        id: layout
        visible: root.shown.length > 1
        Layout.fillWidth: true
        implicitHeight: 230
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        // Logical rectangles of the screens (Display.rects) and the scale to fit them in the box
        readonly property var rects: Display.rects
        readonly property real minX: rects.length ? Math.min(...rects.map(r => r.x)) : 0
        readonly property real minY: rects.length ? Math.min(...rects.map(r => r.y)) : 0
        readonly property real spanW: rects.length ? Math.max(...rects.map(r => r.x + r.w)) - minX : 1
        readonly property real spanH: rects.length ? Math.max(...rects.map(r => r.y + r.h)) - minY : 1
        // Room around them to drag one past the others
        readonly property real k: Math.max(0.01, Math.min((width - 40) / (spanW * 1.6), (height - 56) / (spanH * 1.6)))
        readonly property real ox: (width - spanW * k) / 2
        readonly property real oy: (height - 30 - spanH * k) / 2

        Repeater {
            model: layout.rects

            Rectangle {
                id: screenBox
                required property var modelData
                readonly property real homeX: layout.ox + (modelData.x - layout.minX) * layout.k
                readonly property real homeY: layout.oy + (modelData.y - layout.minY) * layout.k

                x: homeX
                y: homeY
                width: Math.max(8, modelData.w * layout.k - 4)
                height: Math.max(8, modelData.h * layout.k - 4)
                radius: Theme.radiusSmall
                color: dragArea.drag.active ? Theme.buttonHover : Theme.button
                border.width: 2
                border.color: modelData.primary ? Theme.accent : Theme.surfaceBorder
                z: dragArea.drag.active ? 2 : 1

                Text {
                    anchors.centerIn: parent
                    width: parent.width - 8
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideRight
                    text: screenBox.modelData.name
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                    font.weight: Font.Bold
                }

                MouseArea {
                    id: dragArea
                    anchors.fill: parent
                    cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                    drag.target: screenBox
                    drag.threshold: 4
                    // The page scrolls: without this, a vertical drag would scroll it instead
                    preventStealing: true
                    onReleased: {
                        const moved = Math.abs(screenBox.x - screenBox.homeX) >= 4 || Math.abs(screenBox.y - screenBox.homeY) >= 4;
                        const lx = (screenBox.x - layout.ox) / layout.k + layout.minX;
                        const ly = (screenBox.y - layout.oy) / layout.k + layout.minY;
                        // Back home until KWin answers (the new positions then move it)
                        screenBox.x = Qt.binding(() => screenBox.homeX);
                        screenBox.y = Qt.binding(() => screenBox.homeY);
                        if (moved)
                            Display.place(screenBox.modelData.name, Math.round(lx), Math.round(ly));
                    }
                }
            }
        }

        RowLayout {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.margins: 10
            spacing: 8

            Text {
                Layout.fillWidth: true
                text: Tr.t("Drag the screens to match where they are on your desk.")
                elide: Text.ElideRight
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            Pill {
                text: Tr.t("Identify")
                onClicked: Display.identify()
            }
        }
    }

    Repeater {
        model: Display.outputs

        ColumnLayout {
            id: out
            required property var modelData
            readonly property var o: modelData
            readonly property var caps: Display.caps[o.name] ?? {}
            readonly property var mode: o.modes.find(m => m.id === o.currentModeId)
            // Resolutions without duplicates (refresh rate is picked separately), largest first
            readonly property var sizes: [...new Set(o.modes.map(m => m.size.width + "x" + m.size.height))]
                .sort((a, b) => b.split("x")[0] * b.split("x")[1] - a.split("x")[0] * a.split("x")[1])
            readonly property string size: mode ? mode.size.width + "x" + mode.size.height : ""
            readonly property var rates: o.modes.filter(m => m.size.width + "x" + m.size.height === size)
                .sort((a, b) => b.refreshRate - a.refreshRate)

            Layout.fillWidth: true
            spacing: 8

            SectionLabel {
                text: (out.o.name + (Display.outputs.length > 1 && out.o.priority === 1 ? Tr.t(" · primary") : ""))
            }

            SettingRow {
                visible: Display.outputs.length > 1
                title: Tr.t("On")
                icon: "desktop_windows"
                Toggle {
                    checked: out.o.enabled
                    onToggled: on => Display.apply(out.o, { enabled: on })
                }
            }

            SettingRow {
                title: Tr.t("Resolution")
                icon: "aspect_ratio"
                Select {
                    options: out.sizes.map(s => ({ id: s, label: s.replace("x", " × ") }))
                    current: out.size
                    onSelected: id => {
                        // The highest refresh rate for the chosen resolution
                        const best = out.o.modes.filter(m => m.size.width + "x" + m.size.height === id)
                            .sort((a, b) => b.refreshRate - a.refreshRate)[0];
                        if (best)
                            Display.apply(out.o, { mode: best.id });
                    }
                }
            }

            SettingRow {
                visible: out.rates.length > 1
                title: Tr.t("Refresh rate")
                icon: "speed"
                Select {
                    options: out.rates.map(m => ({ id: m.id, label: Math.round(m.refreshRate) + Tr.t(" Hz") }))
                    current: out.o.currentModeId
                    onSelected: id => Display.apply(out.o, { mode: id })
                }
            }

            SettingRow {
                title: Tr.t("Scale")
                description: Tr.t("The size of everything on screen.")
                icon: "zoom_in"
                Segmented {
                    model: [1, 1.25, 1.5, 1.75, 2].map(s => ({ id: String(s), label: Math.round(s * 100) + "%" }))
                    current: String(out.o.scale)
                    onSelected: id => Display.apply(out.o, { scale: Number(id) })
                }
            }

            SettingRow {
                title: Tr.t("Rotation")
                icon: "screen_rotation"
                Select {
                    options: Display.rotations.map(r => ({ id: r.id, label: r.label }))
                    current: Display.rotationId(out.o.rotation)
                    onSelected: id => Display.apply(out.o, { rotation: id })
                }
            }

            SettingRow {
                visible: out.caps.vrr !== undefined && out.caps.vrr !== "incapable"
                title: Tr.t("Variable refresh rate")
                description: Tr.t("Smoother games and video on screens with FreeSync or G-Sync.")
                icon: "motion_photos_auto"
                Select {
                    options: [
                        { id: "automatic", label: Tr.t("Only in full-screen apps") },
                        { id: "always", label: Tr.t("Always") },
                        { id: "never", label: Tr.t("Never") }
                    ]
                    current: (out.caps.vrr ?? "").toLowerCase()
                    onSelected: id => Display.setFeature(out.o, "vrr", id)
                }
            }

            SettingRow {
                visible: out.caps.hdr !== undefined && out.caps.hdr !== "incapable"
                title: "HDR"
                description: Tr.t("Brighter highlights in HDR videos and games.")
                icon: "hdr_on"
                Toggle {
                    checked: out.caps.hdr === "enabled"
                    onToggled: on => Display.setFeature(out.o, "hdr", on ? "enable" : "disable")
                }
            }

            SettingRow {
                visible: out.caps.wcg !== undefined && out.caps.wcg !== "incapable"
                title: Tr.t("Wide color gamut")
                description: Tr.t("More saturated colors, for screens made for it.")
                icon: "palette"
                Toggle {
                    checked: out.caps.wcg === "enabled"
                    onToggled: on => Display.setFeature(out.o, "wcg", on ? "enable" : "disable")
                }
            }

            SettingRow {
                visible: Display.outputs.length > 1 && out.o.priority !== 1
                title: Tr.t("Make primary")
                description: Tr.t("The bar and alerts show on this screen.")
                icon: "star"
                Pill {
                    text: Tr.t("Main")
                    onClicked: Display.apply(out.o, { primary: true })
                }
            }
        }
    }

    // --- Graphics card: NVIDIA's driver (also in the dashboard's Apps tab and the Welcome) ---
    SectionLabel { text: Tr.t("Graphics card") }

    SettingRow {
        title: Store.nvidia.present ? Store.nvidia.name : (SystemInfo.gpu || Tr.t("Graphics card"))
        description: !Store.nvidia.present ? Tr.t("Its driver comes with the system: nothing to install.")
            : Store.nvidia.driver ? Tr.t("NVIDIA's driver is in use.")
            : Store.nvidia.installed ? Tr.t("NVIDIA's driver is installed: restart the computer to use it. If it still isn't used after restarting, Secure Boot may be blocking it (turn it off in the firmware, or enroll the key when asked).")
            : Tr.t("Using the open driver (nouveau): slower in games and video. NVIDIA's driver opens a terminal, asks for your password and needs a restart.")
        icon: "memory"
        PillButton {
            visible: Store.nvidia.present === true && !Store.nvidia.driver && !Store.nvidia.installed
            text: Tr.t("Install NVIDIA driver")
            accent: true
            onClicked: Store.installNvidia()
        }
    }

    // --- Night light ---
    SectionLabel { text: Tr.t("Night light") }

    SettingRow {
        title: Tr.t("Night light")
        description: Tr.t("Warmer colors, easier on the eyes at night.")
        icon: "nightlight"
        Toggle {
            checked: Display.nightEnabled
            onToggled: on => Display.setNightEnabled(on)
        }
    }

    // "0600" -> "6:00"
    function hhmm(v) { return Number(v.slice(0, 2)) + ":" + v.slice(2, 4); }
    readonly property var hours: Array.from({ length: 48 }, (_, i) => {
        const v = String(Math.floor(i / 2)).padStart(2, "0") + (i % 2 ? "30" : "00");
        return { id: v, label: hhmm(v) };
    })

    SettingRow {
        visible: Display.nightEnabled
        title: Tr.t("When")
        description: Display.nightMode === "Times" ? Tr.t("From ") + root.hhmm(Display.eveningBegin) + Tr.t(" to ") + root.hhmm(Display.morningBegin) + "."
            : Display.nightMode === "Location" ? Tr.t("From sunset to sunrise at ") + (Config.options.weather.place || Tr.t("your place")) + "."
            : !Display.hasCoordinates ? Tr.t("Always on. Choose your city in Settings → Weather to follow the sun.")
            : Tr.t("Always on.")
        icon: "schedule"
        Segmented {
            model: [{ id: "Constant", label: Tr.t("Always") }]
                .concat(Display.hasCoordinates ? [{ id: "Location", label: Tr.t("Sunset to sunrise") }] : [])
                .concat([{ id: "Times", label: Tr.t("Custom") }])
            current: ["Times", "Location"].includes(Display.nightMode) ? Display.nightMode : "Constant"
            onSelected: id => Display.setNightSchedule(id)
        }
    }

    SettingRow {
        visible: Display.nightEnabled && Display.nightMode === "Times"
        title: Tr.t("Starts at")
        icon: "wb_twilight"
        Select {
            options: root.hours
            current: Display.eveningBegin
            onSelected: id => Display.setNight("EveningBeginFixed", id)
        }
    }

    SettingRow {
        visible: Display.nightEnabled && Display.nightMode === "Times"
        title: Tr.t("Ends at")
        icon: "wb_sunny"
        Select {
            options: root.hours
            current: Display.morningBegin
            onSelected: id => Display.setNight("MorningBeginFixed", id)
        }
    }

    SettingRow {
        visible: Display.nightEnabled
        title: Tr.t("Temperature · ") + temperature.shown + Tr.t(" K")
        description: Tr.t("Further left is warmer.")
        icon: "thermostat"

        Slider {
            id: temperature
            implicitWidth: 240
            readonly property int minK: 2500
            readonly property int maxK: 6000
            property int shown: Display.nightTemperature
            value: (shown - minK) / (maxK - minK)
            onMoved: v => {
                shown = Math.round((minK + v * (maxK - minK)) / 100) * 100;
                Display.preview(shown);
                commit.restart();
            }
            // Saves once the user stops dragging
            Timer {
                id: commit
                interval: 800
                onTriggered: {
                    Display.stopPreview();
                    Display.setNight("NightTemperature", String(temperature.shown));
                }
            }
        }
    }

    component Pill: Rectangle {
        id: pill
        property string text: ""
        property bool strong: false
        signal clicked

        implicitWidth: pillText.implicitWidth + 28
        implicitHeight: 32
        radius: height / 2
        color: strong ? Theme.accentText : pillMouse.containsMouse ? Theme.buttonHover : Theme.button

        Text {
            id: pillText
            anchors.centerIn: parent
            text: pill.text
            color: pill.strong ? Theme.accent : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall + 1
            font.weight: Font.Bold
        }
        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
