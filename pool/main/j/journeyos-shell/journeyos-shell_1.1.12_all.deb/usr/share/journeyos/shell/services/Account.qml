pragma Singleton

import QtQuick
import Quickshell

// The user's account (AccountsService): name and photo; the password is
// changed with passwd in a terminal (it never goes through the shell).
Singleton {
    id: root

    readonly property string login: Quickshell.env("USER") || ""
    property string path: ""
    property string realName: ""
    property string iconFile: ""
    property bool admin: false

    function busctl(args, callback) {
        Run.cmd(["busctl", "--system", ...args], callback);
    }

    function refresh() {
        busctl(["call", "org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
            "FindUserByName", "s", login], (code, out) => {
            const m = out.match(/"([^"]+)"/);
            if (!m)
                return;
            root.path = m[1];
            const get = (prop, cb) => busctl(["get-property", "org.freedesktop.Accounts", root.path,
                "org.freedesktop.Accounts.User", prop], (c, o) => cb(o.trim()));
            get("RealName", v => root.realName = (v.match(/"(.*)"/) ?? [, ""])[1]);
            get("IconFile", v => root.iconFile = (v.match(/"(.*)"/) ?? [, ""])[1]);
            get("AccountType", v => root.admin = v.endsWith(" 1"));
        });
    }

    function setName(name) {
        if (!path || !name.trim())
            return;
        busctl(["call", "org.freedesktop.Accounts", path, "org.freedesktop.Accounts.User", "SetRealName", "s", name.trim()],
            () => refresh());
    }

    // Choosing a photo: copies it to ~/.face (what the shell uses) and hands it to
    // AccountsService (the login screen); the config's avatar option no longer takes precedence
    function choosePhoto() {
        Run.cmd(["kdialog", "--title", Tr.t("Choose photo"), "--getopenfilename",
            Quickshell.env("HOME") + "/Pictures", "image/png image/jpeg image/webp image/svg+xml"], (code, out) => {
            const file = out.trim();
            if (code !== 0 || !file)
                return;
            Run.cmd(["cp", "-f", file, Quickshell.env("HOME") + "/.face"], () => {
                busctl(["call", "org.freedesktop.Accounts", root.path, "org.freedesktop.Accounts.User",
                    "SetIconFile", "s", Quickshell.env("HOME") + "/.face"], () => refresh());
                Config.options.avatar = "";
            });
        });
    }

    // passwd in a terminal; then the passwords store (KWallet) gets the new one too, otherwise it would
    // no longer open by itself at login (KWallet asks for the old and the new password in its window)
    function changePassword() {
        Apps.run(["konsole", "-e", "sh", "-c",
            'echo "$1"; echo; if passwd; then if [ -f "$HOME/.local/share/kwalletd/kdewallet.kwl" ]; then echo; echo "$2";'
            + ' (qdbus6 org.kde.kwalletd6 /modules/kwalletd6 changePassword kdewallet 0 JourneyOS >/dev/null 2>&1 &); fi; fi;'
            + ' echo; printf "%s " "$3"; read x',
            "sh", Tr.t("Change the password of ") + login,
            Tr.t("Now the passwords store: type the old password and the new one in the window that opens, so it keeps opening at login."),
            Tr.t("Press Enter to close")]);
    }
}
