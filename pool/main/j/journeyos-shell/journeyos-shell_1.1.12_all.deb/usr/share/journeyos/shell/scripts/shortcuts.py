#!/usr/bin/env python3
"""The shell's global shortcuts through KDE's kglobalaccel (component "shadow-kde").

Usage: shortcuts.py action=Meta+Space [action=Meta+A ...] [custom-x=Meta+T<TAB>Name ...]
       shortcuts.py repor   (restore) removes the shell's shortcuts and gives back the keys it took
                            from plasmashell and Spectacle (for the uninstaller)
Writes "pressed <action>" on every key press and "conflict <action> <owner>" when the
key belongs to another app. Keys of components that are not running (plasmashell,
disabled by this shell) are freed first.

Free keys with setForeignShortcut (ai) and an empty list: the a(ai) variant
(setForeignShortcutKeys) has already crashed KWin in another project.

An action's text after a tab is its name in KDE's lists (the user's own shortcuts: apps and
commands). Actions of this component that are no longer given are unregistered, so a removed
shortcut gives its key back.

"Meta" on its own (pressed and released with nothing else) is Qt's Key_Meta as the whole key:
kglobalaccel (Plasma 6) fires it on release, as Plasma does for its launcher.
"""

import os
import sys

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS = "org.kde.kglobalaccel"
PATH = "/kglobalaccel"
IFACE = "org.kde.KGlobalAccel"
COMPONENT = "shadow-kde"
FRIENDLY = "Shadow KDE"

# Components a key can be taken from when they are not running: plasmashell
# (disabled by this shell) and Spectacle (the Print keys go to the shell's screenshots)
FREE_FROM = {"plasmashell", "org.kde.spectacle.desktop"}

MODS = {"meta": 0x10000000, "ctrl": 0x04000000, "alt": 0x08000000, "shift": 0x02000000}
KEYS = {"space": 0x20, "return": 0x01000004, "enter": 0x01000005, "escape": 0x01000000,
        "tab": 0x01000001, "print": 0x01000009, "delete": 0x01000007}
NAMES = {"launcher": "App launcher", "panel": "Quick panel",
         "notifications": "Notification centre", "dashboard": "Dashboard",
         "wallpapers": "Wallpapers", "widgets": "Edit widgets",
         "settings": "Settings", "clipboard": "Clipboard",
         "captureRegion": "Capture a region", "captureScreen": "Capture the screen",
         "captureWindow": "Capture the active window",
         "colorPicker": "Colour picker (copy a colour)",
         "tileHalves": "Tile windows in halves", "tileColumns": "Tile windows in columns",
         "tileMain": "Main window with the others beside it", "tileGrid": "Tile windows in a grid"}

# setShortcut flags
SET_PRESENT = 2
NO_AUTOLOADING = 4   # without it, a key kglobalaccel saved earlier wins over the one given
IS_DEFAULT = 8


def parse(spec):
    # A modifier on its own: Meta alone (kglobalaccel's modifier-only shortcut)
    if spec.strip().lower() == "meta":
        return 0x01000022
    code = 0
    for part in spec.split("+"):
        p = part.strip().lower()
        if p in MODS:
            code |= MODS[p]
        elif p in KEYS:
            code |= KEYS[p]
        elif len(p) == 1:
            code |= ord(p.upper())
        elif p[0] == "f" and p[1:].isdigit():
            code |= 0x01000030 + int(p[1:]) - 1
        else:
            raise ValueError(f"unknown key: {part}")
    return code


def main():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def call(method, args, ret):
        res = conn.call_sync(BUS, PATH, IFACE, method, args,
                             GLib.VariantType(ret) if ret else None,
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack() if res else None

    def running(component):
        # Does the component have a live process owning the name on D-Bus?
        names = conn.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus",
                               "org.freedesktop.DBus", "ListNames", None,
                               GLib.VariantType("(as)"), Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        # Exact name: kded has "org.kde.plasmashell.accentColor" without plasmashell running
        return f"org.kde.{component}" in names or component in names

    actions = {}
    given = set()
    for arg in sys.argv[1:]:
        name, _, spec = arg.partition("=")
        spec, _, friendly = spec.partition("\t")
        if not name:
            continue
        given.add(name)
        action_id = [COMPONENT, name, FRIENDLY, friendly or NAMES.get(name, name)]
        call("doRegister", GLib.Variant("(as)", (action_id,)), None)
        keys = []
        if spec:
            key = parse(spec)
            owner = call("action", GLib.Variant("(i)", (key,)), "(as)")[0]
            if owner and owner[0] != COMPONENT:
                if owner[0] in FREE_FROM and not running(owner[0]):
                    call("setForeignShortcut", GLib.Variant("(asai)", (owner, [])), None)
                else:
                    print(f"conflict {name} {owner[0]}", flush=True)
                    continue
            keys = [key]
        call("setShortcut", GLib.Variant("(asaiu)", (action_id, keys, IS_DEFAULT)), "(ai)")
        active = call("setShortcut", GLib.Variant("(asaiu)", (action_id, keys, SET_PRESENT | NO_AUTOLOADING)), "(ai)")[0]
        actions[name] = active

    # Shortcuts removed since the last time: their keys become free
    try:
        registered = call("allActionsForComponent", GLib.Variant("(as)", ([COMPONENT],)), "(aas)")[0]
    except GLib.Error:
        registered = []
    for action_id in registered:
        if action_id[1] not in given:
            call("unregister", GLib.Variant("(ss)", (COMPONENT, action_id[1])), "(b)")

    path = call("getComponent", GLib.Variant("(s)", (COMPONENT,)), "(o)")[0]

    def pressed(_c, _s, _p, _i, _sig, params):
        _comp, action, _ts = params.unpack()
        print(f"pressed {action}", flush=True)

    conn.signal_subscribe(BUS, "org.kde.kglobalaccel.Component", "globalShortcutPressed",
                          path, None, Gio.DBusSignalFlags.NONE, pressed)
    print("ready " + " ".join(f"{k}={v}" for k, v in actions.items()), flush=True)

    # The shell closed (stdin closed): exit too
    loop = GLib.MainLoop()
    GLib.io_add_watch(GLib.IOChannel.unix_new(sys.stdin.fileno()), GLib.PRIORITY_DEFAULT,
                      GLib.IO_HUP | GLib.IO_ERR, lambda *_: loop.quit())
    loop.run()


def defaults_for(component):
    """Default keys of a component's actions, as text: {action: "Meta+V\tPrint"}.

    plasmashell keeps them in kglobalshortcutsrc (active,default,name); Spectacle in its .desktop
    (X-KDE-Shortcuts per action). When the shell takes a key, kglobalaccel's is left empty.
    """
    out = {}
    if component.endswith(".desktop"):
        path = f"/usr/share/applications/{component}"
        section = "_launch"
        try:
            with open(path, encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith("[Desktop Action "):
                        section = line[len("[Desktop Action "):-1]
                    elif line.startswith("[") and line != "[Desktop Entry]":
                        section = None
                    elif section and line.startswith("X-KDE-Shortcuts="):
                        out[section] = line.split("=", 1)[1].replace(",", "\t")
        except OSError:
            pass
        return out
    path = os.path.expanduser("~/.config/kglobalshortcutsrc")
    group = None
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if line.startswith("["):
                    group = line[1:-1]
                elif group == component and "=" in line and not line.startswith("_k_"):
                    action, _, value = line.partition("=")
                    fields = value.split(",")
                    if len(fields) >= 2 and fields[1] not in ("", "none"):
                        # Several keys separated by a literal "\t"
                        out[action] = fields[1].replace("\\t", "\t")
    except OSError:
        pass
    return out


def repor():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def call(method, args, ret):
        res = conn.call_sync(BUS, PATH, IFACE, method, args,
                             GLib.VariantType(ret) if ret else None,
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack() if res else None

    def actions(component):
        return call("allActionsForComponent", GLib.Variant("(as)", ([component],)), "(aas)")[0]

    # 1. Ours go away (the keys become free)
    for action_id in actions(COMPONENT):
        call("unregister", GLib.Variant("(ss)", (COMPONENT, action_id[1])), "(b)")
    print("shell shortcuts: removed")

    # 2. plasmashell/Spectacle actions without a key go back to their defaults, if those are free
    for component in sorted(FREE_FROM):
        defaults = defaults_for(component)
        for action_id in actions(component):
            if call("shortcut", GLib.Variant("(as)", (action_id,)), "(ai)")[0]:
                continue
            spec = defaults.get(action_id[1])
            if not spec:
                continue
            try:
                keys = [parse(k) for k in spec.split("\t") if k.strip()]
            except ValueError:
                continue
            # Modifier-only keys ("Meta" alone) cannot be written this way: left out
            keys = [k for k in keys if k & 0x01FFFFFF and not call("action", GLib.Variant("(i)", (k,)), "(as)")[0]]
            if keys:
                call("setForeignShortcut", GLib.Variant("(asai)", (action_id, keys)), None)
                print(f"{component}: {action_id[1]} = {spec.replace(chr(9), ', ')}")


if __name__ == "__main__":
    if sys.argv[1:] == ["repor"]:
        repor()
    else:
        main()
