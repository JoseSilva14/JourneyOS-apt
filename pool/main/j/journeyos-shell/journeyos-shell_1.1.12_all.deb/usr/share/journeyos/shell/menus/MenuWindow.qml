import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.services

// Bar menus window (sound, network and Bluetooth): panel on the right, below the bar.
// Esc or clicking outside closes.
PanelWindow {
    id: root

    // This instance's screen (the window's "screen" changes with "visible": binding loop)
    required property var modelScreen
    readonly property bool open: BarMenu.open !== "" && BarMenu.screen === modelScreen
    // The last one opened, so the closing animation still shows it
    property string shown: ""

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-menu"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open)
            shown = BarMenu.open;
        else
            closing.restart();
    }
    Connections {
        target: BarMenu
        function onOpenChanged() { if (BarMenu.open) root.shown = BarMenu.open; }
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    MouseArea {
        anchors.fill: parent
        onClicked: BarMenu.open = ""
    }

    Rectangle {
        id: panel

        readonly property real slide: root.open ? 0 : -Theme.gap

        width: Theme.menuWidth
        height: Math.min(loader.implicitHeight + Theme.cardPadding * 2, parent.height - Theme.gap * 2)
        x: parent.width - width - Theme.gap
        y: Theme.gap + slide
        opacity: root.open ? 1 : 0
        radius: Theme.radiusCard + 4
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        clip: true

        Behavior on y {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }
        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
        Behavior on height {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        focus: root.open
        Keys.onEscapePressed: BarMenu.open = ""

        // Clicks on the panel do not close it
        MouseArea {
            anchors.fill: parent
        }

        Loader {
            id: loader
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: Theme.cardPadding
            active: root.visible
            source: root.shown === "bluetooth" ? "BluetoothMenu.qml"
                : root.shown === "network" ? "NetworkMenu.qml"
                : root.shown === "sound" ? "SoundMenu.qml"
                : root.shown === "claude" ? "ClaudeMenu.qml"
                : root.shown === "docker" ? "DockerMenu.qml"
                : ""
        }
    }
}
