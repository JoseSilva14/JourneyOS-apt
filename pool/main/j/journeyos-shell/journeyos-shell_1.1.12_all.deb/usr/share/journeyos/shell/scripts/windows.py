#!/usr/bin/env python3
"""KWin windows for the dock.

KWin does not have the wlr-foreign-toplevel protocol: a KWin script sends the window
list over D-Bus (to the name org.shadowkde.Windows, owned by this process) on every
change, and this process writes one JSON line per list:
    [{"id", "appId", "cls", "title", "active", "minimized", "output"}]
Commands on stdin, one per line (each runs as a short KWin script):
    activate <id> | minimize <id> | close <id> | toggle <id>
"""

import json
import os
import sys
import tempfile

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

NAME = "org.shadowkde.Windows"
WATCHER = "shadow-kde-windows"

XML = f"""<node><interface name="{NAME}">
<method name="update"><arg type="s" direction="in"/></method>
</interface></node>"""

WATCHER_JS = f"""
function send() {{
    const list = workspace.windowList()
        .filter(w => w.normalWindow && !w.skipTaskbar)
        .map(w => ({{
            id: w.internalId.toString(),
            appId: w.desktopFileName || "",
            cls: w.resourceClass || "",
            title: w.caption || "",
            active: w === workspace.activeWindow,
            minimized: w.minimized,
            output: w.output ? w.output.name : "",
            pid: w.pid
        }}));
    callDBus("{NAME}", "/", "{NAME}", "update", JSON.stringify(list));
}}
function watch(w) {{
    w.captionChanged.connect(send);
    w.minimizedChanged.connect(send);
    w.outputChanged.connect(send);
}}
workspace.windowList().forEach(watch);
workspace.windowAdded.connect(w => {{ watch(w); send(); }});
workspace.windowRemoved.connect(send);
workspace.windowActivated.connect(send);
send();
"""

ACTIONS = {
    "activate": "w.minimized = false; workspace.activeWindow = w;",
    "minimize": "w.minimized = true;",
    "close": "w.closeWindow();",
    # Activates; if it is already the active one, minimises
    "toggle": "if (w === workspace.activeWindow && !w.minimized) w.minimized = true;"
              " else { w.minimized = false; workspace.activeWindow = w; }",
}

RUNTIME = os.environ.get("XDG_RUNTIME_DIR", tempfile.gettempdir())


def main():
    conn = Gio.bus_get_sync(Gio.BusType.SESSION)

    def kwin(method, args, ret=None, path="/Scripting", iface="org.kde.kwin.Scripting"):
        res = conn.call_sync("org.kde.KWin", path, iface, method, args,
                             GLib.VariantType(ret) if ret else None,
                             Gio.DBusCallFlags.NONE, -1, None)
        return res.unpack() if res else None

    def run_script(name, source):
        path = os.path.join(RUNTIME, f"{name}.js")
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(source)
        os.replace(tmp, path)
        kwin("unloadScript", GLib.Variant("(s)", (name,)), "(b)")
        sid = kwin("loadScript", GLib.Variant("(ss)", (path, name)), "(i)")[0]
        if sid < 0:
            raise RuntimeError(f"KWin did not load {name}")
        kwin("run", None, path=f"/Scripting/Script{sid}", iface="org.kde.kwin.Script")
        return name

    def on_call(_conn, _sender, _path, _iface, method, params, invocation):
        if method == "update":
            print(params.unpack()[0], flush=True)
        invocation.return_value(None)

    node = Gio.DBusNodeInfo.new_for_xml(XML)
    conn.register_object("/", node.interfaces[0], on_call, None, None)

    loop = GLib.MainLoop()
    counter = [0]

    def command(line):
        parts = line.split()
        if len(parts) != 2 or parts[0] not in ACTIONS:
            return
        wid = json.dumps(parts[1])
        counter[0] += 1
        name = f"shadow-kde-cmd-{counter[0] % 4}"
        run_script(name, f"""
const w = workspace.windowList().find(w => w.internalId.toString() === {wid});
if (w) {{ {ACTIONS[parts[0]]} }}
""")
        # A command script only runs once: remove it shortly after
        GLib.timeout_add(1500, lambda: kwin("unloadScript", GLib.Variant("(s)", (name,)), "(b)") and False)

    def on_stdin(channel, cond):
        if cond & (GLib.IO_HUP | GLib.IO_ERR):
            loop.quit()
            return False
        line = channel.readline()
        if not line:
            loop.quit()
            return False
        try:
            command(line)
        except (GLib.Error, RuntimeError) as e:
            print(json.dumps({"error": str(e)}), file=sys.stderr, flush=True)
        return True

    def on_name(_conn, _name):
        run_script(WATCHER, WATCHER_JS)

    def on_lost(_conn, _name):
        print("the name org.shadowkde.Windows is already in use", file=sys.stderr, flush=True)
        loop.quit()

    Gio.bus_own_name_on_connection(conn, NAME, Gio.BusNameOwnerFlags.ALLOW_REPLACEMENT | Gio.BusNameOwnerFlags.REPLACE,
                                  on_name, on_lost)
    GLib.io_add_watch(GLib.IOChannel.unix_new(sys.stdin.fileno()), GLib.PRIORITY_DEFAULT,
                      GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, on_stdin)
    try:
        loop.run()
    finally:
        try:
            kwin("unloadScript", GLib.Variant("(s)", (WATCHER,)), "(b)")
        except GLib.Error:
            pass


if __name__ == "__main__":
    main()
