import QtQuick
import QtQuick.Layouts
import Quickshell.Services.UPower
import qs
import qs.components
import qs.services

// Power: battery (state, health, charge limit), profile, dimming/turning off the screen and suspend,
// the profile to switch to, the lid and the power button (on AC and, on a laptop, on battery) and
// automatic locking.
Page {
    id: root

    Component.onCompleted: Power.refresh()

    readonly property var times: [
        { id: "-1", label: Tr.t("Never") }, { id: "60", label: Tr.t("1 minute") }, { id: "120", label: Tr.t("2 minutes") },
        { id: "300", label: Tr.t("5 minutes") }, { id: "600", label: Tr.t("10 minutes") }, { id: "900", label: Tr.t("15 minutes") },
        { id: "1800", label: Tr.t("30 minutes") }, { id: "3600", label: Tr.t("1 hour") }
    ]

    readonly property var bat: Power.battery
    // Quickshell gives the percentage in 0–1 (older versions 0–100)
    readonly property int level: bat ? Math.round(bat.percentage > 1 ? bat.percentage : bat.percentage * 100) : 0

    function duration(seconds) {
        const m = Math.round(seconds / 60);
        if (m < 60)
            return m + Tr.t(" min");
        return Math.floor(m / 60) + Tr.t(" h ") + String(m % 60).padStart(2, "0") + Tr.t(" min");
    }

    readonly property string batteryState: {
        if (!bat)
            return "";
        switch (bat.state) {
        case UPowerDeviceState.Charging:
            return bat.timeToFull > 0 ? Tr.t("Charging · full in ") + duration(bat.timeToFull) : Tr.t("Charging");
        case UPowerDeviceState.Discharging:
            return bat.timeToEmpty > 0 ? Tr.t("On battery · ") + duration(bat.timeToEmpty) + Tr.t(" left") : Tr.t("On battery");
        case UPowerDeviceState.FullyCharged:
            return Tr.t("Fully charged");
        case UPowerDeviceState.PendingCharge:
            return Power.chargeLimit < 100 && root.level >= Power.chargeLimit - 5
                ? Tr.t("Plugged in · not charging (limit reached)") : Tr.t("Plugged in · not charging");
        default:
            return UPower.onBattery ? Tr.t("On battery") : Tr.t("Plugged in");
        }
    }

    // --- Battery ---
    SectionLabel {
        visible: root.bat !== null
        text: Tr.t("Battery")
    }

    SettingRow {
        visible: root.bat !== null
        title: root.level + "%"
        description: root.batteryState
        icon: root.bat && root.bat.state === UPowerDeviceState.Charging ? "battery_charging_full"
            : root.level > 80 ? "battery_full" : root.level > 40 ? "battery_5_bar" : root.level > 15 ? "battery_3_bar" : "battery_alert"

        Rectangle {
            implicitWidth: 160
            implicitHeight: 10
            radius: 5
            color: Theme.button

            Rectangle {
                width: parent.width * Math.min(1, root.level / 100)
                height: parent.height
                radius: 5
                color: root.level <= 15 ? Theme.privacyMic : Theme.accent
            }
            // Where charging stops
            Rectangle {
                visible: Power.chargeLimit < 100
                x: parent.width * Power.chargeLimit / 100 - 1
                width: 2
                height: parent.height + 6
                y: -3
                color: Theme.text
            }
        }
    }

    SettingRow {
        visible: root.bat !== null && root.bat.healthSupported && root.bat.healthPercentage > 0
        title: Tr.t("Battery health")
        description: root.bat && root.bat.energyCapacity > 0
            ? Tr.t("Holds ") + root.bat.energyCapacity.toFixed(1) + Tr.t(" Wh when full.") : ""
        icon: "health_and_safety"

        Text {
            text: root.bat ? Math.round(root.bat.healthPercentage) + "%" : ""
            color: root.bat && root.bat.healthPercentage < 70 ? Theme.privacyMic : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }
    }

    SettingRow {
        visible: root.bat !== null && Power.chargeLimitSupported
        title: Tr.t("Charge limit")
        description: Power.chargeMessage || Tr.t("Stops charging before 100%. Keeps the battery healthier if the laptop is plugged in most of the time.")
        icon: "battery_saver"

        Segmented {
            enabled: !Power.chargeBusy
            model: [100, 90, 80, 60].map(p => ({ id: String(p), label: p === 100 ? Tr.t("Off") : p + "%" }))
            current: String([100, 90, 80, 60].includes(Power.chargeLimit) ? Power.chargeLimit : 100)
            onSelected: id => Power.setChargeLimit(Number(id))
        }
    }

    // --- Profile ---
    SectionLabel {
        visible: Power.profiles.length > 1
        text: Tr.t("Performance")
    }

    SettingRow {
        visible: Power.profiles.length > 1
        title: Tr.t("Power profile")
        description: Tr.t("Power saver uses less; Performance gives everything.")
        icon: "bolt"
        Segmented {
            model: Power.profiles.map(p => ({ id: p, label: Power.profileNames[p] ?? p }))
            current: Power.profile
            onSelected: id => Power.setProfile(id)
        }
    }

    Repeater {
        model: Power.hasBattery ? ["AC", "Battery"] : ["AC"]

        ColumnLayout {
            id: group
            required property string modelData
            readonly property var s: Power.settings[modelData] ?? {}
            readonly property var a: Power.actions[modelData] ?? {}

            Layout.fillWidth: true
            spacing: 8

            SectionLabel {
                text: !Power.hasBattery ? Tr.t("When the computer is idle")
                    : group.modelData === "AC" ? Tr.t("Plugged in") : Tr.t("On battery")
            }

            SettingRow {
                // Only on laptops: the profile follows the power source
                visible: Power.hasBattery && Power.profiles.length > 1
                title: Tr.t("Switch to profile")
                description: group.modelData === "AC" ? Tr.t("When the charger is connected.") : Tr.t("When the charger is unplugged.")
                icon: "bolt"
                Select {
                    options: [{ id: "", label: Tr.t("Keep the current one") }].concat(
                        Power.profiles.map(p => ({ id: p, label: Power.profileNames[p] ?? p })))
                    current: group.a.profile ?? ""
                    onSelected: id => Power.setAction(group.modelData, "profile", id)
                }
            }
            SettingRow {
                title: Tr.t("Dim screen")
                icon: "brightness_medium"
                Select {
                    options: root.times
                    current: String(group.s.dim ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "dim", Number(id))
                }
            }
            SettingRow {
                title: Tr.t("Turn off screen")
                icon: "desktop_access_disabled"
                Select {
                    options: root.times
                    current: String(group.s.off ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "off", Number(id))
                }
            }
            SettingRow {
                title: Tr.t("Sleep")
                icon: "bedtime"
                Select {
                    options: root.times
                    current: String(group.s.suspend ?? -1)
                    onSelected: id => Power.setIdle(group.modelData, "suspend", Number(id))
                }
            }
            SettingRow {
                visible: Power.lidPresent
                title: Tr.t("When the lid is closed")
                icon: "laptop_chromebook"
                Select {
                    options: ["1", "2", "8", "32", "64", "0"].map(id => ({ id, label: Power.actionNames[id] }))
                    current: group.a.lid ?? "1"
                    onSelected: id => Power.setAction(group.modelData, "lid", id)
                }
            }
            SettingRow {
                title: Tr.t("Power button")
                icon: "power_settings_new"
                Select {
                    options: ["16", "1", "2", "8", "32", "64", "0"].map(id => ({ id, label: Power.actionNames[id] }))
                    current: group.a.button ?? "16"
                    onSelected: id => Power.setAction(group.modelData, "button", id)
                }
            }
        }
    }

    SettingRow {
        visible: Power.lidPresent
        title: Tr.t("Ignore the lid with a monitor connected")
        description: Tr.t("Closing the lid does nothing while an external screen is in use.")
        icon: "monitor"
        Toggle {
            checked: Power.lidExternalIgnore
            onToggled: on => Power.setLidExternalIgnore(on)
        }
    }

    SectionLabel { text: Tr.t("Screen lock") }

    SettingRow {
        title: Tr.t("Lock automatically")
        description: Tr.t("Asks for the password after a while without using the computer.")
        icon: "lock_clock"
        Toggle {
            checked: Power.autolock
            onToggled: on => Power.setLock("Autolock", on)
        }
    }

    SettingRow {
        visible: Power.autolock
        title: Tr.t("Lock after")
        icon: "timer"
        Select {
            options: [1, 2, 5, 10, 15, 30, 60].map(m => ({ id: String(m), label: m === 60 ? Tr.t("1 hour") : m + (m === 1 ? Tr.t(" minute") : Tr.t(" minutes")) }))
            current: String(Power.lockMinutes)
            onSelected: id => Power.setLock("Timeout", id)
        }
    }

    SettingRow {
        title: Tr.t("Lock on wake")
        description: Tr.t("After sleep, asks for the password.")
        icon: "lock"
        Toggle {
            checked: Power.lockOnResume
            onToggled: on => Power.setLock("LockOnResume", on)
        }
    }
}
