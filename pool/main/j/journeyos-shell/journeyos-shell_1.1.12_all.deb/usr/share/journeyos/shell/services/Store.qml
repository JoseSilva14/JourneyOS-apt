pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// App store (scripts/store.py), shown in the dashboard Apps tab ("Store"). Sources:
//  - Debian's apps (AppStream catalogue with icons, installed through PackageKit: password window);
//  - a few apps from their makers' repositories (VS Code, Chrome, Steam…: /usr/lib/journeyos/store-vendor);
//  - Flathub, only when turned on (config store.flathub; Flatpak apps for the user, no password).
// Debian's and the makers' apps update with the system (Settings → Updates). Also notices an NVIDIA
// card without NVIDIA's driver.
Singleton {
    id: root

    readonly property bool flathubOn: Config.options.store.flathub

    property bool ready: false          // Debian's catalogue is there
    property bool loaded: false         // status read at least once
    property bool flatpak: false        // flatpak is installed
    property bool flathub: false        // Flathub added (and turned on)
    property var installed: []          // [id]
    property var flatpakApps: []        // [{ id, name, version }] (also when Flathub is off)
    property var protectedPkgs: []      // the system's own packages: no Remove
    property var updates: []            // [id] (Flatpak apps)
    property var nvidia: ({ present: false })
    property var catalog: []            // [{ id, source, from, pkg, desktop, name, summary, icon, kw }]

    // The running job: index | refresh | setup | install | remove | update (one at a time)
    property string job: ""
    property string jobApp: ""
    property int progress: -1
    property string progressText: ""
    property string error: ""
    property var queue: []

    // Shown with no search: well-known apps (makers' IDs and Debian package names)
    readonly property var featuredIds: [
        "vendor:chrome", "vendor:code", "vendor:discord", "vendor:spotify", "vendor:steam", "vendor:brave",
        "vendor:signal", "deb-pkg:vlc", "deb-pkg:gimp", "deb-pkg:libreoffice-writer", "deb-pkg:obs-studio",
        "deb-pkg:krita", "deb-pkg:inkscape", "deb-pkg:kdenlive", "deb-pkg:blender", "deb-pkg:thunderbird",
        "deb-pkg:telegram-desktop", "deb-pkg:keepassxc", "deb-pkg:audacity", "deb-pkg:qbittorrent"
    ]
    readonly property var featured: featuredIds.map(id => id.startsWith("deb-pkg:")
            ? catalog.find(a => a.source === "debian" && a.pkg === id.slice(8))
            : catalog.find(a => a.id === id)).filter(a => a)

    function isInstalled(id) { return installed.includes(id); }
    function busyWith(id) { return jobApp === id || queue.some(j => j.app === id); }
    // The system's own apps (Dolphin, Firefox…) cannot be removed from here
    function canRemove(app) {
        return isInstalled(app.id) && !((app.source === "debian" || app.source === "vendor") && protectedPkgs.includes(app.pkg));
    }

    // Catalogue search: name start > word in name > name > keywords/summary; the makers' apps first on a tie
    function search(q) {
        const t = q.trim().toLowerCase();
        if (!t)
            return [];
        const scored = [];
        for (const a of catalog) {
            const n = a.name.toLowerCase();
            let s = 0;
            if (n === t) s = 100;
            else if (n.startsWith(t)) s = 80;
            else if (n.split(/[\s\-.]+/).some(w => w.startsWith(t))) s = 60;
            else if (n.includes(t)) s = 40;
            else if (a.kw.includes(t) || a.pkg.toLowerCase().includes(t)) s = 20;
            else if (a.summary.toLowerCase().includes(t)) s = 10;
            if (s)
                scored.push({ a, s: s + (a.source === "vendor" ? 5 : 0) });
        }
        return scored.sort((x, y) => y.s - x.s || x.a.name.localeCompare(y.a.name)).slice(0, 60).map(x => x.a);
    }

    // The ones the user installed (not the system's own) with their catalogue info, alphabetical
    readonly property var installedApps: installed.map(id => catalog.find(a => a.id === id)
            ?? flatpakApps.filter(f => f.id === id).map(f => ({ id: f.id, source: "flathub", from: "Flathub",
                pkg: f.id.slice(8), desktop: f.id.slice(8), name: f.name, summary: f.version, icon: "", kw: "" }))[0])
        .filter(a => a && canRemove(a))
        .sort((x, y) => x.name.localeCompare(y.name))

    function refresh() {
        if (!status.running)
            status.running = true;
    }

    function enqueue(kind, app) {
        if (queue.some(j => j.kind === kind && j.app === app) || (job === kind && jobApp === app))
            return;
        queue = [...queue, { kind, app }];
        next();
    }
    function setup() { enqueue("setup", ""); }
    function refreshCatalog() { enqueue("refresh", ""); }
    function install(id) { enqueue("install", id); }
    function remove(id) { enqueue("remove", id); }
    function updateAll() { enqueue("update", ""); }

    function next() {
        if (job || queue.length === 0)
            return;
        const j = queue[0];
        queue = queue.slice(1);
        job = j.kind;
        jobApp = j.app;
        progress = -1;
        progressText = "";
        error = "";
        runner.command = ["env", ...root.env, Quickshell.shellPath("scripts/store.py"), j.kind, ...(j.app ? [j.app] : [])];
        runner.running = true;
    }

    readonly property var env: ["SHADOW_LANG=" + Tr.lang, "SHADOW_STORE_FLATHUB=" + (flathubOn ? "1" : "0")]

    function open(app) {
        if (app.source === "flathub") {
            Apps.run(["flatpak", "run", app.pkg]);
            return;
        }
        // By its .desktop name; makers rename theirs (VS Code's is com.microsoft.VSCode): then by name
        const entry = DesktopEntries.byId(app.desktop) ?? DesktopEntries.byId(app.pkg)
            ?? DesktopEntries.applications.values.find(e => !e.noDisplay && e.name.toLowerCase() === app.name.toLowerCase());
        if (entry)
            Apps.launch(entry, null);
        else
            Events.push({ icon: "error", title: Tr.t("App not found"), text: app.name, duration: 2500 });
    }

    function installNvidia() {
        Apps.run(["konsole", "-e", "env", "SHADOW_LANG=" + Tr.lang, Quickshell.shellPath("scripts/nvidia-driver.sh")]);
    }

    Process {
        id: status
        command: ["env", ...root.env, Quickshell.shellPath("scripts/store.py"), "status"]
        stdout: StdioCollector {
            onStreamFinished: {
                let s = null;
                try {
                    s = JSON.parse(text);
                } catch (e) {}
                root.loaded = true;
                if (!s)
                    return;
                root.ready = s.ready;
                root.flatpak = s.flatpak;
                root.flathub = s.flathub;
                root.installed = s.installed ?? [];
                root.flatpakApps = s.flatpakApps ?? [];
                root.protectedPkgs = s.protected ?? [];
                root.updates = s.updates ?? [];
                root.nvidia = s.nvidia ?? { present: false };
                // The catalogue is made again when apt brought a new one (or the settings changed)
                if (s.stale && s.ready)
                    root.enqueue("index", "");
                else
                    catalogFile.reload();
            }
        }
    }

    // Flathub turned on or off: the catalogue changes
    onFlathubOnChanged: refresh()

    Process {
        id: runner
        stdout: SplitParser {
            onRead: line => {
                let r;
                try {
                    r = JSON.parse(line);
                } catch (e) {
                    return;
                }
                if (r.done) {
                    if (!r.ok)
                        root.error = r.error === "cancelled" ? "" : (r.error || Tr.t("Something went wrong"));
                    return;
                }
                root.progress = r.progress ?? -1;
                if (r.text)
                    root.progressText = r.text;
            }
        }
        onExited: code => {
            const finished = root.job, app = root.jobApp;
            if (code === 0 && (finished === "install" || finished === "remove")) {
                const name = root.catalog.find(a => a.id === app)?.name ?? app;
                Events.push({
                    icon: finished === "install" ? "download_done" : "delete",
                    title: finished === "install" ? Tr.t("App installed") : Tr.t("App removed"),
                    text: name, duration: 2500
                });
            }
            root.job = "";
            root.jobApp = "";
            if (finished === "index" || finished === "refresh" || finished === "setup")
                catalogFile.reload();
            root.refresh();
            root.next();
        }
    }

    FileView {
        id: catalogFile
        path: (Quickshell.env("XDG_CACHE_HOME") || Quickshell.env("HOME") + "/.cache") + "/journeyos/store-v2.json"
        printErrors: false
        blockLoading: false
        onLoaded: {
            try {
                root.catalog = JSON.parse(text()).apps ?? [];
            } catch (e) {
                root.catalog = [];
            }
        }
    }

    // Installed apps and Flatpak updates are looked at again every 6 h
    Timer {
        interval: 6 * 3600 * 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    // An NVIDIA card without its driver: say so once per session (the store has the button)
    property bool nvidiaAnnounced: false
    onNvidiaChanged: if (nvidia.present && !nvidia.driver && !nvidia.installed && !nvidiaAnnounced) announce.start()
    Timer {
        id: announce
        interval: 15000        // not right at startup (the pill ignores alerts then)
        onTriggered: {
            root.nvidiaAnnounced = true;
            Events.push({ icon: "memory", title: Tr.t("NVIDIA driver available"),
                text: Tr.t("Install it in Settings → Screen → Graphics card"), duration: 6000 });
        }
    }

    IpcHandler {
        target: "store"
        function status(): string {
            return JSON.stringify({ ready: root.ready, flathub: root.flathub, catalog: root.catalog.length,
                installed: root.installed, updates: root.updates, job: root.job, app: root.jobApp,
                progress: root.progress, text: root.progressText, error: root.error, nvidia: root.nvidia });
        }
        function setup(): void { root.setup(); }
        function refresh(): void { root.refreshCatalog(); }
        function install(id: string): void { root.install(id); }
        function remove(id: string): void { root.remove(id); }
        function search(q: string): string { return root.search(q).slice(0, 5).map(a => a.id).join(" "); }
    }
}
