#!/usr/bin/env python3
"""Default apps (browser, email, files, terminal…).

  default-apps.py list              → JSON { category: { current, candidates: [{ id, name, icon }], others: [...] } }
  default-apps.py set <cat> <id>    → chooses (xdg-mime default; the terminal goes to kdeglobals)

The candidates are the apps (hidden entries too) whose MimeType includes the type (reads the .desktop files: Debian has no
mimeinfo.cache); for the terminal, the apps in the TerminalEmulator category. "others" are the rest of the visible apps:
one that doesn't declare the type can still be chosen (an editor installed later, for example).
"""

import configparser
import json
import os
import subprocess
import sys

CATEGORIES = {
    "browser": ["x-scheme-handler/http", "x-scheme-handler/https", "text/html"],
    "email": ["x-scheme-handler/mailto"],
    "files": ["inode/directory"],
    "text": ["text/plain"],
    "image": ["image/png", "image/jpeg", "image/webp", "image/gif"],
    "video": ["video/mp4", "video/x-matroska", "video/webm"],
    "music": ["audio/mpeg", "audio/flac", "audio/ogg"],
    "pdf": ["application/pdf"],
    "terminal": [],
}

DIRS = [os.path.expanduser("~/.local/share/applications"), "/usr/local/share/applications",
        "/usr/share/applications", "/var/lib/flatpak/exports/share/applications",
        os.path.expanduser("~/.local/share/flatpak/exports/share/applications")]


def entries():
    seen = {}
    for d in DIRS:
        try:
            files = os.listdir(d)
        except OSError:
            continue
        for f in files:
            if not f.endswith(".desktop") or f in seen:
                continue
            p = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                p.read(os.path.join(d, f), encoding="utf-8")
                e = p["Desktop Entry"]
            except (configparser.Error, KeyError, UnicodeDecodeError):
                continue
            # NoDisplay ones stay: some apps only open a type through a hidden entry
            # (Okular's PDF one is okularApplication_pdf.desktop)
            if e.get("Hidden", "false") == "true":
                continue
            seen[f] = {
                "id": f,
                "visible": e.get("NoDisplay", "false") != "true" and e.get("Type", "Application") == "Application"
                           and bool(e.get("Exec", "")),
                "name": e.get("Name[pt_PT]") or e.get("Name[pt]") or e.get("Name", f),
                "icon": e.get("Icon", ""),
                "mimes": [m for m in e.get("MimeType", "").split(";") if m],
                "categories": [c for c in e.get("Categories", "").split(";") if c],
                "exec": e.get("Exec", ""),
            }
    return list(seen.values())


def run(*cmd):
    return subprocess.run(cmd, capture_output=True, text=True).stdout.strip()


def listing():
    all_entries = entries()
    out = {}
    for cat, mimes in CATEGORIES.items():
        if cat == "terminal":
            cands = [e for e in all_entries if "TerminalEmulator" in e["categories"]]
            current = run("kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "TerminalService")
            if not current:
                app = run("kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "TerminalApplication") or "konsole"
                current = next((e["id"] for e in cands if e["exec"].split()[0].endswith(app)), "")
        else:
            cands = [e for e in all_entries if mimes[0] in e["mimes"]]
            current = run("xdg-mime", "query", "default", mimes[0])
        ids = {e["id"] for e in cands}
        # The terminal must be a terminal; for the rest, any visible app may be chosen
        others = [] if cat == "terminal" else [e for e in all_entries if e["visible"] and e["id"] not in ids
                                                and not e["id"].startswith("shadow-kde-")]
        out[cat] = {
            "current": current,
            "candidates": sorted(({"id": e["id"], "name": e["name"], "icon": e["icon"]} for e in cands),
                                 key=lambda c: c["name"].lower()),
            "others": sorted(({"id": e["id"], "name": e["name"], "icon": e["icon"]} for e in others),
                             key=lambda c: c["name"].lower()),
        }
    return out


def set_default(cat, desktop_id):
    if cat == "terminal":
        e = next((e for e in entries() if e["id"] == desktop_id), None)
        if not e:
            return 1
        binary = os.path.basename(e["exec"].split()[0])
        run("kwriteconfig6", "--notify", "--file", "kdeglobals", "--group", "General", "--key", "TerminalApplication", binary)
        run("kwriteconfig6", "--notify", "--file", "kdeglobals", "--group", "General", "--key", "TerminalService", desktop_id)
        return 0
    for mime in CATEGORIES[cat]:
        run("xdg-mime", "default", desktop_id, mime)
    return 0


if __name__ == "__main__":
    if sys.argv[1:2] == ["list"]:
        print(json.dumps(listing()))
    elif sys.argv[1:2] == ["set"] and len(sys.argv) == 4 and sys.argv[2] in CATEGORIES:
        sys.exit(set_default(sys.argv[2], sys.argv[3]))
    else:
        print(__doc__, file=sys.stderr)
        sys.exit(1)
