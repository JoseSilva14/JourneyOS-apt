import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services
import "../settings/pages"

// Passwords as its own app: a normal window (KWin decoration, shows in the dock as "Passwords")
// with the page settings/pages/PasswordsPage (no longer in Settings). The page only exists while
// the window is open: closing it forgets what was being edited and hides shown passwords again.
FloatingWindow {
    id: root

    title: Tr.t("Passwords")
    visible: Passwords.appOpen
    implicitWidth: 680
    implicitHeight: Math.min(720, (Quickshell.screens[0]?.height ?? 800)
        - Theme.barZone - (Config.options.dock.enabled ? Theme.dockHeight + Theme.gap : 0)
        - Theme.windowTitleHeight - Theme.gap * 2)
    color: Theme.bg

    onVisibleChanged: if (!visible) Passwords.appOpen = false

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Passwords.appOpen = false

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            anchors.rightMargin: 6
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                Layout.rightMargin: 14
                spacing: 12

                Image {
                    source: Quickshell.shellPath("assets/icons/palavras-passe.svg")
                    sourceSize: Qt.size(40, 40)
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: Tr.t("Passwords")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontLarge
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.fillWidth: true
                        text: !Passwords.available ? Tr.t("The passwords store isn't running")
                            : Passwords.locked ? Tr.t("Locked")
                            : Passwords.mine.length + Tr.t(" saved by you · ") + Passwords.fromApps.length + Tr.t(" saved by apps")
                        color: Theme.dim
                        elide: Text.ElideRight
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            Loader {
                Layout.fillWidth: true
                Layout.fillHeight: true
                active: root.visible
                sourceComponent: PasswordsPage {}
            }
        }
    }
}
