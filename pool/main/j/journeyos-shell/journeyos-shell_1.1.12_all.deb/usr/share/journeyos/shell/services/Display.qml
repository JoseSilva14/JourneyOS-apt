pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Displays (kscreen-doctor) and night light (kwinrc [NightColor] + KWin's D-Bus). Changing
// resolution/scale/rotation/arrangement asks for confirmation: with no answer in 15 s, it reverts.
// Variable refresh rate, HDR and wide colour gamut only show for screens that can do them (the JSON
// does not say: "kscreen-doctor -o" does). "Identify" shows each screen's name on it (settings/IdentifyWindow).
Singleton {
    id: root

    property var outputs: []            // from kscreen-doctor -j
    property var caps: ({})             // name → { vrr, hdr, wcg }: "incapable" or the current value
    property bool identifying: false
    property var pending: null          // { previous: [arguments to restore] } awaiting confirmation
    property int countdown: 0

    // Night light
    property bool nightEnabled: false
    property string nightMode: "Constant"    // Constant | Times | Location (Automatic needs a location service)
    property int nightTemperature: 4500
    property string eveningBegin: "1800"
    property string morningBegin: "0600"
    // "Sunset to sunrise" uses the weather's place (Settings → Weather): KWin needs coordinates
    readonly property string location: Config.options.weather.location ?? ""
    readonly property bool hasCoordinates: /^-?\d+(\.\d+)?,\s*-?\d+(\.\d+)?$/.test(location)

    readonly property var rotations: [
        { id: "normal", label: Tr.t("Normal"), value: 1 },
        { id: "left", label: Tr.t("90° left"), value: 2 },
        { id: "inverted", label: "180°", value: 4 },
        { id: "right", label: Tr.t("90° right"), value: 8 }
    ]

    function refresh() {
        Run.cmd(["kscreen-doctor", "-j"], (code, out) => {
            try {
                root.outputs = JSON.parse(out).outputs.filter(o => o.connected);
            } catch (e) {
                console.warn("display: invalid reply from kscreen-doctor");
            }
        });
        Run.cmd(["kscreen-doctor", "-o"], (code, out) => {
            const c = {};
            let name = "";
            for (const raw of out.replace(/\x1b\[[0-9;]*m/g, "").split("\n")) {
                const line = raw.trim();
                const head = line.match(/^Output:\s+\d+\s+(\S+)/);
                if (head) {
                    name = head[1];
                    c[name] = { vrr: "incapable", hdr: "incapable", wcg: "incapable" };
                    continue;
                }
                const m = line.match(/^(Vrr|HDR|Wide Color Gamut):\s*(.+)$/);
                if (name && m)
                    c[name][m[1] === "Vrr" ? "vrr" : m[1] === "HDR" ? "hdr" : "wcg"] = m[2].trim();
            }
            root.caps = c;
        });
        Kcfg.readMany("kwinrc", [
            { group: "NightColor", key: "Active", fallback: "false" },
            { group: "NightColor", key: "Mode", fallback: "Constant" },
            { group: "NightColor", key: "NightTemperature", fallback: "4500" },
            { group: "NightColor", key: "EveningBeginFixed", fallback: "1800" },
            { group: "NightColor", key: "MorningBeginFixed", fallback: "0600" }
        ], v => {
            root.nightEnabled = v["NightColor/Active"] === "true";
            root.nightMode = v["NightColor/Mode"];
            root.nightTemperature = Number(v["NightColor/NightTemperature"]) || 4500;
            root.eveningBegin = v["NightColor/EveningBeginFixed"];
            root.morningBegin = v["NightColor/MorningBeginFixed"];
        });
    }

    function rotationId(value) { return rotations.find(r => r.value === value)?.id ?? "normal"; }

    // kscreen-doctor arguments that restore a display's current state
    function stateArgs(o) {
        const out = ["output." + o.name + ".mode." + o.currentModeId,
            "output." + o.name + ".scale." + o.scale,
            "output." + o.name + ".rotation." + rotationId(o.rotation),
            "output." + o.name + ".position." + o.pos.x + "," + o.pos.y];
        return out;
    }

    // Size on the desktop (logical pixels: mode size over scale, turned on its side when rotated)
    function logicalSize(o) {
        const m = o.modes.find(x => x.id === o.currentModeId);
        let w = m ? m.size.width : o.size.width, h = m ? m.size.height : o.size.height;
        if (o.rotation === 2 || o.rotation === 8)
            [w, h] = [h, w];
        return { width: Math.round(w / o.scale), height: Math.round(h / o.scale) };
    }

    // places: [{ name, x, y }] in logical pixels. One call (kscreen-doctor applies it at once).
    function arrange(places) {
        const args = [], previous = [];
        for (const p of places) {
            const o = outputs.find(x => x.name === p.name);
            if (!o || (o.pos.x === p.x && o.pos.y === p.y))
                continue;
            args.push("output." + p.name + ".position." + p.x + "," + p.y);
            previous.push("output." + p.name + ".position." + o.pos.x + "," + o.pos.y);
        }
        if (!args.length)
            return;
        Run.cmd(["kscreen-doctor", ...args], () => {
            refresh();
            root.pending = { previous };
            root.countdown = 15;
            confirmTimer.restart();
        });
    }

    // The enabled screens as rectangles on the desktop, in logical pixels
    readonly property var rects: outputs.filter(o => o.enabled).map(o => {
        const s = logicalSize(o);
        return { name: o.name, x: o.pos.x, y: o.pos.y, w: s.width, h: s.height, primary: o.priority === 1 };
    })

    // Where a screen dropped at (x, y) ends up: touching the nearest side of another screen and, if
    // close, lined up with its edge (within an eighth of the screen). null if nowhere fits.
    function snap(name, x, y) {
        const me = rects.find(r => r.name === name);
        if (!me)
            return null;
        let best = null;
        for (const o of rects) {
            if (o.name === name)
                continue;
            const clampY = v => Math.max(o.y - me.h + 1, Math.min(o.y + o.h - 1, v));
            const clampX = v => Math.max(o.x - me.w + 1, Math.min(o.x + o.w - 1, v));
            const cands = [
                { x: o.x + o.w, y: clampY(y), side: true }, { x: o.x - me.w, y: clampY(y), side: true },
                { x: clampX(x), y: o.y + o.h, side: false }, { x: clampX(x), y: o.y - me.h, side: false }
            ];
            const tol = Math.max(me.w, me.h) / 8;
            for (const c of cands) {
                if (c.side) {
                    if (Math.abs(c.y - o.y) < tol) c.y = o.y;
                    else if (Math.abs(c.y + me.h - (o.y + o.h)) < tol) c.y = o.y + o.h - me.h;
                } else {
                    if (Math.abs(c.x - o.x) < tol) c.x = o.x;
                    else if (Math.abs(c.x + me.w - (o.x + o.w)) < tol) c.x = o.x + o.w - me.w;
                }
                const overlaps = rects.some(r => r.name !== name && c.x < r.x + r.w && c.x + me.w > r.x
                    && c.y < r.y + r.h && c.y + me.h > r.y);
                const d = Math.hypot(c.x - x, c.y - y);
                if (!overlaps && (!best || d < best.d))
                    best = { x: Math.round(c.x), y: Math.round(c.y), d };
            }
        }
        return best;
    }

    // Moves a screen to (about) x, y: snapped next to the others, and the whole desktop shifted so its
    // top-left corner is at 0,0. Asks for confirmation like the other changes.
    function place(name, x, y) {
        const spot = snap(name, x, y);
        if (!spot)
            return;
        const places = rects.map(r => r.name === name ? { name, x: spot.x, y: spot.y } : { name: r.name, x: r.x, y: r.y });
        const mx = Math.min(...places.map(p => p.x)), my = Math.min(...places.map(p => p.y));
        arrange(places.map(p => ({ name: p.name, x: p.x - mx, y: p.y - my })));
    }

    // what: vrr (never|always|automatic) | hdr | wcg (enable|disable)
    function setFeature(o, what, value) {
        const verb = what === "vrr" ? "vrrpolicy" : what;
        Run.cmd(["kscreen-doctor", "output." + o.name + "." + verb + "." + value], () => refresh());
    }

    function identify() {
        identifying = true;
        identifyTimer.restart();
    }

    Timer {
        id: identifyTimer
        interval: 3000
        onTriggered: root.identifying = false
    }

    // changes: { mode, scale, rotation, enabled, primary } (only those that change)
    function apply(o, changes) {
        const args = [];
        if (changes.mode !== undefined) args.push("output." + o.name + ".mode." + changes.mode);
        if (changes.scale !== undefined) args.push("output." + o.name + ".scale." + changes.scale);
        if (changes.rotation !== undefined) args.push("output." + o.name + ".rotation." + changes.rotation);
        if (changes.enabled !== undefined) args.push("output." + o.name + "." + (changes.enabled ? "enable" : "disable"));
        if (changes.primary) args.push("output." + o.name + ".priority.1");
        if (!args.length)
            return;
        const previous = stateArgs(o);
        Run.cmd(["kscreen-doctor", ...args], () => {
            refresh();
            // Becoming primary needs no confirmation; everything else does
            if (changes.mode !== undefined || changes.scale !== undefined || changes.rotation !== undefined || changes.enabled === false) {
                root.pending = { previous };
                root.countdown = 15;
                confirmTimer.restart();
            }
        });
    }

    function keep() {
        confirmTimer.stop();
        pending = null;
    }

    function revert() {
        confirmTimer.stop();
        if (pending)
            Run.cmd(["kscreen-doctor", ...pending.previous], () => refresh());
        pending = null;
    }

    Timer {
        id: confirmTimer
        interval: 1000
        repeat: true
        onTriggered: {
            root.countdown--;
            if (root.countdown <= 0)
                root.revert();
        }
    }

    // qs ipc call display ...: outputs (positions), place NAME X Y, keep, revert, identify
    IpcHandler {
        target: "display"
        function outputs(): string { root.refresh(); return JSON.stringify(root.rects); }
        function place(name: string, x: int, y: int): void { root.place(name, x, y); }
        function keep(): void { root.keep(); }
        function revert(): void { root.revert(); }
        function identify(): void { root.identify(); }
        function pending(): string { return root.pending ? String(root.countdown) : ""; }
        // Night light: on/off and when (Constant | Times | Location)
        function night(on: bool): void { root.setNightEnabled(on); }
        function nightSchedule(when: string): void { root.setNightSchedule(when); }
    }

    // --- Night light ---
    // Turning it on in automatic mode (KWin's default) does nothing without a location:
    // switch to "Always"
    function setNightEnabled(on) {
        if (on && nightMode !== "Constant" && nightMode !== "Times" && !(nightMode === "Location" && hasCoordinates))
            Kcfg.write("kwinrc", "NightColor", "Mode", "Constant", () => setNight("Active", true));
        else
            setNight("Active", on);
    }

    // when: Constant (always) | Times (the hours below) | Location (sunset to sunrise, at the weather's place)
    function setNightSchedule(when) {
        if (when === "Location") {
            const [lat, lon] = location.split(",").map(Number);
            if (!hasCoordinates || isNaN(lat) || isNaN(lon))
                return;
            Kcfg.write("kwinrc", "NightColor", "LatitudeFixed", String(lat), () =>
                Kcfg.write("kwinrc", "NightColor", "LongitudeFixed", String(lon), () => setNight("Mode", "Location")));
        } else {
            setNight("Mode", when);
        }
    }

    function setNight(key, value) {
        Kcfg.write("kwinrc", "NightColor", key, value, () => {
            Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/KWin",
                "--method", "org.kde.KWin.reconfigure"], () => refresh());
        });
    }

    // Shows the temperature while choosing (KWin reverts on its own after a few seconds)
    function preview(kelvin) {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/org/kde/KWin/NightLight",
            "--method", "org.kde.KWin.NightLight.preview", String(kelvin)]);
    }

    function stopPreview() {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", "/org/kde/KWin/NightLight",
            "--method", "org.kde.KWin.NightLight.stopPreview"]);
    }
}
