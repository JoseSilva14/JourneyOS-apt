pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Services.UPower

// Power: profile (powerprofilesctl), dimming/turning off the screen and suspending (powerdevilrc, per
// "AC" = plugged in and "Battery") and automatic locking (kscreenlockerrc, from kscreenlocker).
// Also, per power source: the profile powerdevil switches to, what closing the lid and pressing the
// power button do; and the battery: its state and health (UPower) and the charge limit
// (/usr/lib/journeyos/battery-limit through pkexec; the sysfs control is read directly).
Singleton {
    id: root

    readonly property bool hasBattery: UPower.displayDevice?.isLaptopBattery ?? false
    // The real battery (the display device is a sum of all of them and has no health)
    readonly property var battery: UPower.devices.values.find(d => d.isLaptopBattery) ?? null

    // For the bar: all batteries together (0-100), charging, and the icon for that level
    readonly property var displayDevice: UPower.displayDevice
    readonly property real batteryPercent: {
        const p = displayDevice?.percentage ?? 0;
        return p > 1 ? p : p * 100;     // Quickshell gives 0-1
    }
    readonly property bool charging: displayDevice?.state === UPowerDeviceState.Charging
    readonly property bool pluggedIn: !UPower.onBattery
    readonly property bool batteryLow: !pluggedIn && batteryPercent <= 15
    readonly property string batteryIcon: charging ? "battery_charging_full"
        : batteryLow ? "battery_alert"
        : batteryPercent >= 95 ? "battery_full"
        : "battery_" + Math.max(0, Math.min(6, Math.floor(batteryPercent / 100 * 7))) + "_bar"
    readonly property string batteryText: Math.round(batteryPercent) + "%"

    property bool lidPresent: false
    // Per profile: { lid, button, profile } (powerdevil action codes; profile "" = leave it)
    property var actions: ({ AC: {}, Battery: {} })
    property bool lidExternalIgnore: true

    property bool chargeLimitSupported: false
    property int chargeLimit: 100           // 100 = no limit
    property string chargeMessage: ""
    property bool chargeBusy: false

    // powerdevil's actions (PowerButtonAction enum)
    readonly property var actionNames: ({
        "0": Tr.t("Do nothing"), "1": Tr.t("Sleep"), "2": Tr.t("Hibernate"), "8": Tr.t("Shut down"),
        "16": Tr.t("Ask what to do"), "32": Tr.t("Lock the screen"), "64": Tr.t("Turn off the screen")
    })

    property string profile: ""
    property var profiles: []           // ["power-saver", "balanced", "performance"]

    // Per powerdevil profile: { dim, off, suspend } in seconds (-1 = never), suspendAction
    property var settings: ({ AC: {}, Battery: {} })

    property bool autolock: false
    property int lockMinutes: 5
    property bool lockOnResume: true

    readonly property var profileNames: ({
        "power-saver": Tr.t("Power saver"), "balanced": Tr.t("Balanced"), "performance": Tr.t("Performance")
    })
    readonly property var profileIcons: ({ "power-saver": "eco", "balanced": "balance", "performance": "speed" })

    function refresh() {
        refreshProfile();
        refreshRest();
    }

    // Only the power mode (the quick panel reads it each time it opens: powerdevil can change it)
    function refreshProfile() {
        Run.cmd(["powerprofilesctl", "list"], (code, out) => {
            const list = [];
            let current = "";
            for (const line of out.split("\n")) {
                const m = line.match(/^(\*)?\s*([a-z-]+):$/);
                if (m) {
                    list.push(m[2]);
                    if (m[1])
                        current = m[2];
                }
            }
            root.profiles = list;
            root.profile = current;
        });
    }

    function refreshRest() {
        const keys = [];
        for (const p of ["AC", "Battery"]) {
            keys.push({ group: [p, "Display"], key: "DimDisplayWhenIdle", fallback: "true" });
            keys.push({ group: [p, "Display"], key: "DimDisplayIdleTimeoutSec", fallback: "300" });
            keys.push({ group: [p, "Display"], key: "TurnOffDisplayWhenIdle", fallback: "true" });
            keys.push({ group: [p, "Display"], key: "TurnOffDisplayIdleTimeoutSec", fallback: "600" });
            keys.push({ group: [p, "SuspendAndShutdown"], key: "AutoSuspendAction", fallback: "1" });
            keys.push({ group: [p, "SuspendAndShutdown"], key: "AutoSuspendIdleTimeoutSec", fallback: "900" });
            // powerdevil's defaults: lid sleeps, the button asks, the profile is left alone
            keys.push({ group: [p, "SuspendAndShutdown"], key: "LidAction", fallback: "1" });
            keys.push({ group: [p, "SuspendAndShutdown"], key: "PowerButtonAction", fallback: "16" });
            keys.push({ group: [p, "Performance"], key: "PowerProfile", fallback: "" });
        }
        keys.push({ group: ["AC", "SuspendAndShutdown"], key: "InhibitLidActionWhenExternalMonitorPresent", fallback: "true" });
        Kcfg.readMany("powerdevilrc", keys, v => {
            const s = {};
            for (const p of ["AC", "Battery"]) {
                const g = k => v[p + "/" + k];
                s[p] = {
                    dim: g("Display/DimDisplayWhenIdle") === "true" ? Number(g("Display/DimDisplayIdleTimeoutSec")) : -1,
                    off: g("Display/TurnOffDisplayWhenIdle") === "true" ? Number(g("Display/TurnOffDisplayIdleTimeoutSec")) : -1,
                    suspend: g("SuspendAndShutdown/AutoSuspendAction") !== "0" ? Number(g("SuspendAndShutdown/AutoSuspendIdleTimeoutSec")) : -1
                };
            }
            root.settings = s;
            const a = {};
            for (const p of ["AC", "Battery"]) {
                a[p] = {
                    lid: v[p + "/SuspendAndShutdown/LidAction"],
                    button: v[p + "/SuspendAndShutdown/PowerButtonAction"],
                    profile: v[p + "/Performance/PowerProfile"]
                };
            }
            root.actions = a;
            root.lidExternalIgnore = v["AC/SuspendAndShutdown/InhibitLidActionWhenExternalMonitorPresent"] !== "false";
        });
        Run.cmd(["busctl", "get-property", "org.freedesktop.UPower", "/org/freedesktop/UPower",
            "org.freedesktop.UPower", "LidIsPresent"], (code, out) => root.lidPresent = out.trim() === "b true");
        // The charge limit: the first battery with the control (all of them get the same value)
        Run.sh('for f in /sys/class/power_supply/*/charge_control_end_threshold; do [ -r "$f" ] && cat "$f" && exit 0; done; exit 1',
            (code, out) => {
                root.chargeLimitSupported = code === 0;
                root.chargeLimit = code === 0 ? (Number(out.trim()) || 100) : 100;
            });
        Kcfg.readMany("kscreenlockerrc", [
            { group: "Daemon", key: "Autolock", fallback: "true" },
            { group: "Daemon", key: "Timeout", fallback: "5" },
            { group: "Daemon", key: "LockOnResume", fallback: "true" }
        ], v => {
            root.autolock = v["Daemon/Autolock"] === "true";
            root.lockMinutes = Number(v["Daemon/Timeout"]) || 5;
            root.lockOnResume = v["Daemon/LockOnResume"] === "true";
        });
    }

    function setProfile(name) {
        profile = name;     // the pill moves right away
        Run.cmd(["powerprofilesctl", "set", name], () => refreshProfile());
    }

    // what: dim | off | suspend; seconds: -1 = never
    function setIdle(p, what, seconds) {
        const never = seconds < 0;
        const done = () => Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.Solid.PowerManagement",
            "--object-path", "/org/kde/Solid/PowerManagement", "--method",
            "org.kde.Solid.PowerManagement.reparseConfiguration"], () => refresh());
        if (what === "suspend") {
            Kcfg.write("powerdevilrc", [p, "SuspendAndShutdown"], "AutoSuspendAction", never ? "0" : "1", () => {
                if (never)
                    done();
                else
                    Kcfg.write("powerdevilrc", [p, "SuspendAndShutdown"], "AutoSuspendIdleTimeoutSec", String(seconds), done);
            });
            return;
        }
        const prefix = what === "dim" ? "DimDisplay" : "TurnOffDisplay";
        Kcfg.write("powerdevilrc", [p, "Display"], prefix + "WhenIdle", !never, () => {
            if (never)
                done();
            else
                Kcfg.write("powerdevilrc", [p, "Display"], prefix + "IdleTimeoutSec", String(seconds), done);
        });
    }

    function reparse() {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.Solid.PowerManagement",
            "--object-path", "/org/kde/Solid/PowerManagement", "--method",
            "org.kde.Solid.PowerManagement.reparseConfiguration"], () => refresh());
    }

    // what: lid | button | profile; p: AC | Battery
    function setAction(p, what, value) {
        const group = what === "profile" ? [p, "Performance"] : [p, "SuspendAndShutdown"];
        const key = what === "lid" ? "LidAction" : what === "button" ? "PowerButtonAction" : "PowerProfile";
        Kcfg.write("powerdevilrc", group, key, String(value), reparse);
    }

    function setLidExternalIgnore(on) {
        Kcfg.write("powerdevilrc", ["AC", "SuspendAndShutdown"], "InhibitLidActionWhenExternalMonitorPresent", on, () =>
            Kcfg.write("powerdevilrc", ["Battery", "SuspendAndShutdown"], "InhibitLidActionWhenExternalMonitorPresent", on, reparse));
    }

    // percent: 50-100 (100 = no limit). Asks for the password (administrators).
    function setChargeLimit(percent) {
        chargeBusy = true;
        chargeMessage = "";
        Run.cmd(["pkexec", "/usr/lib/journeyos/battery-limit", "set", String(percent)], (code, out, err) => {
            chargeBusy = false;
            if (code === 126 || code === 127)
                chargeMessage = Tr.t("Not authorized");
            else if (code !== 0)
                chargeMessage = err.trim() || Tr.t("Could not change the charge limit");
            refresh();
        });
    }

    function setLock(key, value) {
        Kcfg.write("kscreenlockerrc", "Daemon", key, value, () => {
            Run.cmd(["gdbus", "call", "--session", "--dest", "org.freedesktop.ScreenSaver", "--object-path",
                "/ScreenSaver", "--method", "org.kde.screensaver.configure"], () => refresh());
        });
    }

}
