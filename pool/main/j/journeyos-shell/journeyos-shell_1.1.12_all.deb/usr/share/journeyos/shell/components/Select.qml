import QtQuick
import QtQuick.Controls as QQC
import QtQuick.Layouts
import qs
import qs.services

// Choice from a list (with search when it is long): button with the current value that opens the list.
// options: [{ id, label }] (or plain strings); current: id; selected(id).
Rectangle {
    id: root

    property var options: []
    property string current: ""
    property string placeholder: "Escolher…"
    property bool searchable: options.length > 12
    signal selected(string id)

    readonly property var normalized: options.map(o => typeof o === "string" ? { id: o, label: o } : o)
    readonly property string currentLabel: normalized.find(o => o.id === current)?.label ?? ""

    implicitWidth: 240
    implicitHeight: 36
    radius: Theme.radiusSmall + 2
    color: mouse.containsMouse || popup.opened ? Theme.buttonHover : Theme.button

    Behavior on color {
        ColorAnimation { duration: Theme.animFast }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 8
        spacing: 6

        Text {
            Layout.fillWidth: true
            text: root.currentLabel || root.placeholder
            elide: Text.ElideRight
            color: root.currentLabel ? Theme.text : Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
        }
        MIcon {
            icon: "expand_more"
            size: 18
            color: Theme.subtext
        }
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: popup.opened ? popup.close() : popup.open()
    }

    // Prefixed: without it, TextField here would be the QtQuick.Controls one
    QQC.Popup {
        id: popup

        // Below the button, or above it when there is more room there (near the bottom of the
        // window); never taller than the room on that side
        property bool above: false
        property real room: 340
        y: above ? -height - 4 : root.height + 4
        width: Math.max(root.width, 260)
        height: Math.min(column.implicitHeight + 12, 340, room)
        padding: 6
        modal: false
        focus: true
        closePolicy: QQC.Popup.CloseOnEscape | QQC.Popup.CloseOnPressOutside

        onAboutToShow: {
            const top = root.mapToItem(null, 0, 0).y;
            const winH = root.Window.height > 0 ? root.Window.height : top + 400;
            const below = winH - top - root.height - 12;
            const wanted = Math.min(column.implicitHeight + 12, 340);
            above = below < wanted && top - 12 > below;
            room = Math.max(120, above ? top - 12 : below);
        }

        property string query: ""
        readonly property var shown: {
            const q = query.trim().toLowerCase();
            return q ? root.normalized.filter(o => o.label.toLowerCase().includes(q) || o.id.toLowerCase().includes(q)) : root.normalized;
        }

        onOpened: {
            query = "";
            search.text = "";
            if (root.searchable)
                search.forceActiveFocus();
            const i = shown.findIndex(o => o.id === root.current);
            if (i >= 0)
                list.positionViewAtIndex(i, ListView.Center);
        }

        background: Rectangle {
            radius: Theme.radius
            color: Theme.surface
            border.width: 1
            border.color: Theme.surfaceBorder
        }

        contentItem: ColumnLayout {
            id: column
            spacing: 4

            TextField {
                id: search
                Layout.fillWidth: true
                visible: root.searchable
                placeholder: Tr.t("Search")
                onTextChanged: popup.query = text
            }

            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                implicitHeight: Math.min(contentHeight, 280)
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: popup.shown

                delegate: Rectangle {
                    id: item
                    required property var modelData
                    readonly property bool active: modelData.id === root.current

                    width: list.width
                    height: 32
                    radius: Theme.radiusSmall
                    // No transition, as in menus
                    color: active ? Theme.accent : itemMouse.containsMouse ? Theme.buttonHover : "transparent"

                    Text {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        text: item.modelData.label
                        elide: Text.ElideRight
                        color: item.active ? Theme.accentText : Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                    }

                    MouseArea {
                        id: itemMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            popup.close();
                            root.selected(item.modelData.id);
                        }
                    }
                }
            }
        }
    }
}
