pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import qs

// Global shortcuts via kglobalaccel (scripts/shortcuts.py). Keys come
// from config.json; those owned by another app go into "conflicts".
Singleton {
    id: root

    property var conflicts: ({})     // { action: owning component }

    function dispatch(action) {
        if (action === "launcher")
            Launcher.toggle(null);
        else if (action === "panel")
            QuickPanel.toggle(null);
        else if (action === "notifications")
            Notifs.toggleCenter(null);
        else if (action === "dashboard")
            Dashboard.toggle("home", null);
        else if (action === "wallpapers")
            Dashboard.toggle("wallpapers", null);
        else if (action === "widgets")
            Widgets.toggleEditing();
        else if (action === "settings")
            SettingsApp.toggle();
        else if (action === "clipboard")
            Clipboard.toggle(null);
        else if (action === "captureRegion")
            Capture.start("region");
        else if (action === "captureScreen")
            Capture.start("screen");
        else if (action === "captureWindow")
            Capture.start("window");
        else if (action === "colorPicker")
            Capture.start("color");
        else if (action.startsWith("custom-"))
            runCustom(action.slice(7));
        else {
            const tile = Tiling.layouts.find(l => l.shortcut === action);
            if (tile)
                Tiling.apply(tile.id);
        }
    }

    readonly property var keys: Config.options.shortcuts
    readonly property var custom: keys.custom ?? []

    // The user's own shortcuts: an app (by its .desktop entry) or a shell command
    function runCustom(id) {
        const c = custom.find(x => x.id === id);
        if (!c)
            return;
        if (c.app) {
            const entry = DesktopEntries.byId(c.app);
            if (entry)
                Apps.launch(entry, null);
            else
                Events.push({ icon: "error", title: Tr.t("App not found"), text: c.app, duration: 2500 });
        } else if (c.command) {
            Apps.run(["sh", "-c", c.command]);
        }
    }

    Process {
        id: helper
        running: Config.ready
        command: [Quickshell.shellPath("scripts/shortcuts.py"),
            "launcher=" + root.keys.launcher,
            "panel=" + root.keys.panel,
            "notifications=" + root.keys.notifications,
            "dashboard=" + root.keys.dashboard,
            "wallpapers=" + root.keys.wallpapers,
            "widgets=" + root.keys.widgets,
            "settings=" + root.keys.settings,
            "clipboard=" + root.keys.clipboard,
            "captureRegion=" + root.keys.captureRegion,
            "captureScreen=" + root.keys.captureScreen,
            "captureWindow=" + root.keys.captureWindow,
            "colorPicker=" + root.keys.colorPicker,
            "tileHalves=" + root.keys.tileHalves,
            "tileColumns=" + root.keys.tileColumns,
            "tileMain=" + root.keys.tileMain,
            "tileGrid=" + root.keys.tileGrid,
            ...root.custom.map(c => "custom-" + c.id + "=" + (c.keys ?? "") + "\t" + c.name)]
        stdinEnabled: true
        stdout: SplitParser {
            onRead: line => {
                const f = line.split(" ");
                if (f[0] === "pressed")
                    root.dispatch(f[1]);
                else if (f[0] === "conflict")
                    root.conflicts = Object.assign({}, root.conflicts, { [f[1]]: f[2] });
            }
        }
        onExited: restart.start()
        // Each registration starts with no conflicts (they come again from the helper)
        onRunningChanged: if (running) root.conflicts = {}
    }

    // Register again with the new keys: stopping it relaunches it (onExited). If it hasn't started
    // yet (keys read from config.json right at startup), stopping does nothing and nothing would
    // relaunch it: then the timer does
    function reload() {
        if (helper.running)
            helper.running = false;
        restart.restart();
    }

    // Crashed (kglobalaccel restarted, for example): relaunch
    Timer {
        id: restart
        interval: 3000
        onTriggered: helper.running = true
    }

    // Keys changed in config.json: register again (onExited relaunches)
    Connections {
        target: root.keys
        function onLauncherChanged() { root.reload(); }
        function onPanelChanged() { root.reload(); }
        function onNotificationsChanged() { root.reload(); }
        function onDashboardChanged() { root.reload(); }
        function onWallpapersChanged() { root.reload(); }
        function onWidgetsChanged() { root.reload(); }
        function onSettingsChanged() { root.reload(); }
        function onClipboardChanged() { root.reload(); }
        function onCaptureRegionChanged() { root.reload(); }
        function onCaptureScreenChanged() { root.reload(); }
        function onCaptureWindowChanged() { root.reload(); }
        function onColorPickerChanged() { root.reload(); }
        function onTileHalvesChanged() { root.reload(); }
        function onTileColumnsChanged() { root.reload(); }
        function onTileMainChanged() { root.reload(); }
        function onTileGridChanged() { root.reload(); }
        function onCustomChanged() { root.reload(); }
    }
}
