pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Claude plan limits (Claude Code): how much of the 5-hour and the weekly window is used, for the bar
// and its menu. Claude Code gives them to its status line (rate_limits, Pro/Max plans); the status line
// is scripts/claude-statusline.py, which saves them to ~/.cache/journeyos/claude-usage.json. So the
// numbers are as of the last answer in Claude Code ("updated"). connect()/disconnect() set that status
// line in ~/.claude/settings.json, keeping one the user already had (it still runs, after ours).
Singleton {
    id: root

    readonly property string home: Quickshell.env("HOME")
    readonly property string cachePath: home + "/.cache/journeyos/claude-usage.json"
    readonly property string script: Quickshell.shellPath("scripts/claude-statusline.py")

    property bool installed: false      // the claude command exists
    property bool connected: false      // our status line is set in ~/.claude/settings.json
    property bool hasData: false
    property var fiveHour: null         // { used 0-100, resetsAt epoch s }
    property var sevenDay: null
    property double updated: 0          // epoch s of the last answer that brought numbers
    property string model: ""
    property double now: Date.now() / 1000

    readonly property bool showInBar: Config.options.dev.claudeBar && hasData
    // A window whose reset time has passed starts again at 0
    function used(w) { return !w ? 0 : (w.resetsAt && w.resetsAt <= now ? 0 : w.used); }
    readonly property real fivePct: used(fiveHour)
    readonly property real weekPct: used(sevenDay)
    readonly property bool stale: updated > 0 && now - updated > 6 * 3600

    function refresh() {
        Run.sh('command -v claude >/dev/null || [ -x "$HOME/.local/bin/claude" ]', code => root.installed = code === 0);
        Run.cmd(["python3", "-c", "import json,os,sys\n"
            + "p=os.path.expanduser('~/.claude/settings.json')\n"
            + "try: d=json.load(open(p))\nexcept Exception: d={}\n"
            + "c=(d.get('statusLine') or {}).get('command','')\n"
            + "sys.exit(0 if 'claude-statusline.py' in c else 1)"], code => root.connected = code === 0);
        cache.reload();
    }

    // Sets our status line (the user's previous one, if any, is kept and still runs)
    function connect(done) {
        Run.cmd(["python3", "-c", "import json,os,sys\n"
            + "script=sys.argv[1]\n"
            + "p=os.path.expanduser('~/.claude/settings.json'); os.makedirs(os.path.dirname(p), exist_ok=True)\n"
            + "try: d=json.load(open(p))\nexcept FileNotFoundError: d={}\n"
            + "old=(d.get('statusLine') or {}).get('command','')\n"
            + "nxt=os.path.expanduser('~/.config/journeyos/claude-statusline-next')\n"
            + "if old and 'claude-statusline.py' not in old:\n"
            + "    os.makedirs(os.path.dirname(nxt), exist_ok=True); open(nxt,'w').write(old)\n"
            + "d['statusLine']={'type':'command','command':\"python3 '\"+script+\"'\"}\n"
            + "t=p+'.tmp'; json.dump(d,open(t,'w'),indent=2); os.replace(t,p)\n", script], code => {
            root.refresh();
            if (done)
                done(code === 0);
        });
    }

    // Puts back the user's previous status line (or none)
    function disconnect() {
        Run.cmd(["python3", "-c", "import json,os\n"
            + "p=os.path.expanduser('~/.claude/settings.json')\n"
            + "try: d=json.load(open(p))\nexcept Exception: raise SystemExit\n"
            + "nxt=os.path.expanduser('~/.config/journeyos/claude-statusline-next')\n"
            + "old=open(nxt).read().strip() if os.path.exists(nxt) else ''\n"
            + "if old: d['statusLine']={'type':'command','command':old}\n"
            + "else: d.pop('statusLine',None)\n"
            + "t=p+'.tmp'; json.dump(d,open(t,'w'),indent=2); os.replace(t,p)\n"
            + "os.path.exists(nxt) and os.remove(nxt)\n"], () => root.refresh());
    }

    function openClaude() { Apps.run(["konsole", "-e", "zsh", "-ic", "claude"]); }

    // "in 1 h 20 min" / "Friday 14:00"
    function resetText(epoch) {
        if (!epoch)
            return "";
        const s = Math.max(0, epoch - now);
        if (s < 3600)
            return Tr.t("in ") + Math.max(1, Math.round(s / 60)) + Tr.t(" min");
        if (s < 24 * 3600)
            return Tr.t("in ") + Math.floor(s / 3600) + Tr.t(" h ") + String(Math.floor(s % 3600 / 60)).padStart(2, "0") + Tr.t(" min")
                + " (" + DateTime.time(new Date(epoch * 1000)) + ")";
        const d = new Date(epoch * 1000);
        return d.toLocaleDateString(Qt.locale(Tr.locale), "dddd") + " " + DateTime.time(d);
    }

    function agoText(epoch) {
        const s = Math.max(0, now - epoch);
        if (s < 90)
            return Tr.t("just now");
        if (s < 3600)
            return Tr.t("") + Math.round(s / 60) + Tr.t(" min ago");
        if (s < 48 * 3600)
            return Tr.t("") + Math.round(s / 3600) + Tr.t(" h ago");
        return Tr.t("") + Math.round(s / 86400) + Tr.t(" days ago");
    }

    FileView {
        id: cache
        path: root.cachePath
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                const d = JSON.parse(text());
                const w = x => x ? { used: Number(x.used) || 0, resetsAt: Number(x.resets_at) || 0 } : null;
                root.fiveHour = w(d.five_hour);
                root.sevenDay = w(d.seven_day);
                root.updated = Number(d.updated) || 0;
                root.model = d.model ?? "";
                root.hasData = root.fiveHour !== null || root.sevenDay !== null;
            } catch (e) {
                root.hasData = false;
            }
        }
        onLoadFailed: root.hasData = false
    }

    // Countdowns and "x min ago" move on their own
    Timer {
        running: root.hasData
        interval: 30000
        repeat: true
        onTriggered: root.now = Date.now() / 1000
    }

    Component.onCompleted: refresh()

    IpcHandler {
        target: "claude"
        function status(): string {
            return JSON.stringify({ installed: root.installed, connected: root.connected, fiveHour: root.fivePct,
                week: root.weekPct, updated: root.updated, stale: root.stale });
        }
        function connect(): void { root.connect(null); }
        function disconnect(): void { root.disconnect(); }
    }
}
