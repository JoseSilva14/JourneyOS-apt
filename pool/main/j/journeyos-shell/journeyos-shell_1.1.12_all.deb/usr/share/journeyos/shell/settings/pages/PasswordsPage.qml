import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Passwords: the system's secret store (KWallet, opened at login with the login password). Your
// passwords (add, edit, copy, show, delete; a generator) and, below, what apps saved there (VS Code,
// browsers, git, Wi-Fi…), which can only be deleted. In the launcher: "pass name" copies one.
Page {
    id: root

    property string query: ""
    property var editing: null          // null | {} (new) | an item
    property bool showAllApps: false

    function matches(i) {
        const q = query.trim().toLowerCase();
        return !q || (i.label + " " + i.username + " " + i.url + " " + i.app).toLowerCase().includes(q);
    }
    readonly property var shownMine: Passwords.mine.filter(matches)
    readonly property var shownApps: Passwords.fromApps.filter(matches)

    function edit(item) {
        editing = item ?? {};
        name.text = item?.label ?? "";
        user.text = item?.username ?? "";
        url.text = item?.url ?? "";
        pass.text = "";
        pass.echoMode = TextInput.Password;
        name.grab();
    }

    Component.onCompleted: Passwords.refresh(true)
    Component.onDestruction: Passwords.conceal()

    // --- State of the store ---
    SettingRow {
        visible: Passwords.loaded && !Passwords.available
        title: Tr.t("The passwords store isn't running")
        description: Tr.t("KWallet provides it (kwallet6). Without it, apps keep their logins in plain files or ask every time.")
        icon: "error"
    }

    SettingRow {
        visible: Passwords.available && Passwords.locked
        title: Tr.t("Locked")
        description: Tr.t("It opens by itself when you log in with your password. It stays locked with automatic login, or after changing the password outside Settings: unlock it with the previous one.")
        icon: "lock"
        PillButton {
            text: Tr.t("Unlock")
            accent: true
            enabled: !Passwords.busy
            onClicked: Passwords.unlock()
        }
    }

    // --- Search and add ---
    RowLayout {
        Layout.fillWidth: true
        visible: Passwords.available && !Passwords.locked
        spacing: 8

        TextField {
            Layout.fillWidth: true
            placeholder: Tr.t("Search passwords")
            acceptOnBlur: false
            text: root.query
            onTextChanged: root.query = text
        }
        PillButton {
            text: Tr.t("Add##password")
            accent: true
            onClicked: root.edit(null)
        }
    }

    // --- New / edit ---
    Rectangle {
        Layout.fillWidth: true
        visible: root.editing !== null
        implicitHeight: form.implicitHeight + 32
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.accent

        ColumnLayout {
            id: form
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.margins: 16
            spacing: 10

            Text {
                Layout.fillWidth: true
                text: root.editing?.path ? Tr.t("Edit ") + root.editing.label : Tr.t("New password")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                TextField {
                    id: name
                    Layout.fillWidth: true
                    placeholder: Tr.t("Name (GitHub, bank…)")
                    acceptOnBlur: false
                }
                TextField {
                    id: user
                    Layout.fillWidth: true
                    placeholder: Tr.t("Username or email")
                    acceptOnBlur: false
                }
            }
            TextField {
                id: url
                Layout.fillWidth: true
                placeholder: Tr.t("Website (optional)")
                acceptOnBlur: false
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                TextField {
                    id: pass
                    Layout.fillWidth: true
                    echoMode: TextInput.Password
                    placeholder: root.editing?.path ? Tr.t("Password (empty keeps the current one)") : Tr.t("Password")
                    acceptOnBlur: false
                    onAccepted: save.clicked()
                }
                IconPill {
                    icon: pass.echoMode === TextInput.Password ? "visibility" : "visibility_off"
                    onClicked: pass.echoMode = pass.echoMode === TextInput.Password ? TextInput.Normal : TextInput.Password
                }
                PillButton {
                    text: Tr.t("Generate")
                    onClicked: Passwords.generate(pw => {
                        pass.text = pw;
                        pass.echoMode = TextInput.Normal;
                    })
                }
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Item { Layout.fillWidth: true }
                PillButton {
                    text: Tr.t("Cancel")
                    onClicked: root.editing = null
                }
                PillButton {
                    id: save
                    text: Tr.t("Save")
                    accent: true
                    enabled: !Passwords.busy && name.text.trim() !== "" && (pass.text !== "" || !!root.editing?.path)
                    onClicked: {
                        if (!enabled)
                            return;
                        Passwords.save({ path: root.editing?.path ?? "", label: name.text, username: user.text, url: url.text,
                            password: pass.text }, ok => {
                            if (ok) {
                                root.editing = null;
                                pass.text = "";
                            }
                        });
                    }
                }
            }
        }
    }

    // --- Yours ---
    SectionLabel {
        visible: Passwords.available && !Passwords.locked
        text: Tr.t("Your passwords")
    }

    Text {
        Layout.fillWidth: true
        visible: Passwords.available && !Passwords.locked && Passwords.loaded && root.shownMine.length === 0
        text: Passwords.mine.length ? Tr.t("Nothing matches.") : Tr.t("None yet. They're kept encrypted in your passwords store, which opens when you log in. In the launcher, \"pass name\" copies one (cleared from the clipboard after 30 s).")
        wrapMode: Text.Wrap
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: Passwords.available && !Passwords.locked ? root.shownMine : []

        SettingRow {
            id: row
            required property var modelData
            property bool confirm: false
            readonly property string shown: Passwords.revealed[modelData.path] ?? ""

            title: modelData.label
            description: shown !== "" ? shown : Passwords.describe(modelData)
            icon: "key"

            RowLayout {
                spacing: 6
                IconPill {
                    visible: row.modelData.username !== ""
                    icon: "person"
                    onClicked: Passwords.copy(row.modelData, "username")
                }
                IconPill {
                    icon: row.shown !== "" ? "visibility_off" : "visibility"
                    onClicked: row.shown !== "" ? Passwords.conceal() : Passwords.reveal(row.modelData)
                }
                IconPill {
                    icon: "edit"
                    onClicked: root.edit(row.modelData)
                }
                IconPill {
                    icon: "delete"
                    danger: row.confirm
                    onClicked: {
                        if (row.confirm)
                            Passwords.remove(row.modelData);
                        row.confirm = !row.confirm;
                    }
                }
                PillButton {
                    text: Tr.t("Copy")
                    accent: true
                    onClicked: Passwords.copy(row.modelData, "password")
                }
            }
        }
    }

    // --- Saved by apps ---
    SectionLabel {
        visible: Passwords.available && !Passwords.locked && Passwords.fromApps.length > 0
        text: Tr.t("Saved by apps")
    }

    Repeater {
        model: Passwords.available && !Passwords.locked ? (root.showAllApps ? root.shownApps : root.shownApps.slice(0, 5)) : []

        SettingRow {
            id: appRow
            required property var modelData
            property bool confirm: false
            title: modelData.label
            description: [modelData.app, Passwords.describe(modelData)].filter(x => x).join(" · ")
            icon: "apps"

            PillButton {
                text: appRow.confirm ? Tr.t("Delete?") : Tr.t("Delete")
                danger: appRow.confirm
                onClicked: {
                    if (appRow.confirm)
                        Passwords.remove(appRow.modelData);
                    appRow.confirm = !appRow.confirm;
                }
            }
        }
    }

    PillButton {
        visible: Passwords.available && !Passwords.locked && !root.showAllApps && root.shownApps.length > 5
        text: Tr.t("Show all (") + root.shownApps.length + ")"
        onClicked: root.showAllApps = true
    }

    // Round icon button
    component IconPill: Rectangle {
        id: pill
        property string icon: ""
        property bool danger: false
        signal clicked

        implicitWidth: 32
        implicitHeight: 32
        radius: 16
        color: danger ? Theme.privacyMic : mouse.containsMouse ? Theme.buttonHover : Theme.button

        MIcon {
            anchors.centerIn: parent
            icon: pill.icon
            size: 16
            color: pill.danger ? Theme.accentText : Theme.text
        }
        MouseArea {
            id: mouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
