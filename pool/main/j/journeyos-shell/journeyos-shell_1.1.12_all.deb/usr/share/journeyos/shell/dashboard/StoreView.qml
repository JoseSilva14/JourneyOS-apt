import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// App store (Apps tab → Store, services/Store): Debian's apps, a few from their makers (VS Code,
// Chrome, Steam…) and, when turned on below, Flathub's. No search: Flatpak updates, installed and
// featured apps; with a search: catalogue results. Each app says where it comes from. On top, the
// NVIDIA driver card when the computer has an NVIDIA card without its driver.
SmoothFlickable {
    id: root

    property string query: ""
    signal closeRequested

    readonly property var results: visible ? Store.search(query) : []
    readonly property int columns: Math.max(1, Math.floor(width / 300))

    contentHeight: column.implicitHeight + 8
    clip: true

    Component.onCompleted: Store.refresh()

    ColumnLayout {
        id: column
        width: root.width - 14
        spacing: Theme.gap

        // --- NVIDIA driver ---
        Card {
            visible: Store.nvidia.present && !Store.nvidia.driver && !Store.nvidia.installed
            icon: "memory"
            title: Tr.t("NVIDIA card: ") + (Store.nvidia.name ?? "")
            text: Tr.t("Install NVIDIA's driver for full performance (games, video). It opens a terminal and asks for your password; restart afterwards.")
            action: Tr.t("Install driver")
            onActivated: {
                Store.installNvidia();
                root.closeRequested();
            }
        }

        // --- Catalogue not there yet (before the first apt update) ---
        Card {
            visible: Store.loaded && !Store.ready && Store.job !== "refresh"
            icon: "storefront"
            title: Tr.t("The catalogue isn't downloaded yet")
            text: Tr.t("Debian's list of apps arrives with the first look for updates. Download it now?")
            action: Tr.t("Download")
            onActivated: Store.refreshCatalog()
        }
        Card {
            visible: Store.job === "refresh" || Store.job === "setup" || (Store.job === "index" && Store.catalog.length === 0)
            icon: "downloading"
            title: Store.job === "index" ? Tr.t("Preparing the catalogue…") : Tr.t("Getting the catalogue…")
            text: Store.progressText
            progress: Store.progress
        }
        Text {
            visible: Store.error !== "" && Store.job === ""
            Layout.fillWidth: true
            text: Tr.t("Error: ") + Store.error
            wrapMode: Text.Wrap
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }

        // --- Updates ---
        Card {
            visible: !root.query.trim() && (Store.updates.length > 0 || Store.job === "update")
            icon: "system_update"
            title: Store.job === "update" ? Tr.t("Updating…") : Store.updates.length + Tr.t(" Flathub app updates")
            text: Store.job === "update" ? Store.progressText : ""
            progress: Store.job === "update" ? Store.progress : -2
            action: Store.job === "update" ? "" : Tr.t("Update all")
            onActivated: Store.updateAll()
        }

        // --- Sections ---
        Section {
            visible: !root.query.trim() && Store.installedApps.length > 0
            title: Tr.t("Installed")
            apps: Store.installedApps
        }
        Section {
            visible: Store.catalog.length > 0 && !root.query.trim()
            title: Tr.t("Featured")
            apps: Store.featured
        }
        Section {
            visible: Store.catalog.length > 0 && root.query.trim() !== ""
            title: root.results.length ? Tr.t("Results") : Tr.t("Nothing found")
            apps: root.results
        }

        // --- Flathub (optional) ---
        Rectangle {
            Layout.fillWidth: true
            Layout.topMargin: 6
            visible: !root.query.trim() && Store.flatpak
            implicitHeight: flathubRow.implicitHeight + 24
            radius: Theme.radius
            color: Theme.surfaceCard

            RowLayout {
                id: flathubRow
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 14
                anchors.rightMargin: 12
                spacing: 12

                MIcon {
                    icon: "storefront"
                    size: 24
                    color: Theme.subtext
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: Tr.t("Flathub apps too")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontNormal
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.fillWidth: true
                        text: Store.flathubOn && !Store.flathub
                            ? Tr.t("Flathub isn't set up yet: it downloads its catalogue (a few minutes).")
                            : Tr.t("Flatpak versions: newer, installed just for you, but they take more space.")
                        wrapMode: Text.Wrap
                        color: Theme.subtext
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
                Pill {
                    visible: Store.flathubOn && !Store.flathub
                    label: Store.job === "setup" ? Tr.t("Setting up…") : Tr.t("Set up")
                    primary: true
                    available: Store.job === ""
                    onClicked: Store.setup()
                }
                Toggle {
                    checked: Store.flathubOn
                    onToggled: on => Config.options.store.flathub = on
                }
            }
        }
    }

    // A titled grid of apps
    component Section: ColumnLayout {
        id: section
        property string title: ""
        property var apps: []
        Layout.fillWidth: true
        spacing: 8

        Text {
            text: section.title
            color: Theme.subtext
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
            font.weight: Font.DemiBold
        }
        GridLayout {
            Layout.fillWidth: true
            columns: root.columns
            columnSpacing: 8
            rowSpacing: 8

            Repeater {
                model: section.apps
                AppCard {
                    required property var modelData
                    app: modelData
                }
            }
        }
    }

    // One app: icon, name, summary and install / open / remove
    component AppCard: Rectangle {
        id: card
        property var app: ({})
        readonly property bool installed: Store.isInstalled(app.id)
        readonly property bool busy: Store.busyWith(app.id)
        readonly property bool running: Store.jobApp === app.id

        Layout.fillWidth: true
        Layout.preferredWidth: 1
        implicitHeight: 72
        radius: Theme.radius
        color: cardMouse.containsMouse ? Theme.surfaceCardHover : Theme.surfaceCard

        MouseArea {
            id: cardMouse
            anchors.fill: parent
            hoverEnabled: true
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 10
            spacing: 12

            Item {
                implicitWidth: 44
                implicitHeight: 44
                Image {
                    id: icon
                    anchors.fill: parent
                    source: card.app.icon ? "file://" + card.app.icon : ""
                    sourceSize.width: 88
                    sourceSize.height: 88
                    asynchronous: true
                    smooth: true
                    visible: status === Image.Ready
                }
                Rectangle {
                    anchors.fill: parent
                    visible: icon.status !== Image.Ready
                    radius: 12
                    color: Theme.button
                    Text {
                        anchors.centerIn: parent
                        text: (card.app.name ?? "?").charAt(0).toUpperCase()
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 20
                        font.weight: Font.Bold
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 3
                Text {
                    Layout.fillWidth: true
                    text: card.app.name ?? ""
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    font.weight: Font.DemiBold
                }
                // Where it comes from, then the summary (or the progress)
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6
                    SourceBadge {
                        app: card.app
                    }
                    Text {
                        Layout.fillWidth: true
                        text: card.running && Store.progress >= 0 ? Store.progress + "%"
                            : card.running ? (Store.job === "remove" ? Tr.t("Removing…") : Tr.t("Downloading and installing…")) : card.busy ? Tr.t("Waiting…")
                            : (card.app.summary ?? "")
                        elide: Text.ElideRight
                        color: Theme.dim
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            // Remove (installed, on hover)
            Round {
                visible: Store.canRemove(card.app) && !card.busy && (cardMouse.containsMouse || hovered)
                glyph: "delete"
                onClicked: Store.remove(card.app.id)
            }
            Pill {
                label: card.busy ? (card.running ? (Store.job === "remove" ? Tr.t("Removing") : Tr.t("Installing")) : Tr.t("Queued"))
                    : card.installed ? Tr.t("Open") : Tr.t("Install")
                primary: !card.installed && !card.busy
                available: !card.busy
                onClicked: {
                    if (card.installed) {
                        Store.open(card.app);
                        root.closeRequested();
                    } else {
                        Store.install(card.app.id);
                    }
                }
            }
        }
    }

    // Where an app comes from: Debian (the system's own repository), its maker's repository
    // ("verified" mark: the official app), or Flathub (Flatpak)
    component SourceBadge: Rectangle {
        id: badge
        property var app: ({})
        readonly property string source: app.source ?? ""
        readonly property color tint: source === "debian" ? "#d70751" : source === "vendor" ? "#3b82f6" : "#8b5cf6"

        visible: source !== ""
        implicitWidth: badgeRow.implicitWidth + 12
        implicitHeight: 18
        radius: 9
        color: Qt.rgba(tint.r, tint.g, tint.b, 0.18)

        Row {
            id: badgeRow
            anchors.centerIn: parent
            spacing: 3
            MIcon {
                anchors.verticalCenter: parent.verticalCenter
                visible: badge.source === "vendor"
                icon: "verified"
                size: 11
                color: badge.tint
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: badge.source === "debian" ? "Debian" : badge.source === "flathub" ? "Flathub" : (badge.app.from ?? "")
                color: Qt.lighter(badge.tint, Theme.light ? 0.8 : 1.35)
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall - 1
                font.weight: Font.DemiBold
            }
        }
    }

    // Card with an icon, text, optional progress and an action
    component Card: Rectangle {
        id: info
        property string icon: ""
        property string title: ""
        property string text: ""
        property string action: ""
        property int progress: -2          // -2 = no bar, -1 = indeterminate
        signal activated

        Layout.fillWidth: true
        implicitHeight: infoRow.implicitHeight + 28
        radius: Theme.radius
        color: Theme.surfaceCard

        RowLayout {
            id: infoRow
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: 14
            anchors.rightMargin: 12
            spacing: 12

            MIcon {
                icon: info.icon
                size: 26
                color: Theme.text
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4
                Text {
                    Layout.fillWidth: true
                    text: info.title
                    wrapMode: Text.Wrap
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    font.weight: Font.DemiBold
                }
                Text {
                    Layout.fillWidth: true
                    visible: info.text !== ""
                    text: info.text
                    wrapMode: Text.Wrap
                    maximumLineCount: 3
                    elide: Text.ElideRight
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                }
                Rectangle {
                    visible: info.progress > -2
                    Layout.fillWidth: true
                    implicitHeight: 4
                    radius: 2
                    color: Theme.button
                    Rectangle {
                        height: parent.height
                        radius: 2
                        color: Theme.accent
                        width: info.progress >= 0 ? parent.width * info.progress / 100 : parent.width * 0.3
                        x: info.progress >= 0 ? 0 : (parent.width - width) * pulse.value
                        Behavior on width {
                            NumberAnimation { duration: Theme.animFast }
                        }
                    }
                    // Indeterminate: a sliding segment
                    NumberAnimation {
                        id: pulseAnim
                        target: pulse
                        property: "value"
                        from: 0
                        to: 1
                        duration: 1200
                        loops: Animation.Infinite
                        running: info.visible && info.progress === -1
                    }
                    QtObject {
                        id: pulse
                        property real value: 0
                    }
                }
            }
            Pill {
                visible: info.action !== ""
                label: info.action
                primary: true
                onClicked: info.activated()
            }
        }
    }

    component Pill: Rectangle {
        id: pill
        property string label: ""
        property bool primary: false
        property bool available: true
        signal clicked

        implicitWidth: pillText.implicitWidth + 28
        implicitHeight: 34
        radius: height / 2
        opacity: available ? 1 : 0.6
        color: primary ? Theme.accent : pillMouse.containsMouse && available ? Theme.buttonHover : Theme.button

        Text {
            id: pillText
            anchors.centerIn: parent
            text: pill.label
            color: pill.primary ? Theme.accentText : Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall + 1
            font.weight: Font.Bold
        }
        MouseArea {
            id: pillMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: pill.available ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: if (pill.available) pill.clicked()
        }
    }

    component Round: Rectangle {
        id: round
        property string glyph: ""
        readonly property bool hovered: roundMouse.containsMouse
        signal clicked

        implicitWidth: 30
        implicitHeight: 30
        radius: 15
        color: roundMouse.containsMouse ? Theme.buttonHover : Theme.button

        MIcon {
            anchors.centerIn: parent
            icon: round.glyph
            size: 16
            color: Theme.subtext
        }
        MouseArea {
            id: roundMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: round.clicked()
        }
    }
}
