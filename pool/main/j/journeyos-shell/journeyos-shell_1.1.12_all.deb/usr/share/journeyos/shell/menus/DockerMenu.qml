import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Docker menu (bar): the containers that failed first, then the running ones, with restart,
// start/stop and logs; the stopped ones only counted. The Dev tab has everything.
ColumnLayout {
    id: root

    spacing: 6

    readonly property var failed: Dev.containers.filter(c => c.failed)
    readonly property var running: Dev.containers.filter(c => !c.failed && c.state === "running")
    readonly property int stopped: Dev.containers.length - failed.length - running.length
    readonly property int maxRows: 8

    Component.onCompleted: Dev.refreshContainers()

    RowLayout {
        Layout.fillWidth: true
        Layout.bottomMargin: 4
        spacing: 8

        MIcon {
            icon: "view_in_ar"
            size: 18
        }
        Text {
            Layout.fillWidth: true
            text: "Docker"
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }
        Text {
            text: Dev.running + Tr.t(" running") + (root.failed.length ? " · " + root.failed.length + Tr.t(" failed") : "")
            color: root.failed.length ? Theme.privacyMic : Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    Repeater {
        model: [...root.failed, ...root.running].slice(0, root.maxRows)

        MenuRow {
            id: row
            required property var modelData
            readonly property bool isRunning: modelData.state === "running" || modelData.state === "restarting"

            icon: modelData.failed ? "error" : "view_in_ar"
            active: !modelData.failed && modelData.state === "running"
            busy: !!Dev.pending[modelData.id]
            title: modelData.name
            subtitle: (modelData.project ? modelData.project + " · " : "") + modelData.status
            onClicked: Dev.logs(modelData)

            MenuButton {
                visible: row.hovered || row.busy
                icon: "restart_alt"
                onClicked: Dev.container("restart", row.modelData)
            }
            MenuButton {
                visible: row.hovered || row.busy
                icon: row.isRunning ? "stop" : "play_arrow"
                onClicked: Dev.container(row.isRunning ? "stop" : "start", row.modelData)
            }
            MenuButton {
                visible: row.hovered && row.modelData.url !== ""
                icon: "open_in_new"
                onClicked: {
                    BarMenu.open = "";
                    Dev.openUrl(row.modelData.url);
                }
            }
        }
    }

    Text {
        Layout.fillWidth: true
        Layout.leftMargin: 8
        visible: root.failed.length + root.running.length > root.maxRows || root.stopped > 0
        wrapMode: Text.Wrap
        text: [root.failed.length + root.running.length > root.maxRows
                ? (root.failed.length + root.running.length - root.maxRows) + Tr.t(" more running") : "",
            root.stopped > 0 ? root.stopped + (root.stopped === 1 ? Tr.t(" stopped container") : Tr.t(" stopped containers")) : ""]
            .filter(x => x).join(" · ")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Text {
        Layout.fillWidth: true
        Layout.leftMargin: 8
        visible: root.failed.length + root.running.length === 0
        text: Tr.t("No container is running.")
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Rectangle {
        Layout.fillWidth: true
        Layout.topMargin: 2
        implicitHeight: 1
        color: Theme.surfaceBorder
    }

    MenuRow {
        visible: Config.options.dev.enabled
        icon: "space_dashboard"
        title: Tr.t("Open the Dev tab")
        onClicked: {
            BarMenu.open = "";
            Dashboard.toggle("dev", null);
        }
    }
    MenuRow {
        icon: "settings"
        title: Tr.t("Settings…")
        onClicked: {
            BarMenu.open = "";
            SettingsApp.show("dev");
        }
    }
}
