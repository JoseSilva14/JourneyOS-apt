#!/usr/bin/env python3
"""Phone link (KDE Connect) for the shell: talks to kdeconnectd over the session D-Bus.

  phone.py list                      JSON: {"running", "self": {"id", "name"}, "devices": [...]}
  phone.py pair|unpair|accept|reject ID
  phone.py ring|ping|clipboard ID    find the phone (it rings), a test notification, send the clipboard
  phone.py share ID FILE...          send files
  phone.py browse ID                 mount the phone's storage and open it in the file manager
  phone.py rename NAME               this computer's name, as phones see it
  phone.py refresh                   look for devices again

Exit code 0 = done; 1 = failed (the reason on stderr); 2 = KDE Connect is not installed.
"""
import json
import os
import subprocess
import sys

try:
    from gi.repository import Gio, GLib
except ImportError:
    print("python3-gi is missing", file=sys.stderr)
    sys.exit(1)

BUS_NAME = "org.kde.kdeconnect"
ROOT = "/modules/kdeconnect"
TIMEOUT = 8000  # ms; the first call may start the daemon


def bus():
    return Gio.bus_get_sync(Gio.BusType.SESSION, None)


def call(path, iface, method, args=None, sig=None, timeout=TIMEOUT):
    reply = bus().call_sync(BUS_NAME, path, iface, method, args, GLib.VariantType(sig) if sig else None,
                            Gio.DBusCallFlags.NONE, timeout, None)
    return reply.unpack() if reply is not None else ()


def prop(path, iface, name, default=None):
    try:
        return call(path, "org.freedesktop.DBus.Properties", "Get",
                    GLib.Variant("(ss)", (iface, name)), "(v)")[0]
    except GLib.Error:
        return default


def device_path(dev_id):
    if not dev_id or not all(c.isalnum() or c in "_-" for c in dev_id):
        fail("invalid device id")
    return f"{ROOT}/devices/{dev_id}"


def fail(message, code=1):
    print(message, file=sys.stderr)
    sys.exit(code)


def installed():
    return any(os.path.exists(os.path.join(d, "kdeconnectd")) for d in os.environ.get("PATH", "/usr/bin").split(":")) \
        or os.path.exists("/usr/bin/kdeconnectd")


def device_info(dev_id):
    path = device_path(dev_id)
    d = "org.kde.kdeconnect.device"
    paired = bool(prop(path, d, "isPaired", False))
    info = {
        "id": dev_id,
        "name": prop(path, d, "name", dev_id),
        "type": prop(path, d, "type", "phone"),       # phone | tablet | desktop | laptop | tv
        "reachable": bool(prop(path, d, "isReachable", False)),
        "paired": paired,
        # 0 not paired, 1 we asked, 2 they asked (accept/reject), 3 paired
        "pairState": int(prop(path, d, "pairState", 0)),
        "verification": prop(path, d, "verificationKey", ""),
        "battery": None,
        "plugins": [],
    }
    if paired and info["reachable"]:
        try:
            info["plugins"] = list(call(path, d, "loadedPlugins", None, "(as)")[0])
        except GLib.Error:
            pass
        if "kdeconnect_battery" in info["plugins"]:
            charge = prop(path + "/battery", d + ".battery", "charge", -1)
            if charge is not None and charge >= 0:
                info["battery"] = {"charge": int(charge),
                                   "charging": bool(prop(path + "/battery", d + ".battery", "isCharging", False))}
    return info


def cmd_list():
    out = {"installed": installed(), "running": False, "self": {"id": "", "name": ""}, "devices": []}
    if not out["installed"]:
        print(json.dumps(out))
        return
    try:
        out["self"]["id"] = call(ROOT, "org.kde.kdeconnect.daemon", "selfId", None, "(s)")[0]
        out["self"]["name"] = call(ROOT, "org.kde.kdeconnect.daemon", "announcedName", None, "(s)")[0]
        ids = call(ROOT, "org.kde.kdeconnect.daemon", "devices", GLib.Variant("(bb)", (False, False)), "(as)")[0]
        out["running"] = True
    except GLib.Error:
        print(json.dumps(out))
        return
    for dev_id in ids:
        try:
            info = device_info(dev_id)
        except GLib.Error:
            continue
        # Devices seen once on some network and never paired only add noise
        if info["paired"] or info["reachable"]:
            out["devices"].append(info)
    out["devices"].sort(key=lambda d: (not d["paired"], not d["reachable"], d["name"].lower()))
    print(json.dumps(out))


def main():
    if len(sys.argv) < 2:
        fail(__doc__)
    action, args = sys.argv[1], sys.argv[2:]
    if action == "list":
        return cmd_list()
    if not installed():
        fail("KDE Connect is not installed", 2)
    d = "org.kde.kdeconnect.device"
    try:
        if action == "refresh":
            call(ROOT, "org.kde.kdeconnect.daemon", "forceOnNetworkChange")
        elif action == "rename":
            name = " ".join(args).strip()[:32]
            if not name:
                fail("empty name")
            call(ROOT, "org.kde.kdeconnect.daemon", "setAnnouncedName", GLib.Variant("(s)", (name,)))
        elif action in ("pair", "unpair", "accept", "reject"):
            method = {"pair": "requestPairing", "unpair": "unpair", "accept": "acceptPairing",
                      "reject": "cancelPairing"}[action]
            call(device_path(args[0] if args else ""), d, method)
        elif action == "ring":
            call(device_path(args[0] if args else "") + "/findmyphone", d + ".findmyphone", "ring")
        elif action == "ping":
            call(device_path(args[0] if args else "") + "/ping", d + ".ping", "sendPing")
        elif action == "clipboard":
            call(device_path(args[0] if args else "") + "/clipboard", d + ".clipboard", "sendClipboard")
        elif action == "share":
            if len(args) < 2:
                fail("no files")
            urls = [Gio.File.new_for_path(f).get_uri() if "://" not in f else f for f in args[1:]]
            call(device_path(args[0]) + "/share", d + ".share", "shareUrls", GLib.Variant("(as)", (urls,)))
        elif action == "browse":
            path = device_path(args[0] if args else "") + "/sftp"
            if not call(path, d + ".sftp", "mountAndWait", None, "(b)", timeout=30000)[0]:
                error = call(path, d + ".sftp", "getMountError", None, "(s)")[0]
                fail(error or "could not open the phone's files (is the phone unlocked?)")
            folders = call(path, d + ".sftp", "getDirectories", None, "(a{sv})")[0]
            target = next(iter(folders), None) or call(path, d + ".sftp", "mountPoint", None, "(s)")[0]
            subprocess.Popen(["xdg-open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        else:
            fail(__doc__)
    except GLib.Error as e:
        fail(e.message.split(": ", 1)[-1])


if __name__ == "__main__":
    main()
