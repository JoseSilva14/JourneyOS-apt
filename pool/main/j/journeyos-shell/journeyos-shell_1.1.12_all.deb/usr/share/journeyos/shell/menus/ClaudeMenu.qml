import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Claude limits menu (bar): the 5-hour and the weekly window, how much is used and free, when each
// resets, and as of when (the numbers come from Claude Code's last answer).
ColumnLayout {
    id: root

    spacing: 10

    Component.onCompleted: ClaudeUsage.refresh()

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        MIcon {
            icon: "auto_awesome"
            size: 18
        }
        Text {
            Layout.fillWidth: true
            text: Tr.t("Claude limits")
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }
        Text {
            visible: ClaudeUsage.updated > 0
            text: ClaudeUsage.agoText(ClaudeUsage.updated)
            color: ClaudeUsage.stale ? Theme.privacyMic : Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontSmall
        }
    }

    Repeater {
        model: [
            { label: Tr.t("Current session (5 hours)"), w: ClaudeUsage.fiveHour, pct: ClaudeUsage.fivePct },
            { label: Tr.t("This week"), w: ClaudeUsage.sevenDay, pct: ClaudeUsage.weekPct }
        ]

        ColumnLayout {
            id: win
            required property var modelData
            readonly property real pct: modelData.pct
            readonly property bool reset: !!modelData.w && modelData.w.resetsAt > 0 && modelData.w.resetsAt <= ClaudeUsage.now

            Layout.fillWidth: true
            visible: modelData.w !== null
            spacing: 5

            RowLayout {
                Layout.fillWidth: true
                Text {
                    Layout.fillWidth: true
                    text: win.modelData.label
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.DemiBold
                }
                Text {
                    text: Math.round(win.pct) + Tr.t("% used")
                    color: win.pct >= 90 ? Theme.privacyMic : Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall + 1
                    font.weight: Font.Bold
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 8
                radius: 4
                color: Theme.button

                Rectangle {
                    width: parent.width * Math.min(1, win.pct / 100)
                    height: parent.height
                    radius: 4
                    color: win.pct >= 90 ? Theme.privacyMic : Theme.accent
                }
            }

            Text {
                Layout.fillWidth: true
                wrapMode: Text.Wrap
                text: win.reset ? Tr.t("Reset since the last reading")
                    : Math.max(0, 100 - Math.round(win.pct)) + Tr.t("% free · resets ") + ClaudeUsage.resetText(win.modelData.w?.resetsAt ?? 0)
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }

    Text {
        Layout.fillWidth: true
        visible: !ClaudeUsage.hasData
        wrapMode: Text.Wrap
        text: !ClaudeUsage.installed ? Tr.t("Claude Code is not installed.")
            : !ClaudeUsage.connected ? Tr.t("Connect it to Claude Code to see your plan's limits here.")
            : Tr.t("The numbers arrive with Claude Code's next answer (Pro and Max plans).")
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Text {
        Layout.fillWidth: true
        visible: ClaudeUsage.hasData
        wrapMode: Text.Wrap
        text: Tr.t("As of Claude Code's last answer") + (ClaudeUsage.model ? " · " + ClaudeUsage.model : "")
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Rectangle {
        Layout.fillWidth: true
        Layout.topMargin: 2
        implicitHeight: 1
        color: Theme.surfaceBorder
    }

    MenuRow {
        visible: ClaudeUsage.installed && !ClaudeUsage.connected
        icon: "link"
        title: Tr.t("Connect to Claude Code")
        onClicked: ClaudeUsage.connect(null)
    }
    MenuRow {
        visible: ClaudeUsage.installed
        icon: "terminal"
        title: Tr.t("Open Claude Code")
        onClicked: {
            BarMenu.open = "";
            ClaudeUsage.openClaude();
        }
    }
    MenuRow {
        icon: "settings"
        title: Tr.t("Settings…")
        onClicked: {
            BarMenu.open = "";
            SettingsApp.show("dev");
        }
    }
}
