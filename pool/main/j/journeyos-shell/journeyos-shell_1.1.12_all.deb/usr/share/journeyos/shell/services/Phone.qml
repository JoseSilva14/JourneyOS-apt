pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Phone link (KDE Connect): the paired phones (battery, ring, send files and the clipboard, browse
// their files), the ones nearby to pair and pairing requests. Everything goes through
// scripts/phone.py (kdeconnectd's D-Bus); "gdbus monitor" on the daemon refreshes the list when
// something changes. The firewall ports come with journeyos-desktop (firewall kdeconnect).
Singleton {
    id: root

    property bool loaded: false
    property bool installed: true
    property bool running: false
    property string selfName: ""
    property var devices: []            // see phone.py list
    property string busy: ""            // "<action> <id>" while running
    property string message: ""

    readonly property var paired: devices.filter(d => d.paired)
    readonly property var requests: devices.filter(d => d.pairState === 2)
    readonly property var nearby: devices.filter(d => !d.paired && d.pairState !== 2 && d.reachable)
    // The first paired phone that is connected (for the wizard and summaries)
    readonly property var phone: paired.find(d => d.reachable) ?? null

    readonly property string script: Quickshell.shellPath("scripts/phone.py")

    // The Phone app's window (phone/PhoneWindow; its own app, not a Settings page)
    property bool open: false
    function toggle() {
        open = !open;
        if (open)
            refresh();
    }
    function show() {
        open = true;
        refresh();
    }

    function refresh() {
        if (!lister.running)
            lister.running = true;
        else
            again = true;
    }
    property bool again: false

    function run(action, id, extra, done) {
        busy = action + " " + (id ?? "");
        message = "";
        Run.cmd(["python3", script, action, ...(id ? [id] : []), ...(extra ?? [])], (code, out, err) => {
            busy = "";
            if (code !== 0)
                message = err.trim() || Tr.t("KDE Connect did not answer");
            else if (done)
                message = done;
            refresh();
        });
    }

    function pair(id) { run("pair", id); }
    function unpair(id) { run("unpair", id, [], Tr.t("Forgotten")); }
    function accept(id) { run("accept", id); }
    function reject(id) { run("reject", id); }
    function ring(id) { run("ring", id, [], Tr.t("Ringing")); }
    function ping(id) { run("ping", id, [], Tr.t("Sent")); }
    function sendClipboard(id) { run("clipboard", id, [], Tr.t("Clipboard sent")); }
    function browse(id) { run("browse", id); }
    function rename(name) { if (name.trim() && name.trim() !== selfName) run("rename", "", [name.trim()]); }
    function search() { run("refresh", ""); }

    // Asks which files (the system's file dialog) and sends them
    function shareFiles(id) {
        Run.cmd(["kdialog", "--title", Tr.t("Send to phone"), "--getopenfilename", Quickshell.env("HOME"),
            "--multiple", "--separate-output"], (code, out) => {
            const files = out.split("\n").map(f => f.trim()).filter(f => f);
            if (code === 0 && files.length)
                run("share", id, files, files.length === 1 ? Tr.t("File sent") : files.length + Tr.t(" files sent"));
        });
    }

    Process {
        id: lister
        command: ["python3", root.script, "list"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const d = JSON.parse(text);
                    root.installed = d.installed;
                    root.running = d.running;
                    root.selfName = d.self.name;
                    root.devices = d.devices;
                } catch (e) {
                    root.running = false;
                }
                root.loaded = true;
            }
        }
        onExited: if (root.again) {
            root.again = false;
            root.refresh();
        }
    }

    // Changes on the daemon (devices appear, pair, battery): refresh, at most every half second
    Process {
        id: monitor
        running: root.loaded && root.installed
        command: ["gdbus", "monitor", "--session", "--dest", "org.kde.kdeconnect"]
        stdout: SplitParser {
            onRead: line => { if (line.includes("/modules/kdeconnect")) debounce.restart(); }
        }
        // The daemon went away (or was not up yet): look again a bit later
        onExited: restartMonitor.start()
    }
    Timer {
        id: restartMonitor
        interval: 5000
        onTriggered: {
            root.refresh();
            monitor.running = root.installed;
        }
    }
    Timer {
        id: debounce
        interval: 500
        onTriggered: root.refresh()
    }

    // Battery and reachability without signals (older phone apps): a slow look while something uses it
    Timer {
        running: root.loaded && root.running && root.paired.length > 0
        interval: 60000
        repeat: true
        onTriggered: root.refresh()
    }

    Component.onCompleted: refresh()

    IpcHandler {
        target: "phone"
        function status(): string { return JSON.stringify({ installed: root.installed, running: root.running, name: root.selfName, devices: root.devices.map(d => ({ id: d.id, name: d.name, paired: d.paired, reachable: d.reachable, battery: d.battery })), message: root.message }); }
        function refresh(): void { root.refresh(); }
        function ring(id: string): void { root.ring(id); }
        function toggle(): void { root.toggle(); }
    }
}
