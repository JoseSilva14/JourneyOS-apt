#!/usr/bin/env python3
"""Passwords in the system's secret store (Secret Service, org.freedesktop.secrets: KWallet here,
opened at login with the login password by pam_kwallet). The same store VS Code, Chrome, git
(credential-libsecret) and NetworkManager use, so Settings → Passwords also lists what apps saved.

passwords.py status            JSON { available, locked, items: [...] } (items empty while locked)
  item: { path, label, username, url, mine, app, modified }  (mine = saved from JourneyOS)
passwords.py unlock            unlocks the store (KWallet asks for its password if it is not open)
passwords.py copy PATH [username]
                             copies the password (or the username) of an item; the password is
                             cleared from the clipboard after 30 s if it is still there, and kept
                             out of the clipboard history
passwords.py show PATH         prints the password
passwords.py save              JSON on stdin { path?, label, username, url, password }: new item, or
                             changes the one at path (password "" = keep it)
passwords.py delete PATH
passwords.py generate [LEN]    a random password (letters, digits and symbols; 20 by default)

Secrets never go through the command line (argv is visible to other processes): they are read
from stdin and written to stdout/wl-copy's stdin.
"""
import hashlib
import json
import os
import secrets as rnd
import string
import subprocess
import sys
import time

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS = "org.freedesktop.secrets"
ROOT = "/org/freedesktop/secrets"
SERVICE = "org.freedesktop.Secret.Service"
COLLECTION = "org.freedesktop.Secret.Collection"
ITEM = "org.freedesktop.Secret.Item"
PROMPT = "org.freedesktop.Secret.Prompt"
SCHEMA = "org.journeyos.Password"
CLEAR_AFTER = 30
SKIP = os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "journeyos", "clipboard-skip")

bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)


def call(path, iface, method, args=None, reply=None, timeout=-1):
    return bus.call_sync(BUS, path, iface, method, args, GLib.VariantType(reply) if reply else None,
                         Gio.DBusCallFlags.NONE, timeout, None).unpack()


def prop(path, iface, name):
    return call(path, "org.freedesktop.DBus.Properties", "Get", GLib.Variant("(ss)", (iface, name)), "(v)")[0]


def prompt(path):
    """Runs a Secret Service prompt (KWallet's password dialog) and waits for its answer.
    Returns (dismissed, result)."""
    if path == "/":
        return False, None
    loop = GLib.MainLoop()
    answer = {}

    def done(_conn, _sender, _path, _iface, _signal, params):
        answer["v"] = params.unpack()
        loop.quit()

    sub = bus.signal_subscribe(BUS, PROMPT, "Completed", path, None, Gio.DBusSignalFlags.NONE, done)
    call(path, PROMPT, "Prompt", GLib.Variant("(s)", ("",)))
    GLib.timeout_add_seconds(300, loop.quit)
    loop.run()
    bus.signal_unsubscribe(sub)
    dismissed, result = answer.get("v", (True, None))
    return dismissed, result


def available():
    try:
        names = bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus",
                              "ListActivatableNames", None, None, Gio.DBusCallFlags.NONE, 5000, None).unpack()[0]
        running = bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus",
                                "NameHasOwner", GLib.Variant("(s)", (BUS,)), None, Gio.DBusCallFlags.NONE, 5000, None).unpack()[0]
        return running or BUS in names
    except GLib.Error:
        return False


def session():
    return call(ROOT, SERVICE, "OpenSession", GLib.Variant("(sv)", ("plain", GLib.Variant("s", ""))), "(vo)")[1]


def collection(create=False):
    path = call(ROOT, SERVICE, "ReadAlias", GLib.Variant("(s)", ("default",)), "(o)")[0]
    if path != "/" or not create:
        return path
    props = {"org.freedesktop.Secret.Collection.Label": GLib.Variant("s", "kdewallet")}
    path, p = call(ROOT, SERVICE, "CreateCollection", GLib.Variant("(a{sv}s)", (props, "default")), "(oo)")
    if path == "/":
        dismissed, result = prompt(p)
        if dismissed:
            raise SystemExit("cancelled")
        path = result
    return path


def unlock(paths):
    unlocked, p = call(ROOT, SERVICE, "Unlock", GLib.Variant("(ao)", (paths,)), "(aoo)")
    if p != "/":
        dismissed, _ = prompt(p)
        if dismissed:
            raise SystemExit("cancelled")


def get_secret(path):
    s = session()
    _, _, value, _ = call(path, ITEM, "GetSecret", GLib.Variant("(o)", (s,)), "((oayays))")[0]
    return bytes(value).decode("utf-8", errors="replace")


def item_info(path):
    attrs = dict(prop(path, ITEM, "Attributes"))
    schema = attrs.get("xdg:schema", "")
    mine = schema == SCHEMA
    return {
        "path": path,
        "label": prop(path, ITEM, "Label"),
        "username": attrs.get("username") or attrs.get("user") or attrs.get("account") or "",
        "url": attrs.get("url") or attrs.get("server") or "",
        "mine": mine,
        # Who saved it: the "application" or "service" attribute, else the schema when it says
        # something (org.gnome.keyring.NetworkPassword…; not the generic one)
        "app": "" if mine else (attrs.get("application") or attrs.get("service")
                                or ("" if schema in ("", "org.freedesktop.Secret.Generic") else schema)),
        "modified": prop(path, ITEM, "Modified"),
    }


def status():
    if not available():
        return {"available": False, "locked": False, "items": []}
    col = collection()
    if col == "/":
        return {"available": True, "locked": False, "items": [], "empty": True}
    locked = prop(col, COLLECTION, "Locked")
    if locked:
        # KWallet reports the collection locked until someone asks, even with the wallet already open
        # (pam_kwallet at login): ask without a prompt; if it wants the password, it stays locked
        unlocked, _ = call(ROOT, SERVICE, "Unlock", GLib.Variant("(ao)", ([col],)), "(aoo)")
        locked = col not in unlocked
    items = []
    if not locked:
        for path in prop(col, COLLECTION, "Items"):
            try:
                items.append(item_info(path))
            except GLib.Error:
                continue
    items.sort(key=lambda i: (not i["mine"], i["label"].lower()))
    return {"available": True, "locked": locked, "items": items}


def copy(text, secret):
    """wl-copy from stdin. A password: its hash goes to the clipboard history's skip list, and a
    detached child clears it after CLEAR_AFTER seconds if it is still what's copied."""
    data = text.encode("utf-8")
    if secret:
        os.makedirs(os.path.dirname(SKIP), mode=0o700, exist_ok=True)
        fd = os.open(SKIP, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        os.write(fd, (hashlib.sha256(data).hexdigest() + "\n").encode())
        os.close(fd)
    subprocess.run(["wl-copy"], input=data, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    if not secret:
        return
    # A separate process (not fork: Gio has threads) clears it later; it gets the password on
    # stdin and is out of the caller's way (its own session, no pipes the shell is reading)
    child = subprocess.Popen([sys.executable, os.path.abspath(__file__), "clear-later"], stdin=subprocess.PIPE,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    child.stdin.write(data)
    child.stdin.close()


def clear_later():
    """Clears the clipboard after CLEAR_AFTER seconds if it still has the password (from stdin), and
    takes its hash off the history's skip list."""
    data = sys.stdin.buffer.read()
    time.sleep(CLEAR_AFTER)
    current = subprocess.run(["wl-paste", "--no-newline"], capture_output=True).stdout
    if current == data:
        subprocess.run(["wl-copy", "--clear"])
    digest = hashlib.sha256(data).hexdigest()
    try:
        with open(SKIP, encoding="ascii") as fh:
            rest = [h for h in fh.read().split() if h != digest]
        with open(SKIP, "w", encoding="ascii") as fh:
            fh.write("".join(h + "\n" for h in rest))
    except OSError:
        pass


def save(d):
    col = collection(create=True)
    unlock([col])
    label = (d.get("label") or "").strip()
    if not label:
        raise SystemExit("the name is empty")
    attrs = {"xdg:schema": SCHEMA, "username": (d.get("username") or "").strip(), "url": (d.get("url") or "").strip()}
    password = d.get("password") or ""
    path = d.get("path") or ""
    if path:
        bus.call_sync(BUS, path, "org.freedesktop.DBus.Properties", "Set",
                      GLib.Variant("(ssv)", (ITEM, "Label", GLib.Variant("s", label))), None, Gio.DBusCallFlags.NONE, -1, None)
        bus.call_sync(BUS, path, "org.freedesktop.DBus.Properties", "Set",
                      GLib.Variant("(ssv)", (ITEM, "Attributes", GLib.Variant("a{ss}", attrs))), None, Gio.DBusCallFlags.NONE, -1, None)
        if password:
            secret = (session(), b"", password.encode("utf-8"), "text/plain")
            call(path, ITEM, "SetSecret", GLib.Variant("((oayays))", (secret,)))
        return path
    if not password:
        raise SystemExit("the password is empty")
    props = {
        "org.freedesktop.Secret.Item.Label": GLib.Variant("s", label),
        "org.freedesktop.Secret.Item.Attributes": GLib.Variant("a{ss}", attrs),
    }
    secret = (session(), b"", password.encode("utf-8"), "text/plain")
    path, p = call(col, COLLECTION, "CreateItem", GLib.Variant("(a{sv}(oayays)b)", (props, secret, False)), "(oo)")
    if path == "/":
        dismissed, result = prompt(p)
        if dismissed:
            raise SystemExit("cancelled")
        path = result
    return path


def generate(length):
    alphabet = string.ascii_letters + string.digits + "!#$%&*+-=?@^_"
    while True:
        pw = "".join(rnd.choice(alphabet) for _ in range(length))
        # At least one of each kind (some sites insist)
        if (any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw)
                and any(not c.isalnum() for c in pw)):
            return pw


def main():
    a = sys.argv[1:]
    try:
        if a == ["status"]:
            print(json.dumps(status(), ensure_ascii=False))
        elif a == ["unlock"]:
            unlock([collection(create=True)])
            print(json.dumps(status(), ensure_ascii=False))
        elif len(a) in (2, 3) and a[0] == "copy":
            if len(a) == 3 and a[2] == "username":
                copy(item_info(a[1])["username"], False)
            else:
                copy(get_secret(a[1]), True)
        elif len(a) == 2 and a[0] == "show":
            sys.stdout.write(get_secret(a[1]))
        elif a == ["save"]:
            print(save(json.load(sys.stdin)))
        elif len(a) == 2 and a[0] == "delete":
            p = call(a[1], ITEM, "Delete", None, "(o)")[0]
            if prompt(p)[0]:
                raise SystemExit("cancelled")
        elif a == ["clear-later"]:
            clear_later()
        elif a and a[0] == "generate":
            print(generate(int(a[1]) if len(a) > 1 and a[1].isdigit() else 20))
        else:
            print(__doc__, file=sys.stderr)
            return 2
    except GLib.Error as e:
        print(e.message, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
