import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Phone (KDE Connect): this computer's name, pairing requests, the paired phones (battery, ring,
// send files and the clipboard, browse their files, forget) and the ones nearby to pair.
Page {
    id: root

    Component.onCompleted: Phone.refresh()

    property string confirmForget: ""

    function deviceIcon(t) {
        return t === "tablet" ? "tablet_android" : t === "desktop" ? "desktop_windows" : t === "laptop" ? "laptop"
            : t === "tv" ? "tv" : "smartphone";
    }

    function batteryText(b) {
        if (!b)
            return "";
        return b.charge + "%" + (b.charging ? Tr.t(" · charging") : "");
    }

    // --- Not available ---
    SettingRow {
        visible: Phone.loaded && !Phone.installed
        title: Tr.t("KDE Connect is not installed")
        description: Tr.t("Install the kdeconnect package to link your phone.")
        icon: "phonelink_off"
    }

    SettingRow {
        visible: Phone.loaded && Phone.installed && !Phone.running
        title: Tr.t("Starting the phone link…")
        description: Phone.message || Tr.t("If it takes long, try again.")
        icon: "hourglass_empty"
        PillButton {
            text: Tr.t("Try again")
            onClicked: Phone.refresh()
        }
    }

    // --- This computer ---
    SectionLabel {
        visible: Phone.running
        text: Tr.t("This computer")
    }

    SettingRow {
        visible: Phone.running
        title: Tr.t("Name")
        description: Tr.t("How your phone sees this computer.")
        icon: "badge"
        TextField {
            implicitWidth: 220
            text: Phone.selfName
            onAccepted: t => Phone.rename(t)
        }
    }

    // --- Requests ---
    SectionLabel {
        visible: Phone.running && Phone.requests.length > 0
        text: Tr.t("Wants to pair")
    }

    Repeater {
        model: Phone.running ? Phone.requests : []

        SettingRow {
            id: req
            required property var modelData
            title: modelData.name
            description: Tr.t("Check that the phone shows the same code: ") + modelData.verification
            icon: root.deviceIcon(modelData.type)

            RowLayout {
                spacing: 8
                PillButton {
                    text: Tr.t("Reject")
                    onClicked: Phone.reject(req.modelData.id)
                }
                PillButton {
                    text: Tr.t("Accept")
                    accent: true
                    onClicked: Phone.accept(req.modelData.id)
                }
            }
        }
    }

    // --- Paired ---
    SectionLabel {
        visible: Phone.running && Phone.paired.length > 0
        text: Tr.t("Your devices")
    }

    Repeater {
        model: Phone.running ? Phone.paired : []

        ColumnLayout {
            id: dev
            required property var modelData
            readonly property var d: modelData
            readonly property bool on: d.reachable
            readonly property bool forgetting: root.confirmForget === d.id
            function has(p) { return d.plugins.includes("kdeconnect_" + p); }

            Layout.fillWidth: true
            spacing: 6

            SettingRow {
                title: dev.d.name
                description: !dev.on ? Tr.t("Not connected. Open KDE Connect on it, on the same network.")
                    : dev.d.battery ? Tr.t("Connected · battery ") + root.batteryText(dev.d.battery)
                    : Tr.t("Connected")
                icon: root.deviceIcon(dev.d.type)

                PillButton {
                    text: dev.forgetting ? Tr.t("Forget it? Click again") : Tr.t("Forget")
                    danger: dev.forgetting
                    onClicked: {
                        if (dev.forgetting) {
                            root.confirmForget = "";
                            Phone.unpair(dev.d.id);
                        } else {
                            root.confirmForget = dev.d.id;
                            forgetTimeout.restart();
                        }
                    }
                }
            }

            // Actions (only while connected)
            Flow {
                visible: dev.on
                Layout.fillWidth: true
                Layout.leftMargin: 4
                Layout.bottomMargin: 6
                spacing: 8

                PillButton {
                    visible: dev.has("findmyphone")
                    text: Tr.t("Ring")
                    onClicked: Phone.ring(dev.d.id)
                }
                PillButton {
                    visible: dev.has("share")
                    text: Tr.t("Send files…")
                    onClicked: Phone.shareFiles(dev.d.id)
                }
                PillButton {
                    visible: dev.has("clipboard")
                    text: Tr.t("Send clipboard")
                    onClicked: Phone.sendClipboard(dev.d.id)
                }
                PillButton {
                    visible: dev.has("sftp")
                    text: Tr.t("Browse files")
                    onClicked: Phone.browse(dev.d.id)
                }
                PillButton {
                    visible: dev.has("ping")
                    text: Tr.t("Send a test")
                    onClicked: Phone.ping(dev.d.id)
                }
            }
        }
    }

    Text {
        visible: Phone.message !== ""
        Layout.fillWidth: true
        Layout.leftMargin: 4
        text: Phone.message
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    // --- Nearby ---
    SectionLabel {
        visible: Phone.running
        text: Tr.t("Nearby")
    }

    Repeater {
        model: Phone.running ? Phone.nearby : []

        SettingRow {
            id: near
            required property var modelData
            readonly property bool asked: modelData.pairState === 1
            title: modelData.name
            description: asked ? Tr.t("Accept on the device. Code: ") + modelData.verification : Tr.t("Not paired")
            icon: root.deviceIcon(modelData.type)

            PillButton {
                text: near.asked ? Tr.t("Cancel") : Tr.t("Pair")
                accent: !near.asked
                onClicked: near.asked ? Phone.reject(near.modelData.id) : Phone.pair(near.modelData.id)
            }
        }
    }

    SettingRow {
        visible: Phone.running
        title: Phone.nearby.length ? Tr.t("Not on the list?") : Tr.t("No devices nearby")
        description: Tr.t("Install KDE Connect on the phone (Google Play, F-Droid or the App Store), open it on the same Wi-Fi and pair from there or here.")
        icon: "travel_explore"
        PillButton {
            text: Tr.t("Search")
            enabled: Phone.busy === ""
            onClicked: Phone.search()
        }
    }

    Timer {
        id: forgetTimeout
        interval: 4000
        onTriggered: root.confirmForget = ""
    }
}
