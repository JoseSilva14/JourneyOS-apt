import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services

// Exit screen: lock, suspend, log out, restart, shut down, as round buttons in the centre.
// A specific request (e.g. "Shut down") comes preselected and runs by itself after 30 s; touching the
// keyboard or mouse stops the countdown. Arrows select, Enter runs, Esc or clicking outside gives up.
PanelWindow {
    id: root

    readonly property bool open: Session.open
    readonly property var current: Session.actions.find(a => a.id === Session.selected) ?? null

    screen: Windows.activeScreen
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-session"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open)
            keys.forceActiveFocus();
        else
            closing.restart();
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    function move(delta) {
        const list = Session.actions;
        const i = list.findIndex(a => a.id === Session.selected);
        Session.selected = list[(i + delta + list.length) % list.length].id;
        Session.countdown = 0;
    }

    Item {
        id: keys
        anchors.fill: parent
        focus: true
        Keys.onLeftPressed: root.move(-1)
        Keys.onRightPressed: root.move(1)
        Keys.onTabPressed: root.move(1)
        Keys.onBacktabPressed: root.move(-1)
        Keys.onReturnPressed: Session.perform(Session.selected)
        Keys.onEnterPressed: Session.perform(Session.selected)
        Keys.onSpacePressed: Session.perform(Session.selected)
        Keys.onEscapePressed: Session.cancel()
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.7)
        opacity: root.open ? 1 : 0

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
    }

    MouseArea {
        anchors.fill: parent
        onClicked: Session.cancel()
    }

    Rectangle {
        anchors.centerIn: parent
        width: card.implicitWidth + 64
        height: card.implicitHeight + 56
        radius: Theme.radiusCard + 14
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        opacity: root.open ? 1 : 0
        scale: root.open ? 1 : 0.96

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        // Clicks on the card do not close it
        MouseArea {
            anchors.fill: parent
        }

        ColumnLayout {
            id: card
            anchors.centerIn: parent
            spacing: 28

            ColumnLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 6

                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: Tr.t("See you, ") + User.name
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 26
                    font.weight: Font.Bold
                }
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: Session.countdown > 0 && root.current
                        ? root.current.label + Tr.t(" in ") + Session.countdown + Tr.t(" s")
                        : Tr.t("Choose what to do")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                }
            }

            Row {
                Layout.alignment: Qt.AlignHCenter
                spacing: 18

                Repeater {
                    model: Session.actions

                    delegate: Column {
                        id: action
                        required property var modelData
                        readonly property bool selected: modelData.id === Session.selected
                        spacing: 10

                        Rectangle {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: 88
                            height: 88
                            radius: 44
                            color: action.selected ? Theme.accent : actionMouse.containsMouse ? Theme.buttonHover : Theme.button
                            scale: actionMouse.pressed ? 0.94 : 1

                            Behavior on color {
                                ColorAnimation { duration: Theme.animFast }
                            }
                            Behavior on scale {
                                NumberAnimation { duration: Theme.animFast }
                            }

                            MIcon {
                                anchors.centerIn: parent
                                icon: action.modelData.icon
                                size: 32
                                color: action.selected ? Theme.accentText : Theme.text
                            }

                            // The countdown: a ring around the chosen one that empties
                            Ring {
                                anchors.fill: parent
                                anchors.margins: -6
                                visible: action.selected && Session.countdown > 0
                                value: Session.countdown / Session.countdownStart
                                thickness: 3
                            }

                            MouseArea {
                                id: actionMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: if (Session.selected !== action.modelData.id) {
                                    Session.selected = action.modelData.id;
                                    Session.countdown = 0;
                                }
                                onClicked: Session.perform(action.modelData.id)
                            }
                        }

                        // Long labels ("Restart to Windows") wrap instead of widening the row
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: 108
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            text: action.modelData.label
                            color: action.selected ? Theme.text : Theme.subtext
                            font.family: Theme.font
                            font.pixelSize: Theme.fontNormal
                            font.weight: action.selected ? Font.Bold : Font.Normal
                        }
                    }
                }
            }
        }
    }
}
