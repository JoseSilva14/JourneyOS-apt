pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Long terminal commands: the JourneyOS zsh setup calls "terminal finished" (IPC) when a command
// that took 10 s or more ends. If it took at least dev.notifyAfter seconds and its terminal is not
// the active window, a notification says how it went; clicking it brings the terminal back.
// The terminal is found by process: the shell sends its own pid and its parents', and each window
// carries its pid (scripts/windows.py).
Singleton {
    id: root

    readonly property bool enabled: Config.options.dev.notifyCommands
    readonly property int after: Config.options.dev.notifyAfter

    function duration(s) {
        if (s < 60)
            return s + Tr.t(" s");
        const m = Math.floor(s / 60);
        if (m < 60)
            return m + Tr.t(" min ") + String(s % 60).padStart(2, "0") + Tr.t(" s");
        return Math.floor(m / 60) + Tr.t(" h ") + String(m % 60).padStart(2, "0") + Tr.t(" min");
    }

    function finished(command, code, seconds, pids) {
        if (!enabled || seconds < after)
            return;
        const chain = String(pids).split(/\s+/).map(Number).filter(p => p > 1);
        const win = Windows.list.find(w => w.pid && chain.includes(w.pid)) ?? null;
        // Already looking at it
        if (win && win.active)
            return;
        const cmd = command.trim().replace(/\s+/g, " ");
        const shown = cmd.length > 60 ? cmd.slice(0, 57) + "…" : cmd;
        const ok = code === 0;
        const title = (ok ? Tr.t("Finished: ") : Tr.t("Failed: ")) + shown;
        const body = Tr.t("Took ") + duration(seconds) + (ok ? "" : Tr.t(" · exit code ") + code)
            + (win ? " · " + win.title : "");
        Run.cmd(["notify-send", "--app-name=" + Tr.t("Terminal"), "--icon=utilities-terminal",
            "--urgency=" + (ok ? "normal" : "critical"), "--wait", "--action=default=" + Tr.t("Show"), title, body],
            (c, out) => {
                if (out.trim() === "default" && win)
                    Windows.activate(win.id);
            });
    }

    IpcHandler {
        target: "terminal"
        // command, exit code, seconds it took, the shell's pid and its parents' (space-separated)
        function finished(command: string, code: int, seconds: int, pids: string): void {
            root.finished(command, code, seconds, pids);
        }
    }
}
