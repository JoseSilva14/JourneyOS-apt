#!/usr/bin/env python3
"""System packages through PackageKit's D-Bus API (Settings → Updates and the app store).

  pk.py update            installs every pending update
  pk.py install PKG...    installs Debian packages (by name)
  pk.py remove PKG...     removes them (never what depends on them, nor anything else)

pkcon cannot do this from the shell: with -y it marks the transaction non-interactive and polkit
refuses without asking for the password; without -y it wants "y" from a terminal, and given one it
asks for the password there itself (pkttyagent). Here each transaction carries the "interactive=true"
hint, so polkit asks the shell's agent (the usual password window).

Prints pkcon-like lines: "Percentage:\tN" and "Status:\t<text>"; errors go to stderr. Exits 0 when it
all went through (or there was nothing to do), 1 otherwise.
"""

import locale
import sys

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS = "org.freedesktop.PackageKit"
TX = "org.freedesktop.PackageKit.Transaction"

FILTER_NONE = 1 << 1           # PK_FILTER_ENUM_NONE
FLAG_ONLY_TRUSTED = 1 << 1     # PK_TRANSACTION_FLAG_ENUM_ONLY_TRUSTED
EXIT_SUCCESS = 1               # PK_EXIT_ENUM_SUCCESS
INFO_INSTALLED = 1             # PK_INFO_ENUM_INSTALLED
INFO_AVAILABLE = 2             # PK_INFO_ENUM_AVAILABLE
INFO_BLOCKED = 13              # PK_INFO_ENUM_BLOCKED: held back, not installable now

# PkStatusEnum → text (the rest: no line)
STATUS = {1: "Waiting", 2: "Starting", 3: "Running", 4: "Querying", 6: "Removing", 8: "Downloading",
          9: "Installing", 10: "Updating", 11: "Cleaning up", 13: "Resolving dependencies",
          14: "Checking signatures", 15: "Testing changes", 16: "Committing changes",
          20: "Downloading repository information", 21: "Downloading list of packages",
          25: "Waiting for authentication", 26: "Scanning applications",
          29: "Waiting for package manager lock", 34: "Finished"}


def say(line):
    print(line, flush=True)


class PackageKit:
    def __init__(self):
        self.conn = Gio.bus_get_sync(Gio.BusType.SYSTEM)
        self.lang = (locale.getlocale()[0] or "C") + ".UTF-8"
        self.quiet = False      # no progress lines (looking things up)

    def transaction(self):
        path = self.conn.call_sync(BUS, "/org/freedesktop/PackageKit", "org.freedesktop.PackageKit",
                                   "CreateTransaction", None, GLib.VariantType("(o)"),
                                   Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        self.conn.call_sync(BUS, path, TX, "SetHints",
                            GLib.Variant("(as)", (["interactive=true", "locale=" + self.lang],)),
                            None, Gio.DBusCallFlags.NONE, -1, None)
        return path

    def run(self, method, args):
        """Calls method on a new transaction and waits for Finished: {exit, packages, errors}."""
        path = self.transaction()
        loop = GLib.MainLoop()
        state = {"exit": 0, "packages": [], "errors": []}

        def signal(_c, _s, _p, _i, name, params):
            v = params.unpack()
            if name == "Package":
                state["packages"].append((v[0], v[1]))
            elif name == "ErrorCode":
                state["errors"].append(v[1])
            elif name == "Finished":
                state["exit"] = v[0]
                loop.quit()

        def props(_c, _s, _p, _i, _n, params):
            if self.quiet:
                return
            _iface, changed, _gone = params.unpack()
            if "Percentage" in changed and changed["Percentage"] <= 100:
                say(f"Percentage:\t{changed['Percentage']}")
            if "Status" in changed and changed["Status"] in STATUS:
                say(f"Status:\t{STATUS[changed['Status']]}")

        subs = [self.conn.signal_subscribe(BUS, TX, None, path, None, Gio.DBusSignalFlags.NONE, signal),
                self.conn.signal_subscribe(BUS, "org.freedesktop.DBus.Properties", "PropertiesChanged",
                                           path, None, Gio.DBusSignalFlags.NONE, props)]
        self.conn.call_sync(BUS, path, TX, method, args, None, Gio.DBusCallFlags.NONE, -1, None)
        loop.run()
        for s in subs:
            self.conn.signal_unsubscribe(s)
        return state

    def resolve(self, names):
        """name → [installed package id or None, available package id or None]."""
        self.quiet = True
        found = self.run("Resolve", GLib.Variant("(tas)", (FILTER_NONE, names)))
        self.quiet = False
        out = {n: [None, None] for n in names}
        for info, pid in found["packages"]:
            name, _ver, arch, _data = pid.split(";")
            if name not in out or arch not in ("amd64", "all", ""):
                continue
            if info == INFO_INSTALLED:
                out[name][0] = pid
            elif info == INFO_AVAILABLE and out[name][1] is None:
                out[name][1] = pid
        return out


def fail(state, what):
    print("\n".join(state["errors"]) or f"{what} failed (exit {state['exit']})", file=sys.stderr)
    return 1


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("update", "install", "remove"):
        print(__doc__, file=sys.stderr)
        return 2
    cmd, names = sys.argv[1], sys.argv[2:]
    pk = PackageKit()

    if cmd == "update":
        found = pk.run("GetUpdates", GLib.Variant("(t)", (FILTER_NONE,)))
        if found["exit"] != EXIT_SUCCESS:
            return fail(found, "listing the updates")
        ids = [pid for info, pid in found["packages"] if info != INFO_BLOCKED]
        if ids:
            done = pk.run("UpdatePackages", GLib.Variant("(tas)", (FLAG_ONLY_TRUSTED, ids)))
            if done["exit"] != EXIT_SUCCESS:
                return fail(done, "the update")
        say("Percentage:\t100")
        return 0

    if not names:
        print("no packages given", file=sys.stderr)
        return 2
    resolved = pk.resolve(names)
    if cmd == "install":
        missing = [n for n, (inst, avail) in resolved.items() if not inst and not avail]
        if missing:
            print("not found: " + " ".join(missing), file=sys.stderr)
            return 1
        ids = [avail for inst, avail in resolved.values() if not inst]
        if ids:
            done = pk.run("InstallPackages", GLib.Variant("(tas)", (FLAG_ONLY_TRUSTED, ids)))
            if done["exit"] != EXIT_SUCCESS:
                return fail(done, "the installation")
    else:
        ids = [inst for inst, _avail in resolved.values() if inst]
        if ids:
            # allow_deps false: if something depends on it, nothing is removed (an error instead);
            # autoremove false: apt's autoremove can take packages that only look unused
            done = pk.run("RemovePackages", GLib.Variant("(tasbb)", (0, ids, False, False)))
            if done["exit"] != EXIT_SUCCESS:
                return fail(done, "the removal")
    say("Percentage:\t100")
    return 0


if __name__ == "__main__":
    sys.exit(main())
