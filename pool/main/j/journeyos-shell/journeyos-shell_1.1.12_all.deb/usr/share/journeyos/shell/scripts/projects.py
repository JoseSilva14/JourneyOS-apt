#!/usr/bin/env python3
"""Projects for the launcher: git repositories under the given folders (up to 3 levels down).

  projects.py ROOT...        JSON list, most recently used first:
    [{"name", "path", "branch", "changes", "ahead", "behind", "kinds": ["Go", ...], "used": epoch}]

"changes" counts modified, staged and new files. Folders that don't exist are skipped; hidden folders,
node_modules, vendor and the like are not searched. Each repository gets at most 3 s (git status).
"""
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

SKIP = {"node_modules", "vendor", "target", "build", "dist", "__pycache__", "venv", ".venv", "env"}
DEPTH = 3
# Files that say what a project is made of
MARKERS = [
    ("go.mod", "Go"), ("package.json", "Node"), ("Cargo.toml", "Rust"), ("pyproject.toml", "Python"),
    ("requirements.txt", "Python"), ("setup.py", "Python"), ("pom.xml", "Java"), ("build.gradle", "Java"),
    ("build.gradle.kts", "Kotlin"), ("composer.json", "PHP"), ("Gemfile", "Ruby"), ("CMakeLists.txt", "C/C++"),
    ("meson.build", "C/C++"), ("Makefile", "Make"), ("Dockerfile", "Docker"), ("docker-compose.yml", "Docker"),
    ("compose.yaml", "Docker"), ("compose.yml", "Docker"), ("shell.qml", "QML"), ("pubspec.yaml", "Dart"),
    ("mix.exs", "Elixir"), ("deno.json", "Deno"),
]


def find_repos(root, depth):
    try:
        entries = list(os.scandir(root))
    except OSError:
        return
    if any(e.name == ".git" for e in entries):
        yield root
        return  # submodules and nested repos belong to this one
    if depth == 0:
        return
    for e in entries:
        if e.is_dir(follow_symlinks=False) and not e.name.startswith(".") and e.name not in SKIP:
            yield from find_repos(e.path, depth - 1)


def git_dir(path):
    g = os.path.join(path, ".git")
    if os.path.isfile(g):  # worktree / submodule: "gitdir: <path>"
        try:
            with open(g, encoding="utf-8") as f:
                line = f.read().strip()
            if line.startswith("gitdir:"):
                d = line.split(":", 1)[1].strip()
                return d if os.path.isabs(d) else os.path.normpath(os.path.join(path, d))
        except OSError:
            pass
    return g


def info(path):
    out = {"name": os.path.basename(path), "path": path, "branch": "", "changes": 0, "ahead": 0, "behind": 0,
           "kinds": [], "used": 0}
    gd = git_dir(path)
    # Last activity: the newest of HEAD, index and the last fetch
    for f in ("HEAD", "index", "FETCH_HEAD", "logs/HEAD"):
        try:
            out["used"] = max(out["used"], int(os.stat(os.path.join(gd, f)).st_mtime))
        except OSError:
            pass
    try:
        r = subprocess.run(["git", "--no-optional-locks", "-C", path, "status", "--porcelain=v1", "--branch"],
                           capture_output=True, text=True, timeout=3)
        lines = r.stdout.splitlines()
        if lines and lines[0].startswith("## "):
            head = lines[0][3:]
            branch = head.split("...")[0].split(" ")[0]
            if branch.startswith("No commits yet on "):
                branch = head[len("No commits yet on "):]
            out["branch"] = "" if branch == "HEAD" else branch
            if "[" in head:
                for part in head[head.index("[") + 1:head.rindex("]")].split(", "):
                    k, _, n = part.partition(" ")
                    if k in ("ahead", "behind") and n.isdigit():
                        out[k] = int(n)
            lines = lines[1:]
        out["changes"] = len(lines)
    except (subprocess.SubprocessError, OSError, ValueError):
        pass
    if not out["branch"]:
        try:
            with open(os.path.join(gd, "HEAD"), encoding="utf-8") as f:
                ref = f.read().strip()
            out["branch"] = ref.rsplit("/", 1)[-1] if ref.startswith("ref:") else ref[:7]
        except OSError:
            pass
    try:
        names = set(os.listdir(path))
    except OSError:
        names = set()
    kinds = []
    for marker, kind in MARKERS:
        if marker in names and kind not in kinds:
            kinds.append(kind)
    if "package.json" in names and any(n.startswith(("vite.config", "next.config")) for n in names):
        kinds[kinds.index("Node")] = "Node · " + ("Vite" if any(n.startswith("vite.config") for n in names) else "Next")
    out["kinds"] = kinds[:3]
    return out


def main():
    roots = []
    for r in sys.argv[1:]:
        p = os.path.realpath(os.path.expanduser(r))
        if os.path.isdir(p) and p not in roots:
            roots.append(p)
    repos = []
    for r in roots:
        for repo in find_repos(r, DEPTH):
            if repo not in repos:
                repos.append(repo)
    with ThreadPoolExecutor(max_workers=8) as pool:
        result = list(pool.map(info, repos))
    result.sort(key=lambda p: -p["used"])
    print(json.dumps(result))


if __name__ == "__main__":
    main()
