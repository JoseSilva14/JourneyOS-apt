import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Default apps: which app opens each kind of thing. First the apps that say they open it, then
// (after a separator) any other installed app.
Page {
    id: root

    Component.onCompleted: DefaultApps.refresh()

    Repeater {
        model: DefaultApps.categories

        SettingRow {
            id: row
            required property var modelData
            readonly property var info: DefaultApps.data[modelData.id] ?? { current: "", candidates: [], others: [] }
            readonly property var others: info.others ?? []

            title: modelData.label
            icon: modelData.icon

            Select {
                visible: row.info.candidates.length + row.others.length > 0
                options: row.info.candidates.map(c => ({ id: c.id, label: c.name }))
                    .concat(row.others.map(c => ({ id: c.id, label: c.name })))
                current: row.info.current
                onSelected: id => DefaultApps.set(row.modelData.id, id)
            }
            Text {
                visible: row.info.candidates.length + row.others.length === 0
                text: Tr.t("No app installed")
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }
}
