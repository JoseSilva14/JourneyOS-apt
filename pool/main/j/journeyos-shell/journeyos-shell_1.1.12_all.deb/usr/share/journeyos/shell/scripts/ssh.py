#!/usr/bin/env python3
"""SSH keys and hosts for Settings → Development and the launcher.

ssh.py status          JSON { keys: [...], hosts: [...], gh: "ok" | "login" | "missing", config: path }
  keys:   the key pairs in ~/.ssh ({ name, type, bits, comment, fingerprint, pub }), ed25519 first
  hosts:  the Host entries of ~/.ssh/config (and the files it Includes), without wildcards
          ({ name, hostname, user, port })
ssh.py generate        creates ~/.ssh/id_ed25519 (no passphrase; ssh-keygen -p adds one) and prints
                       its status entry. Refuses to overwrite an existing key
ssh.py github-add      adds the public key to the GitHub account with the gh command (needs gh and
                       "gh auth login"); prints what gh says
ssh.py github-test     ssh -T git@github.com: prints the GitHub user name it authenticates as (exit 0),
                       or the reason (exit 1)
ssh.py edit-config     makes sure ~/.ssh/config exists (mode 600) and prints its path
"""
import glob
import json
import os
import re
import shutil
import socket
import subprocess
import sys

SSH = os.path.expanduser("~/.ssh")
CONFIG = os.path.join(SSH, "config")
KEY = os.path.join(SSH, "id_ed25519")


def run(cmd, timeout=15, **kw):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)
        return r.returncode, r.stdout, r.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, "", str(e)


def key_info(pub_path):
    try:
        with open(pub_path, encoding="utf-8") as f:
            pub = f.read().strip()
    except OSError:
        return None
    code, out, _ = run(["ssh-keygen", "-l", "-f", pub_path])
    if code != 0:
        return None
    # "256 SHA256:abc… comment (ED25519)"
    m = re.match(r"(\d+)\s+(\S+)\s+(.*)\s+\((\w+)\)$", out.strip())
    if not m:
        return None
    return {"name": os.path.basename(pub_path)[:-4], "bits": int(m.group(1)), "fingerprint": m.group(2),
            "comment": m.group(3).strip(), "type": m.group(4).lower(), "pub": pub}


def keys():
    out = []
    for pub in sorted(glob.glob(os.path.join(SSH, "*.pub"))):
        # Only pairs (the private key next to it): not other people's keys kept here
        if not os.path.exists(pub[:-4]):
            continue
        k = key_info(pub)
        if k:
            out.append(k)
    out.sort(key=lambda k: (k["type"] != "ed25519", k["name"] != "id_ed25519", k["name"]))
    return out


def config_files(path, seen):
    """The config file and the ones it Includes (relative paths are under ~/.ssh), in order."""
    real = os.path.realpath(path)
    if real in seen or not os.path.isfile(path):
        return []
    seen.add(real)
    files = [path]
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return files
    for line in lines:
        m = re.match(r"\s*include\s+(.+)", line, re.I)
        if not m:
            continue
        for pattern in m.group(1).split():
            pattern = os.path.expanduser(pattern.strip('"'))
            if not os.path.isabs(pattern):
                pattern = os.path.join(SSH, pattern)
            for inc in sorted(glob.glob(pattern)):
                files += config_files(inc, seen)
    return files


def hosts():
    out, names = [], set()
    for path in config_files(CONFIG, set()):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except OSError:
            continue
        current = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = re.split(r"\s*=\s*|\s+", line, maxsplit=1)
            key, value = parts[0].lower(), (parts[1] if len(parts) > 1 else "").strip().strip('"')
            if key == "host":
                current = []
                for name in value.split():
                    # Patterns (*, ?, !negations) are rules, not places to connect to
                    if re.search(r"[*?!]", name) or name in names:
                        continue
                    names.add(name)
                    h = {"name": name, "hostname": "", "user": "", "port": ""}
                    out.append(h)
                    current.append(h)
            elif key == "match":
                current = []
            elif key in ("hostname", "user", "port"):
                for h in current:
                    if not h[key]:
                        h[key] = value
    return out


def gh_state():
    if not shutil.which("gh"):
        return "missing"
    code, _, _ = run(["gh", "auth", "status", "--hostname", "github.com"], timeout=8)
    return "ok" if code == 0 else "login"


def main():
    a = sys.argv[1:]
    if a == ["status"]:
        print(json.dumps({"keys": keys(), "hosts": hosts(), "gh": gh_state(), "config": CONFIG}))
        return 0
    if a == ["generate"]:
        if os.path.exists(KEY) or os.path.exists(KEY + ".pub"):
            print("~/.ssh/id_ed25519 already exists", file=sys.stderr)
            return 1
        os.makedirs(SSH, mode=0o700, exist_ok=True)
        os.chmod(SSH, 0o700)
        comment = f"{os.environ.get('USER', 'user')}@{socket.gethostname()}"
        code, _, err = run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", comment, "-f", KEY])
        if code != 0:
            print(err.strip(), file=sys.stderr)
            return 1
        print(json.dumps(key_info(KEY + ".pub")))
        return 0
    if a == ["github-add"]:
        ks = keys()
        if not ks:
            print("no SSH key", file=sys.stderr)
            return 1
        title = f"{socket.gethostname()} (JourneyOS)"
        code, out, err = run(["gh", "ssh-key", "add", os.path.join(SSH, ks[0]["name"] + ".pub"), "--title", title], timeout=30)
        text = (out + err).strip()
        # Already there counts as done
        if code != 0 and "already" in text.lower():
            code = 0
        print(text, file=sys.stdout if code == 0 else sys.stderr)
        return code
    if a == ["github-test"]:
        # GitHub always closes with exit 1; the greeting says whether the key was accepted. Its host
        # key is added to known_hosts the first time (accept-new: never replaces a different one)
        code, out, err = run(["ssh", "-T", "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new",
                              "-o", "ConnectTimeout=10", "git@github.com"], timeout=20)
        text = (out + err).strip()
        m = re.search(r"Hi ([^!]+)! You've successfully authenticated", text)
        if m:
            print(m.group(1))
            return 0
        print(text.splitlines()[-1] if text else "no answer from github.com", file=sys.stderr)
        return 1
    if a == ["edit-config"]:
        os.makedirs(SSH, mode=0o700, exist_ok=True)
        if not os.path.exists(CONFIG):
            with open(CONFIG, "w", encoding="utf-8") as f:
                f.write("# SSH hosts: each one shows up in the launcher (\"ssh name\" opens a terminal there).\n"
                        "# Example:\n"
                        "# Host server\n"
                        "#     HostName 192.168.1.10\n"
                        "#     User me\n")
            os.chmod(CONFIG, 0o600)
        print(CONFIG)
        return 0
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
