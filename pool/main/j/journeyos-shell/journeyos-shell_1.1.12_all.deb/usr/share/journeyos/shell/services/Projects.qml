pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Projects in the launcher: the git repositories under dev.projectRoots (scripts/projects.py), with
// branch, uncommitted changes, ahead/behind and what they're made of. Typing a project's name opens
// it in the editor; "cd <name>" opens a terminal there; "projects" lists them all, most recent first.
// The list is refreshed when the launcher opens (at most every 30 s).
Singleton {
    id: root

    property var list: []
    property bool loaded: false
    property double scannedAt: 0

    readonly property var roots: Config.options.dev.projectRoots ?? []

    function refresh(force) {
        if (scanner.running || (!force && Date.now() - scannedAt < 30000))
            return;
        scanner.command = ["python3", Quickshell.shellPath("scripts/projects.py"), ...roots];
        scanner.running = true;
    }

    Connections {
        target: Launcher
        function onOpenChanged() { if (Launcher.open) root.refresh(false); }
    }

    Process {
        id: scanner
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    root.list = JSON.parse(text);
                } catch (e) {
                    console.warn("projects: invalid reply");
                }
                root.loaded = true;
                root.scannedAt = Date.now();
            }
        }
    }

    // --- Opening ---
    // Code editors, in order of preference, when dev.editor is "auto"
    readonly property var editors: ["com.microsoft.VSCode.desktop", "code.desktop", "code-oss.desktop", "codium.desktop", "com.visualstudio.code.desktop",
        "com.vscodium.codium.desktop", "dev.zed.Zed.desktop", "zed.desktop", "jetbrains-idea.desktop", "jetbrains-goland.desktop",
        "org.kde.kate.desktop"]

    function entry(id) {
        return DesktopEntries.applications.values.find(e => e.id === id || e.id + ".desktop" === id) ?? null;
    }

    readonly property var editorEntry: {
        const chosen = Config.options.dev.editor ?? "auto";
        if (chosen !== "auto")
            return entry(chosen);
        for (const id of editors) {
            const e = entry(id);
            if (e)
                return e;
        }
        return null;
    }
    // For choosing (Settings → Development): the known editors, then the installed development and
    // text-editing apps, then every other app (any app can open a folder, if it knows how)
    readonly property var editorChoices: {
        const all = DesktopEntries.applications.values.filter(e => !e.noDisplay && !e.id.startsWith("shadow-kde-"));
        const known = editors.map(id => entry(id)).filter(e => e);
        const dev = all.filter(e => !known.includes(e)
            && (e.categories ?? []).some(c => c === "TextEditor" || c === "IDE" || c === "Development"));
        const rest = all.filter(e => !known.includes(e) && !dev.includes(e));
        const byName = (a, b) => a.name.localeCompare(b.name);
        return [...known, ...dev.sort(byName)].map(e => ({ id: e.id, label: e.name }))
            .concat(rest.sort(byName).map(e => ({ id: e.id, label: e.name })));
    }
    readonly property string editorName: editorEntry ? editorEntry.name : (Config.options.dev.editor !== "auto" ? Config.options.dev.editor : "")

    function openEditor(path) {
        const chosen = Config.options.dev.editor ?? "auto";
        let cmd;
        if (editorEntry)
            cmd = editorEntry.command.filter(a => !/^%[a-zA-Z]$/.test(a));
        else if (chosen !== "auto")
            cmd = chosen.split(/\s+/).filter(a => a);   // a plain command ("nvim-qt", "subl")
        else
            cmd = ["xdg-open"];
        Apps.run(["sh", "-c", 'cd "$0" && exec "$@"', path, ...cmd, path]);
    }

    function openTerminal(path) { Apps.run(["konsole", "--workdir", path]); }

    // --- Launcher results ---
    function home(path) { return path.replace(Quickshell.env("HOME"), "~"); }

    function describe(p) {
        const parts = [];
        if (p.branch)
            parts.push(p.branch);
        if (p.changes)
            parts.push(p.changes + (p.changes === 1 ? Tr.t(" change") : Tr.t(" changes")));
        if (p.ahead)
            parts.push("↑" + p.ahead);
        if (p.behind)
            parts.push("↓" + p.behind);
        parts.push(...p.kinds);
        parts.push(home(p.path));
        return parts.join(" · ");
    }

    function item(p, terminal) {
        return {
            kind: "project", key: (terminal ? "cd:" : "p:") + p.path, title: terminal ? Tr.t("Terminal in ") + p.name : p.name,
            subtitle: describe(p), glyph: terminal ? "terminal" : (p.changes ? "edit_note" : "code"),
            run: () => terminal ? root.openTerminal(p.path) : root.openEditor(p.path)
        };
    }

    function score(p, q) {
        const name = Launcher.norm(p.name);
        if (name === q) return 950;
        if (name.startsWith(q)) return 750;
        if (Launcher.words(p.name).some(w => w.startsWith(q))) return 560;
        if (name.includes(q)) return 420;
        if (Launcher.norm(p.path).includes("/" + q)) return 200;
        if (q.length >= 3 && Launcher.subsequence(q, name)) return 110;
        return 0;
    }

    // [{ item, s }] for the launcher; listAll = the "projects" keyword
    function results(raw) {
        const q = Launcher.norm(raw.trim());
        if (!q || !list.length)
            return [];
        if (/^(projects?|projetos?|repos?|repositorios?)$/.test(q))
            return list.slice(0, 30).map((p, i) => ({ item: item(p, false), s: 1000 - i }));
        const cd = /^cd\s+(.*)$/.exec(q);
        if (cd) {
            const t = cd[1].trim();
            return list.map(p => ({ item: item(p, true), s: t ? score(p, t) : 300 })).filter(x => x.s > 0);
        }
        // From 2 letters (a single one would bring every project with that initial)
        if (q.length < 2)
            return [];
        return list.map(p => ({ item: item(p, false), s: score(p, q) })).filter(x => x.s > 0);
    }

    IpcHandler {
        target: "projects"
        function list(): string { return JSON.stringify(root.list.map(p => p.name + " | " + root.describe(p))); }
        function refresh(): void { root.refresh(true); }
        function open(name: string): void {
            const p = root.list.find(x => x.name === name);
            if (p)
                root.openEditor(p.path);
        }
        function editor(): string { return root.editorName; }
    }
}
