pragma Singleton

import QtQuick
import Quickshell

// Dock apps: the pinned ones (config.json, dock.pinned) and then
// the open ones that are not pinned, each with its windows.
Singleton {
    id: root

    readonly property var pinned: Config.options.dock.pinned

    // A window's .desktop entry: by the .desktop name, otherwise by the class
    function entryFor(w) {
        return DesktopEntries.byId(w.appId)
            ?? DesktopEntries.byId(w.cls)
            ?? DesktopEntries.heuristicLookup(w.cls)
            ?? null;
    }

    // The shell's own windows (settings) have the
    // Quickshell id: they count as the settings entry's windows
    readonly property string selfKey: "org.quickshell"

    function keyFor(w) {
        // The shell's windows are told apart by title (the Calculator, the Phone, Passwords; the rest are Settings)
        if (w.appId === selfKey)
            return w.title === Tr.t("Calculator") ? "shadow-kde-calculadora"
                : w.title === Tr.t("Phone") ? "shadow-kde-telemovel"
                : w.title === Tr.t("Passwords") ? "shadow-kde-palavras-passe" : SettingsApp.desktopId;
        const e = entryFor(w);
        return e ? e.id : (w.appId || w.cls);
    }

    // [{ key, entry, windows, pinned, name?, icon? }] (name/icon when there is no .desktop entry)
    readonly property var apps: {
        const groups = {};
        for (const w of Windows.list) {
            const k = keyFor(w);
            (groups[k] = groups[k] ?? []).push(w);
        }
        const out = [];
        for (const id of pinned) {
            const entry = DesktopEntries.byId(id);
            if (entry)
                out.push({ key: id, entry, windows: groups[id] ?? [], pinned: true });
        }
        for (const k in groups) {
            if (pinned.includes(k))
                continue;
            if (k === SettingsApp.desktopId)
                out.push({ key: k, entry: DesktopEntries.byId(k), windows: groups[k], pinned: false, name: Tr.t("Settings"), icon: "preferences-system" });
            else
                // The shell's tools (shadow-kde-*) get their entry from the group id
                out.push({ key: k, entry: DesktopEntries.byId(k) ?? entryFor(groups[k][0]), windows: groups[k], pinned: false });
        }
        return out;
    }

    function isPinned(key) { return pinned.includes(key); }

    function setPinned(key, on) {
        const list = pinned.filter(k => k !== key);
        if (on)
            list.push(key);
        Config.options.dock.pinned = list;
    }

    // Click: opens if there are no windows; with one, activates/minimizes; with several, goes
    // to the next (the active one, if it belongs to this app, minimizes on the last)
    function activate(app) {
        const ws = app.windows;
        if (ws.length === 0) {
            if (app.entry)
                Apps.launch(app.entry);
            return;
        }
        if (ws.length === 1) {
            Windows.toggle(ws[0].id);
            return;
        }
        const i = ws.findIndex(w => w.active);
        Windows.activate(ws[(i + 1) % ws.length].id);
    }

    function closeAll(app) {
        for (const w of app.windows)
            Windows.close(w.id);
    }
}
