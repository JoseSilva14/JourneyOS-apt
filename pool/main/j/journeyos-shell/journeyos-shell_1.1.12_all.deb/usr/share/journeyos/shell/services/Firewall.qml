pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Firewall (ufw), for Settings → Network. Reading goes through /usr/lib/journeyos/firewall-status
// (pkexec, no password for the person at the computer); changes through /usr/lib/journeyos/firewall
// (pkexec, administrators, asks once and remembers for a few minutes). Both and their polkit policy
// come with journeyos-desktop.
Singleton {
    id: root

    property bool loaded: false
    property bool installed: false
    property bool enabled: false
    property var rules: []          // [{ action, spec, comment, args }]
    property bool busy: false
    property string message: ""

    function refresh() {
        if (!reader.running)
            reader.running = true;
    }

    function change(args, done) {
        busy = true;
        message = "";
        Run.cmd(["pkexec", "/usr/lib/journeyos/firewall", ...args], (code, out, err) => {
            busy = false;
            if (code === 126 || code === 127)
                message = Tr.t("Not authorized");
            else if (code !== 0)
                message = err.trim() || Tr.t("Could not change the firewall");
            else if (done)
                message = done;
            refresh();
        });
    }

    function setEnabled(on) {
        change([on ? "enable" : "disable"], on ? Tr.t("Firewall on") : Tr.t("Firewall off"));
    }

    // port: "8000" or "6000:6010"; proto: tcp | udp | any
    function allow(port, proto, comment) {
        change(["allow", String(port).trim(), proto, comment || ""], Tr.t("Port opened"));
    }

    function remove(rule) {
        change(["delete", ...rule.args], Tr.t("Rule removed"));
    }

    Process {
        id: reader
        command: ["pkexec", "/usr/lib/journeyos/firewall-status"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const d = JSON.parse(text);
                    root.installed = d.installed;
                    root.enabled = d.enabled;
                    root.rules = d.rules ?? [];
                } catch (e) {
                    root.installed = false;
                }
                root.loaded = true;
            }
        }
    }

    IpcHandler {
        target: "firewall"
        function status(): string { return JSON.stringify({ installed: root.installed, enabled: root.enabled, rules: root.rules.map(r => r.spec), message: root.message }); }
        function refresh(): void { root.refresh(); }
    }
}
