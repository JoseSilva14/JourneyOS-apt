pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Open bar menu (sound, network or Bluetooth). Opening one closes the other panels.
Singleton {
    id: root

    property string open: ""        // "" | sound | network | bluetooth | claude | docker
    property var screen: null

    function toggle(name, screen) {
        if (open === name && (!screen || screen === root.screen)) {
            open = "";
            return;
        }
        root.screen = screen ?? Windows.activeScreen;
        open = name;
    }

    onOpenChanged: {
        if (open) {
            QuickPanel.open = false;
            Notifs.centerOpen = false;
            Dashboard.open = false;
        }
    }

    Connections {
        target: QuickPanel
        function onOpenChanged() { if (QuickPanel.open) root.open = ""; }
    }
    Connections {
        target: Notifs
        function onCenterOpenChanged() { if (Notifs.centerOpen) root.open = ""; }
    }

    IpcHandler {
        target: "menu"
        function sound(): void { root.toggle("sound", null); }
        function network(): void { root.toggle("network", null); }
        function bluetooth(): void { root.toggle("bluetooth", null); }
        function claude(): void { root.toggle("claude", null); }
        function docker(): void { root.toggle("docker", null); }
        function close(): void { root.open = ""; }
    }
}
