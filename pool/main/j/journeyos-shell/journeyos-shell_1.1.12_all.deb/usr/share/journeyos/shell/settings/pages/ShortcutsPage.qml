import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services

// Shortcuts: click the shortcut and press the new keys (Esc cancels, Backspace clears).
// Below, the user's own shortcuts: open an app or run a command.
Page {
    id: root

    readonly property var actions: [
        { id: "launcher", title: Tr.t("App launcher"), icon: "apps" },
        { id: "panel", title: Tr.t("Quick panel"), icon: "tune" },
        { id: "notifications", title: Tr.t("Notification center"), icon: "notifications" },
        { id: "dashboard", title: "Dashboard", icon: "dashboard" },
        { id: "wallpapers", title: "Wallpapers", icon: "wallpaper" },
        { id: "widgets", title: Tr.t("Edit widgets"), icon: "widgets" },
        { id: "settings", title: Tr.t("Settings"), icon: "tune" },
        { id: "clipboard", title: Tr.t("Clipboard"), icon: "content_paste" },
        { id: "captureRegion", title: Tr.t("Screenshot of a region"), icon: "crop" },
        { id: "captureScreen", title: Tr.t("Screenshot of the screen"), icon: "fullscreen" },
        { id: "captureWindow", title: Tr.t("Screenshot of active window"), icon: "web_asset" },
        { id: "colorPicker", title: Tr.t("Color picker"), icon: "colorize" },
        ...Tiling.layouts.map(l => ({ id: l.shortcut, title: Tr.t("Windows: ") + l.title.toLowerCase(), icon: l.icon }))
    ]

    readonly property var custom: Config.options.shortcuts.custom ?? []

    readonly property var apps: DesktopEntries.applications.values.filter(e => !e.noDisplay)
        .map(e => ({ id: e.id, label: e.name }))
        .sort((a, b) => a.label.localeCompare(b.label))

    property string recording: ""      // action waiting for keys ("custom-<id>" for the user's own)
    property bool metaAlone: false      // Meta is down and nothing else was pressed since

    // While recording, the keys go to the page only (otherwise Meta alone, Meta+Space… would also
    // open what they are assigned to)
    function blockShortcuts(on) {
        Run.cmd(["gdbus", "call", "--session", "--dest", "org.kde.kglobalaccel", "--object-path", "/kglobalaccel",
            "--method", "org.kde.KGlobalAccel.blockGlobalShortcuts", on ? "true" : "false"]);
    }
    onRecordingChanged: blockShortcuts(recording !== "")
    Component.onDestruction: if (recording !== "") blockShortcuts(false)

    function isMeta(key) {
        return key === Qt.Key_Meta || key === Qt.Key_Super_L || key === Qt.Key_Super_R;
    }

    function keysOf(id) {
        if (id.startsWith("custom-"))
            return custom.find(c => "custom-" + c.id === id)?.keys ?? "";
        return Config.options.shortcuts[id] ?? "";
    }

    // A key belongs to one action at a time: it is taken from any other one (built-in or the user's)
    function assign(id, keys) {
        const mine = id.startsWith("custom-");
        if (keys)
            for (const a of actions)
                if (a.id !== id && Config.options.shortcuts[a.id] === keys)
                    Config.options.shortcuts[a.id] = "";
        if (mine || keys)
            Config.options.shortcuts.custom = custom.map(c => "custom-" + c.id === id ? Object.assign({}, c, { keys })
                : keys && c.keys === keys ? Object.assign({}, c, { keys: "" }) : c);
        if (!mine)
            Config.options.shortcuts[id] = keys;
    }

    // Recording ends before saving: saving a shortcut of the user's rebuilds its row (and the
    // key box handling the key with it), so nothing can be left to do in that box afterwards
    function record(id, keys) {
        recording = "";
        assign(id, keys);
    }

    function addCustom(entry) {
        const id = Date.now().toString(36);
        Config.options.shortcuts.custom = [...custom, Object.assign({ id, keys: "" }, entry)];
        // Straight to choosing its keys
        recording = "custom-" + id;
    }

    function removeCustom(id) {
        if (recording === "custom-" + id)
            recording = "";
        Config.options.shortcuts.custom = custom.filter(c => c.id !== id);
    }

    // Qt key → name in shortcut format ("Meta+Alt+D")
    function keyName(event) {
        const k = event.key;
        let name = "";
        if (k >= Qt.Key_A && k <= Qt.Key_Z) name = String.fromCharCode(k);
        else if (k >= Qt.Key_0 && k <= Qt.Key_9) name = String.fromCharCode(k);
        else if (k >= Qt.Key_F1 && k <= Qt.Key_F12) name = "F" + (k - Qt.Key_F1 + 1);
        else if (k === Qt.Key_Space) name = "Space";
        else if (k === Qt.Key_Return) name = "Return";
        else if (k === Qt.Key_Print) name = "Print";
        else if (k === Qt.Key_Delete) name = "Delete";
        else return "";
        const m = event.modifiers;
        const mods = [];
        if (m & Qt.MetaModifier) mods.push("Meta");
        if (m & Qt.ControlModifier) mods.push("Ctrl");
        if (m & Qt.AltModifier) mods.push("Alt");
        if (m & Qt.ShiftModifier) mods.push("Shift");
        return [...mods, name].join("+");
    }

    // The key box: click it and press the keys
    component KeyBox: Rectangle {
        id: keyBox
        required property string action
        readonly property string keys: root.keysOf(action)
        readonly property bool waiting: root.recording === action

        implicitWidth: Math.max(140, keyText.implicitWidth + 28)
        implicitHeight: 34
        radius: Theme.radiusSmall + 2
        color: waiting ? Theme.accent : keyMouse.containsMouse ? Theme.buttonHover : Theme.button
        focus: waiting
        // A new shortcut of the user's is created already waiting for its keys
        onWaitingChanged: if (waiting) forceActiveFocus()
        Component.onCompleted: if (waiting) forceActiveFocus()

        Behavior on color {
            ColorAnimation { duration: Theme.animFast }
        }

        Text {
            id: keyText
            anchors.centerIn: parent
            text: keyBox.waiting ? Tr.t("Press the keys…") : (keyBox.keys || Tr.t("No shortcut"))
            color: keyBox.waiting ? Theme.accentText : keyBox.keys ? Theme.text : Theme.dim
            font.family: Theme.font
            font.pixelSize: Theme.fontNormal
            font.weight: Font.Bold
        }

        MouseArea {
            id: keyMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                root.recording = keyBox.waiting ? "" : keyBox.action;
                keyBox.forceActiveFocus();
            }
        }

        Keys.onPressed: event => {
            if (!keyBox.waiting)
                return;
            event.accepted = true;
            // Meta on its own: decided when it is released without anything else in between
            root.metaAlone = root.isMeta(event.key) && !event.isAutoRepeat
                ? (event.modifiers & ~Qt.MetaModifier) === 0 : false;
            if (event.key === Qt.Key_Escape) {
                root.recording = "";
            } else if (event.key === Qt.Key_Backspace) {
                root.record(keyBox.action, "");
            } else {
                const name = root.keyName(event);
                if (name)
                    root.record(keyBox.action, name);
            }
        }
        Keys.onReleased: event => {
            if (!keyBox.waiting)
                return;
            event.accepted = true;
            if (root.isMeta(event.key) && root.metaAlone) {
                root.metaAlone = false;
                root.record(keyBox.action, "Meta");
            }
        }
    }

    Text {
        Layout.fillWidth: true
        text: Tr.t("Click a shortcut and press the new keys (Meta on its own also works: press and release it). Esc cancels, Backspace removes the shortcut.")
        wrapMode: Text.Wrap
        color: Theme.subtext
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: root.actions

        SettingRow {
            id: row
            required property var modelData
            readonly property string conflict: Shortcuts.conflicts[modelData.id] ?? ""

            title: modelData.title
            description: conflict ? Tr.t("This key belongs to “") + conflict + Tr.t("”: choose another.") : ""
            icon: modelData.icon

            KeyBox { action: row.modelData.id }
        }
    }

    // The user's own: an app or a command
    SectionLabel { text: Tr.t("Your shortcuts") }

    Repeater {
        model: root.custom

        SettingRow {
            id: crow
            required property var modelData
            readonly property string conflict: Shortcuts.conflicts["custom-" + modelData.id] ?? ""
            readonly property bool found: !modelData.app || DesktopEntries.byId(modelData.app) !== null

            title: modelData.name
            description: conflict ? Tr.t("This key belongs to “") + conflict + Tr.t("”: choose another.")
                : modelData.app ? (found ? Tr.t("Opens the app") : Tr.t("App not found")) : modelData.command
            icon: modelData.app ? "apps" : "terminal"

            RowLayout {
                spacing: 8
                KeyBox { action: "custom-" + crow.modelData.id }
                Rectangle {
                    implicitWidth: 32
                    implicitHeight: 32
                    radius: 16
                    color: removeMouse.containsMouse ? Theme.buttonHover : Theme.button
                    MIcon {
                        anchors.centerIn: parent
                        icon: "delete"
                        size: 16
                    }
                    MouseArea {
                        id: removeMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.removeCustom(crow.modelData.id)
                    }
                }
            }
        }
    }

    Text {
        Layout.fillWidth: true
        visible: root.custom.length === 0
        text: Tr.t("No shortcuts of your own yet. Add one below: an app or a command.")
        wrapMode: Text.Wrap
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    SettingRow {
        title: Tr.t("Open an app")
        description: Tr.t("Choose the app, then press the keys.")
        icon: "add"
        Select {
            options: root.apps
            placeholder: Tr.t("Choose…")
            searchable: true
            onSelected: id => root.addCustom({ name: root.apps.find(a => a.id === id)?.label ?? id, app: id })
        }
    }

    Rectangle {
        Layout.fillWidth: true
        implicitHeight: form.implicitHeight + 32
        radius: Theme.radius
        color: Theme.surfaceCard
        border.width: 1
        border.color: Theme.surfaceBorder

        ColumnLayout {
            id: form
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.margins: 16
            spacing: 10

            Text {
                Layout.fillWidth: true
                text: Tr.t("Run a command")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: Theme.fontNormal
                font.weight: Font.DemiBold
            }
            Text {
                Layout.fillWidth: true
                text: Tr.t("Runs in sh, as in a terminal (e.g. konsole -e htop, or playerctl play-pause). After adding, press the keys.")
                wrapMode: Text.Wrap
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: cmdName
                    implicitWidth: 150
                    placeholder: Tr.t("Name")
                    acceptOnBlur: false
                }
                TextField {
                    id: cmdText
                    Layout.fillWidth: true
                    placeholder: Tr.t("Command")
                    acceptOnBlur: false
                    onAccepted: addCmd.clicked()
                }
                PillButton {
                    id: addCmd
                    text: Tr.t("Add##juntar")
                    accent: true
                    enabled: cmdText.text.trim() !== ""
                    onClicked: {
                        const command = cmdText.text.trim();
                        if (!command)
                            return;
                        root.addCustom({ name: cmdName.text.trim() || command.split(" ")[0], command });
                        cmdName.text = "";
                        cmdText.text = "";
                    }
                }
            }
        }
    }
}
