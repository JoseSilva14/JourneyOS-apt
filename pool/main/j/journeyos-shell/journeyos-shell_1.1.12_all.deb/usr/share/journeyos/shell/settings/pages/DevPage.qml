import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Development: the Dev UI (the dashboard's Dev tab, with ports in use and Docker containers), Docker in
// the bar, the notification for long terminal commands, the projects in the launcher, SSH keys and hosts
// and the Claude limits.
Page {
    id: root

    Component.onCompleted: {
        Projects.refresh(true);
        Ssh.refresh(true);
        ClaudeUsage.refresh();
    }

    SectionLabel { text: "UI Dev" }

    SettingRow {
        title: "UI Dev"
        description: Tr.t("Adds the Dev tab to the dashboard: ports in use (which program is on each) and Docker containers, with start, stop, logs and terminal.")
        icon: "terminal"
        Toggle {
            checked: Config.options.dev.enabled
            onToggled: on => Config.options.dev.enabled = on
        }
    }

    SettingRow {
        visible: Config.options.dev.enabled
        title: Tr.t("Open the Dev tab")
        description: Tr.t("Also with \"portas\" or \"contentores\" in the launcher.")
        icon: "space_dashboard"
        PillButton {
            text: Tr.t("Open")
            onClicked: Dashboard.toggle("dev", null)
        }
    }

    SettingRow {
        title: Tr.t("Docker in the bar")
        description: Dev.dockerState === "missing" ? Tr.t("Docker is not installed.")
            : Dev.dockerState === "permission" ? Tr.t("No access to Docker: add yourself to the docker group (sudo usermod -aG docker $USER) and log in again.")
            : Dev.dockerState === "down" ? Tr.t("The Docker service is stopped.")
            : Tr.t("How many containers are running, and which failed (with a notification when one fails). Shows up when there are containers.")
        icon: "view_in_ar"
        Toggle {
            checked: Config.options.dev.dockerBar
            onToggled: on => Config.options.dev.dockerBar = on
        }
    }

    // --- Terminal ---
    SectionLabel { text: Tr.t("Terminal") }

    SettingRow {
        title: Tr.t("Tell me when a long command finishes")
        description: Tr.t("A notification when a terminal command ends while you're in another window, with how it went. Clicking it brings the terminal back.")
        icon: "notifications_active"
        Toggle {
            checked: Config.options.dev.notifyCommands
            onToggled: on => Config.options.dev.notifyCommands = on
        }
    }

    SettingRow {
        visible: Config.options.dev.notifyCommands
        title: Tr.t("Long means")
        description: Tr.t("In zsh (the default shell). JOURNEYOS_NOTIFY=0 in ~/.zshrc turns it off for good.")
        icon: "timer"
        Select {
            options: [10, 30, 60, 120, 300].map(s => ({ id: String(s), label: s < 60 ? s + Tr.t(" seconds") : s === 60 ? Tr.t("1 minute") : (s / 60) + Tr.t(" minutes") }))
            current: String(Config.options.dev.notifyAfter)
            onSelected: id => Config.options.dev.notifyAfter = Number(id)
        }
    }

    // --- Projects ---
    SectionLabel { text: Tr.t("Projects") }

    SettingRow {
        title: Projects.loaded ? Projects.list.length + (Projects.list.length === 1 ? Tr.t(" project found") : Tr.t(" projects found")) : Tr.t("Projects")
        description: Tr.t("Git repositories in your project folders show up in the launcher: type the name to open it in the editor, \"cd name\" for a terminal there, \"projects\" for all of them.")
        icon: "source"
        PillButton {
            text: Tr.t("Look again")
            onClicked: Projects.refresh(true)
        }
    }

    SettingRow {
        title: Tr.t("Project folders")
        description: Tr.t("Searched up to three levels down. Separated by commas.")
        icon: "folder"
        TextField {
            implicitWidth: 300
            text: (Config.options.dev.projectRoots ?? []).join(", ")
            onAccepted: t => {
                Config.options.dev.projectRoots = t.split(",").map(x => x.trim()).filter(x => x);
                Projects.refresh(true);
            }
        }
    }

    SettingRow {
        title: Tr.t("Open projects in")
        description: Config.options.dev.editor === "auto" ? Tr.t("Automatic: ") + (Projects.editorName || Tr.t("no code editor found")) : ""
        icon: "code"
        Select {
            options: [{ id: "auto", label: Tr.t("Automatic") }].concat(Projects.editorChoices)
            searchable: true
            current: Config.options.dev.editor
            onSelected: id => Config.options.dev.editor = id
        }
    }

    // --- SSH ---
    SectionLabel { text: "SSH" }

    SettingRow {
        title: Ssh.key ? Tr.t("SSH key") : Tr.t("No SSH key yet")
        description: Ssh.key ? Ssh.key.type + " · " + Ssh.key.fingerprint + (Ssh.key.comment ? " · " + Ssh.key.comment : "")
            : Tr.t("Creates ~/.ssh/id_ed25519, to use git with GitHub and to log in to servers without a password. No passphrase (ssh-keygen -p adds one).")
        icon: "key"
        PillButton {
            visible: !Ssh.key
            enabled: !Ssh.busy
            text: Tr.t("Create key")
            accent: true
            onClicked: Ssh.generate()
        }
        PillButton {
            visible: !!Ssh.key
            text: Tr.t("Copy")
            onClicked: Ssh.copyKey()
        }
    }

    SettingRow {
        visible: !!Ssh.key
        title: "GitHub"
        description: Ssh.githubUser ? Tr.t("Working: GitHub knows this key as ") + Ssh.githubUser + "."
            : Ssh.githubError ? Ssh.githubError
            : Ssh.gh === "ok" ? Tr.t("Adds the key to your GitHub account (with the gh command, already logged in).")
            : Tr.t("Copies the key and opens GitHub's page to paste it. With the gh command logged in (gh auth login), it's added straight away.")
        icon: "cloud_upload"
        RowLayout {
            spacing: 8
            PillButton {
                enabled: !Ssh.busy
                text: Tr.t("Add to GitHub")
                accent: !Ssh.githubUser
                onClicked: Ssh.addToGithub()
            }
            PillButton {
                enabled: !Ssh.busy
                text: Ssh.busy ? Tr.t("Testing…") : Tr.t("Test")
                onClicked: Ssh.testGithub()
            }
        }
    }

    SettingRow {
        title: Ssh.hosts.length ? Ssh.hosts.length + (Ssh.hosts.length === 1 ? Tr.t(" SSH host") : Tr.t(" SSH hosts")) : Tr.t("SSH hosts")
        description: Tr.t("The hosts in ~/.ssh/config show up in the launcher: \"ssh name\" opens a terminal connected there, \"ssh\" lists them all.")
        icon: "dns"
        PillButton {
            text: Tr.t("Edit")
            onClicked: Ssh.editConfig()
        }
    }

    // --- Claude Code ---
    SectionLabel { text: "Claude Code" }

    SettingRow {
        title: Tr.t("Claude limits in the bar")
        description: !ClaudeUsage.installed ? Tr.t("Claude Code is not installed (curl -fsSL https://claude.ai/install.sh | bash).")
            : ClaudeUsage.connected ? Tr.t("Connected: the 5-hour and weekly use of your plan show in the bar after each answer (Pro and Max plans).")
            : Tr.t("Shows how much of your plan's 5-hour and weekly limits you've used. Adds a status line to Claude Code (yours, if you have one, keeps working).")
        icon: "auto_awesome"
        PillButton {
            visible: ClaudeUsage.installed
            text: ClaudeUsage.connected ? Tr.t("Disconnect") : Tr.t("Connect")
            accent: !ClaudeUsage.connected
            onClicked: ClaudeUsage.connected ? ClaudeUsage.disconnect() : ClaudeUsage.connect(null)
        }
    }

    SettingRow {
        visible: ClaudeUsage.connected
        title: Tr.t("Show in the bar")
        description: ClaudeUsage.hasData ? Tr.t("Last numbers: ") + ClaudeUsage.agoText(ClaudeUsage.updated) : Tr.t("Waiting for Claude Code's next answer.")
        icon: "view_day"
        Toggle {
            checked: Config.options.dev.claudeBar
            onToggled: on => Config.options.dev.claudeBar = on
        }
    }
}
