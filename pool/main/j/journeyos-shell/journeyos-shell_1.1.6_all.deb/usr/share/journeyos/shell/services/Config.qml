pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Settings persisted in ~/.config/shadow-kde/config.json.
Singleton {
    id: root

    readonly property string dir: Quickshell.env("HOME") + "/.config/shadow-kde"
    readonly property alias options: adapter
    property bool ready: false
    property real lastWrite: 0

    FileView {
        id: file
        path: root.dir + "/config.json"
        watchChanges: true
        atomicWrites: true
        // Our own writes also arrive as "changed": re-reading them in the middle of
        // several consecutive changes restored old values (focus mode lost its "active")
        onFileChanged: {
            if (Date.now() - root.lastWrite > 3000)
                reload();
        }
        onAdapterUpdated: {
            root.lastWrite = Date.now();
            writeAdapter();
        }
        onLoaded: root.ready = true
        onLoadFailed: error => {
            // Does not exist yet: write the defaults
            if (error === FileViewError.FileNotFound) {
                writeAdapter();
                root.ready = true;
            }
        }

        JsonAdapter {
            id: adapter

            // Path to an image; empty = dark gradient
            // JourneyOS wallpaper (journeyos-desktop); the user's choice is saved in config.json
            property string wallpaper: "/usr/share/wallpapers/JourneyOS/contents/images/3840x2160.jpg"
            // Name on the user card; empty = the system's
            property string displayName: ""
            // Photo on the user card; empty = ~/.face
            property string avatar: ""
            // Folders for the Wallpapers tab (KDE theme folders give one image per theme)
            property list<string> wallpaperDirs: ["~/Pictures/Wallpapers", "/usr/share/wallpapers"]

            // First-run wizard (welcome/): shown while done is false
            property JsonObject welcome: JsonObject {
                property bool done: false
            }

            // Pomodoro (services/Countdown.qml, the pill's Time tab)
            property JsonObject pomodoro: JsonObject {
                property int focus: 25              // minutes
                property int shortBreak: 5
                property int longBreak: 15
                property int every: 4               // long break every N focus sessions
                property bool autoStart: true       // the next phase starts on its own
                property string focusMode: ""       // focus mode turned on during the session ("" = none)
                property bool showTask: true        // the next task next to the time
            }

            // Eyedropper (services/Colors.qml)
            property JsonObject colors: JsonObject {
                property string format: "hex"       // hex | rgb | hsl
            }

            // Window tiling (services/Tiling.qml)
            property JsonObject tiling: JsonObject {
                property int gap: 8                 // px between windows and around them
            }

            // Updates: look online at login (a notification if there are any)
            property JsonObject updates: JsonObject {
                property bool checkAtLogin: true
            }

            property JsonObject session: JsonObject {
                property string windows: ""         // "Restart to Windows": PARTUUID (or number) of the entry; "" = the first
            }

            property JsonObject polkit: JsonObject {
                property bool own: true             // the shell's authorization dialog (instead of KDE's)
            }

            property JsonObject a11y: JsonObject {
                property bool reduceMotion: false   // shell animations set to 0
            }

            property JsonObject clock: JsonObject {
                property bool use24h: true
            }

            // Shell language: auto (the system's) | pt | en (services/Tr.qml)
            property string language: "auto"

            property JsonObject theme: JsonObject {
                property string scheme: "mono"      // see services/Scheme.qml
                property string wallColor: ""       // Auto: the chosen wallpaper colour (empty = the best one)
                property bool apps: true            // apps (KDE, GTK, Konsole) follow the theme
                property string mode: "dark"        // dark | light | auto (light from 7h to 19h)
            }

            property JsonObject bar: JsonObject {
                property string style: "flat"       // flat | floating | islands | island
            }

            property JsonObject weather: JsonObject {
                property string location: ""    // what wttr.in gets: "lat,lon" (a searched city) or a name; empty = by IP address
                property string place: ""       // the chosen city's name, shown instead of wttr.in's nearest area
            }

            property JsonObject notifications: JsonObject {
                property bool dnd: false        // Do not disturb
                property int timeout: 5000      // ms on screen, when the app does not say
                property bool sound: true       // Ocean theme sound on arrival
                property string where: "pill"   // corner | pill | both (urgent ones also in the corner)
            }

            // Global shortcuts (Meta+Space format); empty = no shortcut
            property JsonObject shortcuts: JsonObject {
                property string launcher: "Meta+Space"
                property string panel: "Meta+A"
                property string notifications: "Meta+N"
                property string dashboard: "Meta+Alt+D"
                property string wallpapers: "Meta+Alt+W"
                property string widgets: "Meta+Alt+E"
                property string settings: "Meta+U"
                property string clipboard: "Meta+V"
                property string captureRegion: "Print"
                property string captureScreen: "Shift+Print"
                property string captureWindow: "Meta+Print"
                property string colorPicker: "Meta+Shift+C"
                property string tileHalves: "Meta+Alt+1"
                property string tileColumns: "Meta+Alt+2"
                property string tileMain: "Meta+Alt+3"
                property string tileGrid: "Meta+Alt+4"
                // The user's own: [{ id, name, app (desktop id) or command, keys }]
                property var custom: []
            }

            // Focus modes (see services/Focus.qml). In each mode, "" / false = leave that alone
            property JsonObject focus: JsonObject {
                property string active: ""
                property bool auto: false           // the active one was entered by the schedule
                property string last: "work"
                property real skipUntil: 0          // left manually: the schedule only resumes after this (ms)
                property var saved: ({})            // the state before the active mode
                property var modes: [
                    { id: "work", name: "Work", icon: "work", dnd: true, keepAwake: true, profile: "", theme: "", wallpaper: "",
                        schedule: { enabled: false, from: "09:00", to: "18:00", days: [1, 2, 3, 4, 5] } },
                    { id: "game", name: "Gaming", icon: "sports_esports", dnd: true, keepAwake: true, profile: "performance", theme: "", wallpaper: "",
                        schedule: { enabled: false, from: "21:00", to: "23:30", days: [5, 6, 7] } },
                    { id: "rest", name: "Rest", icon: "bedtime", dnd: true, keepAwake: false, profile: "power-saver", theme: "dark", wallpaper: "",
                        schedule: { enabled: false, from: "23:00", to: "07:00", days: [1, 2, 3, 4, 5, 6, 7] } }
                ]
            }

            // ICS calendars (see services/Agenda.qml)
            property JsonObject calendar: JsonObject {
                property var sources: []            // [{ name, url, color }]
                property int remind: 10             // minutes before an event (0 = no reminder)
                property bool pill: true            // the next event in the pill, with the time left
            }

            // Dev UI: the dashboard's Dev tab (ports and containers)
            property JsonObject dev: JsonObject {
                property bool enabled: false
                // A notification when a terminal command that took this long finishes while you're
                // in another window (services/LongCommands, hook in the JourneyOS zsh setup)
                property bool notifyCommands: true
                property int notifyAfter: 30            // seconds
                // Projects in the launcher (services/Projects): git repositories under these folders
                property var projectRoots: ["~/Dev", "~/dev", "~/Projects", "~/projects", "~/Projetos", "~/projetos", "~/src", "~/code", "~/git", "~/repos", "~/work"]
                property string editor: "auto"          // auto | a .desktop id (code.desktop…) | a command
                // Claude plan limits in the bar (services/ClaudeUsage), once Claude Code has sent them
                property bool claudeBar: true
                // Docker in the bar (services/Dev): how many containers are running and which failed
                property bool dockerBar: true
            }

            property JsonObject launcher: JsonObject {
                property string layout: "list"      // list | grid
                // Apps hidden from the launcher and the Apps tab (services/ShellApps.qml)
                property bool hideReplaced: true    // the ones the shell replaces
                property var hidden: []             // hidden manually
                property var shown: []              // replaced ones the user still wants to see
            }

            property JsonObject notch: JsonObject {
                property bool enabled: true
                property bool hover: true       // open when the mouse rests over it
            }

            property JsonObject dock: JsonObject {
                property bool enabled: true
                // Ids of the .desktop entries, in dock order
                property list<string> pinned: ["org.kde.dolphin", "firefox-esr", "org.kde.konsole",
                    "org.kde.kate", "shadow-kde-settings"]
                property bool dashboard: true       // dashboard button at the start of the dock
            }

            // Desktop widgets (see services/Widgets.qml)
            property JsonObject widgets: JsonObject {
                property var items: [
                    { id: "clock", type: "clock", x: 0, y: 0, scale: 1, style: "card" },
                    { id: "resources", type: "resources", x: 0, y: 1, scale: 1, style: "card" },
                    { id: "user", type: "user", x: 1, y: 0, scale: 1, style: "card" },
                    { id: "calendar", type: "calendar", x: 1, y: 1, scale: 1, style: "card" }
                ]
                // Extension tabs in the pill and the dashboard: [{ type: "user/<id>", options }]
                property var notchTabs: []
                property var dashboardTabs: []
            }
        }
    }
}
