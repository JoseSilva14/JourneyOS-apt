pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// System updates: check (pkcon refresh), the list (apt list --upgradable) and install
// (pkcon -y update, with progress; asks for authorization). Notifies at the end. At login (a minute
// later, so the network is up) it looks online once and, if there is something, a notification
// with "Update" opens Settings → Updates (config updates.checkAtLogin).
// unattended-upgrades also installs them by itself once a day; this makes them visible right away.
Singleton {
    id: root

    property var packages: []           // [{ name, from, to }]
    property bool checking: false
    property bool installing: false
    property int progress: 0
    property string status: ""
    property string lastChecked: ""

    function list(done) {
        Run.sh("apt list --upgradable 2>/dev/null | grep upgradable", (code, out) => {
            root.packages = out.trim().split("\n").filter(l => l).map(l => {
                // name/archive new-version arch [upgradable from: old-version]
                const m = l.match(/^([^/]+)\/\S+ (\S+) \S+ \[upgradable from: ([^\]]+)\]/);
                return m ? { name: m[1], to: m[2], from: m[3] } : { name: l, to: "", from: "" };
            });
            if (done)
                done();
        });
    }

    // announce: a notification when there are updates (the check at login)
    function check(announce) {
        if (checking || installing)
            return;
        checking = true;
        // Through sh: without pkcon (packagekit-tools) it still ends (127) instead of hanging on "Searching…"
        Run.cmd(["sh", "-c", "exec pkcon refresh"], code => {
            root.checking = false;
            if (code === 0)
                root.lastChecked = Qt.formatTime(new Date(), "HH:mm");
            list(() => {
                if (announce && root.packages.length)
                    root.announce();
            });
            SystemInfo.checkUpdates();
        });
    }

    function announce() {
        const n = packages.length;
        Run.cmd(["notify-send", "--app-name=" + Tr.t("Updates"), "--icon=system-software-update", "--wait",
            "--action=default=" + Tr.t("Update"),
            n === 1 ? Tr.t("1 update available") : n + Tr.t(" updates available"),
            Tr.t("Open Settings → Updates to install them now (otherwise they install by themselves within a day).")],
            (c, out) => {
                if (out.trim() === "default") {
                    Notifs.centerOpen = false;
                    SettingsApp.show("updates");
                }
            });
    }

    Timer {
        id: atLogin
        interval: 60 * 1000
        running: Config.ready && Config.options.updates.checkAtLogin
        onTriggered: root.check(true)
    }

    function install() {
        if (installing || !packages.length)
            return;
        installing = true;
        progress = 0;
        status = Tr.t("Preparing…");
        installer.running = true;
    }

    Process {
        id: installer
        command: ["sh", "-c", "exec pkcon -y --plain update"]
        stdout: SplitParser {
            onRead: line => {
                const p = line.match(/Percentage:\s*(\d+)/);
                if (p)
                    root.progress = Number(p[1]);
                const s = line.match(/Status:\s*(.+)/);
                if (s)
                    root.status = s[1].trim();
            }
        }
        onExited: code => {
            root.installing = false;
            root.status = code === 0 ? Tr.t("Up to date") : Tr.t("Couldn't update");
            Quickshell.execDetached(["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
                "--object-path", "/org/freedesktop/Notifications", "--method", "org.freedesktop.Notifications.Notify",
                "--", Tr.t("Updates"), "0", "system-software-update", root.status,
                code === 0 ? Tr.t("The system is up to date.") : Tr.t("See the details in a terminal with: sudo apt full-upgrade"),
                "[]", "{}", "8000"]);
            root.list();
            SystemInfo.checkUpdates();
        }
    }

    IpcHandler {
        target: "updates"
        // The check at login, now (with the notification if there are updates)
        function check(): void { root.check(true); }
        function status(): string {
            return JSON.stringify({ checking: root.checking, lastChecked: root.lastChecked, packages: root.packages.length });
        }
    }
}
