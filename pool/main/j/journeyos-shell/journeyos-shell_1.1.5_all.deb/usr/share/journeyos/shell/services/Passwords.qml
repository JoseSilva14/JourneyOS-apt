pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Passwords (scripts/passwords.py): the system's secret store (KWallet as org.freedesktop.secrets,
// opened at login with the login password). Settings → Passwords lists, adds, edits and deletes
// them (and shows what apps saved there); in the launcher "pass name" copies a password, which is
// cleared from the clipboard after 30 s and never goes to the clipboard history.
// Passwords never pass through the command line: saving writes them to the script's stdin.
Singleton {
    id: root

    readonly property string script: Quickshell.shellPath("scripts/passwords.py")

    property bool available: true
    property bool locked: false
    property var items: []              // { path, label, username, url, mine, app, modified }
    property bool loaded: false
    property double scannedAt: 0
    property bool busy: false
    property var revealed: ({})         // path → password, shown for a while in Settings

    readonly property var mine: items.filter(i => i.mine)
    readonly property var fromApps: items.filter(i => !i.mine)

    function refresh(force) {
        if (scanner.running || (!force && Date.now() - scannedAt < 15000))
            return;
        scanner.running = true;
    }

    Process {
        id: scanner
        command: ["python3", root.script, "status"]
        stdout: StdioCollector {
            onStreamFinished: root.apply(text)
        }
    }

    function apply(text) {
        try {
            const d = JSON.parse(text);
            available = d.available;
            locked = d.locked;
            items = d.items;
        } catch (e) {
            console.warn("passwords.py: invalid reply");
        }
        loaded = true;
        scannedAt = Date.now();
    }

    Connections {
        target: Launcher
        function onOpenChanged() { if (Launcher.open) root.refresh(false); }
    }

    // KWallet asks for its password (when it was not opened at login: automatic login, or the
    // login password changed)
    function unlock() {
        busy = true;
        Run.cmd(["python3", script, "unlock"], (code, out, err) => {
            root.busy = false;
            if (code === 0)
                root.apply(out);
            else if (err.trim() !== "cancelled")
                Events.push({ icon: "error", title: Tr.t("Couldn't unlock the passwords"), text: err.trim(), duration: 4000 });
        });
    }

    function copy(item, field) {
        Run.cmd(["python3", script, "copy", item.path].concat(field === "username" ? ["username"] : []), (code, out, err) => {
            Events.push(code !== 0 ? { icon: "error", title: Tr.t("Couldn't copy it"), text: err.trim(), duration: 3000 }
                : field === "username" ? { icon: "person", title: Tr.t("Username copied"), text: item.label, duration: 1500 }
                : { icon: "key", title: Tr.t("Password copied"), text: item.label + Tr.t(" · cleared in 30 s"), duration: 2500 });
        });
    }

    // Shows the password in Settings for 20 s
    function reveal(item) {
        Run.cmd(["python3", script, "show", item.path], (code, out) => {
            if (code !== 0)
                return;
            const r = Object.assign({}, root.revealed);
            r[item.path] = out;
            root.revealed = r;
            hide.restart();
        });
    }
    function conceal() { revealed = {}; }
    Timer {
        id: hide
        interval: 20000
        onTriggered: root.conceal()
    }

    // { path?, label, username, url, password } — done(ok, error)
    property var saveDone: null
    property string pendingJson: ""
    function save(data, done) {
        if (saver.running)
            return;
        busy = true;
        saveDone = done ?? null;
        pendingJson = JSON.stringify(data);
        saver.running = true;
    }
    Process {
        id: saver
        command: ["python3", root.script, "save"]
        stdinEnabled: true
        onStarted: {
            write(root.pendingJson);
            root.pendingJson = "";
            stdinEnabled = false;       // end of input
        }
        stderr: StdioCollector { id: saveErr }
        onExited: code => {
            stdinEnabled = true;
            root.busy = false;
            const err = saveErr.text.trim();
            if (root.saveDone)
                root.saveDone(code === 0, err);
            if (code !== 0 && err !== "cancelled")
                Events.push({ icon: "error", title: Tr.t("Couldn't save the password"), text: err, duration: 4000 });
            root.conceal();
            root.refresh(true);
        }
    }

    function remove(item) {
        Run.cmd(["python3", script, "delete", item.path], (code, out, err) => {
            if (code !== 0 && err.trim() !== "cancelled")
                Events.push({ icon: "error", title: Tr.t("Couldn't delete it"), text: err.trim(), duration: 4000 });
            root.refresh(true);
        });
    }

    // done(password)
    function generate(done) {
        Run.cmd(["python3", script, "generate"], (code, out) => { if (code === 0) done(out.trim()); });
    }

    function open() { SettingsApp.show("passwords"); }

    // --- Launcher: "pass name" (also password / passwords / senha / palavra-passe) ---
    function describe(i) {
        return [i.username, i.url.replace(/^https?:\/\//, "").replace(/\/$/, "")].filter(x => x).join(" · ");
    }

    function results(raw) {
        const m = /^(?:pass|passwords?|senhas?|palavras?-passe)(?:\s+(.*))?$/i.exec(raw.trim());
        if (!m)
            return [];
        if (!available || locked || !mine.length)
            return [{ item: { kind: "passwords", key: "passwords:open", title: Tr.t("Passwords"),
                subtitle: !available ? Tr.t("The passwords store isn't running")
                    : locked ? Tr.t("Locked · Enter unlocks it") : Tr.t("None saved yet · Enter opens Settings"),
                glyph: "key", run: () => locked ? root.unlock() : root.open() }, s: 990 }];
        const q = Launcher.norm((m[1] ?? "").trim());
        return mine.map((i, n) => {
            const label = Launcher.norm(i.label);
            const s = !q ? 900 - n : label === q ? 980 : label.startsWith(q) ? 920
                : label.includes(q) ? 800 : Launcher.norm(i.url + " " + i.username).includes(q) ? 600 : 0;
            return { item: { kind: "passwords", key: "pass:" + i.path, title: i.label,
                subtitle: (describe(i) ? describe(i) + " · " : "") + Tr.t("Enter copies the password"),
                glyph: "key", run: () => root.copy(i, "password") }, s };
        }).filter(x => x.s > 0);
    }

    IpcHandler {
        target: "passwords"
        function status(): string {
            return JSON.stringify({ available: root.available, locked: root.locked, mine: root.mine.length, apps: root.fromApps.length });
        }
        function refresh(): void { root.refresh(true); }
        function unlock(): void { root.unlock(); }
    }
}
