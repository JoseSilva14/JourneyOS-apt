import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs
import qs.components
import qs.services
import qs.dashboard
import qs.menus
import qs.settings.pages

// First-run wizard: a centred card with the steps at the top, each step's content
// (the same pieces as the dashboard and menus, to change things for real right away) and
// Back/Next at the bottom. Skip (or Esc) closes and does not reopen by itself.
PanelWindow {
    id: root

    readonly property bool open: Welcome.open

    screen: Windows.activeScreen
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    visible: open || closing.running
    WlrLayershell.namespace: "shadow-welcome"
    WlrLayershell.layer: WlrLayer.Overlay
    // The steps have text fields (search, Wi-Fi password)
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    onOpenChanged: {
        if (open)
            keys.forceActiveFocus();
        else
            closing.restart();
    }

    Timer {
        id: closing
        interval: Theme.animNormal
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.6)
        opacity: root.open ? 1 : 0

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(860, root.width - 64)
        height: Math.min(620, root.height - 64)
        radius: Theme.radiusCard + 6
        color: Theme.surface
        border.width: 1
        border.color: Theme.surfaceBorder
        opacity: root.open ? 1 : 0
        scale: root.open ? 1 : 0.96

        Behavior on opacity {
            NumberAnimation { duration: Theme.animNormal }
        }
        Behavior on scale {
            NumberAnimation { duration: Theme.animNormal; easing.type: Easing.OutCubic }
        }

        // Esc closes; Enter advances when no text field has the keyboard
        Item {
            id: keys
            anchors.fill: parent
            focus: true
            Keys.onEscapePressed: Welcome.finish()
            Keys.onReturnPressed: Welcome.next()
            Keys.onEnterPressed: Welcome.next()
            Keys.onRightPressed: Welcome.next()
            Keys.onLeftPressed: Welcome.back()
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 28
            spacing: 20

            // Steps
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                Repeater {
                    model: Welcome.steps

                    Rectangle {
                        id: stepChip
                        required property var modelData
                        required property int index
                        readonly property bool current: index === Welcome.step
                        readonly property bool done: index < Welcome.step

                        Layout.fillWidth: true
                        implicitHeight: 34
                        radius: height / 2
                        color: current ? Theme.accent : chipMouse.containsMouse ? Theme.buttonHover : Theme.button

                        Behavior on color {
                            ColorAnimation { duration: Theme.animFast }
                        }

                        RowLayout {
                            anchors.centerIn: parent
                            spacing: 6

                            MIcon {
                                icon: stepChip.done ? "check" : stepChip.modelData.icon
                                size: 15
                                color: stepChip.current ? Theme.accentText : stepChip.done ? Theme.text : Theme.subtext
                            }
                            Text {
                                text: stepChip.modelData.title
                                color: stepChip.current ? Theme.accentText : stepChip.done ? Theme.text : Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                                font.weight: stepChip.current ? Font.Bold : Font.Normal
                            }
                        }

                        MouseArea {
                            id: chipMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Welcome.step = stepChip.index
                        }
                    }
                }
            }

            // Step title and explanation
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4
                visible: Welcome.step > 0

                Text {
                    text: ["", Tr.t("Choose the look"), Tr.t("Choose a wallpaper"), Tr.t("Pin your apps to the dock"),
                        Tr.t("Connect to the internet"), Tr.t("Apps and updates"), Tr.t("Link your phone"),
                        Tr.t("Everyday shortcuts")][Welcome.step]
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: Theme.fontLarge + 2
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    text: ["",
                        Tr.t("Dark, light or changing with the time of day, and the accent color. \"Auto\" takes it from the wallpaper."),
                        Tr.t("Click an image to use it. Yours go in ~/Pictures/Wallpapers."),
                        Tr.t("Click an app (or the pin) to add it to or remove it from the dock."),
                        Tr.t("Pick a network. If you're already connected, you can continue."),
                        Tr.t("Where to get apps, and how the system keeps itself up to date."),
                        Tr.t("With KDE Connect: notifications, files and the clipboard between phone and computer. You can skip this."),
                        Tr.t("You can change every key in Settings → Shortcuts.")][Welcome.step]
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                }
            }

            // Content: only the current step exists (the network only scans when visible)
            Loader {
                id: content
                Layout.fillWidth: true
                Layout.fillHeight: true
                sourceComponent: [hello, look, wallpaper, dock, network, apps, phone, shortcutKeys][Welcome.step]
            }

            // Bottom: skip, back, next
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                PillButton {
                    text: Tr.t("Skip")
                    visible: !Welcome.last
                    onClicked: Welcome.finish()
                }
                Item {
                    Layout.fillWidth: true
                }
                Text {
                    text: (Welcome.step + 1) + Tr.t(" of ") + Welcome.steps.length
                    color: Theme.dim
                    font.family: Theme.font
                    font.pixelSize: Theme.fontSmall
                    Layout.rightMargin: 6
                }
                PillButton {
                    text: Tr.t("Back")
                    visible: Welcome.step > 0
                    onClicked: Welcome.back()
                }
                PillButton {
                    text: Welcome.step === 0 ? Tr.t("Start") : Welcome.last ? Tr.t("Finish") : Tr.t("Next")
                    accent: true
                    onClicked: Welcome.next()
                }
            }
        }
    }

    // --- Steps ---

    Component {
        id: hello

        Item {
            ColumnLayout {
                anchors.centerIn: parent
                width: Math.min(parent.width, 520)
                spacing: 14

                Image {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.preferredWidth: 96
                    Layout.preferredHeight: 96
                    source: Theme.logo
                    fillMode: Image.PreserveAspectFit
                    smooth: true
                    mipmap: true
                }
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: 6
                    text: Tr.t("Hello, ") + User.name
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 30
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    text: Tr.t("Welcome to JourneyOS. Let's set things up your way: look, wallpaper, dock, network, apps and your phone. It takes a minute, and you can change all of it later in Settings.")
                    color: Theme.subtext
                    font.family: Theme.font
                    font.pixelSize: Theme.fontNormal
                    lineHeight: 1.2
                }
            }
        }
    }

    Component {
        id: look
        ThemeTab {}
    }

    Component {
        id: wallpaper
        WallpapersTab {}
    }

    Component {
        id: dock
        AppsTab {
            pinMode: true
        }
    }

    Component {
        id: network

        Item {
            NetworkMenu {
                anchors.horizontalCenter: parent.horizontalCenter
                width: Math.min(parent.width, 520)
                embedded: true
                listHeight: 340
            }
        }
    }

    Component {
        id: apps

        Item {
            Component.onCompleted: Store.refresh()

            ColumnLayout {
                anchors.horizontalCenter: parent.horizontalCenter
                width: Math.min(parent.width, 600)
                spacing: 10

                SettingRow {
                    Layout.fillWidth: true
                    title: Tr.t("App store")
                    description: Store.ready ? Tr.t("Ready. Find apps in the Dashboard → Apps → Store.")
                        : Store.job === "setup" ? (Store.progressText || Tr.t("Setting up…"))
                        : !Store.flatpak && Store.loaded ? Tr.t("Flatpak is missing, so the store can't be set up.")
                        : Tr.t("Adds Flathub: thousands of apps, installed just for you, without a password.")
                    icon: Store.ready ? "check_circle" : "storefront"

                    PillButton {
                        visible: !Store.ready && Store.flatpak
                        text: Store.job === "setup" ? Tr.t("Setting up…") : Tr.t("Set up")
                        accent: true
                        enabled: Store.job === ""
                        onClicked: Store.setup()
                    }
                }

                SettingRow {
                    Layout.fillWidth: true
                    visible: Store.nvidia.present === true && !Store.nvidia.driver && !Store.nvidia.installed
                    title: Tr.t("NVIDIA graphics card")
                    description: Tr.t("Without NVIDIA's driver, games and video run slower. Installing it asks for the password and a restart.")
                    icon: "memory"

                    PillButton {
                        text: Tr.t("Install the driver")
                        onClicked: Store.installNvidia()
                    }
                }

                SettingRow {
                    Layout.fillWidth: true
                    title: Tr.t("Updates")
                    description: Tr.t("Security updates install on their own. On btrfs, a snapshot is taken before each one: Settings → Snapshots can undo it.")
                    icon: "system_update"
                }
            }
        }
    }

    Component {
        id: phone

        Item {
            PhonePage {
                anchors.horizontalCenter: parent.horizontalCenter
                width: Math.min(parent.width, 600)
                height: parent.height
            }
        }
    }

    Component {
        id: shortcutKeys

        GridLayout {
            columns: 2
            rowSpacing: 10
            columnSpacing: 10

            Repeater {
                model: [
                    { id: "launcher", title: Tr.t("App launcher"), icon: "search", tip: Tr.t("Apps, math, emojis and commands") },
                    { id: "panel", title: Tr.t("Quick panel"), icon: "tune", tip: Tr.t("Wi-Fi, sound, brightness and modes") },
                    { id: "notifications", title: Tr.t("Notifications"), icon: "notifications", tip: Tr.t("Alerts and calendar") },
                    { id: "dashboard", title: "Dashboard", icon: "space_dashboard", tip: Tr.t("Calendar, apps, theme and performance") },
                    { id: "clipboard", title: Tr.t("Clipboard"), icon: "content_paste", tip: Tr.t("What you copied before") },
                    { id: "captureRegion", title: Tr.t("Screenshot##app"), icon: "crop", tip: Tr.t("Select a region") },
                    { id: "settings", title: Tr.t("Settings"), icon: "settings", tip: Tr.t("Everything you can change") },
                    { id: "tileHalves", title: Tr.t("Arrange windows"), icon: "grid_view",
                        tip: Tr.t("Halves, columns, main, grid") }
                ]

                Rectangle {
                    id: keyTile
                    required property var modelData
                    readonly property string keys: {
                        const k = Config.options.shortcuts;
                        // The four tiling ones with the default shortcuts: "Meta+Alt+1–4"
                        if (modelData.id === "tileHalves" && k.tileHalves.endsWith("1")
                                && k.tileGrid === k.tileHalves.slice(0, -1) + "4")
                            return k.tileHalves + "–4";
                        return k[modelData.id] ?? "";
                    }

                    Layout.fillWidth: true
                    implicitHeight: 64
                    radius: Theme.radius
                    color: Theme.surfaceCard
                    border.width: 1
                    border.color: Theme.surfaceBorder

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 12
                        spacing: 12

                        Rectangle {
                            implicitWidth: 38
                            implicitHeight: 38
                            radius: Theme.radiusSmall + 2
                            color: Theme.button

                            MIcon {
                                anchors.centerIn: parent
                                icon: keyTile.modelData.icon
                                size: 19
                            }
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2
                            Text {
                                Layout.fillWidth: true
                                text: keyTile.modelData.title
                                elide: Text.ElideRight
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontNormal
                                font.weight: Font.DemiBold
                            }
                            Text {
                                Layout.fillWidth: true
                                text: keyTile.modelData.tip
                                elide: Text.ElideRight
                                color: Theme.subtext
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                            }
                        }
                        Rectangle {
                            implicitWidth: keyLabel.implicitWidth + 16
                            implicitHeight: 26
                            radius: Theme.radiusSmall
                            color: Theme.button
                            border.width: 1
                            border.color: Theme.surfaceBorder

                            Text {
                                id: keyLabel
                                anchors.centerIn: parent
                                text: keyTile.keys || "—"
                                color: Theme.text
                                font.family: Theme.font
                                font.pixelSize: Theme.fontSmall
                                font.weight: Font.Bold
                            }
                        }
                    }
                }
            }

            Text {
                Layout.columnSpan: 2
                Layout.fillWidth: true
                Layout.topMargin: 4
                wrapMode: Text.Wrap
                text: Tr.t("More: right-click the desktop to edit widgets, and hover the pill at the top to see music and alerts.")
                color: Theme.subtext
                font.family: Theme.font
                font.pixelSize: Theme.fontSmall
            }
        }
    }
}
