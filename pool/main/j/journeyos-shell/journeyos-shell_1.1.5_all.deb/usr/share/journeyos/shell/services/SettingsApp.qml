pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Settings window state (Meta+U, quick panel button, IPC).
Singleton {
    id: root

    property bool open: false
    property string page: "home"

    // Settings .desktop entry (for the dock and the launcher): the shell writes it at startup
    readonly property string desktopId: "shadow-kde-settings"

    // By group (title in the sidebar)
    // Search in the pages: by name and by the words of what they contain (no accents or capitals)
    function norm(t) { return t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }
    function search(query) {
        const q = norm(query.trim());
        if (!q)
            return pages;
        const words = q.split(/\s+/);
        return pages
            .map(p => ({ p, label: norm(p.label), all: norm(p.label + " " + p.keywords) }))
            .filter(x => words.every(w => x.all.includes(w)))
            // Those with the query in the name first
            .sort((a, b) => (b.label.includes(q) - a.label.includes(q)))
            .map(x => x.p);
    }

    readonly property var pages: [
        { id: "home", label: Tr.t("Home"), icon: "home", group: "", keywords: "início resumo" },
        { id: "account", label: Tr.t("Account"), icon: "account_circle", group: "", keywords: "conta nome fotografia foto avatar palavra-passe password senha" },
        { id: "passwords", label: Tr.t("Passwords"), icon: "key", group: "", keywords: "palavras-passe passwords senhas cofre vault credenciais kwallet chaves tokens logins guardados gerador keyring secret" },
        { id: "network", label: Tr.t("Network"), icon: "wifi", group: Tr.t("Connections"), keywords: "rede internet wifi wi-fi cabo ethernet ip dns gateway mac vpn ligações guardadas esquecer firewall ufw portas porta segurança bloquear" },
        { id: "bluetooth", label: Tr.t("Bluetooth"), icon: "bluetooth", group: Tr.t("Connections"), keywords: "bluetooth auscultadores rato teclado emparelhar visível aparelhos" },
        { id: "sound", label: Tr.t("Sound"), icon: "volume_up", group: Tr.t("Devices"), keywords: "som áudio volume saída entrada microfone colunas auscultadores apps notificações" },
        { id: "display", label: Tr.t("Screen"), icon: "desktop_windows", group: Tr.t("Devices"), keywords: "ecrã monitor resolução frequência hz escala tamanho rotação principal luz noturna temperatura nvidia driver drivers placa gráfica gpu graphics card" },
        { id: "power", label: Tr.t("Power"), icon: "power", group: Tr.t("Devices"), keywords: "energia bateria perfil poupança desempenho escurecer apagar ecrã suspender dormir bloqueio automático" },
        { id: "input", label: Tr.t("Keyboard and mouse"), icon: "keyboard", group: Tr.t("Devices"), keywords: "teclado rato touchpad disposição layout repetição velocidade aceleração scroll natural canhoto tocar" },
        { id: "storage", label: Tr.t("Storage"), icon: "sd_storage", group: Tr.t("Devices"), keywords: "armazenamento discos espaço pen usb montar desmontar ejetar lixo" },
        { id: "printers", label: Tr.t("Printers"), icon: "print", group: Tr.t("Devices"), keywords: "impressoras imprimir página de teste" },
        { id: "theme", label: Tr.t("Theme"), icon: "palette", group: Tr.t("Personalization"), keywords: "tema cores esquema claro escuro automático destaque apps barra" },
        { id: "look", label: Tr.t("Appearance"), icon: "brush", group: Tr.t("Personalization"), keywords: "aparência tipo de letra fonte tamanho ícones cursor animações" },
        { id: "bar", label: Tr.t("Bar and pill"), icon: "view_day", group: Tr.t("Personalization"), keywords: "barra pílula notch estilo flutuante ilhas rato" },
        { id: "dock", label: Tr.t("Dock"), icon: "dock", group: Tr.t("Personalization"), keywords: "dock fixadas apps" },
        { id: "desktop", label: Tr.t("Desktop"), icon: "wallpaper", group: Tr.t("Personalization"), keywords: "ambiente de trabalho wallpaper fundo pastas widgets" },
        { id: "notifications", label: Tr.t("Notifications"), icon: "notifications", group: Tr.t("Personalization"), keywords: "notificações avisos não incomodar som tempo pílula canto" },
        { id: "launcherapps", label: Tr.t("Launcher apps"), icon: "apps", group: Tr.t("Personalization"), keywords: "apps lançador esconder mostrar substituídas kcalc spectacle system settings menu aplicações" },
        { id: "tabs", label: Tr.t("Tabs"), icon: "tab", group: Tr.t("Personalization"), keywords: "abas tabs extensões pílula notch dashboard widgets personalizar juntar" },
        { id: "focus", label: Tr.t("Focus modes"), icon: "center_focus_strong", group: Tr.t("Personalization"), keywords: "foco modos trabalho jogo descanso horário não incomodar perfil concentração pomodoro pausa" },
        { id: "users", label: Tr.t("Users"), icon: "group", group: Tr.t("System"), keywords: "utilizadores contas administrador nova conta apagar palavra-passe" },
        { id: "a11y", label: Tr.t("Accessibility"), icon: "accessibility_new", group: Tr.t("System"), keywords: "acessibilidade lupa zoom leitor de ecrã orca letra maior cursor movimento animações teclas fixas" },
        { id: "privacy", label: Tr.t("Privacy"), icon: "shield", group: Tr.t("System"), keywords: "privacidade microfone câmara histórico ficheiros recentes lixo notificações" },
        { id: "session", label: Tr.t("Session"), icon: "power_settings_new", group: Tr.t("System"), keywords: "sessão bloquear sair reiniciar desligar entrar apps da última vez" },
        { id: "updates", label: Tr.t("Updates"), icon: "system_update", group: Tr.t("System"), keywords: "atualizações pacotes instalar procurar sistema" },
        { id: "snapshots", label: Tr.t("Snapshots"), icon: "history", group: Tr.t("System"), keywords: "snapshots cópias de segurança restaurar desfazer atualização btrfs snapper voltar atrás backup" },
        { id: "windows", label: Tr.t("Windows"), icon: "web_asset", group: Tr.t("System"), keywords: "janelas foco duplo clique maximizar meio ecrã vista geral canto ecrãs virtuais" },
        { id: "defaultapps", label: Tr.t("Default apps"), icon: "open_in_browser", group: Tr.t("System"), keywords: "apps por omissão navegador email ficheiros terminal editor imagens vídeo música pdf" },
        { id: "autostart", label: Tr.t("Autostart"), icon: "rocket_launch", group: Tr.t("System"), keywords: "arranque automático iniciar ao entrar apps" },
        { id: "dev", label: Tr.t("Development"), icon: "terminal", group: Tr.t("System"), keywords: "programação dev ui dev portas contentores docker containers programador" },
        { id: "shortcuts", label: Tr.t("Shortcuts"), icon: "keyboard_command_key", group: Tr.t("System"), keywords: "atalhos teclas teclado" },
        { id: "calendar", label: Tr.t("Calendars"), icon: "event", group: Tr.t("System"), keywords: "calendários agenda eventos google nextcloud outlook ics webcal avisos lembretes pílula próximo evento" },
        { id: "datetime", label: Tr.t("Date and time"), icon: "schedule", group: Tr.t("System"), keywords: "data hora fuso horário relógio 24 horas acertar" },
        { id: "locale", label: Tr.t("Region and language"), icon: "translate", group: Tr.t("System"), keywords: "região idioma língua formatos números moeda language english inglês português" },
        { id: "weather", label: Tr.t("Weather"), icon: "cloud", group: Tr.t("System"), keywords: "tempo meteorologia cidade localização" },
        { id: "about", label: Tr.t("About"), icon: "info", group: Tr.t("System"), keywords: "sobre sistema computador versão hardware" }
    ]

    function show(page) {
        if (page)
            root.page = page;
        open = true;
        QuickPanel.open = false;
        Dashboard.open = false;
        BarMenu.open = "";
    }

    function toggle() {
        if (open)
            open = false;
        else
            show("");
    }

    FileView {
        path: Quickshell.env("HOME") + "/.local/share/applications/" + root.desktopId + ".desktop"
        atomicWrites: true
        printErrors: false
        // Exec is only used when opened from outside the shell; the dock and the launcher open it directly
        // In the shell language; rewritten when the language changes
        readonly property string entryText: `[Desktop Entry]
Type=Application
Name=${Tr.t("Settings")}
GenericName=${Tr.t("System settings")}
Comment=${Tr.t("Shell and system settings")}
Icon=preferences-system
Exec=qs -p ${Quickshell.shellPath("")} ipc call settings open home
Categories=Settings;System;
Keywords=definições;preferências;configurar;settings;preferences;
StartupNotify=false
`
        onEntryTextChanged: setText(entryText)
        Component.onCompleted: setText(entryText)
    }

    IpcHandler {
        target: "settings"
        function open(page: string): void { root.show(page); }
        function toggle(): void { root.toggle(); }
        function close(): void { root.open = false; }
    }
}
