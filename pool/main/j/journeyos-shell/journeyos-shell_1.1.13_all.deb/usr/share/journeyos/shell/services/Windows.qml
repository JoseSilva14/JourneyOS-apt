pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Open windows (scripts/windows.py, via a KWin script) and commands on them.
Singleton {
    id: root

    property var list: []            // [{ id, appId, cls, title, active, minimized, output, pid }]
    readonly property var active: list.find(w => w.active) ?? null
    // Screen of the active window (where popups appear); without a window, the first
    readonly property var activeScreen: Quickshell.screens.find(s => s.name === active?.output) ?? Quickshell.screens[0]

    function activate(id) { send("activate " + id); }
    function minimize(id) { send("minimize " + id); }
    function close(id) { send("close " + id); }
    // Activates; if it is already active, minimizes
    function toggle(id) { send("toggle " + id); }

    // KWin's own previews (the effects Plasma's task manager uses): highlight shows only these windows
    // on screen, the rest faded ([] = back to normal); present lays them out side by side, live
    function kwinCall(path, method, ids) {
        const arr = ids.length ? "[" + ids.map(i => "'" + String(i).replace(/'/g, "") + "'").join(", ") + "]" : "@as []";
        Quickshell.execDetached(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", path,
            "--method", method, arr]);
    }
    function highlight(ids) { kwinCall("/org/kde/KWin/HighlightWindow", "org.kde.KWin.HighlightWindow.highlightWindows", ids); }
    function present(ids) { kwinCall("/org/kde/KWin/Effect/WindowView1", "org.kde.KWin.Effect.WindowView1.activate", ids); }

    function send(cmd) {
        if (helper.running)
            helper.write(cmd + "\n");
    }

    Process {
        id: helper
        running: true
        stdinEnabled: true
        command: [Quickshell.shellPath("scripts/windows.py")]
        stdout: SplitParser {
            onRead: line => {
                try {
                    root.list = JSON.parse(line);
                } catch (e) {
                    console.warn("windows: invalid line");
                }
            }
        }
        // Crashed (KWin restarted, for example): relaunch
        onExited: restart.start()
    }

    Timer {
        id: restart
        interval: 2000
        onTriggered: helper.running = true
    }

    // Tests: the list, and the preview effects by id
    IpcHandler {
        target: "windows"
        function list(): string { return JSON.stringify(root.list.map(w => ({ id: w.id, appId: w.appId, title: w.title }))); }
        function highlight(id: string): void { root.highlight(id ? [id] : []); }
        function present(ids: string): void { root.present(ids.split(" ").filter(x => x)); }
    }
}
