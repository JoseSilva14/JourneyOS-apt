import QtQuick
import QtQuick.Layouts
import qs
import qs.components
import qs.services

// Firewall (ufw): on/off, the open ports (close: second click) and opening one. The content of the
// Firewall app (firewall/FirewallWindow); it is no longer in Settings → Network.
Page {
    id: root

    property string confirmRule: ""     // rule awaiting the second click

    Component.onCompleted: Firewall.refresh()

    SettingRow {
        visible: Firewall.loaded && !Firewall.installed
        title: Tr.t("The firewall (ufw) is not installed")
        description: "sudo apt install ufw"
        icon: "error"
    }

    SettingRow {
        visible: Firewall.loaded && Firewall.installed
        title: Tr.t("Firewall")
        description: Firewall.message || (Firewall.enabled
            ? Tr.t("Blocks connections from other devices that this computer did not ask for")
            : Tr.t("Off: anything listening on this computer can be reached from the network"))
        icon: Firewall.enabled ? "shield" : "remove_moderator"

        Toggle {
            checked: Firewall.enabled
            enabled: !Firewall.busy
            onToggled: on => Firewall.setEnabled(on)
        }
    }

    SectionLabel {
        visible: Firewall.loaded && Firewall.installed
        text: Tr.t("Open ports")
    }

    Text {
        Layout.fillWidth: true
        visible: Firewall.loaded && Firewall.installed && Firewall.rules.length === 0
        text: Tr.t("No ports open: nothing on this computer can be reached from the network.")
        wrapMode: Text.Wrap
        color: Theme.dim
        font.family: Theme.font
        font.pixelSize: Theme.fontSmall
    }

    Repeater {
        model: Firewall.loaded && Firewall.installed ? Firewall.rules : []

        SettingRow {
            id: ruleRow
            required property var modelData
            readonly property string key: modelData.args.join(" ")
            readonly property bool confirming: root.confirmRule === key

            title: Firewall.ruleTitle(modelData.spec)
            description: (modelData.action === "allow" ? Tr.t("Open to the network") : modelData.action)
                + (modelData.comment ? " · " + modelData.comment : "")
            icon: "lan"

            PillButton {
                text: ruleRow.confirming ? Tr.t("Close it? Click again") : Tr.t("Close")
                danger: ruleRow.confirming
                enabled: !Firewall.busy
                onClicked: {
                    if (ruleRow.confirming) {
                        root.confirmRule = "";
                        Firewall.remove(ruleRow.modelData);
                    } else {
                        root.confirmRule = ruleRow.key;
                        confirmTimeout.restart();
                    }
                }
            }
        }
    }

    SettingRow {
        visible: Firewall.loaded && Firewall.installed
        title: Tr.t("Open a port")
        description: Tr.t("For a server on this computer (a game, development, sharing files)")
        icon: "add_circle"

        RowLayout {
            spacing: 8

            TextField {
                id: portField
                implicitWidth: 120
                placeholder: "8000"
                acceptOnBlur: false
                onAccepted: t => openButton.clicked()
            }
            Select {
                id: protoSelect
                implicitWidth: 130
                options: [{ id: "tcp", label: "TCP" }, { id: "udp", label: "UDP" }, { id: "any", label: "TCP + UDP" }]
                current: "tcp"
                onSelected: id => current = id
            }
            PillButton {
                id: openButton
                readonly property bool valid: /^\d{1,5}(:\d{1,5})?$/.test(portField.text.trim())
                    && !(portField.text.includes(":") && protoSelect.current === "any")
                text: Tr.t("Open")
                accent: true
                enabled: valid && !Firewall.busy
                onClicked: {
                    if (!valid)
                        return;
                    Firewall.allow(portField.text.trim(), protoSelect.current, "");
                    portField.text = "";
                }
            }
        }
    }

    Timer {
        id: confirmTimeout
        interval: 4000
        onTriggered: root.confirmRule = ""
    }
}
