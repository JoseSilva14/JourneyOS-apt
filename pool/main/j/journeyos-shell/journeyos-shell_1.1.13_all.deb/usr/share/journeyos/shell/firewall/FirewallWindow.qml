import QtQuick
import QtQuick.Layouts
import Quickshell
import qs
import qs.components
import qs.services
import "../settings/pages"

// Firewall as its own app: a normal window (KWin decoration, shows in the dock as "Firewall") with
// the page settings/pages/FirewallPage (no longer in Settings → Network), loaded while it is open.
FloatingWindow {
    id: root

    title: Tr.t("Firewall")
    visible: Firewall.appOpen
    implicitWidth: 640
    implicitHeight: Math.min(720, (Quickshell.screens[0]?.height ?? 800)
        - Theme.barZone - (Config.options.dock.enabled ? Theme.dockHeight + Theme.gap : 0)
        - Theme.windowTitleHeight - Theme.gap * 2)
    color: Theme.bg

    onVisibleChanged: if (!visible) Firewall.appOpen = false

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Firewall.appOpen = false

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            anchors.rightMargin: 6
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                Layout.rightMargin: 14
                spacing: 12

                Image {
                    source: Quickshell.shellPath("assets/icons/firewall.svg")
                    sourceSize: Qt.size(40, 40)
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: Tr.t("Firewall")
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: Theme.fontLarge
                        font.weight: Font.DemiBold
                    }
                    Text {
                        Layout.fillWidth: true
                        text: !Firewall.loaded ? "" : !Firewall.installed ? Tr.t("The firewall (ufw) is not installed")
                            : (Firewall.enabled ? Tr.t("On") : Tr.t("Off")) + " · " + Firewall.rules.length + Tr.t(" rules")
                        color: Theme.dim
                        elide: Text.ElideRight
                        font.family: Theme.font
                        font.pixelSize: Theme.fontSmall
                    }
                }
            }

            Loader {
                Layout.fillWidth: true
                Layout.fillHeight: true
                active: root.visible
                sourceComponent: FirewallPage {}
            }
        }
    }
}
