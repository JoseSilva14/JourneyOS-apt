pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// Firewall (ufw), for the Firewall app (firewall/FirewallWindow) and the Dev tab's ports. Reading goes through /usr/lib/journeyos/firewall-status
// (pkexec, no password for the person at the computer); changes through /usr/lib/journeyos/firewall
// (pkexec, administrators, asks once and remembers for a few minutes). Both and their polkit policy
// come with journeyos-desktop.
Singleton {
    id: root

    property bool loaded: false
    property bool installed: false
    property bool enabled: false
    property var rules: []          // [{ action, spec, comment, args }]
    property bool busy: false
    property string message: ""

    // The Firewall app's window
    property bool appOpen: false
    function toggle() {
        appOpen = !appOpen;
        if (appOpen)
            refresh();
    }
    function show() {
        appOpen = true;
        refresh();
    }

    // "5353/udp" → "Port 5353 · UDP", "6000:6010/tcp" → "Ports 6000–6010 · TCP", "80" → "Port 80 · TCP + UDP"
    function ruleTitle(spec) {
        // "from 192.168.0.0/16 port 5353 proto udp": answers from a source port, only from those addresses
        const f = /^from (\S+) port (\d+) proto (tcp|udp)$/.exec(spec);
        if (f)
            return Tr.t("From port ") + f[2] + " · " + f[3].toUpperCase() + " · " + f[1];
        const m = /^(\d+)(?::(\d+))?(?:\/(tcp|udp))?$/.exec(spec);
        if (!m)
            return spec;
        const ports = m[2] ? Tr.t("Ports") + " " + m[1] + "–" + m[2] : Tr.t("Port") + " " + m[1];
        return ports + " · " + (m[3] ? m[3].toUpperCase() : "TCP + UDP");
    }

    // The "allow" rule that opens this port for this protocol (alone, in a range, or for both), or null
    function ruleFor(port, proto) {
        const n = Number(port);
        return rules.find(r => {
            if (r.action !== "allow")
                return false;
            const m = /^(\d+)(?::(\d+))?(?:\/(tcp|udp))?$/.exec(r.spec);
            if (!m || (m[3] && m[3] !== proto))
                return false;
            return n >= Number(m[1]) && n <= Number(m[2] || m[1]);
        }) ?? null;
    }

    function refresh() {
        if (!reader.running)
            reader.running = true;
    }

    function change(args, done) {
        busy = true;
        message = "";
        Run.cmd(["pkexec", "/usr/lib/journeyos/firewall", ...args], (code, out, err) => {
            busy = false;
            if (code === 126 || code === 127)
                message = Tr.t("Not authorized");
            else if (code !== 0)
                message = err.trim() || Tr.t("Could not change the firewall");
            else if (done)
                message = done;
            refresh();
        });
    }

    function setEnabled(on) {
        change([on ? "enable" : "disable"], on ? Tr.t("Firewall on") : Tr.t("Firewall off"));
    }

    // port: "8000" or "6000:6010"; proto: tcp | udp | any
    function allow(port, proto, comment) {
        change(["allow", String(port).trim(), proto, comment || ""], Tr.t("Port opened"));
    }

    function remove(rule) {
        change(["delete", ...rule.args], Tr.t("Rule removed"));
    }

    Process {
        id: reader
        command: ["pkexec", "/usr/lib/journeyos/firewall-status"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const d = JSON.parse(text);
                    root.installed = d.installed;
                    root.enabled = d.enabled;
                    root.rules = d.rules ?? [];
                } catch (e) {
                    root.installed = false;
                }
                root.loaded = true;
            }
        }
    }

    IpcHandler {
        target: "firewall"
        function status(): string { return JSON.stringify({ installed: root.installed, enabled: root.enabled, rules: root.rules.map(r => r.spec), message: root.message }); }
        function refresh(): void { root.refresh(); }
        function toggle(): void { root.toggle(); }
    }
}
