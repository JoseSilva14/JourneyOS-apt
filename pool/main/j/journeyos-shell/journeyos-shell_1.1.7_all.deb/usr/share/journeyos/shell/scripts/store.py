#!/usr/bin/env python3
"""App store backend (services/Store). Three sources, each app says where it comes from:
  - debian:  Debian's apps (AppStream DEP-11 catalogue that apt downloads, with icons; the
             appstream package and /etc/apt/apt.conf.d/60journeyos-appstream), installed through
             PackageKit (scripts/pk.py: the shell's password window);
  - vendor:  a few apps from their makers' own APT repositories (/usr/lib/journeyos/store-vendor
             through pkexec: adds the repository and installs; updates come with the system's);
  - flathub: Flatpak apps for the user, only when turned on (SHADOW_STORE_FLATHUB=1, Settings).

  store.py status             {"ready", "stale", "installed": [ids], "protected": [pkgs], "flatpak",
                               "flathub", "updates": [flatpak ids], "nvidia": {...}}
  store.py index              the catalogue → ~/.cache/journeyos/store-v2.json
                              {"flathub": bool, "apps": [{id, source, from, pkg, desktop, name,
                              summary, icon, kw}]}
  store.py refresh            downloads Debian's catalogue again (pkcon refresh), then index
  store.py setup              adds Flathub (user) + its catalogue + Breeze GTK theme; then index
  store.py install <id>       \\
  store.py remove <id>         > progress lines {"progress": n, "text"}, finally {"done", "ok", "error"}
  store.py update             /   (update: Flatpak apps; the rest update with the system)
IDs: "deb:<AppStream id>", "vendor:<id>", "flathub:<app id>".
"""

import glob
import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

HOME = os.path.expanduser("~")
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.join(HOME, ".cache")), "journeyos")
INDEX = os.path.join(CACHE, "store-v2.json")
FLATPAK_APPSTREAM = os.path.join(HOME, ".local/share/flatpak/appstream/flathub")
SWCATALOG = "/var/lib/swcatalog"
HERE = os.path.dirname(os.path.abspath(__file__))
STORE_ICONS = os.path.join(HERE, "..", "assets", "store")
VENDOR_HELPER = "/usr/lib/journeyos/store-vendor"
LANG = (os.environ.get("SHADOW_LANG") or "en").split("_")[0]
FLATHUB = os.environ.get("SHADOW_STORE_FLATHUB") == "1"

# Makers' apps (the IDs /usr/lib/journeyos/store-vendor knows): package, .desktop, maker, summaries
VENDOR = [
    {"id": "code", "name": "Visual Studio Code", "pkg": "code", "desktop": "com.microsoft.VSCode", "from": "Microsoft",
     "en": "Code editor", "pt": "Editor de código", "kw": "vscode editor ide programming code"},
    {"id": "chrome", "name": "Google Chrome", "pkg": "google-chrome-stable", "desktop": "google-chrome",
     "from": "Google", "en": "Web browser", "pt": "Navegador de internet", "kw": "browser web internet google"},
    {"id": "brave", "name": "Brave", "pkg": "brave-browser", "desktop": "brave-browser", "from": "Brave",
     "en": "Private web browser", "pt": "Navegador de internet privado", "kw": "browser web internet privacy"},
    {"id": "spotify", "name": "Spotify", "pkg": "spotify-client", "desktop": "spotify", "from": "Spotify",
     "en": "Music and podcasts", "pt": "Música e podcasts", "kw": "music streaming podcasts música"},
    {"id": "signal", "name": "Signal", "pkg": "signal-desktop", "desktop": "signal-desktop", "from": "Signal",
     "en": "Private messenger", "pt": "Mensagens privadas", "kw": "chat messenger messages mensagens"},
    {"id": "steam", "name": "Steam", "pkg": "steam-launcher", "desktop": "steam", "from": "Valve",
     "en": "Games", "pt": "Jogos", "kw": "games gaming valve jogos"},
    {"id": "discord", "name": "Discord", "pkg": "discord", "desktop": "discord", "from": "Discord",
     "en": "Voice, video and text chat", "pt": "Conversas por voz, vídeo e texto", "kw": "chat voice gaming voz"},
]


def out(obj):
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def run(*cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
    except OSError as e:
        return 127, "", str(e)
    return r.returncode, r.stdout, r.stderr


# ------------------------------------------------------------------ Debian (AppStream DEP-11 YAML)

def unquote(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] == "'":
        return v[1:-1].replace("''", "'")
    if len(v) >= 2 and v[0] == v[-1] == '"':
        return v[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    return v


def pick(langs):
    """The text in the shell language (pt, pt-PT…), else the untranslated one (C)."""
    for k in (LANG, LANG + "-PT" if LANG == "pt" else LANG, LANG + "_PT" if LANG == "pt" else LANG):
        if langs.get(k):
            return langs[k]
    return langs.get("C") or langs.get("en") or ""


def dep11_docs(path):
    """Yields each component of a DEP-11 file as {key: value}: only the keys the store uses. A small
    reader for this regular format (2-space indents) instead of a YAML library."""
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
        header, doc = None, None
        section, sub, lang, item = None, None, None, None
        for raw in fh:
            line = raw.rstrip("\n")
            if line == "---":
                if doc is not None:
                    if header is None:
                        header = doc
                    else:
                        yield header, doc
                doc, section, sub = {}, None, None
                continue
            if doc is None or not line.strip():
                continue
            if not line.startswith(" ") and not line.startswith("-"):
                key, _, val = line.partition(":")
                section, sub, lang, item = key, None, None, None
                if val.strip():
                    doc[key] = unquote(val)
                continue
            if section in ("Name", "Summary"):
                m = re.match(r"^  ([^\s:][^:]*):\s?(.*)$", line)
                if m:
                    doc.setdefault(section, {})[m.group(1)] = unquote(m.group(2))
            elif section == "Keywords":
                m = re.match(r"^  ([^\s:-][^:]*):\s*$", line)
                if m:
                    lang = m.group(1)
                elif line.startswith("  - ") and lang in ("C", LANG):
                    doc.setdefault("Keywords", []).append(unquote(line[4:]))
            elif section == "Icon":
                m = re.match(r"^  ([a-z]+):\s*(.*)$", line)
                if m:
                    sub = m.group(1)
                    if sub == "stock" and m.group(2):
                        doc["IconStock"] = unquote(m.group(2))
                elif sub == "cached":
                    m = re.match(r"^  - name:\s*(.+)$", line)
                    if m:
                        item = {"name": unquote(m.group(1))}
                        doc.setdefault("IconCached", []).append(item)
                    else:
                        m = re.match(r"^    width:\s*(\d+)", line)
                        if m and item is not None:
                            item["width"] = int(m.group(1))
            elif section == "Launchable":
                if line.startswith("  - ") and "desktop" not in doc:
                    doc["desktop"] = unquote(line[4:])
        if doc is not None and header is not None:
            yield header, doc


def debian_files():
    return sorted(glob.glob(os.path.join(SWCATALOG, "yaml", "*.yml.gz")))


def debian_apps():
    apps = []
    for path in debian_files():
        for header, doc in dep11_docs(path):
            if doc.get("Type") != "desktop-application" or not doc.get("Package") or not doc.get("ID"):
                continue
            name = pick(doc.get("Name", {}))
            if not name:
                continue
            origin = header.get("Origin", "")
            icon = ""
            for c in sorted(doc.get("IconCached", []), key=lambda c: abs(c.get("width", 64) - 64)):
                p = os.path.join(SWCATALOG, "icons", origin, "64x64", c["name"])
                if os.path.exists(p):
                    icon = p
                    break
            cid = doc["ID"]
            desktop = doc.get("desktop") or (cid if cid.endswith(".desktop") else "")
            apps.append({"id": "deb:" + cid, "source": "debian", "from": "Debian", "pkg": doc["Package"],
                         "desktop": desktop[:-8] if desktop.endswith(".desktop") else desktop,
                         "name": name, "summary": pick(doc.get("Summary", {})), "icon": icon,
                         "kw": " ".join(doc.get("Keywords", [])).lower()})
    return apps


def vendor_apps():
    apps = []
    for v in VENDOR:
        icon = os.path.normpath(os.path.join(STORE_ICONS, v["id"] + ".png"))
        apps.append({"id": "vendor:" + v["id"], "source": "vendor", "from": v["from"], "pkg": v["pkg"],
                     "desktop": v["desktop"], "name": v["name"], "summary": v.get(LANG) or v["en"],
                     "icon": icon if os.path.exists(icon) else "", "kw": v["kw"]})
    return apps


def installed_packages():
    code, so, _ = run("dpkg-query", "-W", "-f", "${Package} ${db:Status-Abbrev}\n")
    return {l.split()[0] for l in so.splitlines() if len(l.split()) > 1 and l.split()[1].startswith("ii")}


def protected_packages():
    """What the system itself needs (the JourneyOS packages' dependencies): never removed from the store."""
    names = {"journeyos-desktop", "journeyos-shell", "quickshell"}
    code, so, _ = run("dpkg-query", "-W", "-f", "${Depends},", "journeyos-desktop", "journeyos-shell")
    for dep in so.split(","):
        for alt in dep.split("|"):
            names.add(alt.strip().split(" ")[0].split(":")[0])
    return sorted(n for n in names if n)


# ------------------------------------------------------------------ Flathub (optional)

def flatpak_dir():
    if not os.path.isdir(FLATPAK_APPSTREAM):
        return None
    for a in os.listdir(FLATPAK_APPSTREAM):
        d = os.path.join(FLATPAK_APPSTREAM, a, "active")
        if os.path.isdir(d):
            return d
    return None


def has_remote():
    code, so, _ = run("flatpak", "remotes", "--user", "--columns=name")
    return code == 0 and "flathub" in so.split()


def flatpak_installed():
    if not shutil.which("flatpak"):
        return []
    code, so, _ = run("flatpak", "list", "--user", "--app", "--columns=application,name,version")
    apps = []
    if code == 0:
        for line in so.splitlines():
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0]:
                apps.append({"id": "flathub:" + parts[0], "name": parts[1],
                             "version": parts[2] if len(parts) > 2 else ""})
    return apps


def flatpak_updates():
    code, so, _ = run("flatpak", "remote-ls", "--user", "--updates", "--app", "--columns=application")
    return ["flathub:" + l.strip() for l in so.splitlines() if l.strip()] if code == 0 else []


def localized(el, tag):
    """The element's text in the shell language, else the untranslated one."""
    plain = None
    for c in el.findall(tag):
        lang = c.get("{http://www.w3.org/XML/1998/namespace}lang")
        if lang and lang.split("_")[0] == LANG:
            return (c.text or "").strip()
        if lang is None and plain is None:
            plain = (c.text or "").strip()
    return plain or ""


def flathub_apps():
    d = flatpak_dir()
    if not d:
        return []
    src = os.path.join(d, "appstream.xml.gz")
    if not os.path.exists(src):
        src = os.path.join(d, "appstream.xml")
    if not os.path.exists(src):
        return []
    icons = os.path.join(d, "icons", "128x128")
    opener = gzip.open if src.endswith(".gz") else open
    apps = []
    with opener(src, "rb") as fh:
        for _, el in ET.iterparse(fh, events=("end",)):
            if el.tag != "component":
                continue
            if el.get("type") not in ("desktop", "desktop-application"):
                el.clear()
                continue
            cid = (el.findtext("id") or "").strip()
            if cid.endswith(".desktop"):
                cid = cid[:-8]
            name = localized(el, "name")
            if cid and name:
                icon = os.path.join(icons, cid + ".png")
                kw = " ".join((k.text or "") for k in el.iter("keyword"))
                apps.append({"id": "flathub:" + cid, "source": "flathub", "from": "Flathub", "pkg": cid,
                             "desktop": cid, "name": name, "summary": localized(el, "summary"),
                             "icon": icon if os.path.exists(icon) else "", "kw": kw.lower()})
            el.clear()
    return apps


# ------------------------------------------------------------------ catalogue

def index():
    apps = vendor_apps() + debian_apps()
    if FLATHUB:
        apps += flathub_apps()
    apps.sort(key=lambda a: a["name"].lower())
    os.makedirs(CACHE, exist_ok=True)
    tmp = INDEX + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"flathub": FLATHUB, "lang": LANG, "apps": apps}, fh, ensure_ascii=False)
    os.replace(tmp, INDEX)
    out({"done": True, "ok": True, "count": len(apps)})
    return 0


def read_index():
    try:
        with open(INDEX, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def stale(idx):
    """The index is missing or older than what it is made from (or made for other settings)."""
    if not idx or idx.get("flathub") != FLATHUB or idx.get("lang") != LANG:
        return True
    made = os.path.getmtime(INDEX)
    sources = debian_files() + [os.path.abspath(__file__)]
    if FLATHUB and flatpak_dir():
        sources.append(flatpak_dir())
    return any(os.path.getmtime(s) > made for s in sources if os.path.exists(s))


def status():
    idx = read_index()
    pkgs = installed_packages()
    installed = []
    if idx:
        installed = [a["id"] for a in idx["apps"] if a["source"] in ("debian", "vendor") and a["pkg"] in pkgs]
    flatpaks = flatpak_installed()
    remote = FLATHUB and bool(shutil.which("flatpak")) and has_remote()
    out({"ready": bool(debian_files()), "stale": stale(idx), "installed": installed + [f["id"] for f in flatpaks],
         "flatpakApps": flatpaks, "protected": protected_packages(), "flatpak": bool(shutil.which("flatpak")),
         "flathub": remote, "updates": flatpak_updates() if remote else [], "nvidia": nvidia()})
    return 0


# ------------------------------------------------------------------ jobs

def stream(cmd, parse=None):
    """Runs a command, turning its output into progress lines. Returns (exit code, last line)."""
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    except OSError as e:
        return 127, str(e)
    last = ""
    for raw in p.stdout:
        for line in re.split(r"[\r\n]", raw):
            line = line.strip()
            if not line:
                continue
            got = parse(line) if parse else None
            if got is None:
                m = re.search(r"(\d+)%", line)
                got = (int(m.group(1)) if m else -1, line)
            if got is False:
                continue
            last = line
            out({"progress": got[0], "text": got[1][:120]})
    return p.wait(), last


def parse_pk(line):
    m = re.match(r"^Percentage:\s*(\d+)", line)
    if m:
        return int(m.group(1)), ""
    m = re.match(r"^Status:\s*(.+)", line)
    if m:
        return -1, m.group(1)
    return None


def parse_apt(line):
    # APT::Status-Fd: dlstatus:<n>:<percent>:<text> (download), pmstatus:<pkg>:<percent>:<text> (dpkg)
    m = re.match(r"^(dl|pm)status:[^:]*:([\d.]+):(.*)$", line)
    if m:
        pct = float(m.group(2))
        # Download first half, installation second half of the bar
        return int(pct / 2 + (50 if m.group(1) == "pm" else 0)), m.group(3)
    return False if line.startswith(("Reading", "Building", "Get:", "Hit:", "Selecting", "Preparing",
                                     "Unpacking", "Setting up", "Processing")) else None


def find(app_id):
    idx = read_index() or {"apps": []}
    a = next((a for a in idx["apps"] if a["id"] == app_id), None)
    if a:
        return a
    if app_id.startswith("flathub:"):
        return {"id": app_id, "source": "flathub", "pkg": app_id[8:]}
    return None


def action(kind, app_id):
    if kind == "update":
        code, last = stream(["flatpak", "update", "--user", "-y", "--noninteractive"])
        out({"done": True, "ok": code == 0, "error": "" if code == 0 else last})
        return code
    a = find(app_id)
    if not a:
        out({"done": True, "ok": False, "error": "unknown app: " + app_id})
        return 1
    pk = os.path.join(HERE, "pk.py")
    if a["source"] == "debian":
        if kind == "remove" and a["pkg"] in protected_packages():
            out({"done": True, "ok": False, "error": "part of the system"})
            return 1
        code, last = stream([pk, kind, a["pkg"]], parse_pk)
    elif a["source"] == "vendor":
        code, last = stream(["pkexec", VENDOR_HELPER, kind, app_id[7:]], parse_apt)
    else:
        if kind == "install":
            cmd = ["flatpak", "install", "--user", "-y", "--noninteractive", "flathub", a["pkg"]]
        else:
            cmd = ["flatpak", "uninstall", "--user", "-y", "--noninteractive", a["pkg"]]
        code, last = stream(cmd)
        if code == 0 and kind == "remove":
            # Runtimes nothing uses any more (a removed app's GNOME/KDE platform: hundreds of MB)
            run("flatpak", "uninstall", "--user", "--unused", "-y", "--noninteractive")
    # pkexec: 126 = the password window was closed
    error = "" if code == 0 else ("cancelled" if code == 126 else last)
    out({"done": True, "ok": code == 0, "error": error})
    return code


def refresh():
    out({"progress": -1, "text": "Debian"})
    code, last = stream(["pkcon", "refresh"], lambda l: False)
    if code != 0 and not debian_files():
        out({"done": True, "ok": False, "error": last or "could not download the catalogue"})
        return 1
    return index()


def setup():
    if not shutil.which("flatpak"):
        out({"done": True, "ok": False, "error": "flatpak is not installed"})
        return 1
    out({"progress": -1, "text": "Flathub"})
    code, _, err = run("flatpak", "remote-add", "--user", "--if-not-exists", "flathub",
                       "https://dl.flathub.org/repo/flathub.flatpakrepo")
    if code != 0:
        out({"done": True, "ok": False, "error": err.strip()[:200]})
        return 1
    code, last = stream(["flatpak", "update", "--user", "--appstream", "flathub"])
    if code != 0:
        out({"done": True, "ok": False, "error": last})
        return 1
    # Flatpak apps read the shell's GTK colours (colors.css) and KDE settings; Breeze for GTK apps
    run("flatpak", "override", "--user", "--filesystem=xdg-config/gtk-3.0:ro",
        "--filesystem=xdg-config/gtk-4.0:ro", "--filesystem=xdg-config/kdeglobals:ro")
    stream(["flatpak", "install", "--user", "-y", "--noninteractive", "flathub",
            "org.gtk.Gtk3theme.Breeze", "org.gtk.Gtk3theme.Breeze-Dark"])
    return index()


# ------------------------------------------------------------------ NVIDIA (shown in the store)

def nvidia():
    """An NVIDIA card and whether NVIDIA's driver is in use (or nouveau, or nothing). From /sys (lspci
    is only for the name: pciutils may be missing, and a missing command must not break the store)."""
    cards = []
    base = "/sys/bus/pci/devices"
    try:
        for dev in sorted(os.listdir(base)):
            d = os.path.join(base, dev)
            try:
                with open(os.path.join(d, "vendor")) as fh:
                    vendor = fh.read().strip()
                with open(os.path.join(d, "class")) as fh:
                    cls = fh.read().strip()
            except OSError:
                continue
            # 0x03xxxx = display controller (VGA, 3D, other)
            if vendor == "0x10de" and cls.startswith("0x03"):
                link = os.path.join(d, "driver")
                module = os.path.basename(os.readlink(link)) if os.path.islink(link) else ""
                cards.append((dev, module))
    except OSError:
        pass
    if not cards:
        return {"present": False}
    dev, module = cards[0]
    name = "NVIDIA"
    try:
        code, so, _ = run("lspci", "-s", dev)
        if code == 0 and so.strip():
            name = re.sub(r"\s*\(rev .*\)", "", so.strip().split(": ", 1)[-1])
            name = re.sub(r"^NVIDIA Corporation\s+", "NVIDIA ", name)
            # "NVIDIA GA104 [GeForce RTX 3070]" → "NVIDIA GeForce RTX 3070"
            m = re.search(r"\[([^\]]+)\]", name)
            if m:
                name = "NVIDIA " + m.group(1)
    except OSError:
        pass
    loaded = module == "nvidia" or os.path.exists("/proc/driver/nvidia/version")
    installed = os.path.exists("/usr/share/doc/nvidia-driver")
    return {"present": True, "driver": loaded, "installed": installed, "module": module, "name": name}


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "status":
        return status()
    if cmd == "index":
        return index()
    if cmd == "refresh":
        return refresh()
    if cmd == "setup":
        return setup()
    if cmd in ("install", "remove") and len(sys.argv) > 2:
        return action(cmd, sys.argv[2])
    if cmd == "update":
        return action("update", "")
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
