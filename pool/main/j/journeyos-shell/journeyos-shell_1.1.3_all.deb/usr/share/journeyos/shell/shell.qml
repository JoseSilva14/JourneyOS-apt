//@ pragma UseQApplication
import QtQuick
import Quickshell
import Quickshell.Io
import qs.bar
import qs.desktop
import qs.notifications
import qs.panel
import qs.launcher
import qs.dashboard
import qs.dock
import qs.notch
import qs.settings
import qs.menus
import qs.clipboard
import qs.auth
import qs.session
import qs.capture
import qs.welcome
import qs.calculator
import qs.services

// Root: bar, desktop, notification centre and quick panel per screen.
ShellRoot {
    // Loaded without errors: 10 s later, saves this configuration as the "last good" one
    // (scripts/run.sh starts with it if the next one fails to load)
    Timer {
        running: true
        interval: 10000
        onTriggered: Quickshell.execDetached([Quickshell.shellPath("scripts/guard.sh"), "save"])
    }

    // Singletons only start when used: those with shortcuts or IPC start right away
    readonly property var services: [Shortcuts, Wallpapers, Launcher, Dashboard, QuickPanel, KeepAwake, Widgets, Scheme, SettingsApp, LockTheme, Brightness, Countdown, Privacy, Events, BarMenu, Clipboard, Keyboard, Auth, Session, Capture, Focus, Agenda, Welcome, Tiling, Colors, Notes, Tasks, Reminders, Convert, Share, Webapps, Dev, ShellApps, Calculator, WifiConnect, BtAgent, Store, Snapshots, Firewall, Tr]
    Variants {
        model: Quickshell.screens

        Scope {
            id: perScreen
            required property ShellScreen modelData

            Desktop {
                screen: perScreen.modelData
            }

            Editor {
                screen: perScreen.modelData
            }

            Bar {
                screen: perScreen.modelData
            }

            Dock {
                screen: perScreen.modelData
            }

            Notch {
                screen: perScreen.modelData
                primary: perScreen.modelData === Quickshell.screens[0]
            }

            Center {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            Panel {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            MenuWindow {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            CaptureOverlay {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            ClipboardWindow {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            LauncherWindow {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }

            DashboardWindow {
                screen: perScreen.modelData
                modelScreen: perScreen.modelData
            }
        }
    }

    // Popups on the active window's screen
    Popups {
        screen: Windows.activeScreen
    }

    SettingsWindow {}

    AuthWindow {}
    PairWindow {}

    SessionWindow {}
    WelcomeWindow {}
    CalculatorWindow {}

    CapturePreview {}

    // qs -p <folder> ipc call shell reload
    IpcHandler {
        target: "shell"
        function reload(): void { Quickshell.reload(true); }
        function ping(): string { return "ok"; }
    }
}
