pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io

// SSH keys and hosts (scripts/ssh.py): Settings → Development creates a key (ed25519), adds it to
// GitHub (with the gh command, or by copying it and opening GitHub's page) and tests it; the launcher
// lists the hosts of ~/.ssh/config: "ssh name" opens a terminal connected there, "ssh" lists them all.
Singleton {
    id: root

    readonly property string script: Quickshell.shellPath("scripts/ssh.py")

    property var keys: []
    property var hosts: []
    property string gh: ""              // ok | login | missing
    property string configPath: Quickshell.env("HOME") + "/.ssh/config"
    property bool loaded: false
    property double scannedAt: 0
    property bool busy: false           // generating, adding to GitHub or testing
    property string githubUser: ""      // after a test that worked
    property string githubError: ""     // after one that did not

    readonly property var key: keys.length ? keys[0] : null

    function refresh(force) {
        if (scanner.running || (!force && Date.now() - scannedAt < 30000))
            return;
        scanner.running = true;
    }

    Process {
        id: scanner
        command: ["python3", root.script, "status"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const d = JSON.parse(text);
                    root.keys = d.keys;
                    root.hosts = d.hosts;
                    root.gh = d.gh;
                    root.configPath = d.config;
                } catch (e) {
                    console.warn("ssh.py: invalid reply");
                }
                root.loaded = true;
                root.scannedAt = Date.now();
            }
        }
    }

    Connections {
        target: Launcher
        function onOpenChanged() { if (Launcher.open) root.refresh(false); }
    }

    function generate() {
        busy = true;
        Run.cmd(["python3", script, "generate"], (code, out, err) => {
            root.busy = false;
            Events.push(code === 0 ? { icon: "key", title: Tr.t("SSH key created"), text: "~/.ssh/id_ed25519", duration: 2500 }
                : { icon: "error", title: Tr.t("Couldn't create the key"), text: err.trim(), duration: 4000 });
            root.refresh(true);
        });
    }

    function copyKey() {
        if (!key)
            return;
        Quickshell.execDetached(["wl-copy", "--", key.pub]);
        Events.push({ icon: "content_copy", title: Tr.t("Public key copied"), text: key.name + ".pub", duration: 1500 });
    }

    // With gh logged in, straight to the account; otherwise the key goes to the clipboard and GitHub's
    // "New SSH key" page opens, to paste it there
    function addToGithub() {
        if (!key)
            return;
        if (gh !== "ok") {
            copyKey();
            Apps.run(["xdg-open", "https://github.com/settings/ssh/new"]);
            Events.push({ icon: "content_paste", title: Tr.t("Paste the key on GitHub"), text: Tr.t("It's in the clipboard: paste it in \"Key\" and save."), duration: 5000 });
            return;
        }
        busy = true;
        Run.cmd(["python3", script, "github-add"], (code, out, err) => {
            root.busy = false;
            Events.push(code === 0 ? { icon: "check_circle", title: Tr.t("Key added to GitHub"), text: out.trim(), duration: 3000 }
                : { icon: "error", title: Tr.t("GitHub didn't take the key"), text: err.trim().split("\n").pop(), duration: 5000 });
            if (code === 0)
                root.testGithub();
        });
    }

    function testGithub() {
        busy = true;
        githubError = "";
        Run.cmd(["python3", script, "github-test"], (code, out, err) => {
            root.busy = false;
            root.githubUser = code === 0 ? out.trim() : "";
            const e = err.trim();
            root.githubError = code === 0 ? ""
                : /Permission denied \(publickey\)/.test(e) ? Tr.t("GitHub doesn't know this key yet: add it first (it can take a minute to work).")
                : /Could not resolve|timed out|Network is unreachable/i.test(e) ? Tr.t("Couldn't reach GitHub: check the internet connection.")
                : (e || Tr.t("It didn't work"));
        });
    }

    function editConfig() {
        Run.cmd(["python3", script, "edit-config"], (code, out) => {
            if (code === 0)
                Apps.run(["xdg-open", out.trim()]);
            root.refresh(true);
        });
    }

    // A terminal connected to the host; if ssh fails, the window stays to show why
    function connect(name) {
        Apps.run(["konsole", "-e", "sh", "-c", 'ssh "$0" || { printf "\\n[ssh: %s]  Enter closes" "$?"; read x; }', name]);
    }

    // --- Launcher ---
    function describe(h) {
        const where = (h.user ? h.user + "@" : "") + (h.hostname || h.name) + (h.port && h.port !== "22" ? ":" + h.port : "");
        return Tr.t("SSH · ") + where;
    }

    function item(h) {
        return { kind: "ssh", key: "ssh:" + h.name, title: "ssh " + h.name, subtitle: describe(h), glyph: "terminal",
            run: () => root.connect(h.name) };
    }

    // [{ item, s }]: "ssh" lists every host, "ssh name" the ones that match
    function results(raw) {
        const m = /^ssh(?:\s+(.*))?$/i.exec(raw.trim());
        if (!m || !hosts.length)
            return [];
        const q = Launcher.norm((m[1] ?? "").trim());
        return hosts.map((h, i) => {
            const n = Launcher.norm(h.name);
            const s = !q ? 900 - i : n === q ? 980 : n.startsWith(q) ? 900 : n.includes(q) ? 700
                : Launcher.norm(h.hostname).includes(q) ? 500 : 0;
            return { item: item(h), s };
        }).filter(x => x.s > 0);
    }

    IpcHandler {
        target: "ssh"
        function status(): string {
            return JSON.stringify({ keys: root.keys.map(k => k.name + " " + k.type + " " + k.fingerprint), hosts: root.hosts.map(h => h.name), gh: root.gh });
        }
        function refresh(): void { root.refresh(true); }
        function connect(name: string): void { root.connect(name); }
    }
}
